//
//  RNNativeTool.h
//  LearnStarterTests
//
//  Created by xukj on 2019/12/12.
//  Copyright © 2019 Facebook. All rights reserved.
//  需要native实现的rn项目代码
//

#import <Foundation/Foundation.h>
#if __has_include(<React/RCTBridgeModule.h>)
#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#else
#import "RCTBridgeModule.h"
#import "RCTUtils.h"
#endif

@interface RNNativeTool : NSObject<RCTBridgeModule>

@end
