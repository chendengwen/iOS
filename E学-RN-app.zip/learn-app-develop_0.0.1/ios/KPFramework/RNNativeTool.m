//
//  RNNativeTool.m
//  LearnStarterTests
//
//  Created by xukj on 2019/12/12.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "RNNativeTool.h"
#import <UIKit/UIKit.h>

@implementation RNNativeTool

@synthesize bridge = _bridge;

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(currentAppLogo:(RCTResponseSenderBlock)callback)
{
  UIApplication *application = [UIApplication sharedApplication];
  
  if (![application respondsToSelector:@selector(supportsAlternateIcons)]) {
    callback(@[RCTMakeError(@"对不起，您的系统版本不支持该功能！", nil, nil)]);
    return;
  }
  
  if (![application supportsAlternateIcons]) {
    callback(@[RCTMakeError(@"对不起，您的设备不支持该功能！", nil, nil), [NSNull null]]);
    return;
  }
  
  NSString *name = [application alternateIconName];
  callback(@[[NSNull null], name ? name : [NSNull null]]);
}

// 替换app图标，替换的图标需要在info.plist中配置
RCT_EXPORT_METHOD(useAppLogo:(NSString *)name callback:(RCTResponseSenderBlock)callback)
{
  UIApplication *application = [UIApplication sharedApplication];
  
  if (![application respondsToSelector:@selector(supportsAlternateIcons)]) {
    callback(@[RCTMakeError(@"对不起，您的系统版本不支持该功能！", nil, nil), [NSNull null]]);
    return;
  }
  
  if (![application supportsAlternateIcons]) {
    callback(@[RCTMakeError(@"对不起，您的设备不支持该功能！", nil, nil), [NSNull null]]);
    return;
  }
  
  NSMutableString *selectorString = [[NSMutableString alloc] initWithCapacity:40];
  [selectorString appendString:@"_setAlternate"];
  [selectorString appendString:@"IconName:"];
  [selectorString appendString:@"completionHandler:"];
  
  SEL selector = NSSelectorFromString(selectorString);
  IMP imp = [application methodForSelector:selector];
  void (*func)(id, SEL, id, id) = (void *)imp;
  if (func) {
    func(application, selector, name, ^(NSError * _Nullable error) {
      if (error) {
        callback(@[RCTMakeError([error localizedDescription], nil, nil), [NSNull null]]);
      }
      else {
        callback(@[[NSNull null], [NSNull null]]);
      }
    });
  }
}

- (dispatch_queue_t)methodQueue
{
  return dispatch_get_main_queue();
}

@end
