//
//  RNHardwareTool.m
//  LearnStarter
//
//  Created by xukj on 2018/8/17.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import "RNHardwareTool.h"
#import <KPFrameworkObjC/KPHardwareTool.h>
#import <KPFrameworkObjC/KPDeviceMacro.h>
#import <KPFrameworkObjC/KPGlobalMacro.h>

static const NSString * DEVICE_ISIPHONEX = @"isIphoneX";
static const NSString * DEVICE_INFORMATION = @"deviceInformation";
static const NSString * DEVICE_STATUSBARHEIGHT = @"statusBarHeight";
static const NSString * DEVICE_BOTTOMHEIGHT = @"bottomHeight";
static const NSString * DEVICE_BRAND = @"deviceBrand";
static const NSString * DEVICE_MODEL = @"deviceModel";
static const NSString * DEVICE_OS = @"deviceOS";
static const NSString * DEVICE_OS_VERSION = @"deviceOSVersion";
static const NSString * DEVICE_APP_VERSION = @"appVersion";
static const NSString * DEVICE_UUID = @"UUID";
static const NSString * DEVICE_APP_BUILDVERSION = @"appBuildVersion";

@implementation RNHardwareTool

RCT_EXPORT_MODULE();

- (NSDictionary<NSString *,id> *)constantsToExport
{
  return @{ DEVICE_ISIPHONEX: @(kpIsIPhoneXGen),
            DEVICE_INFORMATION: [KPHardwareTool humanReadableDeviceType],
            DEVICE_STATUSBARHEIGHT: @([KPHardwareTool statusBarHeight]),
            DEVICE_BOTTOMHEIGHT: @(kpIsIPhoneXGen ? 34 : 0),
            DEVICE_BRAND: @"apple",
            DEVICE_MODEL: kpNNilStringDefault([KPHardwareTool deviceType], @"apple device") ,
            DEVICE_OS: kpNNilStringDefault([KPHardwareTool systemName], @"iOS"),
            DEVICE_OS_VERSION: kpNNilStringDefault([KPHardwareTool systemVersion], @"unknown"),
            DEVICE_APP_VERSION: kpAppVer,
            DEVICE_UUID: [KPHardwareTool UUID],
            DEVICE_APP_BUILDVERSION: kpAppBuildVer
            };
}

+ (BOOL)requiresMainQueueSetup
{
  return YES;
}

@end
