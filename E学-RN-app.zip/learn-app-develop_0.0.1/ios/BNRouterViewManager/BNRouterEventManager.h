//
//  BNRouterEventManager.h
//  LearnStarter
//
//  Created by gary on 2020/5/27.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

FOUNDATION_EXPORT NSString * const RouterEmmit;

@interface BNRouterEventManager : RCTEventEmitter<RCTBridgeModule>

+ (void)emitEventWithName:(NSString *)name andInfo:(NSDictionary *)info;

@end

