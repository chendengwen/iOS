//
//  BNRouterViewManager.m
//  LearnStarter
//
//  Created by gary on 2020/5/26.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import "BNRouterViewManager.h"
#import <BNRouter/BNRouter-Swift.h>
#import "BNRouterEventManager.h"

@implementation BNRouterViewManager

+(void)initRouter:(NSString *__nonnull) appKey height:(CGFloat)height {
  CGRect rect = CGRectMake(0, 0, 0, height ? height: 60);
  [BNRouterController sharedInstanceWithAppid:appKey frame:rect clickCallback:^(NSDictionary<NSString *,id> * _Nonnull dic) {
    // 通知RN接收点击事件
    NSLog(@"dic === %@",dic);
    [BNRouterEventManager emitEventWithName:RouterEmmit andInfo:dic];
  }];
}

// 导出该原生View
RCT_EXPORT_MODULE(BNRouterView)

// 创建并返回该原生View
- (UIView *)view
{
  UIView *view = BNRouterController.routerController.view;
  return view;
}

#pragma mark - 导出方法给RN调用
RCT_EXPORT_METHOD(getInfoFromRN:(NSString *)user phone:(NSString *)phoneNo){
  //设置 用户ID 和 手机号码
  if (user != nil && phoneNo != nil) {
    BNRouterController.routerController.userID = user;
    BNRouterController.routerController.phoneNo = phoneNo;
  }
}

#pragma mark - 导出原生View的一些属性，供RN使用
//RCT_EXPORT_VIEW_PROPERTY(zoomEnabled, BOOL)

@end
