//
//  BNRouterViewManager.h
//  LearnStarter
//
//  Created by gary on 2020/5/26.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import <React/RCTViewManager.h>

@interface BNRouterViewManager : RCTViewManager

+(void)initRouter:(NSString *__nonnull) appKey height:(CGFloat)height;

@end

