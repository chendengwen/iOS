//
//  BNRouterEventManager.m
//  LearnStarter
//
//  Created by gary on 2020/5/27.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import "BNRouterEventManager.h"

//Notification
static NSString *Notification_Router = @"routerEmmit";

//EventName
NSString * const RouterEmmit = @"router";

@implementation BNRouterEventManager

RCT_EXPORT_MODULE();

- (NSArray<NSString *> *)supportedEvents{
  return @[
            RouterEmmit,
          ];
}

- (void)startObserving {
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emitEvent:) name:RouterEmmit object:nil];
}

- (void)stopObserving {
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)emitEvent:(NSNotification *)notification{
  [self sendEventWithName:RouterEmmit body:notification.userInfo];
}

+ (void)emitEventWithName:(NSString *)name andInfo:(NSDictionary *)info{
  [[NSNotificationCenter defaultCenter] postNotificationName:RouterEmmit object:self userInfo:info];
}



@end
