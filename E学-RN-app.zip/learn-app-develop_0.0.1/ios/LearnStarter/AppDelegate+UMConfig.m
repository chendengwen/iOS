//
//  AppDelegate+UMConfig.m
//  LearnStarter
//
//  Created by xukj on 2018/12/24.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "AppDelegate+UMConfig.h"
#import "RNUMConfigure.h"
#import <UMShare/UMShare.h>
#import <UMPush/UMessage.h>

NSString * const UMengAppKey = @"5ec63ff8167edd484000020b";
NSString * const WEIXINAPPKEY = @"wxfae0f6fbd89fa6ac";
NSString * const WEIXINAPPSECRET = @"ff9f0beb369431602d2f870d5346a92a";
NSString * const QQAPPKEY = @"101534291";
NSString * const QQAPPSECRET = nil;

@implementation AppDelegate (UMConfig)

- (void)umConfig:(NSDictionary *)launchOptions
{
  [UMConfigure setLogEnabled:YES];
  [RNUMConfigure initWithAppkey:UMengAppKey channel:@"app store"];
  [self setupSharePlatform];
  [self setupShareSetting];
  [self setupPushSetting:launchOptions];
}

#pragma mark - Share

- (void)setupSharePlatform
{
  [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:WEIXINAPPKEY appSecret:WEIXINAPPSECRET redirectURL:nil];
  [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatTimeLine appKey:WEIXINAPPKEY appSecret:WEIXINAPPSECRET redirectURL:nil];
  [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:QQAPPKEY  appSecret:QQAPPSECRET redirectURL:nil];
}

- (void)setupShareSetting
{
  [UMSocialGlobal shareInstance].isUsingHttpsWhenShareContent = NO;
}

- (BOOL)umApplication:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options
{
  //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响。
  BOOL result = [[UMSocialManager defaultManager]  handleOpenURL:url options:options];
  if (!result) {
    // 其他如支付等SDK的回调
  }
  return result;
}

- (BOOL)umApplication:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
  //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响
  BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url sourceApplication:sourceApplication annotation:annotation];
  if (!result) {
    // 其他如支付等SDK的回调
  }
  return result;
}
  
- (BOOL)umApplication:(UIApplication *)application handleOpenURL:(NSURL *)url
{
  BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
  if (!result) {
    // 其他如支付等SDK的回调
  }
  return result;
}

#pragma mark - push

- (void)setupPushSetting:(NSDictionary *)launchOptions
{
  //关闭友盟自带的弹出框
  [UMessage setAutoAlert:NO];
  // Push's basic setting
  UMessageRegisterEntity * entity = [[UMessageRegisterEntity alloc] init];
  //type是对推送的几个参数的选择，可以选择一个或者多个。默认是三个全部打开，即：声音，弹窗，角标
  entity.types = UMessageAuthorizationOptionSound | UMessageAuthorizationOptionBadge | UMessageAuthorizationOptionAlert;
  [UNUserNotificationCenter currentNotificationCenter].delegate = self;
  [UMessage registerForRemoteNotificationsWithLaunchOptions:launchOptions Entity:entity completionHandler:^(BOOL granted, NSError * _Nullable error) {
    if (granted) {
      NSLog(@"推送注册成功");
    }
    else {
      NSLog(@"推送注册失败");
    }
  }];
}

- (void)umApplication:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
  NSLog(@"token: %@",[[[[deviceToken description] stringByReplacingOccurrencesOfString: @"<" withString: @""]
                stringByReplacingOccurrencesOfString: @">" withString: @""]
               stringByReplacingOccurrencesOfString: @" " withString: @""]);
  [UMessage registerDeviceToken:deviceToken];
}

- (void)umApplication:(UIApplication *)app didReceiveRemoteNotification:(NSDictionary *)userInfo
{
  NSLog(@"接收到推送消息(iOS10以下)");
  [UMessage didReceiveRemoteNotification:userInfo];
}

- (void)umApplication:(UIApplication *)app didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
  NSLog(@"接收到推送消息(iOS10以下)");
  [UMessage didReceiveRemoteNotification:userInfo];
}

// iOS10新增：处理前台收到通知的代理方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
  NSLog(@"App在前台获取通知");
  NSDictionary * userInfo = notification.request.content.userInfo;
  if ([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
    // 应用处于前台时的远程推送接受
    // 必须加这句代码
    [UMessage didReceiveRemoteNotification:userInfo];
  }
  else {
    // 应用处于前台时的本地推送接受
    // donothing
  }
  completionHandler(UNNotificationPresentationOptionSound|UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionAlert);
}

// iOS10新增：处理后台点击通知的代理方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)())completionHandler
{
  NSLog(@"App在后台获取通知");
  NSDictionary * userInfo = response.notification.request.content.userInfo;
  if ([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
    // 应用处于后台时的远程推送接受
    // 必须加这句代码
    [UMessage didReceiveRemoteNotification:userInfo];
  }
  else {
    // 应用处于后台时的本地推送接受
    // donothing
  }
}
  
@end
