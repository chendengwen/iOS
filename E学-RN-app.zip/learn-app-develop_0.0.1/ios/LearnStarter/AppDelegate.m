/**
 * Copyright (c) 2015-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import "AppDelegate.h"

#import <React/RCTBridge.h>
#import <React/RCTBundleURLProvider.h>
#import <React/RCTRootView.h>
#import <React/RCTLinkingManager.h>
#import <UIKit/UIKit.h>
#import <react-native-splash-screen/RNSplashScreen.h>
#import <KPFrameworkObjC/UIScrollView+KPExtensions.h>
#import "AppDelegate+UMConfig.h"
#import "AppDelegate+Orientation.h"
#import "MainViewController.h"
#import "IQKeyboardManager.h"

#import "BNRouterViewManager.h"

@interface AppDelegate()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:launchOptions];
  RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge moduleName:@"LearnStarter" initialProperties:nil];
  rootView.backgroundColor = [[UIColor alloc] initWithRed:1.0f green:1.0f blue:1.0f alpha:1];
  self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
  MainViewController *rootViewController = [MainViewController new];
  rootViewController.view = rootView;
  self.window.rootViewController = rootViewController;
  [self.window makeKeyAndVisible];

//  [self keyboardSetting]; // 键盘
//  [RNSplashScreen show]; // 启动页
  
  [BNRouterViewManager initRouter:[[NSBundle mainBundle] bundleIdentifier] height:60];
  
  // 兼容iOS11
  // [UIScrollView kp_appearanceCompatible];
  // 友盟配置
  [self umConfig:launchOptions];

  return YES;
}

//- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
//{
//  return [self oApplication:application supportedInterfaceOrientationsForWindow:window];
//}
  
#if __IPHONE_OS_VERSION_MAX_ALLOWED > 100000
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options
{
  return [self umApplication:app openURL:url options:options] ? : [RCTLinkingManager application:app openURL:url options:options];
}
#endif

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
  return [self umApplication:app openURL:url sourceApplication:sourceApplication annotation:annotation] ? : [RCTLinkingManager application:app openURL:url sourceApplication:sourceApplication annotation:annotation];
}
  
- (BOOL)application:(UIApplication *)app handleOpenURL:(NSURL *)url
{
  return [self umApplication:app handleOpenURL:url] ? : [RCTLinkingManager application:app openURL:url options:nil];
}

#pragma delegate - RCTBridgeDelegate

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index" fallbackResource:nil];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

#pragma mark - 推送

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
  [self umApplication:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
  [self umApplication:application didReceiveRemoteNotification:userInfo];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
  [self umApplication:application didReceiveRemoteNotification:userInfo fetchCompletionHandler:completionHandler];
}

#pragma mark - 键盘
- (void)keyboardSetting
{
  IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
  manager.enable = YES; // 控制整个功能是否开启
  manager.shouldResignOnTouchOutside = YES; // 控制点击背景是否收起键盘
  manager.shouldToolbarUsesTextFieldTintColor = NO; // 控制键盘上的工具条文字亚瑟是否用户自定义
  manager.enableAutoToolbar = NO; // 控制是否显示键盘上的工具条
}

@end
