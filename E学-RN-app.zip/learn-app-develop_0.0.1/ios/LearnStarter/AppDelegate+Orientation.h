//
//  AppDelegate+Orientation.h
//  LearnStarter
//
//  Created by xukj on 2018/12/25.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Orientation)

- (UIInterfaceOrientationMask)oApplication:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window;

@end

NS_ASSUME_NONNULL_END
