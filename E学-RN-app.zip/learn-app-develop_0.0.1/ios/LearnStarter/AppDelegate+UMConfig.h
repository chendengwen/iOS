//
//  AppDelegate+UMConfig.h
//  LearnStarter
///Users/zk/Downloads/lec_adhoc-5.mobileprovision
//  Created by xukj on 2018/12/24.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "AppDelegate.h"
#import <UserNotifications/UNUserNotificationCenter.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const UMengAppKey;

@interface AppDelegate (UMConfig) <UNUserNotificationCenterDelegate>
  
// 配置基础数据
- (void)umConfig:(NSDictionary *)launchOptions;

- (BOOL)umApplication:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options;
- (BOOL)umApplication:(UIApplication *)app openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;
- (BOOL)umApplication:(UIApplication *)app handleOpenURL:(NSURL *)url;

- (void)umApplication:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
// iOS10以下版本必须集成该功能
- (void)umApplication:(UIApplication *)app didReceiveRemoteNotification:(NSDictionary *)userInfo;
- (void)umApplication:(UIApplication *)app didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;

@end

NS_ASSUME_NONNULL_END
