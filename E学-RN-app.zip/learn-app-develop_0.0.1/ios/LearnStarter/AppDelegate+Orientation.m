//
//  AppDelegate+Orientation.m
//  LearnStarter
//
//  Created by xukj on 2018/12/25.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "AppDelegate+Orientation.h"
#import "Orientation.h"

@implementation AppDelegate (Orientation)

- (UIInterfaceOrientationMask)oApplication:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
  return [Orientation getOrientation];
}
  
@end
