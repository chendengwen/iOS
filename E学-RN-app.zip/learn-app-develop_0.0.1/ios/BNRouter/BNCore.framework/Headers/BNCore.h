//
//  BNCore.h
//  BNCore
//
//  Created by gary on 2020/7/3.
//  Copyright © 2020 gary. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for BNCore.
FOUNDATION_EXPORT double BNCoreVersionNumber;

//! Project version string for BNCore.
FOUNDATION_EXPORT const unsigned char BNCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BNCore/PublicHeader.h>


