/**
 * @author xukj
 * @date 2019/11/11
 * @description index 程序入口
 */
import React from 'react';
import { AppRegistry, Alert, Platform } from 'react-native';
import Apps from './src/Apps';
import { ExceptionService } from './src/servie';
import RNRestart from 'react-native-restart';
import { setJSExceptionHandler, setNativeExceptionHandler } from 'react-native-exception-handler';

const reporter = (error, type) => {
    // Logic for reporting to devs
    // Example : Log issues.
    console.log(error); // sample
    let data = {
        content: error === undefined ? '未定义' : error.message + ' ' + error.stack,
        // phone: store.getState().identifyStore.data.phone,
        type: type,
    };
    ExceptionService.sendException(data);
};

let isFirst = true;
const errorHandler = (e, isFatal) => {
    if (typeof e == 'undefined') {
        return;
    }
    reporter(e, 'JS');
    const message = e.message ? e.message : '出错了~ 需要重启APP哦~';

    if (isFatal && isFirst) {
        Alert.alert(
            '哇哦~ 该功能暂时无法使用',
            message,
            [{ text: '确定', onPress: () => RNRestart.Restart() }],
            { cancelable: false }
        );
        isFirst = false;
    }
};
//
setJSExceptionHandler(errorHandler, true);
setNativeExceptionHandler(exceptionString => {
    // This is your custom global error handler
    // You do stuff likehit google analytics to track crashes.
    // or hit a custom api to inform the dev team.
    //NOTE: alert or showing any UI change via JS
    //WILL NOT WORK in case of NATIVE ERRORS.
    reporter(exceptionString, 'Native');
});
// TODO xukj
console.disableYellowBox = false; // 关闭全部黄色警告

const LearnStarter = () => <Apps />;
AppRegistry.registerComponent('LearnStarter', () => LearnStarter);
