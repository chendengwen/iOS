#iOS相关脚本  
  
---
  
提供脚本，用来修正编译、打包、运行时遇到的各种问题。
  
### 1. xcode10-run-simulator  
  
修复问题: `Could not find iPhone X simulator`
  
适配版本: `RN < 0.59.0` `xCode >= 10.0`
    
```shell
// 项目根目录运行
node script/xcode10-run-simulator.js
```

### 2. xcode10-third-party  
  
修复问题: 编译时报错 `double-conversion issues`
  
适配版本: `RN < 0.59.0` `xCode >= 10.0`
  
```shell
// 项目根目录执行
node script/xcode10-third-party.js
```

### 3. xcode11-compatible  
  
修复问题: 运行时报错 `unknown argument type`
  
适配版本: `RN < 0.61.0` `xCode >= 11.0`
    
```shell
// 项目根目录执行
node script/xcode11-run-compatible.js
```
