/**
 * @author xukj
 * @date 2019/10/28
 * @description 修复xcode11的兼容性问题
 */
const path = require('path');
const fs = require('fs');

const rnPath = 'node_modules/react-native';

function fixUnknownType() {
    console.info('\x1B[33m处理xcode11版本低版本运行报错 >>>unknown argument type<<<\x1B[0m');

    const FIXPATH = 'React/Base/RCTModuleMethod.mm';
    const MATCHCONTENT = 'RCTReadString(input, "__attribute__((unused))")';
    const FIXCONTENT = 'RCTReadString(input, "__attribute__((__unused__))") ||     //xcode11 fixed\r\n';

    // 需要修改的脚本地址
    const targetPath = path.resolve(process.cwd(), rnPath + '/' + FIXPATH);
    try {
        let content = fs.readFileSync(targetPath).toString();

        const fixIndex = content.indexOf(MATCHCONTENT);
        if (fixIndex < 0) throw new Error('无法找到匹配的文本');

        content = content.slice(0, fixIndex) + FIXCONTENT + content.slice(fixIndex);
        fs.writeFileSync(targetPath, content);
    } catch (error) {
        console.error(`\n\x1B[31m${error.message}\x1B[0m`);
        console.error('\x1B[31m修复失败，请使用手动实现\x1B[0m');
    }

    console.info('\n\x1B[32m执行完成\n\x1B[0m');
}

fixUnknownType();