/**
 * @author xukj
 * @date 2018/12/07
 * @description api 定义
 * modify by xukj - 1.24.0
 * 重构api结构
 */
import _ from 'lodash';
import Config from '../config/appinfo';
const apiDomain = Config.apiDomain();
const h5Domain = Config.h5Domain();
const resourceDomain = Config.resourceDomain();

export default {
    constConfig: {
        apiDomain: apiDomain,
        resourceDomain: resourceDomain,
    },
    common: {
        getCatgories: '/common/base-data/category/list/<%=type%>', // 获取分类 check
        postException: '/common/upload/exception', // 上报异常 check
        putFinishCourseware: '/common/business/resource/finish/courseware/<%=id%>', //上报积分 check
        putFinishCourse: '/common/business/resource/finish/course/<%=id%>', //check
        postUploadData: '/common/upload/data', // 上报数据 //check
        getPersonalAlias: '/common/personal-info/alias', //check
        postFeedbackInfo: '/common/business/feedback/info', //提交新的意见反馈
        postFeedbackList: '/common/business/feedback/list', // POST 分页查询自己的意见反馈
        getFeedbackInfo: '/common/business/feedback/info/<%=id%>', // GET 获取意见反馈详情
        getCatgoriesByPlatCode: '/common/base-data/category/list',   //根据板块获取分类
        getDeptCode: '/common/department/list', //获取板块列表
        // 专题
        postSubjectList:
            '/extends/v1/topic/getTopicList',
        // '/common/business/special-subject/list', // 专题列表
        //案例
        postCasesList: '/lecquery/bytypes',      //案例列表
        getSubjectInfo: '/extends/v1/topic/getTopicResource',
        //  '/common/business/special-subject/info/<%=id%>', // 专题详情
        // 频道列表
        getChannelList: '/common/base-data/channel/list', // 频道列表
        // 未完成项验证
        getResourceFinishStatus: '/common/business/resource/finish/status/<%=id%>',
        // 消息分组
        postMessageType: '/common/notices-center/class/list',
        // 消息列表
        postMessageList: '/common/notices-center/list/type',
        // 评论消息列表
        postMessageCommentList: '/common/notices-center/list/comment',
        // 点赞消息列表
        postMessageLikeList: '/common/notices-center/list/like',
        getLoginUserInfo: '/web/user/getUserInfo',//获取登录用户信息
    },
    signIn: {
        postSignInWithId: '/app/home-page/sign-in/id/<%=id%>', //签到id签到
        postSignInWithCode: '/app/home-page/sign-in/code/<%=code%>', // 通过签到码签到
        postTrainingSignUserList: '/common/business/training/sign-user/list',
        getTrainingSignUserDetail: '/common/business/training/<%=resourceId%>/<%=userId%>',
    },
    upgrade: {
        postVerify: '/app/common/version/verify', //check
        postInfo: '/app/common/version/info', //check
        // 广告
        getADList: '/app/common/launch/pictures',
    },
    noticePage: {
        postNoticePage: '/common/notices-center/list', //check
    },
    personal: {
        postPagePlayList: '/app/mine/e-class-record/list', //check
        deletePlayList: '/app/mine/common/user-study-record/<%=id%>', //check
        postTrainingPage: '/app/mine/training-record/list', //check
        postReadRecordPage: '/app/mine/read-record/list', //check
        postPeriod: '/app/mine/period/list', //check
        getPeriodDetail: '/app/mine/period/detail/<%=resourceId%>/<%=year%>', //check
        getMyCollection: '/extends/v1/favorites/queryFavoritesList',//收藏
    },
    myInfo: {
        getMyInfo: '/common/user/info', //check
    },
    questionnaire: {
        getQuestionnaire: '/common/business/questionnaire/info/<%=id%>', //check
        postAnswer: '/common/business/questionnaire/answer/<%=resourceId%>/<%=id%>', //check
        postQuestionnaireHistory: '/common/business/questionnaire/answer/list', //check
        postQChannelList: '/common/business/questionnaire/list',
    },
    assign: {
        postAssignmentPage: '/app/plan/list', //check
        deleteResource: '/app/plan/info/<%=id%>', //check
        getLatestPlan: '/app/plan/latest', //获取计划刷新信息
    },
    assignment: {
        postAssignment: '/common/business/resource/assignment', //check
    },
    cancel: {
        postEnrol: '/common/business/training/cancel/enrol/<%=id%>', //check
    },
    comment: {
        getComment: '/common/business/comment/info/<%=id%>', //check
        postComment: '/common/business/comment/info', //check
        getCommentApproveList: '/extends/v1/evaluate/queryApprovalByPage', //评论审批获取记录
        commitApproval: '/extends/v1/evaluate/commitApproval', //评论审批操作
    },
    course: {
        getCourseDetail: '/common/business/e-class/info/<%=id%>', //check
    },
    like: {
        getLike: '/common/business/like/list/<%=id%>', //check
        postToggle: '/common/business/like/toggle/<%=id%>', //check
    },
    news: {
        getTopNews: '/app/home-page/news/top-list', // 获取首页5条新闻  check
        postListApp: '/common/business/news/list', // 获取新闻列表  check
        getDetail: '/common/business/news/info/<%=id%>', // 获取新闻详情 check
    },
    reader: {
        postList: '/common/business/read/list', //check
        getDetail: '/common/business/read/info/<%=resourceId%>', //check
    },
    recommend: {
        getHomeResources: '/app/home-page/recommend/list/column', //check
        getColumnResources: '/app/home-page/recommend/list/column', // 分页查找某个栏目的推荐资源
    },
    recommendpersonal: {
        getRecommendUserList: '/common/business/personal-recommend/user/list', // 获取推荐的人员列表 check
        postSave: '/common/business/personal-recommend/info', // 推荐 check
        postMyRecommend: '/app/mine/personal-recommend/give/list', //check
        postReceivedRecommend: '/app/mine/personal-recommend/receive/list', //check
    },
    resource: {
        postCategory: '/app/category/list', //check
        postCourse: '/common/business/e-class/list', //check
        postTrainning: '/web/offline/course/training/list',
        // '/common/business/training/list', //check
        // postSearch: '/api/resource/search/<%=keyword%>',
        getImageIds: '/common/file/transfile/list/<%=fileid%>', // 获取图片ids check
        getPdfImageIds: '/common/file/transfiles/<%=fileid%>', // (案例管理)获取文件图片ids
    },
    file: {
        upload: '/api/resource/file/upload', // 上传文件
        image: '/api/resource/file/image/<%=id%>/<%=size%>', // 图片地址 check
        imagePdf: '/api/resource/file/image/pdf/<%=id%>', // pdf图片
        imagePdfMark: '/api/resource/file/watermark-image/<%=id%>/<%=uid%>', // 带水印的pdf图片
    },
    traClass: {
        getTraclassDetail: '/common/business/training/info/<%=id%>', //check
        getQuestionNoFinish: '/app/home-page/message/class/question/nofinish', //首页统计
        getQuestionList: '/common/business/training/questions/<%=resourceId%>', //首页统计
    },
    contribution: {
        getSum: '/app/mine/contribution/sum', //check
        postPageList: '/app/mine/contribution/list', //check
    },
    integral: {
        getList: '/app/mine/integral/list', //check
    },
    setting: {
        getBanners:
            '/extends/v1/banner/app/list/',
        // '/extends/v1/banner/setting/list/',
        // '/app/home-page/banner/list', //check  
        postSpecialSubjectList: '/common/business/special-subject/list', // 专题列表 check
        getSpecialSubjectInfo: '/common/business/special-subject/info/<%=id%>', // 专题内资源列表 check
    },
    testPaper: {
        postStart: '/common/business/test-paper/start/<%=resourceId%>/<%=id%>', //check
        postQuit: '/common/business/test-paper/quit/<%=paperId%>', //check
        getSummary: '/common/business/test-paper/paper-summary/<%=id%>', // 试卷详情接口
        getList: '/common/business/test-paper/list/<%=resourceId%>', //check
        postTestPaperList: '/common/business/test-paper/list', // 获取试卷列表
        getTestResultReview: '/common/business/test-paper/review/result/<%=id%>', // 回顾答案
        putManualSubmit: '/common/business/test-paper/submit/<%=resourceId%>/<%=id%>', // 提交答案
        putAutoSubmit: '/common/business/test-paper/autosubmit/<%=resourceId%>/<%=id%> ', // 自动提交答案
        addtoPlan: '/common/business/resource/assignment',    //加入计划
    },
    newnotices: {
        postNewNotices: '/common/notices-center/newest', //check
    },
    project: {
        getSurveyDetail: '/common/business/survey/info/<%=resourceId%>', //获取预开课详情 check
        putSurvey: '/common/business/survey/toggle/<%=resourceId%>', //check
    },
    ask: {
        postList: '/common/business/ask/list', //check
        postSave: '/common/business/ask/info', //check
        deleteAsk: '/common/business/ask/info/<%=askid%>', //check
        postReplyList: '/common/business/ask/reply/list/<%=askid%>', //check
        postReplySave: '/common/business/ask/reply/info/<%=askid%>', //check
        deleteReply: '/common/business/ask/reply/info/<%=askid%>/<%=id%>', //check
        getDetail: '/common/business/ask/info/<%=askid%>', //check
    },
    teacher: {
        getMasterTeacherDetail: '/common/business/class-adviser/info/<%=id%>', //check
        postTeacherDetails: '/common/business/teacher/authentication/list-info', //check
    },
    user: {
        putModifyUserInfo: '/common/user/info', //check
        postTestedList: '/app/mine/test/done/list', //check
        postCareerList: '/app/user/career/list', //check
        getCareerDetail: '/app/user/career/info/<%=id%>', //check
    },
    question: {
        getProjectDetail: '/common/business/questionnaire/answer/info/<%=id%>', //check
    },
    lecquery: {
        searchResourceAll: '/lecquery/all', // 所有项目搜索，一个项目一条数据不分页
        searchResourceList: '/lecquery/bytypes', // 分项搜索，分页
        getSearchKeywords: '/lecquery/allkeys', // 搜索历史keyword,
        deleteSearchKeywords: '/lecquery/allkeys', // 清空搜索历史keyword,
    },
    offline: {
        getSchedule: '/common/business/training/schedules/<%=classId%>',
    },
    h5: {
        getTimeMachine: '/time-machine/<%=user%>',
        getAppDiscover: '/app-discover',
    },
    approval: {
        postApprovalTodoList: '/app/approval-management/approval-task/todo-list',
        postApprovalDoneList: '/app/approval-management/approval-task/done-list',
        postApproval: '/app/approval-management/approval-task/approval',
        getApproveTrainingDetail: '/app/approval-management/approval-task/training/<%=resourceId%>', // 审批面授详情
        getApproveEClassDetail: '/app/approval-management/approval-task/course/<%=resourceId%>', // 审批E课详情
        getApproveNewsDetail: '/app/approval-management/approval-task/news/<%=resourceId%>', // 审批新闻详情
        getApproveQuestionDetail:
            '/app/approval-management/approval-task/questionnaire/<%=resourceId%>', // 审批问卷详情
        getApproveTestDetail: '/app/approval-management/approval-task/test/<%=resourceId%>', // 审批考试详情
        getApproveReaderDetail: '/app/approval-management/approval-task/reader/<%=resourceId%>', // 审批阅读详情
        getResourceVisibleList:
            '/app/approval-management/approval-task/resource-visibility/<%=resourceId%>', // 可见性
        getApprovalInfo:
            '/app/approval-management/approval-task/resource-task/track-list/<%=resourceId%>',
        publishEClass: '/workbench/my-publish/e-class/publish/<%=bussSerialNo%>', // 发布E课
        publishTrain: '/workbench/my-publish/training/publish/<%=bussSerialNo%>', // 发布培训
        publishExam: '/workbench/my-publish/exam/publish/<%=bussSerialNo%>', // 发布考试
    },
    account: {
        manageSendCode: '/manage/modifyPhone/sendCode', // 发送验证码 - manage
        manageModifyPhone: '/manage/modifyPhone', // 修改手机号 - manage
    },
    teacherCourse: {
        getColumns: '/app/common/column/list/10/99999',
        getTeachers: '/app/teacher/center/list',
        getTeacherDetail: '/common/business/teacher/authentication/list-info',
        getColumnDetail: '/common/business/teacher/authentication/course/info/<%=id%>',
    },

    cases: {
        giveLikeCease: '/extends/v1/caseEvalu/giveLikeCase',
        getAllSort: '/extends/v1/caseInfo/getCaseType',
        queryCaseList: '/extends/v1/caseInfo/queryCaseList',    //查询案例列表
    },
    teacherCenter: {
        getTeacherList: '/extends/v1/lecturerInfo/queryByPage?pageNo=<%=pageNo%>' + '&pageSize=<%=pageSize%>',
        getLecturerInfoByID: '/extends/v1/lecturerInfo/',
    },
    caseManagement: {
        getCaseApprovalList: '/extends/v1/caseFlow/queryDeptAuditList',// 获取(案例管理)审核列表
        getCaseDetailInfo: '/extends/v1/caseInfo/getCaseInfo',// 获取(案例管理)已审核详情页信息和基本信息
        updateCaseAudit: '/extends/v1/caseFlow/updateCaseAudit', //案例审批
        getCaseRecordsList: '/extends/v1/caseFlow/queryDeptAuditList', //获取(案例管理-个人提交记录)列表
        getImgByEmpId: '/extends/v1/user/photo/stream-public/getImgByEmpId', //根据empId获取头像
        getRecordsList: '/extends/v1/caseFlow/queryApplyList', //获取个人提交记录
        saveCaseInfo: '/extends/v1/caseFlow/saveCaseInfo', //保存案例草稿信息
        submitCaseInfo: '/extends/v1/caseFlow/commitCaseInfo', //提交案例信息
        getApproverByUserId: '/extends/v1/caseInfo/getApprovelByUser', //提交个人记录时，获取审批人信息
        updateApprover: '/extends/v1/caseFlow/updateApprover', //提交个人记录时，更新审批人信息
        queryFlowAuditByBidAndType: '/extends/flow/queryFlowAuditByBidAndType', //根据业务id和业务类型获取流程详细记录
        recallCase: '/extends/v1/caseInfo/recallCaseProcess', //撤回案例
        getUserListByName: '/extends/v1/caseInfo/getUserListByName', //根据姓名搜索用户 
        getUserRecordsList: '/extends/v1/workflow/get-my-commit', //获取个人提交记录(新)
        getUserApprovalList: '/extends/v1/workflow/get-my-approve', //获取我的审批列表（新）
        getFlowDetailList: '/extends/v1/workflow/get-approve-detail', //获取审批流详情（新）
        submitApproval: '/extends/v1/workflow/do-approve', //提交审批意见（新）
        getSensitiveWordsList: '/extends/v1/caseInfo/transfer/allList', //获取敏感词列表
        getRejectOptionsList: '/extends/v1/workflow/get-reject-options', //获取驳回选项列表
    },

    lecturerManagement: {
        getApprovalList: '/extends/v1/lecmanager/queryUserAuditList', //获取个人审核列表(不区分部门和宝能大学)
        getApprovalDetailInfo: '/extends/v1/lecmanager/queryLecturerById/<%=lecturerApplyId%>', //根据申请ID获取讲师管理记录详情
        updateLecturerAudit: '/extends/v1/lecmanager/updateUserAudit', //审批
        getRecordsList: '/extends/v1/lecmanager/queryApplyList', //获取个人提交记录
        submitLecturerInfo: '/extends/v1/lecmanager/lecturer', //普通用户申请-暂存、申请人提交讲师申请信息
        updateApplyStatus: '/extends/v1/lecmanager/lecturerApply/<%=lecturerApplyId%>/<%=type%>', //更新申请信息(删除或撤回)
    },
    honorRoll: {
        getHonorById: '/extends/v1/honorRoll/userId/<%=userId%>',         //根据用户ID获取个人荣誉
        getHotCourse: '/extends/v1/honorRoll/queryHotCourse',         // 获取前5的热门课程
        getEvaluateByUserId: '/extends/v1/honorRoll/getEvaluateByUserId/<%=userId%>',   //根据用户ID个人获取所发布资源的评论
        getLikeByUserId: '/extends/v1/honorRoll/getLikeByUserId/<%=userId%>',      //根据用户ID个人获取所发布资源的点赞
        queryByPageCourse: '/extends/v1/honorRoll/queryByPageCourse/', //课程记录分页查询
        queryByPageTrainingClass: '/extends/v1/honorRoll/queryByPageTrainingClass/', //授课记录分页查询
        userCertificate: '/extends/userCertificate/list',    //获取用户证书列表
        mySubscribe: '/web/plan/list',    // 我的订阅
        queryResourceById: '/extends/resource/queryResourceById',
    },
    eClassManagement: {//e课提交与审批
        getApprovalDetailInfo: '/workbench/common/e-class/<%=bussSerialNo%>', //根据业务ID获取详情
        getCurriculas: '/teacher/snapshot/project/<%=bussSerialNo%>/curriculas', //根据业务ID获取E课的在线课程
        getQuestionnaires: '/teacher/test/snapshot/resource/<%=bussSerialNo%>', //根据业务ID获取E课的试卷
    },

    favorite: {//收藏
        getFavoriteStatus: '/extends/v1/favorites/checkFavorites', //获取收藏状态
        toggleFavoriteStatus: '/extends/v1/favorites/favoritesResource', //收藏或取消收藏
    },

    //消息中心
    messageCenter: {
        getUnRead: '/extends/v1/message/getUnRead', //未读消息
        getMessageType: '/extends/v1/app/message/getMessageType',   //消息类型
        searchMessage: '/extends/v1/message/list',       //搜索
        getMessageByType: '/extends/v1/app/message/classifyList', //根据分类获取未读消息列表
        getUnReadMessage: '/extends/v1/app/message/list',  //15天内未读消息
        updateIsRead: '/extends/v1/app/message/updateAllIsRead',  // 15天内消息全部已读
        updateIsReadById: '/extends/v1/app/message/updateById',  //更新已读
        getMessageApprovalDetail: '/extends/v1/app/message/approval-details', // 查看系统消息审批详情
        saveOrUpdate: '/extends/v1/message/saveOrUpdate',        //保存/更新/发布消息
        recallMessage: '/extends/v1/message/recallMessageProcess', //撤回消息审批
        getMessageRecordsList: '/extends/v1/message/queryApplyList', //获取个人提交记录
        checkApproval:'/extends/v1/message/checkApproval',  //审批校验
    },
    // -------------------------------------------------
    // 以下待重构
    identify: {
        sendCode: '/identify/sendCode',
        userNameIdentify: '/identify/identifyByUserName',
        mobileIdentify: '/identify/identifyByMobile',
    },
    active: {
        domain: '/active/domain', //pwd,phone,code, userName选传
        outer: '/active/outer', //pwd,phone,code
        sendCode: '/active/sendCode', //phone
    },
    evalate: {
        getCaseEvalate: '/extends/v1/evaluate/queryByPage',  //获取评论记录
        setCaseLike: '/extends/v1/evaluate/like',  //点赞
        addCaseEvalate: '/extends/v1/evaluate',  //新增
        detetCaseEvalate: '/extends/v1/evaluate/',//删除评论
        deleteByCondition: '/extends/v1/evaluate/deleteByCondition',
    },
    getUrl: (api, data) => {
        let strCompiled = _.template(api);
        let fetchApi = apiDomain + strCompiled(data);
        return fetchApi;
    },

    getH5Url: (api, data) => {
        let strCompiled = _.template(api);
        let fetchApi = h5Domain + strCompiled(data);
        return fetchApi;
    },

    getResourceUrl: (api, data) => {
        let strCompiled = _.template(api);
        let fetchApi = resourceDomain + strCompiled(data);
        return fetchApi;
    },
};
