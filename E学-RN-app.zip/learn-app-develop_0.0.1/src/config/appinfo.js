export default {
    appInfo: {
        name: '在线365',
        descr: '在线365',
        site: '',
        version: '0.3.0',
        copyright: '',
        environment: 'dev'   //uat,prd,dev
    },
    authorInfo: {
        name: '',
        email: '',
        homepage: ''
    },

    resourceDomain() {
        switch (this.appInfo.environment) {
            case 'dev':
                return 'http://learnresource-stg.bngrp.com:31080/resource'; 
            case 'uat':
                return 'https://lec-study-uat.foresealife.com:446/resource';
            case 'prd':
                return 'http://learnresource.bngrp.com/resource';   
        }
    },

    apiDomain() {
        switch (this.appInfo.environment) {
            case 'dev':
                return 'http://learnauth-stg.bngrp.com:32080/auth';
            case 'uat':
                return 'https://lec-study-uat.foresealife.com/auth';
            case 'prd':
                return 'http://learnauth.bngrp.com/auth';  
        }
    },

    h5Domain() {
        switch (this.appInfo.environment) {
            case 'dev':
                return 'http://learnapp-stg.bngrp.com:30080/h5';  
            case 'uat':
                return 'https://lec-study-uat.foresealife.com:444/h5';
            case 'prd':
                return 'http://learnapp.bngrp.com/h5';
        };
    }
};