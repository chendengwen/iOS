/**
 * @author xukj
 * @date 2018/12/12
 * @description StudyTimeUtil 学时统计工具
 * 
 * modify by xukj - 1.27.0
 * 调整学时统计的数据库模型。需要支持批量查询多个用户的学时统计数据。数据模型如下:
{
    studyId: { // studyId = userId + snapshotId + contentId
        resourceId,
        snapshotId,
        contentId,
        userId,
        type,
        duration,
        timestamp,
    }
}
 * 
 * modify by xukj - 1.24.0
 * 使用方式: 在需要统计的地方使用
 * @see startTimer 开始统计学时
 * @see stopTimer 结束统计学时
 * 对外新增获取数据和清空数据功能，以后的学时统计数据操作入口只有该文件
 * 
 * Created by zk on 2018/4/21.
 * 学习情况收集，收集的数据如下:
 * resourceId - 学习资源ID
 * snapshotId - 学习课程ID
 * contentId - 课件Id
 * type - 课程类型
 * duration - 学习时长（秒）
 * timestamp - 学习记录时间
 */
import { StudyTimeStorageService } from '../servie';
import { IdentifyExtension } from '../redux';
import { SeaConstant } from '../asserts';
// 学时时长间隔 单位秒
const STUDY_DURATION = 5;

/**
 * 统计学时
 * @param {object} payload 学时数据
 */
async function collect(payload) {
    try {
        // 1.是否登录用户
        const sessionData = IdentifyExtension.getLoginSessionData();
        if (!sessionData) return;

        // 2.获取当前用户id
        let userId;
        const userInfo = IdentifyExtension.getLoginUserInfo();
        if (userInfo) userId = userInfo.id;

        // 3. 索引  studyId = userId + snapshotId + contentId
        const studyId = `${userId}+${payload.snapshotId}+${payload.contentId}`;
        
        // 4. 获取数据
        let studyDataValues = await StudyTimeStorageService.loadStudyTime()
            .then(data => {
                return Promise.resolve(data ? data : {});
            })
            .catch(() => {
                return Promise.resolve({});
            });
            
        // 5. 更新学时
        let duration = STUDY_DURATION;
        const timestamp = new Date().getTime();
        const studyData = studyDataValues[studyId];
        if (studyData) duration = studyData.duration + duration;
        studyDataValues[studyId] = { ...payload, userId, duration: duration, timestamp: timestamp };

        // 6.持久化学习数据
        console.log('学时统计', studyId);
        await StudyTimeStorageService.saveStudyTime(studyDataValues);
    } catch (error) {
        // do nothing
    }
}

// 计时器
let studyTimer;

/**
 * 开启timer，统计学时
 * @param {*} value 附件数据，结构参考头部说明
 */
function startTimer(value) {
    stopTimer();
    // 只保存需要统计的数据
    const payloadForCollector = payload(
        value.resourceId,
        value.type,
        value.snapshotId,
        value.contentId
    );
    if (!payloadForCollector) return;
    studyTimer = setInterval(() => {
        try {
            collect(payloadForCollector);
        } catch (error) {
            // do nothing
            console.log('error', error);
        }
    }, STUDY_DURATION * 1000);
}

/**
 * 关闭timer，统计学时
 */
function stopTimer() {
    studyTimer && clearInterval(studyTimer);
    studyTimer = null;
}

/**
 * 统计学时需要的payload，阅读类型不需要传递snapshotId和contentId
 * @param {string} resourceId
 * @param {number} type
 * @param {string} snapshotId
 * @param {string} contentId
 */
function payload(resourceId, type, snapshotId, contentId) {
    // resourceId 和 type 为必填项
    if (!resourceId || !type) {
        return null;
    }

    // 阅读特殊，3种id为同样的值
    if (type == SeaConstant.ResourceType.READER) {
        return {
            resourceId,
            snapshotId: resourceId,
            contentId: resourceId,
            type,
        };
    }

    // 其他需要传递3个值
    return {
        resourceId,
        snapshotId,
        contentId,
        type,
    };
}

/**
 * 所有统计的学习数据
 */
function getUserStudyTimes() {
    return StudyTimeStorageService.loadStudyTime().then(data => {
        return Promise.resolve(Object.values(data));
    });
}

/**
 * 清空学习数据
 */
function resetUserStudyTime() {
    return StudyTimeStorageService.resetStudyTime();
}

export default {
    startTimer,
    stopTimer,
    collect,
    payload,
    getUserStudyTimes,
    resetUserStudyTime,
};
