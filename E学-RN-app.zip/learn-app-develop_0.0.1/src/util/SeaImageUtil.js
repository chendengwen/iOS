/**
 * @author xukj
 * @date 2018/7/11
 * @description 图片相关的工具
 */
import fetchApi from '../config/api';
import { IdentifyExtension } from '../redux';

/**
 * @description 获取图片的URL，推荐使用这里的方法来获取。(不推荐直接使用config里面的方法)
 * @param {string} [imageId] - 图片id
 * @param {string} [imageUrl] - 图片默认url(如果没有设置图片id，则直接返回默认的url)
 * @param {string} [size] - 尺寸 l 大图, m 中图, s 小图
 * @return {string} 图片地址
 */
function getImageUri(imageId, imageUrl, size = 's') {
    if (!!imageId) {
        return fetchApi.getResourceUrl(fetchApi.file.image, { id: imageId, size: size });
    } else {
        return imageUrl;
    }
}

/**
 * pdf image 图片
 * @param {string} imageId 图片id
 * @param {bool} mark 是否添加水印
 */
function getPdfImageUri(imageId, mark) {
    if (imageId && mark) {
        // 有水印
        const userInfo = IdentifyExtension.getLoginUserInfo();
        return userInfo
            ? fetchApi.getResourceUrl(fetchApi.file.imagePdfMark, { id: imageId, uid: userInfo.id })
            : null;
    } else if (imageId) {
        // 无水印
        return fetchApi.getResourceUrl(fetchApi.file.imagePdf, { id: imageId });
    } else {
        // 无图片
        return null;
    }
}

/**
 * @description 获取图片source = { uri: xxxxx }
 * @see getImageUri
 * @param {string} [id]
 * @param {string} [url]
 * @param {string} [size]
 * @return {*} 图片的source
 */
function getImageSource(id, url, size = 'm') {
    const uri = getImageUri(id, url, size);
    if (!!uri) {
        return { uri: uri };
    } else {
        return undefined;
    }
}

/**
 * @description 获取头像Image需要展示的source
 * @see getImageUri
 * @param {string} [sex] - 性别，默认男,
 * @param {string} [id]
 * @param {string} [url]
 * @param {string} [size]
 * @return {*} 图片的source
 */
function getHeaderSource(sex, id, url, size = 's') {
    const uri = getImageUri(id, url, size);
    if (uri) {
        return { uri: uri };
    } else if (sex === '女') {
        return require('../asserts/images/myView/female.png');
    } else {
        return require('../asserts/images/myView/male.png');
    }
}

export default {
    getImageUri,
    getImageSource,
    getHeaderSource,
    getPdfImageUri,
};
