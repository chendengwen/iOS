/**
 * Created by zk on 2018/5/30.
 */
export default class BackgroundTimer {
    interval = null;
    settimer(callback){
         let startTime=new Date().getTime();
        this.interval=setInterval(()=>{
          let now=new Date().getTime();
          let diff=now-startTime;
          callback(Math.floor(diff/1000))
        },1000)
    }
    stoptimer(){
        this.interval&&clearInterval(this.interval)
    }
}
