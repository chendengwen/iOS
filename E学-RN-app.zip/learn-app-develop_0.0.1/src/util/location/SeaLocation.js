/**
 * @author xukj
 * @date 2019/12/19
 * @description SeaLocation 定位工具
 */
import Geolocation from '@react-native-community/geolocation';
import { wgs84togcj02, wgs84tobd09 } from './LocationUtil';

class LocationControl {
    // watch id
    watchId = null;
    // 当前定位信息
    currentLocation = null;

    constructor() {
        Geolocation.setRNConfiguration({ authorizationLevel: 'whenInUse' });
    }

    /**
     * 获取当前定位
     */
    getLocation(onSuccess, onError) {
        Geolocation.getCurrentPosition(
            result => onSuccess(this._locationInChina(result)),
            onError,
            { enableHighAccuracy: true }
        );
    }

    /**
     * 开始监控定位
     */
    startLocation(onSuccess, onError, distance = 0) {
        // this.stopLocation();
        this.watchId = Geolocation.watchPosition(
            result => onSuccess(this._locationInChina(result)),
            onError,
            {
                distanceFilter: distance,
                enableHighAccuracy: true,
            }
        );
    }

    /**
     * 关闭监控定位
     */
    stopLocation() {
        this.watchId && Geolocation.clearWatch(this.watchId);
        Geolocation.stopObserving();
    }

    // gps坐标需要转换
    _locationInChina = result => {
        const { coords, ...rest } = result;
        // gps 转 高德坐标系
        const gcj02 = wgs84togcj02(coords.longitude, coords.latitude);
        let newCoords = _.cloneDeep(coords);
        newCoords.longitude = gcj02.longitude;
        newCoords.latitude = gcj02.latitude;
        // 保存当前信息
        this.currentLocation = { coords: newCoords, ...rest };
        return _.cloneDeep(this.currentLocation);
    };
}

export default new LocationControl();
