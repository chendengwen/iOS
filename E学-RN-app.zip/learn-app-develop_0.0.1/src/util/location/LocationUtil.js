/* eslint-disable */
/**
 * @author xukj
 * @date 2019/05/23
 * @description GPS坐标系工具 国内的gps坐标系需要做偏移
 * BD-09：百度坐标系(百度地图)
 * GCJ-02：火星坐标系（谷歌中国地图、高德地图）
 * WGS84：地球坐标系（国际通用坐标系，谷歌地图）
 */

const x_PI = (3.14159265358979324 * 3000.0) / 180.0;
const PI = 3.1415926535897932384626;
const a = 6378245.0;
const ee = 0.00669342162296594323;

// 百度坐标系 -> 火星坐标系
export function bd09togcj02(bd_lon, bd_lat) {
    const x = bd_lon - 0.0065;
    const y = bd_lat - 0.006;
    const z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_PI);
    const theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_PI);

    const gcj_lon = z * Math.cos(theta);
    const gcj_lat = z * Math.sin(theta);
    return {
        longitude: gcj_lon,
        latitude: gcj_lat,
    };
}

// 百度坐标系 -> wgs84
export function bd09towgs84(bd_lon, bd_lat) {
    const location = bd09togcj02(bd_lon, bd_lat);
    return gcj02towgs84(location.longitude, location.latitude);
}

// 火星坐标系 -> wgs84
export function gcj02towgs84(gcj_lon, gcj_lat) {
    if (outofChina(gcj_lon, gcj_lat)) {
        //不在国内，不进行纠偏
        return {
            longitude: gcj_lon,
            latitude: gcj_lat,
        };
    } else {
        let dlon = transformlon(gcj_lon - 105.0, gcj_lat - 35.0);
        let dlat = transformlat(gcj_lon - 105.0, gcj_lat - 35.0);
        let radlat = (gcj_lat / 180.0) * PI;
        let magic = Math.sin(radlat);
        magic = 1 - ee * magic * magic;
        let sqrtmagic = Math.sqrt(magic);
        dlon = (dlon * 180.0) / ((a / sqrtmagic) * Math.cos(radlat) * PI);
        dlat = (dlat * 180.0) / (((a * (1 - ee)) / (magic * sqrtmagic)) * PI);
        const mglon = gcj_lon + dlon;
        const mglat = gcj_lat + dlat;
        const wgs_lon = gcj_lon * 2 - mglon;
        const wgs_lat = gcj_lat * 2 - mglat;
        //wgs84坐标系值
        return {
            longitude: wgs_lon,
            latitude: wgs_lat,
        };
    }
}

// 火星坐标系 -> 百度坐标系
export function gcj02tobd09(gcj_lon, gcj_lat) {
    const z = Math.sqrt(gcj_lon * gcj_lon + gcj_lat * gcj_lat) + 0.00002 * Math.sin(gcj_lat * x_PI);
    const theta = Math.atan2(gcj_lat, gcj_lon) + 0.000003 * Math.cos(gcj_lon * x_PI);
    const bd_lon = z * Math.cos(theta) + 0.0065;
    const bd_lat = z * Math.sin(theta) + 0.006;
    return {
        longitude: bd_lon,
        latitude: bd_lat,
    };
}

// wgs84 -> 火星坐标系
export function wgs84togcj02(wgs_lon, wgs_lat) {
    if (outofChina(wgs_lon, wgs_lat)) {
        //不在国内，不进行纠偏
        return {
            longitude: wgs_lon,
            latitude: wgs_lat,
        };
    } else {
        let dwgs_lon = transformlon(wgs_lon - 105.0, wgs_lat - 35.0);
        let dwgs_lat = transformlat(wgs_lon - 105.0, wgs_lat - 35.0);
        let radwgs_lat = (wgs_lat / 180.0) * PI;
        let magic = Math.sin(radwgs_lat);
        magic = 1 - ee * magic * magic;
        const sqrtmagic = Math.sqrt(magic);
        dwgs_lon = (dwgs_lon * 180.0) / ((a / sqrtmagic) * Math.cos(radwgs_lat) * PI);
        dwgs_lat = (dwgs_lat * 180.0) / (((a * (1 - ee)) / (magic * sqrtmagic)) * PI);
        const gcj_lon = wgs_lon + dwgs_lon;
        const gcj_lat = wgs_lat + dwgs_lat;
        return {
            longitude: gcj_lon,
            latitude: gcj_lat,
        };
    }
}

// 火星坐标系 -> 百度坐标系
export function wgs84tobd09(wgs_lon, wgs_lat) {
    const location = wgs84togcj02(wgs_lon, wgs_lat);
    return gcj02tobd09(location.longitude, location.latitude);
}

/**
 * 计算经纬度距离(误差2米) 单位: 米
 * 注: 经纬度值请保证在同一坐标系下
 */
const DEF_PI = 3.14159265359; // PI
const DEF_2PI = 6.28318530712; // 2*PI
const DEF_PI180 = 0.01745329252; // PI/180.0
const DEF_R = 6370693.5; // radius of earth
export function distance(lon1, lat1, lon2, lat2) {
    // 角度转换为弧度
    const ew1 = lon1 * DEF_PI180;
    const ns1 = lat1 * DEF_PI180;
    const ew2 = lon2 * DEF_PI180;
    const ns2 = lat2 * DEF_PI180;
    let dew;
    // 经度差
    dew = ew1 - ew2;
    // 若跨东经和西经180 度，进行调整
    if (dew > DEF_PI) dew = DEF_2PI - dew;
    else if (dew < -DEF_PI) dew = DEF_2PI + dew;
    const dx = DEF_R * Math.cos(ns1) * dew; // 东西方向长度(在纬度圈上的投影长度)
    const dy = DEF_R * (ns1 - ns2); // 南北方向长度(在经度圈上的投影长度)
    // 勾股定理求斜边长
    const distance = Math.sqrt(dx * dx + dy * dy).toFixed(0);
    return Number(distance);
}

//判断是否在国内，不在国内则不做偏移
export function outofChina(lon, lat) {
    return lon < 72.004 || lon > 137.8347 || lat < 0.8293 || lat > 55.8271 || false;
}

// 经度转换
function transformlon(lon, lat) {
    var ret =
        300.0 +
        lon +
        2.0 * lat +
        0.1 * lon * lon +
        0.1 * lon * lat +
        0.1 * Math.sqrt(Math.abs(lon));
    ret += ((20.0 * Math.sin(6.0 * lon * PI) + 20.0 * Math.sin(2.0 * lon * PI)) * 2.0) / 3.0;
    ret += ((20.0 * Math.sin(lon * PI) + 40.0 * Math.sin((lon / 3.0) * PI)) * 2.0) / 3.0;
    ret +=
        ((150.0 * Math.sin((lon / 12.0) * PI) + 300.0 * Math.sin((lon / 30.0) * PI)) * 2.0) / 3.0;
    return ret;
}

// 纬度转换
function transformlat(lon, lat) {
    var ret =
        -100.0 +
        2.0 * lon +
        3.0 * lat +
        0.2 * lat * lat +
        0.1 * lon * lat +
        0.2 * Math.sqrt(Math.abs(lon));
    ret += ((20.0 * Math.sin(6.0 * lon * PI) + 20.0 * Math.sin(2.0 * lon * PI)) * 2.0) / 3.0;
    ret += ((20.0 * Math.sin(lat * PI) + 40.0 * Math.sin((lat / 3.0) * PI)) * 2.0) / 3.0;
    ret += ((160.0 * Math.sin((lat / 12.0) * PI) + 320 * Math.sin((lat * PI) / 30.0)) * 2.0) / 3.0;
    return ret;
}
