/**
 * @description 构造函数
 * @param {string} [message]
 * @param {number} [code]
 * @param {any} [data]
 * @return {FSLError}
 */
function FSLError(message, code = -10000, data) {
    this.message = message;
    this.code = code;
    this.data = data;
}

FSLError.prototype = new Error();

export default FSLError;
