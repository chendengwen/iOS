import { IdentifyExtension } from '../redux';

/**
 * 是否是超管
 */
export function isSuperAdmin() {
    if (
        IdentifyExtension.getLoginUserInfo() != null &&
        IdentifyExtension.getLoginUserInfo().userRoles
    ) {
        let roles = IdentifyExtension.getLoginUserInfo().userRoles;
        for (let i = 0; i < roles.length; i++) {
            if (roles[i].roleCode == 'R_SYSTEM_ADMINISTRATOR') {
                return true;
            }
        }
    }
    return false;
}

/**
 * 是否是板块管理员
 */
export function isPlateAdmin() {
    if (
        IdentifyExtension.getLoginUserInfo() != null &&
        IdentifyExtension.getLoginUserInfo().userRoles
    ) {
        let roles = IdentifyExtension.getLoginUserInfo().userRoles;
        for (let i = 0; i < roles.length; i++) {
            if (roles[i].roleCode == 'R_PLATE_ADMIN') {
                return true;
            }
        }
    }
    return false;
}

/**
 * 获取超管选择的板块代码
 */
export function getChosenPlateCode() {
    if (IdentifyExtension.getLoginUserInfo() != null) {
        return IdentifyExtension.getLoginUserInfo().chosenPlateCode;
    }
    return '';
}

/**
 * 获取登录用户职级
 */
export function getUserStaffLevel() {
    if (IdentifyExtension.getLoginUserInfo() != null) {
        return IdentifyExtension.getLoginUserInfo().staffLevel;
    }
    return '';
}

/**
 * 职级是否是A或S
 * @param {string} staffLevel
 */
export function isStaffLevelAorS(staffLevel) {
    if (
        !_.isEmpty(staffLevel) &&
        (staffLevel === 'A' || staffLevel === 'S' || staffLevel === 'a' || staffLevel === 's')
    ) {
        return true;
    }else{
        return false;
    }
}

export default {
    isSuperAdmin,
    isPlateAdmin,
    getChosenPlateCode,
    getUserStaffLevel,
    isStaffLevelAorS,
};
