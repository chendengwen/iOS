/**
 * @author xukj
 * @date 2018/8/30
 * @description PV统计相关工具。PV统计保存在本地，如果清空缓存则需要重新统计。保存方式为key{string} - value{int}
 * 目前支持通过router来统计
 *
 * 使用方式：
 * 1.统计打开新页面，例 Actions.show('personalInfo') 或 Actions.show('personalInfo', { userId: xxxx });
 * 2.支持其他统计方式 SeaPVUtil.pv(); 或 SeaPVUtil.pv('custom', xxxx);
 *
 * add by xukj - 1.24.0
 * 对外新增获取数据和清空数据功能，以后的PV数据操作入口只有该文件
 */
import { DeviceEventEmitter, InteractionManager } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { PVStorageService } from '../servie';
import { SeaConstant } from '../asserts';
import SeaAnalyticsUtil from './umeng/SeaAnalyticsUtil';

/*
 * @private
 * @description 日志
 */
const logger = value => {
    // console.log('pv', value);
};

/**
 * @private
 * @description 默认的pv统计数量 +1，统计key为PV_PAGE_OPEN_KEY
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function _pvPageOpen(onSuccess, onFail) {
    (async () => {
        let value = 1;

        // 获取数量
        try {
            value = await PVStorageService.loadPVStorage();
            value += 1;
        } catch (error) {
            // do noting
        }

        // 更新数量
        try {
            await PVStorageService.savePVStorage(value);
            if (onSuccess) onSuccess(value);
            logger({ key: 'default', value: value });
        } catch (error) {
            if (onFail) onFail(error);
            logger({ key: 'default', error: error });
        }
    })();
}

/**
 * @private
 * @description pv自定义统计。统计方式为 key-value
 * @param {string} [key]
 * @param {string} [value]
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function _pvOther(key, value, onSuccess, onFail) {
    (async () => {
        try {
            const result = await PVStorageService.savePVStorage(value, key);
            if (onSuccess) onSuccess(result);
            logger({ key: key, value: value });
        } catch (error) {
            if (onFail) onFail(error);
            logger({ key: key, error: error });
        }
    })();
}

/**
 * @description 统计pv，统计方式为 key - value，如果key === undefined 则默认统计页面打开数量
 * @param {string} [key]
 * @param {*} [value]
 * @return
 */
function pv(key, value) {
    if (key) {
        _pvOther(key, value);
    } else {
        _pvPageOpen();
    }
}

/**
 * @description router页面跳转
 * 1. 其中插入pv统计数量
 * 2. 如果是返回home，则触发home激活通知
 * @param {string} [sceneKey] 需要打开的页面key
 * @param {*} [props] 页面需要传递的props
 * @param {boolean} [immediate] 是否立即调用，不等待界面动画
 */
Actions.__proto__.show = function(sceneKey, props, immediate = false) {
    // 记录pv
    pv();
    // 友盟打点
    SeaAnalyticsUtil.saveMobEvent(sceneKey);
    // ...

    if (immediate) {
        this[sceneKey](props);
    } else {
        InteractionManager.runAfterInteractions(() => {
            this[sceneKey](props);
        });
    }
};

/**
 * @private
 * @description 替换Actions里面的 focus 方法
 * 在该方法前插入监控home界面激活的逻辑
 * @deprecated react-native-router-flux 已升级到 4.x，该方式已无效
 */
// const callFocus = Actions.__proto__.focus;
// function onFoucs(props) {
//     const scene = props && props.scene ? props.scene : {};
//     if (scene.sceneKey == 'tabbar' && scene.index == 0) {
//         console.log('focus', 'home激活');
//         DeviceEventEmitter.emit(SeaConstant.SeaGlobalEventType.HOME_APPEAR);
//     }
//     // 调用原来的方法
//     callFocus.call(Actions, props);
// }
// Actions.focus = onFoucs;

/**
 * 获取pv数据
 * @param {string} key pvKey 默认为页面打开的统计
 */
function getPVData(key) {
    return PVStorageService.loadPVStorage(key);
}

/**
 * 重置pv数据
 * @param {string} key pvKey 默认为页面打开的统计
 */
function resetPVData(key) {
    return PVStorageService.resetPVStorage(key);
}

export default {
    pv,
    getPVData,
    resetPVData,
};
