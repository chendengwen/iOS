/**
 * @author xukj
 * @date 2019/12/12
 * @description SeaNative 原生方法桥接
 */
import { NativeModules, Platform } from 'react-native';

const SeaNativeTool = NativeModules.RNNativeTool;

function useAppLogo(name, callback = error => {}) {
    SeaNativeTool.useAppLogo(name, callback);
}

function currentAppLogo(callback = (error, name) => {}) {
    SeaNativeTool.currentAppLogo(callback);
}

export default {
    useAppLogo,
    currentAppLogo,
};
