/**
 * @author xukj
 * @date 2019/03/21
 * @description function相关工具
 */

/**
 * 防止短时间多次触发
 * @param {function} func 方法
 * @param {number} interval 时间控制
 */
let isCalled = false;
let timer;
function debounce(func, interval = 1000) {
    return function() {
        if (!isCalled) {
            isCalled = true;
            timer && clearTimeout(timer);
            timer = setTimeout(() => (isCalled = false), interval);
            return func.apply(this, arguments);
        }
    };
}

export default {
    debounce,
};
