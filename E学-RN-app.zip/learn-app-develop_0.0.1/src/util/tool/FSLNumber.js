/**
 * @author xukj
 * @date 2018/9/18
 * @description number扩展方法
 */

/**
 * @description 秒转换为小时
 * @param {number} [seconds] (单位: 秒)
 * @return {number}
 */
function timeHours(seconds = 0) {
    return seconds / 60.0 / 60.0;
}

/**
 * @description 秒转换为分
 * @param {number} [seconds] (单位: 秒)
 * @return {number}
 */
function timeMinutes(seconds = 0) {
    return seconds / 60.0;
}

/**
 * @description 秒转化为可读的时间 00:00:00格式
 * @param {number} time 秒
 * @param {string} format h/m/s
 */
function timeString(seconds, format = 'h') {
    let hour = parseInt(seconds / 60 / 60);
    let minute = parseInt((seconds / 60) % 60);
    let second = parseInt(seconds % 60);
    hour = hour < 10 ? '0' + hour : hour;
    minute = minute < 10 ? '0' + minute : minute;
    second = second < 10 ? '0' + second : second;
    let text = '';
    switch (format) {
        case 'h':
            text = `${hour}:${minute}:${second}`;
            break;
        case 'm':
            text = `${minute}:${second}`;
            break;
        case 's':
            text = `${second}`;
            break;
        default:
            text = `${hour}:${minute}:${second}`;
    }
    return text;
}

export default {
    timeHours,
    timeMinutes,
    timeString,
};
