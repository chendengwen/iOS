/**
 * @author xukj
 * @date 2019/03/21
 * @description 工具包，使用方式类似lodash
 */
import FSLNumber from './FSLNumber';
import FSLFunction from './FSLFunction';

export default {
    ...FSLNumber,
    ...FSLFunction,
};
