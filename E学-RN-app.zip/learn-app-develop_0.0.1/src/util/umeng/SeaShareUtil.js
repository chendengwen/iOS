/**
 * @author xukj
 * @date 2018/12/25
 * @description SeaShareUtil 友盟分享桥接代码
 */
import { NativeModules } from 'react-native';

const ShareUtil = NativeModules.UMShareModule;

/**
 * @description 资源类型
 * @type {{CANCEL: number, SUCCESS: number}}
 */
const ShareCode = {
    CANCEL: -1,
    SUCCESS: 200,
};

/**
 * @description 资源类型
 * @type {{QQ: number, Sina: number, WechatSessoin: number, WeChatTimeLine: number, QQZone: number, EMail: number, Sms: number}}
 */
const SharePlatform = {
    QQ: 0,
    Sina: 1,
    WechatSessoin: 2,
    WeChatTimeLine: 3, 
    QQZone: 4,
    EMail: 5,
    Sms: 6,
};

export {
    ShareUtil,
    ShareCode,
    SharePlatform,
};