/**
 * @author xukj
 * @date 2019/06/05
 * @description SeaPushUtil 友盟推送桥接代码
 */
import { NativeModules } from 'react-native';

const AnalyticsUtil = NativeModules.UMAnalyticsModule;

/**
 * 友盟打点
 * key: 事件key, eventId: 友盟自定义事件id
 */
const MobEventMap = {
    // 频道列表打点
    courseChannel: 'courseChannel',
    trainingChannel: 'trainingChannel',
    bookChannel: 'bookChannel',
    testChannel: 'testChannel',
    qbarChannel: 'qbarChannel',
    qChannelList: 'qChannelList',
    subjectChannel: 'subjectChannel',
    // 频道各个详情页打点
    courseDetail: 'courseDetail',
    trainningDetail: 'trainningDetail',
    bookDetail: 'bookDetail',
    testpaperDesc: 'testpaperDesc',
    qaQuestionDetail: 'qaQuestionDetail',
    QProjectDesc: 'QProjectDesc',
    subjectDetail: 'subjectDetail',
};

/**
 * 友盟打点
 * @param {string} key 打点的key
 * @param {string} label 扩展
 */
function saveMobEvent(key, label) {
    // 开发模式不统计
    if (__DEV__) return;

    const eventId = MobEventMap[key];
    if (eventId && label) {
        AnalyticsUtil.onEventWithLabel(key, label);
    } else if (eventId) {
        AnalyticsUtil.onEvent(key);
    }
}

export default { MobEventMap, saveMobEvent };
