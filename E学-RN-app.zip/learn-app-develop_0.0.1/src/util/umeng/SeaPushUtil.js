/**
 * @author xukj
 * @date 2019/06/05
 * @description SeaPushUtil 友盟推送桥接代码
 */
import { NativeModules } from 'react-native';

const PushUtil = NativeModules.UMPushModule;

export { PushUtil };
