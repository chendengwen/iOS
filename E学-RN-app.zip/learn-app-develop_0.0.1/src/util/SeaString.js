import 'string.fromcodepoint';
import moment from 'moment';

/**
 * @description 将字符串转化成指定长度 + ...
 * @param {string} [s] 字符串
 * @param {number} [length] 长度限制
 * @return {string} 结果字符串
 */
export function subString(s, length) {
    if (s.length > length) {
        return s.substr(0, length) + '...';
    } else return s;
}

/**
 * @description 给html添加默认样式
 * @param {string} [html] html文本
 * @return {string} 加入样式后的html文本
 */
export function appendHtmlCommonHeader(html) {
    const head =
        '<head> <meta name="viewport" content="width=device-width"> <style type="text/css">img {max-width: 100%;height:auto;vertical-align: middle;}  p{font-family:-apple-system-font,"Helvetica Neue","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;line-height:150%;}</style> </head>';
    const result = head
        .concat('<body>')
        .concat(html)
        .concat('</body>');
    return result;
}

/**
 * @description 将emoji代码转回utf16编码的方法，用于显示
 * @param {string} [str] 需要转码的string
 * @return {string}
 */
export function utf16Encoding(str) {
    const patt = /&#[0-9a-fA-F]*;/g;
    str = str.replace(patt, char => {
        char = char.slice(2, -1);
        char = String.fromCodePoint(parseInt(char, 16));
        return char;
    });
    return str;
}

/**
 * @description 将utf16编码进行处理的方法，用于提供给服务器存储
 * @param {string} [str] 需要解码的string
 * @return {string}
 */
export function utf16Decoding(str) {
    const patt = /[\ud800-\udbff][\udc00-\udfff]/g; // 检测utf16字符正则
    str = str.replace(patt, function (char) {
        let code;
        if (char.length === 2) {
            code = char.codePointAt(0);
            return '&#' + code.toString(16) + ';';
        } else {
            return char;
        }
    });
    return str;
}

/**
 * @description 是否是合法的邮箱
 * @param {string} [str]
 * @return {bool}
 */
export function isEmail(str) {
    const regex = /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
    return regex.test(str);
}

/**
 * @description 是否是合法的手机号 仅验证11位数字
 * @param {string} [str]
 * @return {bool}
 */
export function isPhoneNumber(str) {
    const regex = /^[0-9]{11}$/g;
    return regex.test(str);
}

/**
 * @description 隐藏手机号中间的数字
 * @param {string} str 手机号
 * @return {string}
 */
export function toSecertPhoneNumber(str) {
    if (isPhoneNumber(str)) {
        return str.replace(/(\w{3})\w*(\w{4})/, '$1****$2');
    } else {
        return '****';
    }
}

/**
 * @description 可读的数量。大于3位数显示k
 * @param {number} [count] - 数量
 * @return {string}
 */
export function readableCount(count) {
    if (count > 999) {
        return `${Math.round(count / 1000)}k`;
    } else {
        return `${count}`;
    }
}

/**
 * @description 可读文件大小, < 1024 * 1024 显示kb, 其他显示MB
 * @param {number} [size] 文件大小
 * @return {string}
 */
export function readableSize(size = 0) {
    const show = parseFloat(size) / 1024 / 1024;
    if (show > 1) {
        return `${Math.ceil(size / 1024 / 1024)}MB`;
    } else {
        return `${Math.ceil(size / 1024)}KB`;
    }
}

/**
 * @description 查询所有子串的位置
 * @param {string} [str] 字符串
 * @param {string} [subStr] 字串
 * @return {Array} 子串位置
 */
export function subStringPostions(str, subStr) {
    let positions = [];
    let pos = str.indexOf(subStr);
    while (pos > -1) {
        positions.push(pos);
        pos = str.indexOf(subStr, pos + 1);
    }
    return positions;
}

/**
 * 截取时间字符串中的年月日部分，如果不符合条件返回默认值
 * @param {string} timeStr 时间字符串 2018-01-08 08:08:09
 */
export function subDateString(timeStr, defaultStr) {
    if (!!!timeStr) return defaultStr;
    if (typeof timeStr != 'string') return defaultStr;
    if (timeStr.length < 10) return defaultStr;
    return timeStr.substr(0, 10);
}

/**
 * 显示时间: 刚刚、xx分钟前、xx小时前、xx天前、MM-DD、YYYY-MM-DD
 * @param {number}} timestamp 时间戳13位
 */
export function shortDateString(timestamp) {
    const now = moment();
    const target = moment(timestamp);

    const diffSecond = now.diff(target, 'seconds');
    if (diffSecond < 60) {
        // 1分钟内
        return '刚刚';
    }

    const diffMinute = now.diff(target, 'minutes');
    if (diffMinute < 60) {
        // 60分钟内
        return `${diffMinute}分钟前`;
    }

    const diffHour = now.diff(target, 'hours');
    if (diffHour < 24) {
        // 24小时内
        return `${diffHour}小时前`;
    }

    const diffDay = now.diff(target, 'days');
    if (diffDay <= 30) {
        // 30天内
        return `${diffDay}天前`;
    }

    if (target.year() == now.year()) {
        // 1年内
        return target.format('MM-DD');
    }

    return target.format('YYYY-MM-DD');
}

export function getCurrentFormatTime() {
    let date = new Date();
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    let minute = date.getMinutes();
    let second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
}

export default {
    subString,
    appendHtmlCommonHeader,
    utf16Decoding,
    utf16Encoding,
    isEmail,
    isPhoneNumber,
    readableCount,
    readableSize,
    subStringPostions,
    subDateString,
    toSecertPhoneNumber,
    shortDateString,
    getCurrentFormatTime,
};
