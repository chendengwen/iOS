/**
 * @author xukj
 * @date 2019/03/04
 * @description TestUtil 考试相关信息辅助方法
 */
import { SeaConstant } from '../asserts';

/**
 * 用于展示的选项
 * @param {object} option 选项
 * @return {string}
 */
function optionDisplay(option) {
    return option ? option.optionLabel + '、' + option.optionText : '';
}

/**
 * 用户得分
 * @param {object} topic 题目对象
 * @return {number}
 */
function userScore(topic) {
    if (isEssayQuestion(topic)) {
        // 主观题得分的获取方式特殊
        return _.get(topic, 'options[0].answerScores', 0);
    } else {
        return topic && topic.correct ? topic.scores : 0;
    }
}

/**
 * 标准答案
 * @param {object} topic 题目对象
 * @return {array}
 */
function correctOptions(topic) {
    return _.chain(topic.options)
        .map(option => (option.answer ? option.optionLabel : ''))
        .compact()
        .value();
}

/**
 * 是否主观题
 * @param {object} topic 题目对象
 * @return {bool}
 */
function isEssayQuestion(topic = {}) {
    return topic.type == SeaConstant.TestTopicType.SHORTANSWER;
}

/**
 * 回顾选项展示需要的数据
 * @param {object} option 选项对象
 * @param {bool} review 回顾
 * @return {object}
 */
function optionReviewMode(option, review = true) {
    return {
        on: review,
        answer: option.answer,
        checked: option.isUserAnswer,
    };
}

/**
 * 是否可以考试
 * @param {object} paper 试卷信息
 * @throws {Error}
 */
function checkTestable(paper) {
    // 无权限
    if (paper.status != 1) {
        throw new Error('对不起，您没有权限浏览该门考试');
    }

    // 考试未开始
    if (paper.testStatus == 1) {
        throw new Error('该门考试还未开始');
    }

    // 考试已结束
    if (paper.testStatus == 0) {
        throw new Error('该门考试已结束');
    }

    const statusObject = currentUserTestStatus(paper);
    // 考试次数已耗尽
    if (statusObject.status == UserTestStatus.USED_UP) {
        throw new Error('您的考试次数已满，不能继续考试了哦~');
    }
}

/**
 * 是否正在考试
 * @param {object} userExamDTO
 * @return {bool}
 */
function isUserTesting(userExamDTO) {
    return userExamDTO.userTestStatus == SeaConstant.UserExamType.TESTING;
}

/**
 * 是否考试过期
 * @param {object} paper 试卷信息
 * @param {object} userExamDTO 本次答题信息
 */
function isUserTimeout(paper, userExamDTO) {
    return Date.now() - new Date(userExamDTO.startTestTime).getTime() > paper.duration * 60 * 1000;
}

/**
 * 是否可以回顾试卷
 * @param {object} paper 试卷信息
 * @param {object} userExamDTO 答题信息
 * @throws {Error}
 */
function checkReviewable(paper, userExamDTO) {
    // 1. 试卷不允许回顾
    if (!paper.review) {
        throw new Error('该门考试不允许回顾答案');
    }

    // 2. 无权限
    if (paper.status != 1) {
        throw new Error('对不起，您没有权限浏览该门考试');
    }

    // 3. 考试中 && 该次答题未过期
    if (isUserTesting(userExamDTO) && !isUserTimeout(paper, userExamDTO)) {
        throw new Error('您还没有提交答卷');
    }
}

const UserTestStatus = {
    NONE: 0, // 无效
    FIRST: 1, // 第一次考试
    NO_FIRST: 2, // 非第一次
    TESTING: 3, // 正在考试
    USED_UP: 4, // 次数已用完
};

/**
 * 计算当前用户考试状态
 * @param {object} paper 试卷信息
 * @return {{ status: UserTestStatus, title: string }}
 */
function currentUserTestStatus(paper) {
    // 最新的答题信息
    const latestExamDTO = paper.userExamDTO;

    // 1. 第一次考试
    if (!latestExamDTO || latestExamDTO.examTimes <= 0) {
        return { status: UserTestStatus.FIRST, title: '开始考试' };
    }

    // 是否正在考试
    const isTesting = isUserTesting(latestExamDTO);
    // 是否已达次数限制
    const isMaxTestTimes =
        paper.testFrequency > 0 && paper.testFrequency <= latestExamDTO.examTimes;

    // 2. 不在考试中 && 未达次数上限
    if (!isTesting && !isMaxTestTimes) {
        return { status: UserTestStatus.NO_FIRST, title: '再考一次' };
    }

    // 3. 不在考试中 && 已达次数上限
    if (!isTesting && isMaxTestTimes) {
        return { status: UserTestStatus.USED_UP, title: '次数已满' };
    }

    // 是否已超时
    const isTimeout = isUserTimeout(paper, latestExamDTO);
    // 4. 已超时 && 未达次数上限
    if (isTimeout && !isMaxTestTimes) {
        return { status: UserTestStatus.NO_FIRST, title: '再考一次' };
    }

    // 5. 已超时 && 已达次数上限
    if (isTimeout && isMaxTestTimes) {
        return { status: UserTestStatus.USED_UP, title: '次数已满' };
    }

    // 6. 正在答题
    return { status: UserTestStatus.TESTING, title: '继续考试' };
}

/**
 * 获取本次考试的最后期限
 * @param {object} paper 试卷信息
 * @return {number}
 */
function getNeedSubmitTime(paper) {
    const latestExamDTO = _.first(paper.userExamDTOs);

    if (!latestExamDTO) {
        return -1; // 无期限
    }

    if (!isUserTesting(latestExamDTO)) {
        return -1; // 无期限
    }

    return new Date(latestExamDTO.startTestTime).getTime() + paper.duration * 60 * 1000;
}

export default {
    optionDisplay,
    userScore,
    correctOptions,
    optionReviewMode,
    checkTestable,
    checkReviewable,
    UserTestStatus,
    currentUserTestStatus,
    getNeedSubmitTime,
    isUserTesting,
    isUserTimeout,
    // add by xukj - 1.36.0
    isEssayQuestion,
};
