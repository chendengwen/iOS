/**
 * @author xukj
 * @date 2019/12/27
 * @description SeaAds 广告工具
 */
import { CommonService, ADStorageService } from '../servie';
import SeaCacheUtil from './SeaCacheUtil';
import SeaImageUtil from './SeaImageUtil';

/**
 * @private
 * @description 准备广告
 */
async function prepareAds() {
    try {
        // 1. 从服务器同步广告信息
        const remoteAds = await CommonService.getADList();
        let cachedAds = [];
        for (let index = 0; index < remoteAds.length; index++) {
            // 2. 下载广告图片
            const ad = remoteAds[index];
            const imageUrl = SeaImageUtil.getImageUri(ad.pictureId, null, 'l');
            // const imageUrl = 'https://lec-study-uat.foresealife.com:446/resource/api/resource/file/7512483d-6328-4d54-acb4-ee89f772b84a';
            const downloader = new SeaCacheUtil.Downloader();
            const result = await downloader.start(imageUrl);
            if (result && !result.error) {
                cachedAds.push({
                    imageId: ad.pictureId,
                    imageUri: result.uri,
                    imagePath: result.path,
                    url: ad.url,
                });
            }
        }

        // 3. 保存可用的广告信息到数据库
        await ADStorageService.save(cachedAds);
    } catch (error) {
        // 错误
        console.log(error);
    }
}

/**
 * @private
 * @description 可显示的广告
 * @return {Promise}
 */
function getAds() {
    return ADStorageService.load().catch(error => Promise.resolve([]));
}

export default { prepareAds, getAds };
