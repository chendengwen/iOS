import { requireNativeComponent } from 'react-native';

export default requireNativeComponent('BNRouterView');

