/**
 * @author xukj
 * @date 2018/12/12
 * @description PlayProgressUtil 播放进度统计工具
 * 
 * modify by xukj - 1.27.0
 * 调整学习进度的数据库模型。需要支持批量查询多个用户的学习进度数据。数据模型如下:
{
    progressId: {  // progressId = userId + coursewareId + curriculaSnapshotId
        userId,
        coursewareId,
        curriculaSnapshotId,
        currentPlayedLength,
        totalLength,
    }
}
 * 
 * create by xukj - 1.24.0
 * 统一处理播放进度的统计，需要统计的数据如下
 * 
 * currentPlayedLength - 播放时长
 * totalLength - 总时长
 * coursewareId - 课件id
 * curriculaSnapshotId - 相关id
 */
import { PlayProgressStorageService } from '../servie';
import { IdentifyExtension } from '../redux';

// 验证数据合法性
function isValidatePayload(payload) {
    if (!payload) {
        return false;
    }

    if (!payload.coursewareId) {
        return false;
    }

    if (!payload.curriculaSnapshotId) {
        return false;
    }

    if (payload.currentPlayedLength == 0 || payload.totalLength == 0) {
        return false;
    }

    return true;
}

/**
 * 统计播放进度
 * @param {object} payload 进度数据
 */
async function collect(payload) {
    try {
        // 1.验证数据合法性
        if (!isValidatePayload(payload)) return;

        // 2.是否登录用户
        const sessionData = IdentifyExtension.getLoginSessionData();
        if (!sessionData) return;

        // 3.当前用户id
        let userId;
        const userInfo = IdentifyExtension.getLoginUserInfo();
        if (userInfo) userId = userInfo.id;

        // 4. 索引 progressId = userId + coursewareId + curriculaSnapshotId
        const progressId = `${userId}+${payload.coursewareId}+${payload.curriculaSnapshotId}`;

        // 5.添加或更新数据
        let progressDataValues = await PlayProgressStorageService.loadPlayProgress()
            .then(data => {
                return Promise.resolve(data ? data : {});
            })
            .catch(() => {
                return Promise.resolve({});
            });
        progressDataValues[progressId] = { ...payload, userId };

        // 6.持久化进度数据
        console.log('进度统计', progressId);
        await PlayProgressStorageService.savePlayProgress(progressDataValues);
    } catch (error) {
        // do nothing
    }
}

/**
 * 播放保存的数据
 * @param {number} playedTime 播放时长
 * @param {number} totalTime 总时长
 * @param {string} coursewareId 课件id
 * @param {string} curriculaSnapshotId
 */
function payload(playedTime = 0, totalTime = 0, coursewareId, curriculaSnapshotId) {
    return {
        currentPlayedLength: parseInt(playedTime),
        totalLength: parseInt(totalTime),
        coursewareId: coursewareId,
        curriculaSnapshotId: curriculaSnapshotId,
    };
}

/**
 * 指定用户的所有进度数据
 */
function getUserPlayProgress() {
    return PlayProgressStorageService.loadPlayProgress().then(data => {
        return Promise.resolve(Object.values(data));
    });
}

/**
 * 清空进度数据
 */
function resetUserPlayProgress() {
    return PlayProgressStorageService.resetPlayProgress();
}

export default {
    collect,
    payload,
    getUserPlayProgress,
    resetUserPlayProgress,
};
