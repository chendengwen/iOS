/**
 * Created by xukj on 2018/8/7.
 *
 */
import { FSLHttp as HttpApi } from 'react-native-kpframework';
import { IdentifyExtension } from '../redux';
import { Alert, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import _ from 'lodash';
import { SeaConstant } from '../asserts';
import SeaDevice from './SeaDevice';

const baseHttpApi = new HttpApi.FSLHttpApi();
const deviceOS = SeaDevice.deviceOS();

const HttpErrorCode = {
    BUSINESS_ERROR: 412, // 业务相关错误
    UNKNOWN_BUSINESS_ERROR: 303, // 业务相关非系统错误
    LOCAL_NETWORK_ERROR: -9998, // 本地网络错误
    UNKNOWN: -9997, // 未知错误
};

/**
 * @description get请求 (json格式)
 * @param {string} [url] api
 * @param {*} [extension] 扩展(headers自定义头、resultHandler自定义应答处理、errorHandler自定义错误处理)
 * @return {Promise}
 */
function getHttpApi(url, extension = {}) {
    return new Promise((resolve, reject) => {
        const { headers, resultHandler, errorHandler } = {
            ...defaultExtensions(),
            ...extension,
        };
        baseHttpApi.headers = headers;
        console.log('httpApi', { url: url, header: baseHttpApi.headers, method: 'GET' });
        baseHttpApi
            .GET(url)
            .then(response => {
                resultHandler(resolve, reject, response);
            })
            .catch(error => {
                console.log('httpApi', { url: url, error: error });
                errorHandler(reject, error);
            });
    });
}

/**
 * @description post请求 (json格式)
 * @param {string} [url] api
 * @param {*} [data] body
 * @param {*} [extension] 扩展(headers自定义头、resultHandler自定义应答处理、errorHandler自定义错误处理)
 * @return {Promise}
 */
function postHttpApi(url, data, extension = {}) {
    return new Promise((resolve, reject) => {
        const { headers, resultHandler, errorHandler } = {
            ...defaultExtensions(),
            ...extension,
        };
        baseHttpApi.headers = headers;
        console.log('httpApi', {
            url: url,
            header: baseHttpApi.headers,
            data: data,
            method: 'POST',
        });
        baseHttpApi
            .POST(url, data)
            .then(response => {
                resultHandler(resolve, reject, response);
            })
            .catch(error => {
                console.log('httpApi', { url: url, error: error });
                errorHandler(reject, error);
            });
    });
}

/**
 * @description put请求 (json格式)
 * @param {string} [url] api
 * @param {*} [data] body
 * @param {*} [extension] 扩展(headers自定义头、resultHandler自定义应答处理、errorHandler自定义错误处理)
 * @return {Promise}
 */
function putHttpApi(url, data, extension = {}) {
    return new Promise((resolve, reject) => {
        const { headers, resultHandler, errorHandler } = {
            ...defaultExtensions(),
            ...extension,
        };
        baseHttpApi.headers = headers;
        console.log('httpApi', {
            url: url,
            header: baseHttpApi.headers,
            data: data,
            method: 'PUT',
        });
        baseHttpApi
            .PUT(url, data)
            .then(response => {
                resultHandler(resolve, reject, response);
            })
            .catch(error => {
                console.log('httpApi', { url: url, error: error });
                errorHandler(reject, error);
            });
    });
}

/**
 * @description delete请求 (json格式)
 * @param {string} [url] api
 * @param {*} [data] body
 * @param {*} [extension] 扩展(headers自定义头、resultHandler自定义应答处理、errorHandler自定义错误处理)
 * @return {Promise}
 */
function deleteHttpApi(url, data, extension = {}) {
    return new Promise((resolve, reject) => {
        const { headers, resultHandler, errorHandler } = {
            ...defaultExtensions(),
            ...extension,
        };
        baseHttpApi.headers = headers;
        console.log('httpApi', {
            url: url,
            header: baseHttpApi.headers,
            data: data,
            method: 'DELETE',
        });
        baseHttpApi
            .DELETE(url, data)
            .then(response => {
                resultHandler(resolve, reject, response);
            })
            .catch(error => {
                console.log('httpApi', { url: url, error: error });
                errorHandler(reject, error);
            });
    });
}

/**
 * @description form表单提交（仅支持POST）
 * @param {string} [url] api
 * @param {FormData} [formData] 表单
 * @param {*} [extension] 扩展(headers自定义头、resultHandler自定义应答处理、errorHandler自定义错误处理)
 * @return {Promise}
 */
function formHttpApi(url, formData, extension = { headers: formHeaders() }) {
    return new Promise((resolve, reject) => {
        const { headers, resultHandler, errorHandler } = {
            ...defaultExtensions(),
            ...extension,
        };
        baseHttpApi.headers = headers;
        console.log('httpApi', { url: url, header: baseHttpApi.headers, data: formData });
        baseHttpApi
            .POST(url, formData, 60000)
            .then(response => {
                resultHandler(resolve, reject, response);
            })
            .catch(error => {
                console.log('httpApi', { url: url, error: error });
                errorHandler(reject, error);
            });
    });
}

/**
 * @description 默认api头
 * @return {*}
 */
function defaultHeaders() {
    return {
        Accept: 'application/json',
        'Accept-Encoding': 'gzip',
        'X-Authorization': _.get(IdentifyExtension.getLoginSessionData(), 'authToken', ''),
        'X-Client': 'mobile',
        'X-AccessOrigin': deviceOS,
        'Content-Type': 'application/json',
    };
}

/**
 * @description 表单提交头
 * @return {*}
 */
function formHeaders() {
    return {
        Accept: 'application/json',
        'Accept-Encoding': 'gzip',
        'X-Authorization': _.get(IdentifyExtension.getLoginSessionData(), 'authToken', ''),
        'X-Client': 'mobile',
        'Content-Type': 'multipart/form-data',
    };
}

/**
 * @description 不带token的api头
 * @return {*}
 */
function noTokenHeaders() {
    return {
        Accept: 'application/json',
        'Accept-Encoding': 'gzip',
        'X-Client': 'mobile',
        'Content-Type': 'application/json',
    };
}

/**
 * @description http应答的业务处理，约定服务器端返回的应答必须为json格式
 * 严格意义上，这里不应该添加UI相关的业务逻辑，为了兼容以前的代码这里保留UI操作
 * ps: 包括http的各种错误
 * @param {func} [resolve] Promise.resolve
 * @param {func} [reject] Promise.reject
 * @param {*} [response] 应答
 */
function resultHandler(resolve, reject, response) {

    // 无response
    if (!response) {
        const error = new HttpApi.FSLHttpError('出错啦', HttpErrorCode.UNKNOWN);
        console.log('httpApi', { url: '未知', error: error });
        reject(error);
        return;
    }

    // 成功
    if (response.ok) {
        // 默认response为json格式
        response.json().then(
            json => {
                console.log('httpApi', { url: response.url, response: json });
                resolve(json);
            },
            () => {
                console.log('httpApi', { url: response.url, response: undefined });
                resolve();
            }
        );
        return;
    }

    // 无权限 - 401
    if (response.status === HttpApi.FSLHttpCode.UNAUTHORIZED_ERROR) {
        const error = new HttpApi.FSLHttpError(
            '您的登录已经到期，请重新登录',
            HttpApi.FSLHttpCode.UNAUTHORIZED_ERROR
        );
        console.log('httpApi', { url: response.url, error: error });
        DeviceEventEmitter.emit(SeaConstant.SeaGlobalEventType.LOGOUT, error);
        return;
    }

    // 服务器无响应 - 404
    if (response.status === HttpApi.FSLHttpCode.NOT_FOUND_ERROR) {
        const error = new HttpApi.FSLHttpError('服务器没有响应', response.status, response.data);
        console.log('httpApi', { url: response.url, error: error });
        reject(error);
        return;
    }

    // 其他错误
    response.json().then(
        json => {
            if (response.status === HttpErrorCode.BUSINESS_ERROR) {
                // 业务相关系统错误 - 412
                // 直接使用系统提供的错误日志
                const error = new HttpApi.FSLHttpError(json.error, json.status, json);
                console.log('httpApi', { url: response.url, error: error });
                reject(error);
            } else {
                // 非412 - 直接使用固定的错误日志
                const error = new HttpApi.FSLHttpError('系统错误', json.status, json);
                console.log('httpApi', { url: response.url, error: error });
                reject(error);
            }
        },
        () => {
            const error = new HttpApi.FSLHttpError('系统错误', response.status, response.data);
            console.log('httpApi', { url: response.url, error: error });
            reject(error);
        }
    );
}

/**
 * @description 网络错误
 * @param {func} [reject] Promise.reject
 * @param {*} [error] 错误
 */
function errorHandler(reject, error) {
    const handledError = error;
    let message = handledError.message;
    if (message === 'Network request failed') {
        message = '当前网络不可用，请检查你的网络设置';
        reject(new HttpApi.FSLHttpError(message, HttpApi.FSLHttpCode.LOCAL_NETWORK_ERROR));
        return;
    }

    if (message === 'timeout') {
        message = '网络请求超时，请稍后再试';
        reject(new HttpApi.FSLHttpError(message, HttpApi.FSLHttpCode.LOCAL_NETWORK_ERROR));
        return;
    }

    reject(new HttpApi.FSLHttpError(message, HttpErrorCode.LOCAL_NETWORK_ERROR));
}

/*
 * @private
 * @description 默认的扩展数据
 */
function defaultExtensions() {
    return {
        headers: defaultHeaders(),
        resultHandler,
        errorHandler,
    };
}

export default {
    // http method
    getHttpApi,
    postHttpApi,
    putHttpApi,
    deleteHttpApi,
    formHttpApi,

    // headers
    defaultHeaders,
    formHeaders,
    noTokenHeaders,

    // handler
    resultHandler,
    errorHandler,
};
