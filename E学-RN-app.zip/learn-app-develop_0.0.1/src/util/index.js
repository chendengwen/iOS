/**
 * Created by xukj on 2018/7/18.
 * 通用工具模块
 * @providesModule learn-util
 */
// 原生设备信息
export { default as SeaDevice } from './SeaDevice';
// 图片工具
export { default as SeaImageUtil } from './SeaImageUtil';
// http网络工具
export { default as SeaHttpApi } from './SeaHttpApi';
// string工具
export { default as SeaString } from './SeaString';
// timer
export { default as BackgroundTimer } from './BackgroundTimer';
// pv统计
export { default as SeaPVUtil } from './SeaPVUtil';

export { default as SeaStudyTimeUtil } from './SeaStudyTimeUtil';

export { default as SeaPlayProgressUtil } from './SeaPlayProgressUtil';

export { default as SeaTool } from './SeaTool';

export { default as FSLError } from './FSLError';

export { default as TestUtil } from './TestUtil';

export { default as SeaCacheUtil } from './SeaCacheUtil';

export { default as FSLTool } from './tool/FSLTool';

// 原生交互方法
export { default as SeaNative } from './SeaNative';

// 定位
// ---
export { default as SeaLocation } from './location/SeaLocation';

// 友盟
// ---
//分享
export {
    ShareUtil as SeaShareUtil,
    ShareCode as SeaShareCode,
    SharePlatform as SeaSharePlatform,
} from './umeng/SeaShareUtil';

// 友盟推送
export { PushUtil as SeaPushUtil } from './umeng/SeaPushUtil';

// 统计
export { default as SeaAnalyticsUtil } from './umeng/SeaAnalyticsUtil';

// 广告
export { default as SeaAds } from './SeaAds';

// 用户相关
export { default as SeaUserUtil } from './SeaUserUtil';
