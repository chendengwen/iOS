/**
 * @author xukj
 * @date 2019/06/28
 * @description SeaCacheUtil 缓存管理
 */
import { Platform } from 'react-native';
import { ImageCache } from 'react-native-img-cache-kp';
import RNFetchBlob from 'rn-fetch-blob';
import KPGallery from 'react-native-kpframework-gallery';
import { ADStorageService } from '../servie';

class Downloader {
    handler = (uri, path, error) => {};

    start(uri) {
        return new Promise((resolve, reject) => {
            if (uri != this.uri) {
                this.dispose();
            }

            this.uri = uri;
            const source = { uri: this.uri };
            this.handler = (path, loading, isFail) => {
                if (loading) {
                    return;
                }
                if (isFail) {
                    resolve({ uri: this.uri, path: null, error: new Error('下载失败') });
                } else {
                    resolve({ uri: this.uri, path, error: null });
                }
                this.dispose();
            };

            ImageCache.get().on(source, this.handler, false);
        });
    }

    dispose() {
        ImageCache.get().dispose(this.uri, this.handler);
    }
}

/**
 * 获取缓存大小
 */
function getCacheSize() {
    return Promise.all([getRNImageCacheSize(), getNativeImageCacheSize()]).then(values => {
        return Promise.resolve(Number(values[0]) + Number(values[1]));
    });
}

/**
 * 清空缓存
 */
function clearCache() {
    return Promise.all([clearRNImageCache(), clearNativeImageCache(), clearAdsCache()]).then(() => {
        return Promise.resolve();
    });
}

/**
 * @private
 * @description 获取 react-native-img-cache-kp 组件的缓存大小
 */
function getRNImageCacheSize() {
    const dir = ImageCache.cacheDir();
    return RNFetchBlob.fs
        .lstat(dir)
        .then(stats => {
            return Promise.resolve(_.sumBy(stats, stat => parseInt(stat.size)));
        })
        .catch(() => Promise.resolve(0));
}

/**
 * @private
 * @description 获取 native 组件的缓存大小
 */
function getNativeImageCacheSize() {
    if (Platform.OS == 'ios' || Platform.OS == 'android') {
        return KPGallery.getCacheSize();
    } else {
        return Promise.resolve(0);
    }
}

/**
 * @private
 * @description 清空 react-native-img-cache-kp 缓存
 */
function clearRNImageCache() {
    const dir = ImageCache.cacheDir();
    return RNFetchBlob.fs.unlink(dir);
}

/**
 * @private
 * @description 清空原生缓存
 */
function clearNativeImageCache() {
    if (Platform.OS == 'ios') {
        // iOS
        return KPGallery.clearCache();
    } else if (Platform.OS == 'android') {
        // Android
        return KPGallery.clearCache().catch(() => Promise.resolve());
    } else {
        return Promise.resolve(0);
    }
}

/**
 * @private
 * @description 清除广告缓存
 */
function clearAdsCache() {
    return ADStorageService.reset();
}

export default {
    getCacheSize,
    clearCache,
    // 下载器
    Downloader,
};
