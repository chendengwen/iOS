/**
 * Created by zk on 2019/1/23.
 */
import CryptoJS from 'crypto-js';
const orange = 'oF6mT8aL3cV6cU1g';

function encrypt(word) {
    let cbcIvHex = CryptoJS.enc.Utf8.parse(orange);
    let option = { iv: cbcIvHex, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 };
    const result = CryptoJS.AES.encrypt(
        CryptoJS.enc.Utf8.parse(word),
        CryptoJS.enc.Utf8.parse(orange),
        option
    ).ciphertext.toString();
    return result;
}

function decrypt(message) {
    let cbcIvHex = CryptoJS.enc.Utf8.parse(orange);
    let keyHex = CryptoJS.enc.Utf8.parse(orange);
    let option = { iv: cbcIvHex, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 };
    let decrypted = CryptoJS.AES.decrypt(
        {
            ciphertext: CryptoJS.enc.Hex.parse(message),
        },
        keyHex,
        option
    );
    let result_value = decrypted.toString(CryptoJS.enc.Utf8);
    return result_value;
}

export default {
    encrypt,
    decrypt,
};
