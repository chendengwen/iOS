/**
 * @author xukj
 * @date 2018/8/17
 * @description 设备相关方法
 */
import { NativeModules, Platform, PixelRatio } from 'react-native';

/**
 * @description 判断设备是否是iphoneX，这里使用原生判断而非屏幕来判断
 * android固定false
 * @return {bool}
 */
function isIPhoneX() {
    return NativeModules.RNHardwareTool.isIphoneX;
}

/**
 * @description 判断设备导航栏高度，原生方法已经考虑到了iPhoneX因此不需要再处理
 * @return {number}
 */
function statusBarHeight() {
    const height = NativeModules.RNHardwareTool.statusBarHeight;
    if (Platform.OS == 'ios') {
        return height;
    }
    else {
        return parseInt(height / PixelRatio.get()) + 1;
    }
}

/**
 * @description ios状态栏高度，如果是android则固定返回0
 * @return {number}
 */
function iosStatusBarHeight() {
    if (Platform.OS == 'ios') {
        return NativeModules.RNHardwareTool.statusBarHeight;
    }
    else {
        return 0;
    }
}

/**
 * @description android状态栏高度，如果是ios则固定返回0
 * @return {number}
 */
function androidStatusBarHeight() {
    if (Platform.OS == 'android') {
        return NativeModules.RNHardwareTool.statusBarHeight;
    }
    else {
        return 0;
    }
}

/**
 * @description 设备名称，暂时不支持android
 * @return {string}
 */
function deviceName() {
    return NativeModules.RNHardwareTool.deviceInformation;
}

/**
 * @description 判断设备底部高度，原生方法已经考虑到了iPhoneX因此不需要再特殊处理
 * android固定0
 * @return {number}
 */
function bottomHeight() {
    return NativeModules.RNHardwareTool.bottomHeight;
}

/**
 * @description 品牌
 * @returns {string}
 */
function deviceBrand() {
    return NativeModules.RNHardwareTool.deviceBrand;
}

/**
 * @description 设备名称
 * @return {string}
 */
function deviceModel() {
    return NativeModules.RNHardwareTool.deviceModel;
}

/**
 * @description 设备系统
 * @returns {string} iOS / android
 */
function deviceOS() {
    return NativeModules.RNHardwareTool.deviceOS;
}

/**
 * @description 设备系统版本号
 * @return {string}
 */
function deviceOSVersion() {
    return NativeModules.RNHardwareTool.deviceOSVersion;
}

/**
 * @description app版本
 * @return {string}
 */
function appVersion() {
    return NativeModules.RNHardwareTool.appVersion;
}

/**
 * @description build版本
 * @return {number}
 */
function appBuildVersion() {
    return NativeModules.RNHardwareTool.appBuildVersion;
}

export default {
    isIPhoneX,
    statusBarHeight,
    iosStatusBarHeight,
    androidStatusBarHeight,
    deviceName,
    bottomHeight,
    deviceBrand,
    deviceModel,
    deviceOS,
    deviceOSVersion,
    appVersion,
    appBuildVersion,
};