/**
 * @description 讲师中心
 */

import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import TeacherCenterDetail from '../../view/teacher/detail/TeacherCenterDetail';
import { CaseEvaluateDetailPage } from '../../view/evaluate';

/**
 * @description 路由
 */
export default [
    <Scene
        key="teacherDetail"
        title="讲师详情"
        component={TeacherCenterDetail}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="teacherEvaluateDetailPage"
        title="讲师评价详情"
        component={CaseEvaluateDetailPage}
        {...sceneProps}
        hideNavBar
    />,

];
