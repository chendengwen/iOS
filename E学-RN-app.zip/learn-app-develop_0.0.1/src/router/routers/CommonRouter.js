/**
 * @author xukj
 * @date 2018/11/01
 * @description CommonRouter 通用界面router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {
    QRCodeScanPage,
    QRCodeInputPage,
    SeaWebPage,
    SeaPdfGalleryPage,
    SeaVisibilityListPage,
} from '../../view/common';

/**
 * @description 路由
 */
export default [
    <Scene key="qrCode" title="扫一扫" component={QRCodeScanPage} {...sceneProps} hideNavBar />,
    <Scene key="qrCodeInput" title="输入编码" component={QRCodeInputPage} {...sceneProps} />,
    <Scene key="webview" title="" component={SeaWebPage} {...sceneProps} hideNavBar />,
    <Scene key="pdfGallery" title="" component={SeaPdfGalleryPage} {...sceneProps} hideNavBar />,
    <Scene
        key="visibilityList"
        title="可见范围"
        component={SeaVisibilityListPage}
        {...sceneProps}
    />,
];
