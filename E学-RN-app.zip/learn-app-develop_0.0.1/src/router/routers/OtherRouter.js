/**
 * @author xukj
 * @date 2018/11/01
 * @description OtherRouter 其他router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import { HomeColumnDetailPage } from '../../view/home';
import { TrainingSignPage } from '../../view/training';
import { SeaMediaTestPage } from '../../view/common';
import {
    MessageListPage,
    MessageSearchPage,
    MessageLikeListPage,
    MessageCommentListPage,
} from '../../view/message';

/**
 * @description 路由
 */
export default [
    <Scene key="assgin" title="培训班签到" component={TrainingSignPage} {...sceneProps} />,
    <Scene key="homeColumn" title="专栏" component={HomeColumnDetailPage} {...sceneProps} />,
    <Scene key="mediaTest" title="播放器测试" component={SeaMediaTestPage} {...sceneProps} />,
    <Scene key="messageNormalList" title="消息通知" component={MessageListPage} {...sceneProps} />,
    <Scene
        key="messageSearch"
        title="消息通知"
        component={MessageSearchPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene key="messageLikeList" title="赞" component={MessageLikeListPage} {...sceneProps} />,
    <Scene
        key="messageCommentList"
        title="评论/评分"
        component={MessageCommentListPage}
        {...sceneProps}
    />,
];
