/**
 * @author xukj
 * @date 2018/11/01
 * @description GuideRouter 启动页router
 */
import React from 'react';
import { Scene, ActionConst } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import { AppGuidePage, AppInitialPage, AppAdsPage } from '../../view/guide';

/**
 * @description 路由
 */
export default [
    <Scene
        key="appInitialPage"
        title="等待页"
        component={AppInitialPage}
        type={ActionConst.RESET}
        {...sceneProps}
        hideNavBar
        initial
    />,
    <Scene
        key="appGuidePage"
        title="引导页"
        component={AppGuidePage}
        type={ActionConst.RESET}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="appAdsPage"
        title="广告业"
        component={AppAdsPage}
        type={ActionConst.RESET}
        {...sceneProps}
        hideNavBar
    />,
];
