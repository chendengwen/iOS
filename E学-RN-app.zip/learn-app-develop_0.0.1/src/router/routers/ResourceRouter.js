/**
 * @author xukj
 * @date 2018/11/01
 * @description ResourceRouter 资源router
 */
import React from 'react';
import { Scene, Actions } from 'react-native-router-flux';
import { sceneProps, renderTextButton } from '../RouterRenders';
import { BookDetailPage, BookApprovePage } from '../../view/book';
import {
    ResourceSearchListPage,
    ECourseChannelListPage,
    TraningChannelListPage,
    BookChannelListPage,
    TestChannelListPage,
    CategoryTabsPage,
    RecommendUserSelectionPage,
    AddCommentPage,
    SeaRichTextPage,
    CategoryPage,
    ResourceSearchHistoryPage,
    MultiLevelListPage,
    QChannelListPage,
    QBarChannelListPage,
    SubjectChannelListPage,
    CoursePlayPage,
    SeaScorePage,
    CasesChannelListPage,
    GlobalSearchListPage,
} from '../../view/resource';
import {
    TrainingDetailPage,
    TrainingSurveyPage,
    TeacherDetailPage,
    TrainingCoursePage,
    TrainingApprovePage,
    TrainingCheckinListPage,
    TrainingCheckinDetailPage,
} from '../../view/training';
import { ECourseDetailPage, EClassApprove } from '../../view/course';
import { NewsApprove } from '../../view/news';
import TeacherChannelListPage from '../../view/teacher/view/TeacherChannelListPage';
import {
    CategoryChoosePage,
    CategoryCaseListPage,
    CategoryLecturerListPage,
} from '../../view/home';
import { TestPaperListPage as CategoryExamListPage } from '../../view/examination';
import { TrainingListPage as CategoryTrainingListPage } from '../../view/training';
import { ECourseListPage as CategoryCourseListPage } from '../../view/course';

/**
 * @private
 * @description 打开发布问题按钮
 */
const renderShowQAButton = () => {
    return renderTextButton(() => {
        Actions.show('qaAddQuestion');
    }, '提问');
};

export default [
    // e课
    <Scene
        key="courseChannel"
        title="在线学习列表"
        component={ECourseChannelListPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="courseDetail"
        title="在线学习详情"
        component={ECourseDetailPage}
        {...sceneProps}
        hideNavBar
    />,
    // 面授
    <Scene
        key="trainingChannel"
        title="培训管理列表"
        component={TraningChannelListPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="trainningDetail"
        title="培训班详情"
        component={TrainingDetailPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="trainingCourse"
        title="培训班课程"
        component={TrainingCoursePage}
        {...sceneProps}
        hideNavBar
    />,
    // <Scene key="teacherDetail" title="讲师详情" component={TeacherDetailPage} {...sceneProps} hideNavBar/>,
    <Scene
        key="trainingApprove"
        title="培训管理审批"
        component={TrainingApprovePage}
        {...sceneProps}
    />,
    <Scene
        key="trainingRecords"
        title="个人提交记录"
        component={TrainingApprovePage}
        {...sceneProps}
    />,
    <Scene key="newsApprove" title="新闻审批" component={NewsApprove} {...sceneProps} />,
    <Scene key="eClassApprove" title="在线学习审批" component={EClassApprove} {...sceneProps} />,
    <Scene key="eClassRecords" title="个人提交记录" component={EClassApprove} {...sceneProps} />,
    <Scene
        key="trainingCheckinList"
        title="签到信息"
        component={TrainingCheckinListPage}
        {...sceneProps}
    />,
    <Scene
        key="trainingCheckinDetail"
        title="签到详情"
        component={TrainingCheckinDetailPage}
        {...sceneProps}
    />,
    // 阅读
    <Scene
        key="bookChannel"
        title="阅读"
        component={BookChannelListPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="bookDetail"
        title="阅读详情"
        component={BookDetailPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene key="bookApprove" title="阅读审批" component={BookApprovePage} {...sceneProps} />,
    // 考试
    <Scene
        key="testChannel"
        title="考试"
        component={TestChannelListPage}
        {...sceneProps}
        hideNavBar
    />,
    // 问卷频道列表
    <Scene
        key="qChannelList"
        title="问卷"
        // component={QChannelListPage}
        component={CasesChannelListPage} // 问卷暂时改为案例入口
        {...sceneProps}
        hideNavBar
    />,
    // 问吧
    <Scene
        key="qbarChannel"
        title="问吧"
        // component={QBarChannelListPage}
        component={TeacherChannelListPage}
        {...sceneProps}
        hideNavBar
        // renderRightButton={renderShowQAButton}
    />,
    // 专题
    <Scene
        key="subjectChannel"
        title="问卷"
        component={SubjectChannelListPage}
        // component={CasesChannelListPage}
        {...sceneProps}
        hideNavBar
    />,
    // 推荐
    <Scene
        key="recommendUserSelection"
        title="推荐"
        component={RecommendUserSelectionPage}
        {...sceneProps}
        hideNavBar
    />,
    // 搜索
    <Scene
        key="searchResourceList"
        title="分类搜索"
        component={ResourceSearchListPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="searchGlobalList"
        title="分类搜索"
        component={GlobalSearchListPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="searchResourceHistory"
        title="搜索历史"
        component={ResourceSearchHistoryPage}
        {...sceneProps}
        hideNavBar
    />,
    // 分类
    <Scene key="categoryFlow" title="分类" component={CategoryPage} {...sceneProps} />,
    <Scene key="categoryTabs" title="分类查询" component={CategoryTabsPage} {...sceneProps} />,
    // 其他
    <Scene
        key="addCommentFlow"
        title="发布评论"
        component={AddCommentPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene key="richText" title="在线学习" component={SeaRichTextPage} {...sceneProps} />,
    //预开课
    <Scene key="surveyDetail" title="预开课详情" component={TrainingSurveyPage} {...sceneProps} />,
    // 其他
    <Scene key="multiLevelList" title="选择分类" component={MultiLevelListPage} {...sceneProps} />,
    // 通用课程播放界面
    <Scene
        key="coursePlay"
        title="课程播放"
        component={CoursePlayPage}
        {...sceneProps}
        hideNavBar
    />,
    // 提交评分
    <Scene key="addScore" title="评分" component={SeaScorePage} {...sceneProps} />,
    // 功能分类
    <Scene key="categoryChoose" title="功能分类" component={CategoryChoosePage} {...sceneProps} />,
    // 在线学习分类
    <Scene
        key="categoryECourse"
        title="分类查询"
        component={CategoryCourseListPage}
        {...sceneProps}
    />,
    // 培训分类
    <Scene
        key="categoryTrain"
        title="分类查询"
        component={CategoryTrainingListPage}
        {...sceneProps}
    />,
    // 考试分类
    <Scene key="categoryExam" title="分类查询" component={CategoryExamListPage} {...sceneProps} />,
    // 案例分类
    <Scene key="categoryCase" title="分类查询" component={CategoryCaseListPage} {...sceneProps} />,
    // 讲师分类
    <Scene
        key="categoryLecturer"
        title="分类查询"
        component={CategoryLecturerListPage}
        {...sceneProps}
    />,
];
