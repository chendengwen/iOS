/**
 * @author xukj
 * @date 2018/11/01
 * @description PersonalRouter 个人模块的router
 */
import React from 'react';
import { Scene, Actions } from 'react-native-router-flux';
import { sceneProps, renderTextButton } from '../RouterRenders';
import {
    PersonalInfoPage,
    PersonalInfoEditorPage,
    MyCourseListHistoryPage,
    MyTrainingListHistoryPage,
    MyReadListHistoryPage,
    MyExamListHistoryPage,
    Setting,
    PointsPage,
    Contributes,
    About,
    RecommendTabs,
    RecommendDetail,
    MyStudyPeriodListPage,
    MyStudyPeriodDetailPage,
    MyCareerListPage,
    MyCareerDetailPage,
    FeedbackListPage,
    FeedbackDetailPage,
    FeedbackEditPage,
    PhoneEditorPage,
    ApprovedCaseDetailPage,
    ApprovedCaseDetailInfoPage,
    AddOtherApproverPage,
    ApprovingCaseDetailPage,
    SubmitCaseRecordsDetailPage,
    DraftCaseRecordDetailPage,
    LecturerSubmitAndApproveTabs,
    ApprovedLecturerDetailPage,
    ApprovingLecturerPage,
    ApprovedLecturerDetailInfoPage,
    SearchApproverListPage,
    LecturerRecordsTabs,
    LecturerInfoTabs,
    AddApproverSucPage,
    MyHonor,
    ClassesListPage,
    HonorPage,
    CommentListPage,
    CommentDetailPage,
    SearchMultiApproverListPage,
    SubmitAndApproveTabs,
    RecordsTabs,
    SubmitterInfoPage,
    ApprovalDetailPage,
} from '../../view/personal';
import { ToLearnPage } from '../../view/toLearn';
import { MessageHomePage } from '../../view/message';
import MessageHome from '../../view/personal/message/MessageHome';
import NoticeHomePage from '../../view/personal/message/NoticeHomePage';
import NoticeListPage from '../../view/personal/message/list/NoticeListPage';
import NoticeSearchPage from '../../view/personal/message/search/NoticeSearchPage';
import CollectionListPage from '../../view/personal/collection/CollectionListPage';
import MessageDetail from '../../view/personal/systemnotice/MessageDetail';
import NoticeApprovalDetailPage from '../../view/personal/systemnotice/NoticeApprovalDetailPage';
import SeeMorePlates from '../../view/personal/systemnotice/SeeMorePlates';
import NoticeApprovalPage from '../../view/personal/systemnotice/NoticeApprovalPage';
import NoticeInfoPage from '../../view/personal/systemnotice/NoticeInfoPage';

/**
 * @private
 * @description 打开(提交与审批)个人提交记录按钮
 */
const renderShowRecordsButton = (props) => {
    return renderTextButton(() => {
        Actions.show('recordsTabs', { sourceType: props.sourceType });
    }, '个人提交记录');
};

/**
 * @private
 * @description 打开(讲师管理)个人提交记录按钮
 */
const renderShowLecturerRecordsButton = () => {
    return renderTextButton(() => {
        Actions.show('lecturerRecordsTabs');
    }, '个人提交记录');
};

export default [
    <Scene key="myRecommendTabs" component={RecommendTabs} title="我的推荐" {...sceneProps} />,
    <Scene key="recommendDetail" component={RecommendDetail} title="推荐详情" {...sceneProps} />,
    // (提交与审批)我的审批
    <Scene key="approvalTabs" component={SubmitAndApproveTabs} title="我的审批" {...sceneProps} renderRightButton={renderShowRecordsButton} />,
    <Scene key="recordsTabs" component={RecordsTabs} title="个人提交记录" {...sceneProps} />,

    // (案例管理)我的审批
    <Scene key="approvedCaseDetail" component={ApprovedCaseDetailPage} title="审批详情" {...sceneProps} />,
    <Scene key="caseDetail" component={ApprovedCaseDetailPage} title="案例详情" {...sceneProps} />,
    <Scene key="approvingCaseDetail" component={ApprovingCaseDetailPage} title="审批详情" {...sceneProps} />,
    <Scene key="approvedCaseInfoDetail" component={ApprovedCaseDetailInfoPage} title="基本信息" {...sceneProps} />,
    //添加审批人
    <Scene key="addApprover" component={AddOtherApproverPage} title="审批详情" {...sceneProps} />,
    <Scene key="addApproverForRecords" component={AddOtherApproverPage} title="选择审批人" {...sceneProps} />,
    <Scene key="searchApprover" component={SearchApproverListPage} title="审批详情" {...sceneProps} />,
    <Scene key="searchMultiApprover" component={SearchMultiApproverListPage} title="审批详情" {...sceneProps} />,
    <Scene key="addAndsearchApprover" component={SearchApproverListPage} title="添加审批人" {...sceneProps} />,
    <Scene key="addApproverSuc" component={AddApproverSucPage} title="审批详情" {...sceneProps} />,
    // (案例管理)个人提交记录
    <Scene key="caseSubmittedRecordsDetail" component={SubmitCaseRecordsDetailPage} title="个人提交记录" {...sceneProps} />,
    <Scene key="caseDraftRecordsDetail" component={DraftCaseRecordDetailPage} title="个人提交记录" {...sceneProps} />,
    // (讲师管理)我的审批
    <Scene key="lecturerApprovalTabs" component={LecturerSubmitAndApproveTabs} title="我的审批" {...sceneProps} renderRightButton={renderShowLecturerRecordsButton} />,
    <Scene key="approvedLecturerDetail" component={ApprovedLecturerDetailPage} title="我的审批" {...sceneProps} />,
    <Scene key="approvingLecturerDetail" component={ApprovingLecturerPage} title="审批详情" {...sceneProps} />,
    <Scene key="approvedLecturerInfoDetail" component={ApprovedLecturerDetailInfoPage} title="我的审批-基本信息" {...sceneProps} />,
    // (讲师管理)个人提交记录
    <Scene key="lecturerRecordsTabs" component={LecturerRecordsTabs} title="个人提交记录" {...sceneProps} />,
    <Scene key="lecturerInfoTabs" component={LecturerInfoTabs} title="讲师信息" {...sceneProps} hideNavBar />,

    // （导师管理）提交人信息页
    <Scene key="mentorApprovalDetail" component={ApprovalDetailPage} title="审批详情" {...sceneProps} />,
    <Scene key="mentorSubmitterInfo" component={SubmitterInfoPage} title="提交人基本信息" {...sceneProps} />,

    <Scene
        key="myCourseListHistory"
        component={MyCourseListHistoryPage}
        title="在线学习记录"
        {...sceneProps}
    />,
    <Scene
        key="myTrainingListHistory"
        component={MyTrainingListHistoryPage}
        title="培训管理学习记录"
        {...sceneProps}
    />,
    <Scene
        key="myReadListHistory"
        component={MyReadListHistoryPage}
        title="阅读记录"
        {...sceneProps}
    />,
    <Scene
        key="myExamListHistory"
        component={MyExamListHistoryPage}
        title="我的已考记录"
        {...sceneProps}
    />,
    <Scene
        key="personalInfo"
        component={PersonalInfoPage}
        navigationBarStyle={{ backgroundColor: 'transparent' }}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="personalInfoEditor"
        component={PersonalInfoEditorPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene key="setting" title="设置" component={Setting} {...sceneProps} />,
    <Scene key="about" title="关于" component={About} {...sceneProps} hideNavBar />,
    <Scene key="pointsFlow" component={PointsPage} title="积分历史" {...sceneProps} />,
    <Scene key="contributesFlow" component={Contributes} title="贡献详情" {...sceneProps} />,
    <Scene
        key="studyPeriodList"
        component={MyStudyPeriodListPage}
        title="学时概览"
        {...sceneProps}
    />,
    <Scene
        key="studyPeriodDetail"
        component={MyStudyPeriodDetailPage}
        title="学时详情"
        {...sceneProps}
    />,
    <Scene key="myCareerList" component={MyCareerListPage} title="职业班" {...sceneProps} />,
    <Scene
        key="myCareerDetail"
        component={MyCareerDetailPage}
        title="我的职业班"
        {...sceneProps}
    />,
    <Scene key="feedbackList" component={FeedbackListPage} title="意见反馈" {...sceneProps} />,
    <Scene
        key="feedbackDetail"
        component={FeedbackDetailPage}
        title="我的反馈详情"
        {...sceneProps}
    />,
    <Scene
        key="feedbackEdit"
        component={FeedbackEditPage}
        title="意见反馈"
        {...sceneProps}
        hideNavBar
    />,
    <Scene key="phoneEditor" title="修改手机号" component={PhoneEditorPage} {...sceneProps} />,

    <Scene key='myHonor' title='我的荣誉榜' component={MyHonor} {...sceneProps} hideNavBar />,

    <Scene key='myClass' title='我的课程库' component={ClassesListPage} {...sceneProps} />,
    <Scene key='classRecord' title='我的授课记录' component={ClassesListPage} {...sceneProps} />,
    <Scene key='myCertificate' title='我的证书' component={HonorPage} {...sceneProps} />,
    <Scene key='mySubscribe' title='我的订阅' component={ToLearnPage} {...sceneProps} />,
    //     <Scene
    //     key="tolearn"
    //     component={ToLearnPage}
    //     title=""
    //     iconName="tolearn"
    //     icon={SeaTabMenu}
    //     {...sceneNoItemProps}
    // />
    <Scene key="commentCheckList" component={CommentListPage} title="评论审核" {...sceneProps} />,
    <Scene key="commentDetail" component={CommentDetailPage} title="评论详情" {...sceneProps} />,

    <Scene key="noticeMessage" component={NoticeHomePage} title="通知" {...sceneProps} />,
    <Scene key="message" component={MessageHome} title="消息中心" {...sceneProps} hideNavBar />,
    <Scene key="noticeList" component={NoticeListPage} title="消息中心" {...sceneProps} />,
    <Scene key="noticeSearch" component={NoticeSearchPage} title="消息中心" {...sceneProps} />,
    <Scene key="myCollection" component={CollectionListPage} title="我的收藏" {...sceneProps} />,
    //系统消息审批
    <Scene key='messageDetail' component={MessageDetail} title='审批详情' {...sceneProps} />,
    <Scene key='noticeApproval' component={NoticeApprovalPage} title='审批详情' {...sceneProps} />,
    <Scene key='noticeApprovalDetail' component={NoticeApprovalDetailPage} title='审批详情' {...sceneProps} />,
    <Scene key='seeMore' component={SeeMorePlates} title='系统消息发送范围' {...sceneProps} />,
    <Scene key='noticeInfoPage' component={NoticeInfoPage} title='个人提交记录' {...sceneProps} />,
];

