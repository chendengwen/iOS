/**
 * @author xukj
 * @date 2018/11/01
 * @description Deprecated 已废弃router
 * 为了兼容历史代码，未来会删除
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';

export default [];
