/**
 * @author xukj
 * @date 2018/11/01
 * @description ExamRouters 考试router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {
    TestResultPage,
    TestPaperDescPage,
    TestPaperTestPage,
    TestResourcePaperListPage,
    TestPaperReviewPage,
    TestPaperListPage,
    TestApprovePage,
    TestPaperApprovePage,
} from '../../view/examination';

/**
 * @description 路由
 */
export default [
    <Scene key="testpaperDesc" title="试卷信息" component={TestPaperDescPage} {...sceneProps} />,
    <Scene key="testResult" title="考试结果" component={TestResultPage} {...sceneProps} />,
    <Scene
        key="testpaper"
        title="答题中"
        component={TestPaperTestPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="testResourcePaperList"
        component={TestResourcePaperListPage}
        title="考试"
        {...sceneProps}
    />,
    <Scene
        key="testPaperReview"
        component={TestPaperReviewPage}
        title="考试答案回顾"
        {...sceneProps}
    />,
    <Scene key="testCommonPaperList" component={TestPaperListPage} title="考试" {...sceneProps} />,
    <Scene key="testApprove" title="考试审批" component={TestApprovePage} {...sceneProps} />,
    <Scene key="testRecords" title="个人提交记录" component={TestApprovePage} {...sceneProps} />,
    <Scene
        key="testPaperApprove"
        title="试卷查看"
        component={TestPaperApprovePage}
        {...sceneProps}
    />,
];
