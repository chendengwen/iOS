/**
 * @author ouyfm
 * @date 2020/06/20
 * @description caseRouter 案例
 */

import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {   
    CaseEvaluateDetailPage,
    AddReplyPage,
    EvaluateReplyDetailPage
} from '../../view/evaluate';

/**
 * @description 路由
 */
export default [
    <Scene
        key="caseEvaluateDetailPage"
        title="案例评价详情"
        component={CaseEvaluateDetailPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="caseAddReply"
        title="评论及回复页面"
        component={AddReplyPage}
        {...sceneProps}
        hideNavBar
    />,
   <Scene
        key="caseAnswerReplyPage"
        title="回复详情"
        component={EvaluateReplyDetailPage}
        {...sceneProps}
        // hideNavBar
    />,
];
