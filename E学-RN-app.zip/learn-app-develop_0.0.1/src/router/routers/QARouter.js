/**
 * @author xukj
 * @date 2018/11/01
 * @description QARouter 问吧router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {
    QAQuestionDetailPage,
    QAAddQuestionPage,
    QAAddAnswerPage,
    QAAnswerReplyPage,
    QAAddReplyPage,
} from '../../view/QA';

/**
 * @description 路由
 */
export default [
    <Scene
        key="qaQuestionDetail"
        title="问题详情"
        component={QAQuestionDetailPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="qaAddAnswer"
        title="回答问题"
        component={QAAddAnswerPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene
        key="qaAddQuestion"
        title="提问"
        component={QAAddQuestionPage}
        {...sceneProps}
        hideNavBar
    />,
    <Scene 
        key="qaReplyList" 
        title="全部回复" 
        component={QAAnswerReplyPage} 
        {...sceneProps} 
    />,
    <Scene
        key="qaAddReply"
        title="回答问题"
        component={QAAddReplyPage}
        {...sceneProps}
        hideNavBar
    />,
];
