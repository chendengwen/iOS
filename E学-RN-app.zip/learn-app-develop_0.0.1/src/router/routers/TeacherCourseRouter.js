/**
 * @author xukj
 * @date 2018/11/01
 * @description TeacherCourseRouter 师课router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import { SearchHomePage,TeacherList,TeacherDetail,ColumnDetail} from '../../view/teacherCourse';

/**
 * @description 路由
 */
export default [
    <Scene key="teacherCourseHome" component={SearchHomePage} title="师课" {...sceneProps} hideNavBar/>,
    <Scene key="teacherCourseList" component={TeacherList} title="讲师列表" {...sceneProps} />,
    <Scene key="teacherCourseDetail" component={TeacherDetail}  title="讲师详情" {...sceneProps} hideNavBar/>,
    <Scene key="teacherCourseColumnDetail" component={ColumnDetail} title="课程详情" {...sceneProps} />,
];
