/**
 * @author xukj
 * @date 2018/11/01
 * @description Questionnaire 问卷router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {
    QResourceListPage,
    QPaperDescPage,
    QDetailPage,
    QProjectDescPage,
    QProjectToLearnListPage,
    QProjectHistoryListPage,
    QuestionApprovePage,
    QuestionReviewPage,
    QuestionPaperApprovePage,
} from '../../view/Questionnaire';

export default [
    // e课、面授、首页栏目中的问卷列表
    <Scene
        key="questionnaireList"
        title="问卷列表"
        component={QResourceListPage}
        {...sceneProps}
    />,
    <Scene key="QDesc" title="问卷信息" component={QPaperDescPage} {...sceneProps} hideNavBar />,
    <Scene
        key="QProjectDesc"
        title="问卷项信息"
        component={QProjectDescPage}
        {...sceneProps}
        hideNavBar
    />,
    // 填写问卷页
    <Scene key="QDetail" title="填写问卷" component={QDetailPage} {...sceneProps} hideNavBar />,
    // 我的计划列表
    <Scene
        key="QProjectToLearn"
        title="我的计划"
        component={QProjectToLearnListPage}
        {...sceneProps}
    />,
    <Scene
        key="QProjectHistory"
        title="我的问卷"
        component={QProjectHistoryListPage}
        {...sceneProps}
    />,
    <Scene
        key="QApprove"
        title="问卷审批"
        component={QuestionApprovePage}
        {...sceneProps}
    />,
    <Scene
        key="QPaperApprove"
        title="问卷试题"
        component={QuestionPaperApprovePage}
        {...sceneProps}
    />,
    <Scene
        key="QReview"
        title="问题预览"
        component={QuestionReviewPage}
        {...sceneProps}
    />
];
