/**
 * @author xukj
 * @date 2018/11/01
 * @description 账户模块的router
 * 账户模块是一个功能独立的模块，因此带有自己的stack
 */
import React from 'react';
import { Scene, Stack, ActionConst } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import {
    PwdLogin,
    SelectOrg,
    DomainActive,
    OutworkerActive,
    Identify,
    GetPhoneNum,
} from '../../view/login';

export default (
    <Stack key="account" hideNavBar headerMode="screen" type={ActionConst.RESET}>
        <Scene
            key="getPhoneNum"
            title="getPhoneNum"
            component={GetPhoneNum}
            {...sceneProps}
            hideNavBar
            initial
        />
        <Scene key="identify" title="输入验证码" component={Identify} {...sceneProps} hideNavBar />
        <Scene key="pwdLogin" title="输入验证码" component={PwdLogin} {...sceneProps} hideNavBar />
        <Scene
            key="selectOrg"
            title="请选择登录机构"
            component={SelectOrg}
            {...sceneProps}
            hideNavBar
        />
        <Scene
            key="domainPhoneActive"
            title="内勤手机号激活"
            component={DomainActive}
            {...sceneProps}
            hideNavBar
        />
        <Scene
            key="outworkerActive"
            title="内勤手机号激活"
            component={OutworkerActive}
            {...sceneProps}
            hideNavBar
        />
    </Stack>
);
