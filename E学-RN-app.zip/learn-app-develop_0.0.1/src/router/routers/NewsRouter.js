/**
 * @author xukj
 * @date 2018/11/01
 * @description NewsRouter 新闻router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import { NewsDetailPage, NewsListPage } from '../../view/news';

/**
 * @description 路由
 */
export default [
    <Scene key="newsList" component={NewsListPage} title="新闻" {...sceneProps} />,
    <Scene key="newsDetail" component={NewsDetailPage} title="新闻详情" {...sceneProps} />,
];
