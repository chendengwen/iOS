/**
 * @author xukj
 * @date 2018/11/01
 * @description SubjectRouters 专题router
 */
import React from 'react';
import { Scene } from 'react-native-router-flux';
import { sceneProps } from '../RouterRenders';
import { SubjectRecommendPage, SubjectDetailPage } from '../../view/subject';

/**
 * @description 路由
 */
export default [
    <Scene
        key="subjectRecommend"
        component={SubjectRecommendPage}
        title="推荐专题"
        {...sceneProps}
    />,
    <Scene key="subjectDetail" component={SubjectDetailPage} title="专题课程" {...sceneProps} />,
];
