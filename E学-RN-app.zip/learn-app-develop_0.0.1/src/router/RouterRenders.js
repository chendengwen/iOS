/**
 * @author xukj
 * @date 2018/11/01
 * @description RouterStyles 路由样式定义
 * 因为app端的特性，导航栏是独立于各个界面的；导航栏是界面的外层框架，因此如果在特定界面修改导航栏是一件非常困难的事情，一般会有2种方式；
 * 其一、隐藏导航栏，在需要的界面上自行绘制一个；优点是定制化高，自由度高；缺点是很容易发生导航栏样式不统一，重复代码过多；
 * 其二、判断当前的界面，然后在导航栏上添加；优点是样式统一；缺点是自由度低，代码离散严重；
 * 这里提供的各种render方法，使用的就是上述第二种方案
 */
import React from 'react';
import { StyleSheet, Platform } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { SeaColor, SeaStyle } from '../asserts';
import { SeaNavigationItems } from '../components';

/**
 * 导航栏样式
 */
export const navigationBarStyle = {
    backgroundColor: SeaColor.newMain,
    borderBottomWidth: 0,
};

/**
 * 底部tab样式
 */
export const tabBarStyle = {
    backgroundColor: 'white',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: SeaColor.parting_line,
};

/**
 * 标题样式
 */
export const titleStyle = SeaStyle.navTitle;

/**
 * scene单个页面的样式配置
 * 带左边按钮
 * 因为react-native-router-flux有bug，在android上标题默认左对齐方式：左边按钮-标题-右边按钮
 */
export const sceneProps = {
    titleStyle:
        Platform.OS == 'android'
            ? { flex: 1, textAlign: 'center', paddingRight: 44, ...titleStyle }
            : titleStyle,
    renderBackButton: () => renderBackButton(),
    hideNavBar: false,
};

/**
 * scene单个页面的样式配置
 * 不带左边/右边按钮
 * 因为react-native-router-flux有bug，在android上标题默认左对齐方式：左边按钮-标题-右边按钮
 */
export const sceneNoItemProps = {
    titleStyle:
        Platform.OS == 'android' ? { flex: 1, textAlign: 'center', ...titleStyle } : titleStyle,
    hideNavBar: false,
};

/**
 * 导航栏通用返回键
 * @param {function} onPress 返回按钮，默认pop
 * @return {function}
 */
export function renderBackButton(onPress = Actions.pop) {
    return SeaNavigationItems.renderBackButton(onPress);
}

/**
 * 导航栏通用关闭按钮
 * @param {function} onPress 返回按钮，默认pop
 * @return {function}
 */
export function renderCloseButton(onPress = Actions.pop) {
    return SeaNavigationItems.renderCloseButton(onPress);
}

/**
 * 导航栏文字按钮
 * @param {function} onPress 点击
 * @param {string} title 文字
 * @return {function}
 */
export function renderTextButton(onPress, title) {
    return SeaNavigationItems.renderTextButton(onPress, title);
}

/**
 * 导航栏图标按钮
 * @param {function} onPress 点击
 * @param {string} name 图标名称
 * @return {function}
 */
export function renderIconButton(onPress, name) {
    return SeaNavigationItems.renderIconButton(onPress, name);
}
