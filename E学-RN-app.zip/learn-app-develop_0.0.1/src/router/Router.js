import React from 'react';
import { StyleSheet, Platform } from 'react-native';
import { Scene, Router, Modal, ActionConst, Stack, Tabs } from 'react-native-router-flux';
import { connect } from 'react-redux';
import { AC_SaveNetCtrl } from '../redux/actions/setting';
import { SettingStorageService } from '../servie';
import { SeaScale, SeaColor } from '../asserts';
import { SeaDevice } from '../util';
import { SeaTabMenu } from '../components';
// style
import { navigationBarStyle, tabBarStyle, sceneNoItemProps } from './RouterRenders';
// base page
import { ToLearnPage } from '../view/toLearn';
import { PersonalView } from '../view/personal';
import { Home as HomePage } from '../view/home';
// routers
import GuideRouters from './routers/GuideRouter';
import QARouters from './routers/QARouter';
import AccountRouters from './routers/AccountRouter';
import PersonalRouters from './routers/PersonalRouter';
import NewsRouters from './routers/NewsRouter';
import ExamRouters from './routers/ExamRouters';
import SubjectRouters from './routers/SubjectRouters';
import QuestionnaireRouters from './routers/QuestionnaireRouter';
import ResourceRouters from './routers/ResourceRouter';
import OtherRouters from './routers/OtherRouter';
import DeprecatedRouters from './routers/DeprecatedRouter';
import CommonRouters from './routers/CommonRouter';
import TeacherCourseRouters from './routers/TeacherCourseRouter';
import { MessageHomePage } from '../view/message';
import CaseRouter from './routers/CaseRouter'
import TeacherCenterRouter from './routers/TeacherCenterRouter';
import { SubjectChannelListPage } from '../view/resource';
import Learn from '../view/learn/Learn';
import { SubjectListPage } from '../view/subject';

@connect(undefined, mapDispatchToProps)
export default class AppRouters extends React.PureComponent {
    constructor() {
        super();
    }

    componentDidMount() {
        SettingStorageService.loadSettingNetCtrlPromise().then(
            ret => {
                this.props.saveNetCtrl(ret);
            },
            rejct => {
                this.props.saveNetCtrl(false);
            }
        );
    }

    render() {
        return (
            <Router navigationBarStyle={navigationBarStyle}>
                <Modal headerMode="screen">
                    {GuideRouters}
                    {AccountRouters}
                    <Stack key="main" type={ActionConst.RESET} headerMode="screen" hideNavBar>
                        {ResourceRouters}
                        {QARouters}
                        {NewsRouters}
                        {ExamRouters}
                        {SubjectRouters}
                        {QuestionnaireRouters}
                        {PersonalRouters}
                        {OtherRouters}
                        {DeprecatedRouters}
                        {CommonRouters}
                        {TeacherCourseRouters}
                        {CaseRouter}
                        {TeacherCenterRouter}
                        {this._tabPages()}
                    </Stack>
                </Modal>
            </Router>
        );
    }

    /*
     * @private
     * @description tab
     */
    _tabPages() {
        return (
            <Tabs
                key="tab"
                type={ActionConst.RESET}
                initial
                hideNavBar
                lazy
                tabBarStyle={tabBarStyle}
                showLabel={false}
            >
                <Scene
                    key="home"
                    component={HomePage}
                    type={ActionConst.REFRESH}
                    title="首页"
                    iconName="home"
                    icon={SeaTabMenu}
                    initial
                    {...sceneNoItemProps}
                    hideNavBar
                />
                <Scene
                    key="subject"
                    component={SubjectListPage}
                    title="专题"
                    iconName="subject"
                    icon={SeaTabMenu}
                    {...sceneNoItemProps}
                    hideNavBar
                />
                {/* <Scene
                    key="tolearn"
                    component={ToLearnPage}
                    title="计划"
                    iconName="tolearn"
                    icon={SeaTabMenu}
                    {...sceneNoItemProps}
                /> */}
                {/* <Scene
                    key="message"
                    component={MessageHomePage}
                    title="消息"
                    iconName="message"
                    icon={SeaTabMenu}
                    {...sceneNoItemProps}
                /> */}
                <Scene
                    key="learn"
                    component={Learn}
                    title="学吧"
                    iconName="learn"
                    icon={SeaTabMenu}
                    {...sceneNoItemProps}
                    hideNavBar
                />
                <Scene
                    key="personal"
                    component={PersonalView}
                    title="我的"
                    iconName="personal"
                    icon={SeaTabMenu}
                    {...sceneNoItemProps}
                    hideNavBar
                />
            </Tabs>
        );
    }
}

// /**
//  * 样式
//  */
// const styles = StyleSheet.create({
//     tabBarStyle: {
//         backgroundColor: SeaColor.back,
//         borderTopWidth: StyleSheet.hairlineWidth,
//         borderTopColor: SeaColor.parting_line,
//         justifyContent: 'space-between',
//         alignItems: 'flex-start',
//         height: getTabbarHeight(),
//         marginHorizontal: 10 * SeaScale.scaleHorizontal,
//     },
//     navigationBarStyle: {
//         backgroundColor: SeaColor.main,
//         borderBottomWidth: 0,
//         ...Platform.select({
//             ios: {
//                 height: 44 + SeaDevice.iosStatusBarHeight(),
//                 paddingTop: SeaDevice.isIPhoneX() ? SeaDevice.iosStatusBarHeight() / 2 : 0,
//             },
//             android: {
//                 height: 52,
//             },
//         }),
//     },
//     mainTitle: {
//         justifyContent: 'center',
//         alignItems: 'center',
//         color: 'white',
//     },
// });

// /**
//  * router样式定义
//  */
// const getSceneStyle = (/* NavigationSceneRendererProps */ props, computedProps) => {
//     const style = {
//         flex: 1,
//         backgroundColor: '#fff',
//         shadowColor: null,
//         shadowOffset: null,
//         shadowOpacity: null,
//         shadowRadius: null,
//     };
//     if (computedProps.isActive) {
//         style.marginTop = computedProps.hideNavBar
//             ? 0
//             : Platform.OS === 'android'
//             ? 105 * SeaScale.scaleVertical
//             : 44 + SeaDevice.iosStatusBarHeight();
//         style.marginBottom = computedProps.hideTabBar ? 0 : getTabbarHeight();
//     }
//     return style;
// };

/**
 * tab高度
 */
function getTabbarHeight() {
    return SeaDevice.isIPhoneX() ? 54 : 50;
}

function mapDispatchToProps(dispatch) {
    return {
        saveNetCtrl: ctrl => dispatch(AC_SaveNetCtrl(ctrl)),
    };
}
