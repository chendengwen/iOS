/**
 * @author xukj
 * @date 2019/07/25
 * @description Apps
 */
import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { FSLStorage, FSLProvider } from 'react-native-kpframework';
import _ from 'lodash';
import AppRouters from './router/Router';
import configureStore from './redux/store/index';
import configAppWidget from './view/appWidget';
import { SeaColor, SeaScale, SeaStyle } from './asserts';
import { FSLTool } from './util';

export const store = configureStore;
const widgets = configAppWidget();

// //调试时使用chrome发送请求
// GLOBAL.XMLHttpRequest = GLOBAL.originalXMLHttpRequest || GLOBAL.XMLHttpRequest;

// 定义全局需要使用的变量
global._ = _;
global.$color = SeaColor; // will be deprecated in furture
global.$scale = SeaScale; // will be deprecated in furture
global.$style = SeaStyle; // will be deprecated in furture
global.storage = FSLStorage;
global.fsl = FSLTool; // will be deprecated in furture

console;

//生产环境屏蔽log
if (!__DEV__) {
    global.console = {
        assert: () => {},
        info: () => {},
        log: () => {},
        warn: () => {},
        debug: () => {},
        error: () => {},
        trace: () => {},
        group: () => {},
        table: () => {},
    };
}

export default class Apps extends Component {
    constructor() {
        super();
        this.state = {
            isLoading: true,
            store: store,
        };
    }

    componentDidMount() {
        // 注意，所有在app启动时处理的逻辑，app状态变更时处理的逻辑，应该使用widget模块来处理。
        widgets.didAppStart();
        // 取消黄色警告
        console.disableYellowBox = true;
    }

    render() {
        return (
            <Provider store={this.state.store}>
                <FSLProvider>
                    <AppRouters />
                </FSLProvider>
            </Provider>
        );
    }

    componentWillUnmount() {
        widgets.didAppDestroy();
    }
}
