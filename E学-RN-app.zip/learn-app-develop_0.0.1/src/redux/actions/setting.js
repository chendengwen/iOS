/**
 * Created by zk on 2017/7/3.
 */
import * as TYPES from '../types';
import { SettingStorageService } from '../../servie';

//更新2G/3G/4G是否可播放控制
export function AC_SaveNetCtrl(ctrl) {
    return {
        type: TYPES.SAVE_NET_CTRL,
        netCtrl: ctrl,
    };
}

//设置当前所处网络环境
export function AC_SaveNetInfo(networkType) {
    return {
        type: TYPES.SAVE_NET_INFO,
        networkType: networkType,
    };
}

/**
 * 更新2G/3G/4G是否可播放控制
 * @param {*} resourceId
 */
export function AC_SetNetCtrl(ctrl) {
    return dispatch => {
        SettingStorageService.saveSettingNetCtrlPromise(ctrl).then(() =>
            dispatch(AC_SaveNetCtrl(ctrl))
        );
    };
}
