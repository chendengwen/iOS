/**
 * Created by zk on 2017/10/17.
 */
import * as TYPES from '../types';
export const  AC_INIT_STATUS_WATCHER=(watcher)=>{
    return {
        type:TYPES.INIT_AUDIO_STATUS_WATCHER,
        watcher:watcher
    }
}
export const AC_INIT_TIMER=(timer)=>{
    return {
        type:TYPES.INIT_AUDIO_TIMER,
        timer:timer
    }
}
export const AC_UPDATE_STATUS=(status)=>{
    return {
        type:TYPES.UPDATE_AUDIO_STATUS,
        status:status,
    }
}
export const AC_UPDATE_TIME=(time)=>{
    return {
        type:TYPES.UPDATE_AUDIO_TIME,
        time:time
    }
}
export const AC_UPDATE_DURATION=(duration)=>{
    return {
        type:TYPES.UPDATE_AUDIO_DURATION,
        duration:duration
    }
}