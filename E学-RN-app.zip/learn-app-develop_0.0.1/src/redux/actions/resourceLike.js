/**
 * Created by zk on 2017/7/3.
 */
import * as TYPES from '../types';
import { ResourceService } from '../../servie';

//获取点赞状态进行中
const AC_FetchLikeProcessing = () => {
    return {
        type: TYPES.FETCH_LIKE_DOING,
    };
};

//获取点赞状态成功
const AC_FetchLikeSuccess = data => {
    return {
        type: TYPES.FETCH_LIKE_FINISH,
        data: data,
    };
};

//获取点赞状态失败
const AC_FetchLikeFail = status => {
    return {
        type: TYPES.FETCH_LIKE_FAIL,
        status: status,
    };
};

//反转点赞状态进行中
const AC_ToggleLikeProcessing = () => {
    return {
        type: TYPES.TOGGLE_LIKE_DOING,
    };
};

//反转点赞状态成功
const AC_ToggleLikeSuccess = data => {
    return {
        type: TYPES.TOGGLE_LIKE_FINISH,
        data: data,
    };
};

//反转点赞状态失败
const AC_ToggleLikeFail = error => {
    return {
        type: TYPES.TOGGLE_LIKE_FAIL,
        error: error,
    };
};

export function AC_initLikeData() {
    return {
        type: TYPES.INIT_LIKE_DATA,
    };
}

//获取点赞状态数据
export function AC_AsyFetchLikeData(id) {
    return dispatch => {
        dispatch(AC_FetchLikeProcessing());

        ResourceService.getLikeStatusById({ id: id })
            .then(responseJson => dispatch(AC_FetchLikeSuccess(responseJson.data)))
            .catch(status => dispatch(AC_FetchLikeFail(status)));
    };
}

//反转点赞状态
export function AC_AsyToggleLike(id) {
    return dispatch => {
        dispatch(AC_ToggleLikeProcessing());

        ResourceService.toggleLikeStatusById({ id: id })
            .then(responseJson => dispatch(AC_ToggleLikeSuccess(responseJson.data)))
            .catch(error => dispatch(AC_ToggleLikeFail(error)));
    };
}
