import * as TYPES from '../types';
import { ToLearnService, RewardPointsService, CourseService, ResourceService } from '../../servie';

// e课详情相关
// ---

//开始获取课程详情
const AC_FetchCourseDetailProcessing = () => {
    return {
        type: TYPES.FETCH_COURSE_DETAIL_DOING,
    };
};

//获取课程详情成功
const AC_FetchCourseDetailSuccess = data => {
    return {
        type: TYPES.FETCH_COURSE_DETAIL_FINISH,
        data: data,
    };
};

//获取课程详情失败
const AC_FetchCourseDetailFail = error => {
    return {
        type: TYPES.FETCH_COURSE_DETAIL_FAIL,
        error: error,
    };
};

//添加待学中
const AC_AddToLearnProcessing = () => {
    return {
        type: TYPES.ADD_TO_LEARN_DOING,
    };
};

//添加待学成功
const AC_AddToLearnSuccess = () => {
    return {
        type: TYPES.ADD_TO_LEARN_FINISH,
    };
};

//添加待学失败
const AC_AddToLearnFail = error => {
    return {
        type: TYPES.ADD_TO_LEARN_FAIL,
        error: error,
    };
};

//课程历史记录
const AC_RecordCoursePlayProcessing = () => {
    return {
        type: TYPES.RECORD_COURSE_PLAY_DOING,
    };
};

//课程历史记录成功
const AC_RecordCoursePlaySuccess = () => {
    return {
        type: TYPES.RECORD_COURSE_PLAY_FINISH,
    };
};

//课程历史记录失败
const AC_RecordCoursePlayFail = error => {
    return {
        type: TYPES.RECORD_COURSE_PLAY_FAIL,
        error: error,
    };
};
//在线项目开始填写问卷
export function AC_START_QA() {
    return {
        type: TYPES.START_QA,
    };
}
//问卷填写完成
export function AC_FINISH_QA() {
    return {
        type: TYPES.FINISH_QA,
    };
}

//播放下一个视频
export function AC_PLAY_NEXT(data) {
    return {
        type: TYPES.PLAY_NEXT_VIDEO,
        data: data,
    };
}

//视频播放切换全屏
export function AC_SET_FULL(isFull) {
    return {
        type: TYPES.SET_FULL_SCREEN,
        data: isFull,
    };
}

//异步获取课程详情
export function AC_AsyFetchCourseDetailData(courseId) {
    return dispatch => {
        dispatch(AC_FetchCourseDetailProcessing());
        CourseService.getCourseById(courseId)
            .then(responseJson => {
                if (responseJson.code == '000000') {
                    dispatch(AC_FetchCourseDetailSuccess(responseJson.data))
                }else{
                    dispatch(AC_FetchCourseDetailFail(responseJson.msg)) 
                }
            }).catch(error => dispatch(AC_FetchCourseDetailFail(error)));
    };
}

//课程加入待学
export function AC_ADD_TO_LEARN(resourceId) {
    return dispatch => {
        dispatch(AC_AddToLearnProcessing());
        ToLearnService.addToLearn(resourceId, null, false)
            .then(() => dispatch(AC_AddToLearnSuccess()))
            .catch(error => dispatch(AC_AddToLearnFail(error)));
    };
}

export function AC_InitCourse() {
    return {
        type: TYPES.INIT_COURSE,
    };
}

//课程记录
export function AC_ADD_TO_PLAY(resource) {
    return {
        type: TYPES.ADD_TO_PLAY,
        data: resource,
    };
}
//重置jump属性
export function AC_INIT_JUMP() {
    return {
        type: TYPES.INIT_JUMP,
    };
}
//跳转视频播放器
export function AC_INIT_NEW_PLAYER() {
    return {
        type: TYPES.INIT_NEW_PLAYER,
    };
}
export function AC_ADD_TO_PLAY_WITHOUT_JUMP(resource) {
    return {
        type: TYPES.ADD_TO_PLAY_WITHOUT_JUMP,
        data: resource,
    };
}

// 课件完成
// ---

//上报课件完成
const AC_UpdateFinishStatusDoing = () => {
    return {
        type: TYPES.UPDATE_FINISH_STATUS_DOING,
    };
};

const AC_UpdateFnishStatusDone = () => {
    return {
        type: TYPES.UPDATE_FINISH_STATUS_DONE,
    };
};

const AC_UpdateFinishStatusFail = error => {
    return {
        type: TYPES.UPDATE_FINISH_STATUS_FAIL,
        error: error,
    };
};

/**
 * 更新完成
 * @param {any} payload
 */
export function AC_UpdateFinishStatus(payload) {
    return dispatch => {
        dispatch(AC_UpdateFinishStatusDoing());
        if (payload.type && payload.type == '4') {
            RewardPointsService.reportCourseFinish(payload)
                .then(() => dispatch(AC_UpdateFnishStatusDone()))
                .catch(error => dispatch(AC_UpdateFinishStatusFail(error)));
        } else {
            RewardPointsService.reportPlayFinish(payload)
                .then(() => dispatch(AC_UpdateFnishStatusDone()))
                .catch(error => dispatch(AC_UpdateFinishStatusFail(error)));
        }
    };
}

// 完成状态
// ---

const AC_SetFinishState = data => {
    return {
        type: TYPES.SET_COURSE_FINISH_STATE,
        data,
    };
};

/**
 * 获取完成情况
 * @param {string} resourceId
 */
export function AC_FetchFinishStatus(resourceId) {
    return dispatch => {
        ResourceService.getResourceFinishStatus(resourceId)
            .then(response => dispatch(AC_SetFinishState(response)))
            .catch(error => { });
    };
}

/**
 * 重置问卷完成状态
 * @param {string} resourceId
 */
export function AC_ClearQuestionFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishQuestionnaire: true }));
}

/**
 * 重置考试完成状态
 * @param {string} resourceId
 */
export function AC_ClearExamFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishPaper: true }));
}

/**
 * 重置评论完成状态
 * @param {string} resourceId
 */
export function AC_ClearCommentFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishComment: true }));
}
