/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-07 16:04:42
 */
/**
 * @author xukj
 * @date 2018/12/05
 * @description teachers redux action 讲师、班主任信息
 */
import { FETCH_TEACHER_DETAIL_FINISH, INIT_TEACHERS, FETCH_SCHEDULE_FINISH } from '../types';
import { UserService, TrainingService } from '../../servie';

/**
 * 讲师信息
 * @param {array} data 讲师信息
 */
const AC_FetchTeacherFinish = data => {
    return {
        type: FETCH_TEACHER_DETAIL_FINISH,
        payload: data,
    };
};

/**
 * 大纲
 * @param {object} data 大纲
 */
const AC_FetchScheduleFinish = data => {
    return {
        type: FETCH_SCHEDULE_FINISH,
        payload: data,
    };
};

/**
 * 重置
 */
const AC_Init = () => {
    return {
        type: INIT_TEACHERS,
    };
};

/**
 * 获取讲师信息
 * @param {array} teacherIds 教师ids
 */
const AC_FetchTeacher = teacherIds => {
    return dispatch => {
        UserService.getTeacherDetails(teacherIds)
            .then(responseJson => {
                dispatch(AC_FetchTeacherFinish(responseJson.data));
            })
            .catch(error => {
                // do nothing
            });
    };
};

/**
 * 获取期次大纲
 * @param {string} classId 期次id
 */
const AC_FetchSchedule = classId => {
    return dispatch => {
        TrainingService.getScheduleByResourceId(classId)
            .then(responseJson => {
                dispatch(AC_FetchScheduleFinish(responseJson.data));
            })
            .catch();
    };
};

/**
 * 初始化讲师、班主任信息
 */
const AC_InitTrainingExtra = () => {
    return dispatch => {
        dispatch(AC_Init());
    };
};

export { AC_FetchTeacher, AC_FetchSchedule, AC_InitTrainingExtra };
