/**
 * Created by zk on 2017/10/17.
 */
import * as TYPES from '../types';
export const  AC_SET_REFRESH_TIME=(param)=>{
    const {category,time}=param;
    return {
        type:TYPES.SET_REFRESH_TIME,
        time:time,
        category:category
    }
};

const  AC_SET_LATEST_TIME_ACTION=(timeObj)=>{
    return {
        type:TYPES.SET_LATEST_TIME,
        timeObj:timeObj,
    }
};

const  AC_RESET_REFRESH_TIME_ACTION=(timeObj)=>{
    return {
        type:TYPES.RESET_REFRESH_TIME,
        timeObj:timeObj,
    }
};

export function AC_SET_LATEST_TIME(timeObj) {
    return dispatch=>dispatch(AC_SET_LATEST_TIME_ACTION(timeObj))
}

export function AC_RESET_REFRESH_TIME(timeObj) {
    return dispatch=>dispatch(AC_RESET_REFRESH_TIME_ACTION(timeObj))
}


