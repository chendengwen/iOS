/**
 * @author xukj
 * @date 2019/11/26
 * @description resourceScore 评分
 */
import * as TYPES from '../types';

/**
 * 设置评价状态
 * @param {*} done
 */
export function AC_SetResourceComment(resourceId, isCommented) {
    return {
        type: TYPES.SET_RESOURCE_COMMENTED,
        payload: { resourceId, isCommented },
    };
}

/**
 * 重置评价状态
 */
export function AC_ResetResourceComment(resourceId) {
    return {
        type: TYPES.RESET_RESOURCE_COMMENTED,
        payload: { resourceId },
    };
}
