/**
 * @author xukj
 * @date 2020/01/13
 * @description message 消息相关
 */
import { SET_MESSAGE_GROUPS, LOADING_MESSAGE_GROUPS, RESET_MESSAGE_GROUPS } from '../types';

function setMessageGroups(data) {
    return {
        type: SET_MESSAGE_GROUPS,
        payload: data,
    };
}

function setLoading(loading) {
    return {
        type: LOADING_MESSAGE_GROUPS,
        payload: loading,
    };
}

function reset() {
    return {
        type: RESET_MESSAGE_GROUPS,
    };
}

/**
 * 是否正在加载
 */
export function AC_LoadingMessageGroups(loading) {
    return dispatch => dispatch(setLoading(loading));
}

/**
 * 更新消息分组信息
 * @param {array} data 消息分组信息
 */
export function AC_SetMessageGroups(data) {
    return dispatch => dispatch(setMessageGroups(data));
}

/**
 * 重置
 */
export function AC_ResetMessageGroup() {
    return dispatch => dispatch(reset());
}
