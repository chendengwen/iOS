/**
 * @author xukj
 * @date 2019/04/08
 * @description trainingClass
 *
 * modify by xukj - 1.28.0
 * 错误的情况下，redux直接储存 error
 */
import * as TYPES from '../types';
import { TrainingService, ResourceService } from '../../servie';

//获取培训班详情信息
const AC_FetchTrainingClassDetailProcessing = () => {
    return {
        type: TYPES.FETCH_TRAINING_CLASS_DETAIL_DOING,
    };
};

//获取培训班详情信息
const AC_FetchTrainingClassDetailSuccess = data => {
    return {
        type: TYPES.FETCH_TRAINING_CLASS_DETAIL_FINISH,
        data: data,
    };
};

//获取培训班详情信息
const AC_FetchTrainingClassDetailFail = error => {
    return {
        type: TYPES.FETCH_TRAINING_CLASS_DETAIL_FAIL,
        error: error,
    };
};

/**
 * 初始化培训班redux
 */
export function AC_InitTrainning() {
    return {
        type: TYPES.INIT_TRAINNING,
    };
}

/**
 * 初始化详情redux
 */
export function AC_InitDetail() {
    return {
        type: TYPES.INIT_DETAIL,
    };
}

/**
 * 获取培训班详情信息
 * @param {string} resourceId 期次id
 */
export function AC_FetchTrainingClassDetail(resourceId) {
    return dispatch => {
        dispatch(AC_FetchTrainingClassDetailProcessing());
        // modify by xukj - Sprint 26
        // 接口更改
        TrainingService.getTraclassDetail(resourceId)
            .then(responseJson => dispatch(AC_FetchTrainingClassDetailSuccess(responseJson.data)))
            .catch(error => dispatch(AC_FetchTrainingClassDetailFail(error)));
    };
}

// 培训班完成情况
// ---

const AC_SetFinishState = data => {
    return {
        type: TYPES.SET_TRAINING_FINISH_STATE,
        data,
    };
};

/**
 * 获取培训班完成情况
 * @param {string} resourceId
 */
export function AC_FetchTrainingFinishStatus(resourceId) {
    return dispatch => {
        ResourceService.getResourceFinishStatus(resourceId)
            .then(response => dispatch(AC_SetFinishState(response.data)))
            .catch(error => {});
    };
}

/**
 * 重置问卷完成状态
 * @param {string} resourceId
 */
export function AC_ClearQuestionFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishQuestionnaire: true }));
}

/**
 * 重置考试完成状态
 * @param {string} resourceId
 */
export function AC_ClearExamFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishPaper: true }));
}

/**
 * 重置评论完成状态
 * @param {string} resourceId
 */
export function AC_ClearCommentFinishState(resourceId) {
    return dispatch => dispatch(AC_SetFinishState({ finishComment: true }));
}
