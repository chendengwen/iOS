/**
 * 考试相关action
 */
import * as TYPES from '../types';
import { PersonalService } from '../../servie'


//获取考试历史数据进行中
let AC_FetchExamHistoryProcessing = () => {
    return {
        type : TYPES.FETCH_EXAMHISTORY_DOING
    }
}

//获取考试历史数据成功
let AC_FetchExamHistorySuccess = (data) => {
    return {
        type : TYPES.FETCH_EXAMHISTORY_FINISH,
        data : data
    }
}

//获取考试历史数据失败
let AC_FetchExamHistoryFail = (status) => {
    return {
        type : TYPES.FETCH_EXAMHISTORY_FAIL,
        status : status
    }
}
