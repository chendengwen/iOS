/**
 * Created by songt2 on 2020/9/3.
 */
import * as TYPES from '../types';
import { ResourceService } from '../../servie';

//获取收藏状态进行中
const AC_FetchFavoriteProcessing = () => {
    return {
        type: TYPES.FETCH_FAVORITE_DOING,
    };
};

//获取收藏状态成功
const AC_FetchFavoriteSuccess = (data) => {
    return {
        type: TYPES.FETCH_FAVORITE_FINISH,
        data: data,
    };
};

//获取收藏状态失败
const AC_FetchFavoriteFail = (status) => {
    return {
        type: TYPES.FETCH_FAVORITE_FAIL,
        status: status,
    };
};

//反转收藏状态进行中
const AC_ToggleFavoriteProcessing = () => {
    return {
        type: TYPES.TOGGLE_FAVORITE_DOING,
    };
};

//反转收藏状态成功
const AC_ToggleFavoriteSuccess = (data) => {
    return {
        type: TYPES.TOGGLE_FAVORITE_FINISH,
        data: data,
    };
};

//反转收藏状态失败
const AC_ToggleFavoriteFail = (error) => {
    return {
        type: TYPES.TOGGLE_FAVORITE_FAIL,
        error: error,
    };
};

export function AC_initFavoriteData() {
    return {
        type: TYPES.INIT_FAVORITE_DATA,
    };
}

//获取收藏状态数据
export function AC_AsyFetchFavoriteData(id, type) {
    return (dispatch) => {
        dispatch(AC_FetchFavoriteProcessing());

        ResourceService.getFavoriteStatus({ businessId: id, businessType: type })
            .then((responseJson) => dispatch(AC_FetchFavoriteSuccess(responseJson.data)))
            .catch((status) => dispatch(AC_FetchFavoriteFail(status)));
    };
}

//反转收藏状态
export function AC_AsyToggleFavorite(id, type) {
    return (dispatch) => {
        dispatch(AC_ToggleFavoriteProcessing());

        ResourceService.toggleFavoriteStatus({ businessId: id, businessType: type })
            .then((responseJson) => dispatch(AC_ToggleFavoriteSuccess(responseJson.data)))
            .catch((error) => dispatch(AC_ToggleFavoriteFail(error)));
    };
}
