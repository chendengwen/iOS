/**
 * Created by zk on 2017/10/27.
 */
import * as TYPES from '../types';
import { PersonalService, CommonService } from '../../servie';

/**
 * 查询个人信息ACTION 及 实现
 */
const AC_FetchMyInfoProcessing = () => {
    return {
        type: TYPES.FETCH_MY_INFO_DOING,
    };
};

const AC_FetchMyInfoSuccess = data => {
    return {
        type: TYPES.FETCH_MY_INFO_FINISH,
        data: data,
    };
};

const AC_FetchMyInfoFail = status => {
    return {
        type: TYPES.FETCH_MY_INFO_FAIL,
        status: status,
    };
};

export function AC_StartLoadingLoginUserInfo() {
    return dispatch => dispatch(AC_FetchMyInfoProcessing());
}

export function AC_FinishLoadingLoginUserInfo(data) {
    return dispatch => dispatch(AC_FetchMyInfoSuccess(data));
}

export function AC_FailLoadingLoginUserInfo(error) {
    return dispatch => dispatch(AC_FetchMyInfoFail(error));
}

/**
 *  修改个人信息ACTION 及 实现
 */

// 修改个人信息 - 进行中
const AC_UpdateMyInfoProcessing = () => {
    return {
        type: TYPES.UPDATE_MY_INFO_DOING,
    };
};

// 修改个人信息 - 成功
const AC_UpdateMyInfoSuccess = data => {
    return {
        type: TYPES.UPDATE_MY_INFO_FINISH,
        data: data,
    };
};

// 修改个人信息 - 失败
const AC_UpdateMyInfoFail = error => {
    return {
        type: TYPES.UPDATE_MY_INFO_FAIL,
        error: error,
    };
};

/**
 * @description 修改个人信息
 * @param
 * @return
 */
export function AC_UpdateMyInfo(infoObject) {
    return dispatch => {
        dispatch(AC_UpdateMyInfoProcessing());
        PersonalService.updateUserInfo(infoObject)
            .then(() => {
                dispatch(AC_UpdateMyInfoSuccess(infoObject));
            })
            .catch(error => {
                dispatch(AC_UpdateMyInfoFail(error));
            });
    };
}

/**
 * @description 上传文件
 * @param
 * @return
 */
export function AC_UploadFile(fileUrl, fileType) {
    return dispatch => {
        dispatch(AC_UpdateMyInfoProcessing());
        const file = {
            uri: fileUrl,
            type: fileType,
            name: Math.round(Math.random() * 100000).toString(),
        };
        CommonService.uploadFileToServer(file)
            .then(responseJson => {
                dispatch(AC_UpdateMyInfo({ userImgId: responseJson.id }));
            })
            .catch(error => {
                dispatch(AC_UpdateMyInfoFail(error));
            });
    };
}
