/**
 * @author xukj
 * @date 2018/12/11
 * @description identify 
 * modify by xukj - 1.24.0
 * 重构登录信息管理的redux，现在分为2部分，一部分为sessionData，一部分为userInfo
 */
import { RESET_LOGINUSER, SET_LOGINUSER_SESSIONDATA, SET_LOGINUSER_USERINFO } from '../types';

const initUser = () => {
    return {
        type: RESET_LOGINUSER,
        payload: null,
    };
};

const setSessionData = (data) => {
    return {
        type: SET_LOGINUSER_SESSIONDATA,
        payload: data,
    };
};

const setUserInfo = (data) => {
    return {
        type: SET_LOGINUSER_USERINFO,
        payload: data,
    };
};


/**
 * 初始化登录信息，即注销
 */
export function AC_ClearLoginUser() {
    return dispatch => dispatch(initUser());
}

/**
 * 设置登录信息
 * @param {object} sessionData 登录信息
 */
export function AC_SetLoginData(sessionData) {
    return dispatch => dispatch(setSessionData(sessionData));
}

/**
 * 设置登录用户信息
 * @param {object} userInfo 用户信息
 */
export function AC_SetLoginUserInfo(userInfo) {
    return dispatch => dispatch(setUserInfo(userInfo));
}