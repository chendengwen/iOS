/**
 * Created by zk on 2017/9/21.
 */
import * as TYPES from '../types';
import { QuestionnaireService } from '../../servie';
let AC_FetchQuestionnaireProcessing = () => {
    return {
        type: TYPES.FETCH_QA_DOING,
    };
};

let AC_FetchQuestionnaireSuccess = data => {
    return {
        type: TYPES.FETCH_QA_FINISH,
        data: data,
    };
};

let AC_FetchQuestionnaireFail = error => {
    return {
        type: TYPES.FETCH_QA_FAIL,
        error: error,
    };
};

export function AC_INIT_QA() {
    return {
        type: TYPES.INIT_QA,
    };
}

export function AC_GetQuestionDetail(id) {
    return dispatch => {
        dispatch(AC_FetchQuestionnaireProcessing());
        QuestionnaireService.getQuestionnairePaperDesc(id)
            .then(responseJson => dispatch(AC_FetchQuestionnaireSuccess(responseJson)))
            .catch(error => dispatch(AC_FetchQuestionnaireFail(error)));
    };
}
