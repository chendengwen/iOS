/**
 * Created by zk on 2018/10/17.
 */
import * as TYPES from '../types';
//设置资源状态
export let AC_SetResourceStatus = (status) => {
    return {
        type : TYPES.SET_PROJECT_STATUS,
        status:status
    }
}
//清除资源状态
export  let AC_ClearResourceStatus = () => {
    return {
        type : TYPES.CLEAR_PROJECT_STATUS,
    }
}

