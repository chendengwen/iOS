/**
 * @author xukj
 * @date 2019/04/08
 * @description comment 评论相关action
 */
import * as TYPES from '../types';
import { ResourceService } from '../../servie';

//获取评论进行中
const AC_FetchCommentProcessing = () => {
    return {
        type: TYPES.FETCH_COMMENT_DOING,
    };
};

//获取评论成功
const AC_FetchCommentSuccess = data => {
    return {
        type: TYPES.FETCH_COMMENT_FINISH,
        data: data,
    };
};

//获取评论失败
const AC_FetchCommentFail = error => {
    return {
        type: TYPES.FETCH_COMMENT_FAIL,
        error: error,
    };
};

//添加评论进行中
const AC_AddCommentProcessing = () => {
    return {
        type: TYPES.ADD_COMMENT_DOING,
    };
};

//添加评论成功
const AC_AddCommentSuccess = data => {
    return {
        type: TYPES.ADD_COMMENT_FINISH,
        data: data,
    };
};

//添加评论失败
const AC_AddCommentFail = error => {
    return {
        type: TYPES.ADD_COMMENT_FAIL,
        error: error,
    };
};

//异步获取数据
export function AC_AsyFetchCommentData(resourceId) {
    return dispatch => {
        dispatch(AC_FetchCommentProcessing());

        ResourceService.getResourceComment({ id: resourceId })
            .then(responseJson => dispatch(AC_FetchCommentSuccess(responseJson)))
            .catch(error => dispatch(AC_FetchCommentFail(error)));
    };
}
