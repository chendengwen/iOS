/**
 * @author xukj
 * @date 2019/08/20
 * @description contribute 贡献值
 */
import * as TYPES from '../types';

/**
 * 初始化我的贡献值
 */
export function AC_InitUserContribute() {
    return { type: TYPES.INIT_USER_CONTRIBUTE };
}

/**
 * 更新我的贡献值
 */
export function AC_UpdateContribute(num) {
    return { type: TYPES.UPDATE_USER_CONTRIBUTE, payload: num };
}
