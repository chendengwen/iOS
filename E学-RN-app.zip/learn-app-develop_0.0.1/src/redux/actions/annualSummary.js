/**
 * @author xukj
 * @date 2019/01/10
 * @description annualSummary 个人总结
 */
import { FETCH_ANNUALSUMMARY_SHOWN_DOING, FETCH_ANNUALSUMMARY_SHOWN_FINISH } from '../types';
import { CommonStorageService } from '../../servie';

const AC_LoadAnnualSummary = () => {
    return {
        type: FETCH_ANNUALSUMMARY_SHOWN_DOING,
    };
};

const AC_FinishAnnualSummary = shown => {
    return {
        type: FETCH_ANNUALSUMMARY_SHOWN_FINISH,
        payload: shown,
    };
};

export function AC_GetAnnualShown() {
    return dispatch => {
        dispatch(AC_LoadAnnualSummary());
        CommonStorageService.loadAnnualSummaryShown().then(shown =>
            dispatch(AC_FinishAnnualSummary(shown))
        );
    };
}
