/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-07 16:01:25
 */
import * as TYPES from '../../types';
import { ToLearnService } from '../../../servie';
import { FSLError } from '../../../util';

//初始化报名状态
export function AC_EnrolInit() {
    return {
        type: TYPES.ENROL_INIT,
    };
}

//报名培训班
const AC_EnrolProcessing = () => {
    return {
        type: TYPES.ENROL_DOING,
    };
};

//排名成功
const AC_EnrolSuccess = message => {
    return {
        type: TYPES.ENROL_FINISH,
        data: message,
    };
};

//报名失败
const AC_EnrolFail = error => {
    return {
        type: TYPES.ENROL_FAIL,
        data: error,
    };
};

// 取消报名
const AC_CancelEnrolProcessing = () => {
    return {
        type: TYPES.CANCELENROL_DOING,
    };
};

// 取消报名成功
const AC_CancelEnrolSuccess = message => {
    return {
        type: TYPES.CANCELENROL_FINISH,
        data: message,
    };
};

// 取消报名失败
const AC_CancelEnrolFail = error => {
    return {
        type: TYPES.CANCELENROL_FAIL,
        data: error,
    };
};

/**
 * 线下培训班报名
 * @param {string} resourceId 面授期次id
 * @param {string} classId 培训班id
 */
export function AC_Enrol(resourceId, classId) {
    return dispatch => {
        dispatch(AC_EnrolProcessing());
        ToLearnService.addToLearn(resourceId, classId, false)
            .then(() => dispatch(AC_EnrolSuccess('报名成功')))
            .catch(error => dispatch(AC_EnrolFail(error)));
    };
}

/**
 * 取消面授期次报名
 * @param {string} resourceId 面授期次id
 */
export function AC_CancelEnrol(resourceId) {
    return dispatch => {
        dispatch(AC_CancelEnrolProcessing());
        ToLearnService.cancelEnrol(resourceId)
            .then(responseJson => {
                if (responseJson.data.status == 0) {
                    dispatch(AC_CancelEnrolSuccess('取消报名成功'));
                } else {
                    dispatch(
                        AC_CancelEnrolFail(new FSLError(responseJson.data.desc, responseJson.data.code))
                    );
                }
            })
            .catch(error => dispatch(AC_CancelEnrolFail(error)));
    };
}
