/**
 * Created by zk on 2017/7/7.
 */
import * as TYPES from '../types';
export const  AC_InitStoreDoing=()=>{
    return {type:TYPES.INIT_STORE_DOING}
}

export const AC_InitStoreFinish=()=>{
    return {type:TYPES.INIT_STORE_FINISH}
}