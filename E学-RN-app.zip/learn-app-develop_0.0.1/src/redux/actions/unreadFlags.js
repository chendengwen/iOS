/**
 * @author xukj
 * @date 2019/04/26
 * @description unreadFlags 未读redux
 */
import { SET_UPGRADE_UNREAD_FLAG, RESET_ALL_UNREAD_FLAG } from '../types';

const setUpgrageUnread = count => {
    return { type: SET_UPGRADE_UNREAD_FLAG, payload: count };
};

const resetAllUnread = () => {
    return { type: RESET_ALL_UNREAD_FLAG };
};

/**
 * 设置升级未读标识
 * @param {number} count 未读数量
 */
export function AC_SetUpgradeUnread(count) {
    return dispatch => dispatch(setUpgrageUnread(count));
}

/**
 * 重置升级未读标识
 */
export function AC_ResetUpgradeUnread() {
    return dispatch => dispatch(setUpgrageUnread(0));
}

/**
 * 重置所有未读标识
 */
export function AC_ResetAllUnread() {
    return dispatch => dispatch(resetAllUnread());
}
