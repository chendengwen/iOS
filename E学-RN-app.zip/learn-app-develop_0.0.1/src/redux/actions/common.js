/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-07 15:24:36
 */
/**
 * @author xukj
 * @date 2019/01/10
 * @description common 通用保存的数据
 */
import { SET_LOGINUSER_ALIAS } from '../types';
import { CommonService } from '../../servie';

const AC_SetLoginUserAlias = alias => {
    return {
        type: SET_LOGINUSER_ALIAS,
        payload: alias,
    };
};

/**
 * 获取登录用户的别名
 */
export function AC_FetchLoginUserAlias() {
    return dispatch => {
        CommonService.getPersonalAlias()
            .then(response => dispatch(AC_SetLoginUserAlias(response.data.alias)))
            .catch();
    };
}
