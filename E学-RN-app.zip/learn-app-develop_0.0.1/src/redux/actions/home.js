import * as TYPES from '../types';
import { NewsService, PersonalService, SubjectService, ResourceService } from '../../servie';

// app横幅
// ---

//获取Banner信息
const AC_FetchBannerProcessing = () => {
    return {
        type: TYPES.FETCH_BANNER_DOING,
    };
};

//获取Banner成功
const AC_FetchBannerSuccess = data => {
    return {
        type: TYPES.FETCH_BANNER_FINISH,
        data: data,
    };
};

//获取Banner失败
const AC_FetchBannerFail = error => {
    return {
        type: TYPES.FETCH_BANNER_FAIL,
        error: error,
    };
};

/**
 * @description 获取首页横幅
 */
export function AC_FetchBanner(plateCode) {
    return dispatch => {
        dispatch(AC_FetchBannerProcessing());
        ResourceService.getADBannerResource(plateCode)
            .then(response => dispatch(AC_FetchBannerSuccess(response.data)))
            .catch(error => dispatch(AC_FetchBannerFail(error)));
    };
}

// app推荐
// ---

//获取推荐资源
const AC_FetchRecommendResourceProcessing = () => {
    return {
        type: TYPES.FETCH_RECOMMEND_RESOURCE_DOING,
    };
};

//获取推荐资源成功
const AC_FetchRecommendResourceSuccess = data => {
    return {
        type: TYPES.FETCH_RECOMMEND_RESOURCE_FINISH,
        data: data,
    };
};

//获取推荐资源失败
const AC_FetchRecommendResourceFail = error => {
    return {
        type: TYPES.FETCH_RECOMMEND_RESOURCE_FAIL,
        error: error,
    };
};

/**
 * @description 获取推荐资源
 * @return {function}
 */
export function AC_FetchRecommendResource(columnType, plateCode) {
    return dispatch => {
        dispatch(AC_FetchRecommendResourceProcessing());
        ResourceService.getRecommendResource(columnType, plateCode)
            .then(response => dispatch(AC_FetchRecommendResourceSuccess(response.data)))
            .catch(error => dispatch(AC_FetchRecommendResourceFail(error)));
    };
}

// 首页新闻
// ---

const AC_FetchTopNewsProcessing = () => {
    return {
        type: TYPES.FETCH_TOPNEWS_DOING,
    };
};

const AC_FetchTopNewsSuccess = data => {
    return {
        type: TYPES.FETCH_TOPNEWS_FINISH,
        data: data,
    };
};

const AC_FetchTopNewsFail = error => {
    return {
        type: TYPES.FETCH_TOPNEWS_FAIL,
        error: error,
    };
};

/**
 * @description 获取新闻信息
 * @return {function}
 */
export function AC_FetchTopNews() {
    return dispatch => {
        dispatch(AC_FetchTopNewsProcessing());
        NewsService.getTopNews()
            .then(responseJson => dispatch(AC_FetchTopNewsSuccess(responseJson.data)))
            .catch(error => dispatch(AC_FetchTopNewsFail(error)));
    };
}

// 首页专题
// ---

const AC_FetchSubjectsProcessing = () => {
    return {
        type: TYPES.FETCH_SUBJECTS_DOING,
    };
};

const AC_FetchSubjectsSuccess = data => {
    return {
        type: TYPES.FETCH_SUBJECTS_FINISH,
        data: data,
    };
};

const AC_FetchSubjectsFail = error => {
    return {
        type: TYPES.FETCH_SUBJECTS_FAIL,
        error: error,
    };
};

/**
 * @description 首页获取专题推荐
 * @return {function}
 */
export function AC_FetchSubjects() {
    return dispatch => {
        dispatch(AC_FetchSubjectsProcessing());
        SubjectService.getSubjectList(1, 5, true)
            .then(responseJson => dispatch(AC_FetchSubjectsSuccess(responseJson.data)))
            .catch(error => dispatch(AC_FetchSubjectsFail(error)));
    };
}

// 首页最新消息
// ---

const AC_FetchLatestNoticeProcessing = () => {
    return {
        type: TYPES.FETCH_LATESTNOTICE_DOING,
    };
};

const AC_FetchLatestNoticeSuccess = data => {
    return {
        type: TYPES.FETCH_LATESTNOTICE_FINISH,
        data: data,
    };
};

const AC_FetchLatestNoticeFail = error => {
    return {
        type: TYPES.FETCH_LATESTNOTICE_FAIL,
        error: error,
    };
};

const AC_RestLatestNoticeAction = () => {
    return {
        type: TYPES.FETCH_LATESTNOTICE_RESET,
    };
};

/**
 * @description 最近的消息
 * @return {function}
 */
export function AC_FetchLatestNotice(latestTime) {
    return dispatch => {
        dispatch(AC_FetchLatestNoticeProcessing());
        PersonalService.getLatestNoticeMessage(latestTime)
            .then(response => dispatch(AC_FetchLatestNoticeSuccess(response)))
            .catch(error => dispatch(AC_FetchLatestNoticeFail(error)));
    };
}

/**
 * @description 重置最近的消息
 * @return {function}
 */
export function AC_ResetLatestNotice() {
    return dispatch => {
        dispatch(AC_RestLatestNoticeAction());
    };
}

// 首页频道列表
// ---

const AC_FetchChannelListProcessing = () => ({ type: TYPES.FETCH_CHANNEL_DOING });
const AC_FetchChannelListSuccess = data => ({ type: TYPES.FETCH_CHANNEL_FINISH, data });
const AC_FetchChannelListFail = error => ({ type: TYPES.FETCH_CHANNEL_FAIL, error });

export function AC_FetchChannelList() {
    return dispatch => {
        dispatch(AC_FetchChannelListProcessing());
        ResourceService.getChannelList()
            .then(response => dispatch(AC_FetchChannelListSuccess(response.data)))
            .catch(error => dispatch(AC_FetchChannelListFail(error)));
    };
    return dispatch => {
        dispatch(AC_FetchChannelListProcessing());
        ResourceService.getChannelList()
            .then(response => dispatch(AC_FetchChannelListSuccess([])))
            .catch(error => dispatch(AC_FetchChannelListFail(error)));
    };
}
