/**
 * @author xukj
 * @date 2019/08/20
 * @description points 我的积分
 * Created by zk on 2017/10/27.
 */
import * as TYPES from '../types';

/**
 * 初始化我的积分值
 */
export function AC_InitUserPoints() {
    return { type: TYPES.INIT_USER_POINTS };
}

/**
 * 更新我的积分值
 */
export function AC_UpdateUserPoints(num) {
    return { type: TYPES.UPDATE_USER_POINTS, payload: num };
}
