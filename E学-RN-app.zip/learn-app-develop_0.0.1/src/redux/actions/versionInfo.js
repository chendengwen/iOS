/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-07 15:16:32
 */
/**
 * @author xukj
 * @date 2018/12/27
 * @description versionInfo
 * modify by xukj - 1.24.0
 * 添加redux管理版本信息
 * Created by zk on 2018/1/4.
 */
import * as TYPES from '../types';
import { UpgradeService, SettingStorageService } from '../../servie';

const AC_FetchVersionProcessing = () => {
    return {
        type: TYPES.FETCH_VERSION_DOING,
    };
};

const AC_FetchVersionSuccess = data => {
    return {
        type: TYPES.FETCH_VERSION_FINISH,
        payload: data,
    };
};

const AC_FetchVersionFail = error => {
    return {
        type: TYPES.FETCH_VERSION_FAIL,
        error: error,
    };
};

const AC_FetchIgnoreVersion = data => {
    return {
        type: TYPES.FETCH_IGNORE_VERSION,
        payload: data,
    };
};

/**
 * 获取版本信息
 * @param {number} build app版本号
 * @param {string} platform 平台 ios/android
 */
export function AC_GetUpgradeVersions(build, platform) {
    return dispatch => {
        dispatch(AC_FetchVersionProcessing());
        UpgradeService.verifyVersion(build, platform)
            .then(response => dispatch(AC_FetchVersionSuccess(response.data)))
            .catch(error => dispatch(AC_FetchVersionFail(error)));
    };
}

/**
 * 设置版本信息数据
 * @param {object} value 版本信息
 */
export function AC_SetUpgradeInfo(value) {
    return dispatch => dispatch(AC_FetchVersionSuccess(value));
}

/**
 * 获取未升级版本
 */
export function AC_GetIgnoreVersion() {
    return dispatch => {
        SettingStorageService.loadIgnoreUpgradeVersion()
            .then(version => dispatch(AC_FetchIgnoreVersion(version)))
            .catch(() => dispatch(AC_FetchIgnoreVersion({})));
    };
}

/**
 * 保存忽略的版本
 * @param {object} version 版本信息
 */
export function AC_SetIgnoreVersion(version) {
    return dispatch => {
        dispatch(AC_FetchIgnoreVersion(version));
        SettingStorageService.saveIgnoreUpgradeVersion(version).then();
    };
}
