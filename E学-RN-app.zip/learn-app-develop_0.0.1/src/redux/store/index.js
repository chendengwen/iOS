'use strict';

import { applyMiddleware, createStore, compose } from 'redux';
import thunk from 'redux-thunk';
import { autoRehydrate, persistReducer } from 'redux-persist';
import { FSLStorage } from 'react-native-kpframework';
import reducers from '../reducers';

// // 日志方法
// const logger = store => next => action => {
//     if (typeof action === 'function') console.log('dispatching a function');
//     else console.log('dispatching', action);
//     let result = next(action);
//     console.log('next state', store.getState());
//     return result;
// };

// // 目前日志过多，非必要的情况下移除redux日志
// // const middlewares = [thunk, logger];
// const middlewares = [thunk];

// const createAppStore = applyMiddleware(...middlewares)(createStore);
// const store = autoRehydrate()(createAppStore)(reducers);

const config = {
    key: 'redux-store',
    storage: FSLStorage,
};

const persisedReduer = persistReducer(config, reducers);
const middlewares = applyMiddleware(thunk);

const store = createStore(persisedReduer, undefined, compose(middlewares));

export default store;
