/**
 * @author xukj
 * @date 2019/06/20
 * @description CourseExtension e课
 */
import { AC_UpdateFinishStatus } from '../actions/course';
import store from '../store';

/**
 * 获取resourceStore
 * @return {*}
 */
function updateFinishState(payload) {
    AC_UpdateFinishStatus(payload)(store.dispatch);
}

export default {
    updateFinishState,
};