/**
 * @author xukj
 * @date 2018/12/11
 * @description MyInfoExtension 个人信息操作
 */
import { AC_StartLoadingLoginUserInfo, AC_FinishLoadingLoginUserInfo, AC_FailLoadingLoginUserInfo } from '../actions/myInfo';
import store from '../store';

/**
 * 开始获取用户信息
 */
function startLoadingUserInfo() {
    AC_StartLoadingLoginUserInfo()(store.dispatch);
}

/**
 * 获取用户信息成功
 * @param {object} userInfo 用户信息
 */
function finishLoadingUserInfo(userInfo) {
    AC_FinishLoadingLoginUserInfo(userInfo)(store.dispatch);
}

/**
 * 获取用户信息失败
 * @param {*} error 错误
 */
function failLoadingUserInfo(error) {
    AC_FailLoadingLoginUserInfo(error)(store.dispatch);
}

export default {
    startLoadingUserInfo,
    finishLoadingUserInfo,
    failLoadingUserInfo,
};