/**
 * @author xukj
 * @date 2019/01/03
 * @description OtherExtensions 
 * 某些界面不绑定redux，但是需要调用action
 */
import { AC_SetUpgradeInfo } from '../actions/versionInfo';
import { AC_FetchLoginUserAlias } from '../actions/common';
import store from '../store';

/**
 * 设置版本信息到redux中
 * @param {object} value 版本信息
 */
function setUpgradeInfo(value) {
    AC_SetUpgradeInfo(value)(store.dispatch);
}

/**
 * 获取登录用户别名
 */
function getLoginUserAlias() {
    return store.getState().commonStore.alias;
}

export default {
    setUpgradeInfo,
    getLoginUserAlias,
};