/**
 * @author xukj
 * @date 2020/01/06
 * @description MessageExtension
 * 某些界面不绑定redux，但是需要调用action
 */

import store from '../store';
import {
    AC_SetMessageGroups,
    AC_LoadingMessageGroups,
    AC_ResetMessageGroup,
} from '../actions/message';

/**
 * 设置版本信息到redux中
 * @param {array} value 消息分组信息
 */
function setGroups(groups) {
    AC_SetMessageGroups(groups)(store.dispatch);
}

function setLoading(loading) {
    AC_LoadingMessageGroups(loading)(store.dispatch);
}

function reset() {
    AC_ResetMessageGroup()(store.dispatch);
}

export default {
    setGroups,
    setLoading,
    reset,
};
