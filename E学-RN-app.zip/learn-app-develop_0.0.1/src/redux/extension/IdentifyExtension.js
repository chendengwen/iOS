/**
 * @author xukj
 * @date 2018/12/11
 * @description IdentifyExtension 用户登录信息操作
 */
import { AC_ClearLoginUser, AC_SetLoginData, AC_SetLoginUserInfo } from '../actions/identify';
import store from '../store';

/**
 * 重置登录用户
 */
function clearLoginUser() {
    AC_ClearLoginUser()(store.dispatch);
}

/**
 * 设置登录信息
 * @param {object} sessionData 登录信息
 */
function setLoginSessionData(sessionData) {
    AC_SetLoginData(sessionData)(store.dispatch);
}

/**
 * 设置用户信息
 * @param {object} userInfo 用户信息
 */
function setLoginUserInfo(userInfo) {
    AC_SetLoginUserInfo(userInfo)(store.dispatch);
}

/**
 * 获取当前用户的登录信息
 * @return {object}
 */
function getLoginSessionData() {
    return store.getState().identifyStore.sessionData;
}

/**
 * 获取当前用户信息
 * @return {object}
 */
function getLoginUserInfo() {
    return store.getState().identifyStore.userInfo;
}

/**
 * 当前登录用户是否有权限
 * @param {string} roleType 用户权限
 */
function hasRole(roleType) {
    return _.chain(getLoginUserInfo())
        .get('roles', [])
        .find(value => value.code === roleType)
        .value();
}

export default {
    clearLoginUser,
    setLoginSessionData,
    setLoginUserInfo,
    getLoginSessionData,
    getLoginUserInfo,
    hasRole,
};
