/**
 * @author xukj
 * @date 2018/12/11
 * @description ResourceExtension 资源
 */
import store from '../store';

/**
 * 获取resourceStore
 * @return {*}
 */
function getResourceData() {
    return store.getState().resourceStore;
}

export default {
    getResourceData,
};