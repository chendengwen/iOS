/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-08 12:10:44
 */
import { combineReducers } from 'redux';
import categoryResourceReducer from './categoryResource';
import courseReducer from './course';
import trainingClassReducer from './trainingClass';
import trainingClassUtilReducer from './util/trainingClassUtil';
import identifyReducer from './identify';
import appsReducer from './apps';
import homeReducer from './home';
import examHistoryReducer from './examHistory';
import resourceLikeReducer from './resourceLike';
import resourceFavoriteReducer from './resourceFavorite';
import commentReducer from './comment';
import systemParamReducer from './setting';
import questionnaireReducer from './questionnaire';
import audioReducer from './audio';
import pointsReducer from './points';
import myInfoReducer from './myInfo';
import versionReducer from './versionInfo';
import contributeReducer from './contribute';
import ResourceReducer from './resource';
import trainingExtra from './trainingExtra';
import commonReducer from './common';
import annualSummaryReducer from './annualSummary';
import unreadFlagsReducer from './unreadFlags';
import scoreReducer from './resourceScore';
import planReducer from './plan';
import messageReducer from './message';

export default combineReducers({
    categoryStore: categoryResourceReducer,
    courseStore: courseReducer,
    examHistoryStore: examHistoryReducer,
    trainingClassStore: trainingClassReducer,
    trainingClassUtilStore: trainingClassUtilReducer,
    identifyStore: identifyReducer,
    appsStore: appsReducer,
    homeStore: homeReducer,
    likeStore: resourceLikeReducer,
    favoriteStore: resourceFavoriteReducer,
    scoreStore: scoreReducer,
    commentStore: commentReducer,
    systemParamStore: systemParamReducer,
    questionnaireStore: questionnaireReducer,
    audioStore: audioReducer,
    pointsStore: pointsReducer,
    myInfoStore: myInfoReducer,
    versionStore: versionReducer,
    contribute: contributeReducer,
    resourceStore: ResourceReducer,
    trainingExtraStore: trainingExtra,
    commonStore: commonReducer,
    annualStore: annualSummaryReducer,
    unreadStore: unreadFlagsReducer,
    planStore: planReducer,
    messageStore: messageReducer,
});
