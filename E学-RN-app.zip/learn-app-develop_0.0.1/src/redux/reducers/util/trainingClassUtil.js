/**
 * @author xukj
 * @date 2019/04/08
 * @description trainingClassUtil 签到报名
 *
 * modify by xukj - 1.28.0
 * 修正
 */
import * as TYPES from '../../types';

const initialState = {
    sending: false,
    message: '',
    enrolStatus: -1, // -1 未知、0 未报名、1 报名,
    error: null, // 报名错误
};

export default function trainingClassUtil(state = initialState, action) {
    switch (action.type) {
        case TYPES.ENROL_DOING:
        case TYPES.CANCELENROL_DOING:
            return {
                ...state,
                sending: true,
                message: '',
                error: null,
            };
        case TYPES.ENROL_FINISH:
            return {
                ...state,
                sending: false,
                message: action.data,
                error: null,
                enrolStatus: 1,
            };
        case TYPES.ENROL_FAIL:
            return {
                ...state,
                sending: false,
                message: '',
                error: action.data,
            };
        case TYPES.CANCELENROL_FINISH:
            return {
                ...state,
                sending: false,
                message: action.data,
                error: null,
                enrolStatus: 0,
            };
        case TYPES.CANCELENROL_FAIL:
            return {
                ...state,
                sending: false,
                message: '',
                error: action.data,
            };
        case TYPES.ENROL_INIT:
            return initialState;
        default:
            return state;
    }
}
