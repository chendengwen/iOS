/**
 * Created by zk on 2017/11/9.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    loading: false,
    error: null,  // 失败
};

export default function myInfo(state = initialState, action) {

    switch (action.type) {
        case TYPES.FETCH_MY_INFO_DOING:
            // 不重置数据
            return {
                ...state,
                loading: true,
                error: null,
            };
        case TYPES.FETCH_MY_INFO_FINISH:
            return {
                loading: false,
                data: action.data,
                error: null,
            };
        case TYPES.FETCH_MY_INFO_FAIL:
            // 不重置数据
            return {
                ...state,
                loading: false,
                error: action.error,
            };
        case TYPES.UPDATE_MY_INFO_DOING:
            // 更新操作进行时，不重置data数据
            return {
                ...state,
                loading: true,
                error: null,
            };
        case TYPES.UPDATE_MY_INFO_FINISH:
            // 更新操作完成时，重置data数据
            const userInfo = {
                ...state.data.userInfo,
                ...action.data,
            };
            return {
                loading: false,
                data: {
                    ...state.data,
                    userInfo,
                },
                error: null,
            };
        case TYPES.UPDATE_MY_INFO_FAIL:
            // 更新操作失败时，不重置data数据
            return {
                ...state,
                loading: false,
                error: action.error,
            };
        default:
            return state;

    }
}