/**
 * @author xukj
 * @date 2019/04/08
 * @description comment 评论
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    loading: true,
    exception: null,
    message: null,
    reload: false,
    // modify by xukj - 1.28.0
    sending: false, // 提交评论
    sendError: null, // 提交评论失败
};

export default function comment(state = initialState, action) {
    switch (action.type) {
        case TYPES.FETCH_COMMENT_DOING:
            return {
                message: null,
                loading: true,
                data: null,
                exception: null,
                reload: false,
                sending: false,
                sendError: null,
            };
        case TYPES.FETCH_COMMENT_FINISH:
            return {
                exception: null,
                loading: false,
                data: action.data,
            };
        case TYPES.FETCH_COMMENT_FAIL:
            return {
                data: null,
                loading: false,
                exception: action.error,
            };
        case TYPES.ADD_COMMENT_DOING:
            return {
                message: null,
                loading: true,
                data: null,
                reload: false,
                sending: true,
                sendError: null,
            };
        case TYPES.ADD_COMMENT_FINISH:
            return {
                loading: false,
                reload: true,
                message: '添加评论成功',
                sending: false,
                sendError: null,
            };
        case TYPES.ADD_COMMENT_FAIL:
            return {
                data: null,
                reload: false,
                message: '添加评论失败',
                sending: false,
                sendError: action.error,
            };
        default:
            return state;
    }
}
