import * as TYPES from '../types';

const initialState = {
    netCtrl: null,
};

export default function trainingClass(state=initialState, action){

    switch (action.type){
        case TYPES.SAVE_NET_CTRL:
            return {
                ...state,
                netCtrl: action.netCtrl,
            }
        case TYPES.SAVE_NET_INFO:
            return {
                ...state,
                networkType: action.networkType,
            }

        default:
            return state;
    }

}