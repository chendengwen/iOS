/**
 * Created by zk on 2017/7/4.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    loading:true,
    exception:null,
};

export default function examHistory(state=initialState, action) {
    switch (action.type) {
        case TYPES.FETCH_EXAMHISTORY_DOING:
            return {
                loading: true,
                data: null,
                exception:null,
            }
        case TYPES.FETCH_EXAMHISTORY_FINISH:
            return {
                exception:null,
                loading: false,
                data: action.data
            }
        case TYPES.FETCH_EXAMHISTORY_FAIL:
            console.log('status' + action.status)
            return {
                data: null,
                loading: false,
                exception: action.status
            }
        default:
            return state

    }

}
