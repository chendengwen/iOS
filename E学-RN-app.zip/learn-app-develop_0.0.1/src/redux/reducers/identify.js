/**
 * @author xukj
 * @date 2018/12/11
 * @description identify 
 * modify by xukj - 1.24.0
 * 重构登录信息管理的redux，现在分为2部分，一部分为sessionData，一部分为userInfo
 */
import { RESET_LOGINUSER, SET_LOGINUSER_SESSIONDATA, SET_LOGINUSER_USERINFO } from '../types';
const initialState = {
    sessionData: null,    // 登录信息
    userInfo: null,       // 用户信息
};

export default function identify(state=initialState, action){
    switch (action.type) {
        case SET_LOGINUSER_SESSIONDATA:
            return {
                ...state,
                sessionData: action.payload,
            };
        case SET_LOGINUSER_USERINFO:
            return {
                ...state,
                userInfo: action.payload,
            };
        case RESET_LOGINUSER:
            return initialState;
        default:
            return state;
    }
};