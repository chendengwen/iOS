/**
 * @author xukj
 * @date 2019/04/26
 * @description unreadFlags 未读标识redux
 */
import { SET_UPGRADE_UNREAD_FLAG, RESET_ALL_UNREAD_FLAG } from '../types';

const initialState = {
    unreadUpgrade: 0,
};

export default function unreadFlags(state = initialState, action) {
    switch (action.type) {
        case SET_UPGRADE_UNREAD_FLAG:
            // 升级未读
            return {
                ...state,
                unreadUpgrade: action.payload,
            };
        case RESET_ALL_UNREAD_FLAG:
            // 重置所有
            return { ...initialState };
        default:
            return state;
    }
}
