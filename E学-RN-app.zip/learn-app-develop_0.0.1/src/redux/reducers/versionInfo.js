/**
 * @author xukj
 * @date 2018/12/27
 * @description versionInfo 版本信息
 * modify xukj - 1.24.0
 * 调整reducer的值
 * Created by zk on 2018/1/4.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    loading: false,
    error: null,
    ignoreData: null, // 忽略的版本
};

export default function versionInfo(state = initialState, action) {
    switch (action.type) {
        case TYPES.FETCH_VERSION_DOING:
            return {
                ...state,
                data: null,
                loading: true,
                error: null,
            };
        case TYPES.FETCH_VERSION_FINISH:
            return {
                ...state,
                data: action.payload,
                loading: false,
                error: null,
            };
        case TYPES.FETCH_VERSION_FAIL:
            return {
                ...state,
                data: null,
                loading: false,
                error: null,
            };
        case TYPES.FETCH_IGNORE_VERSION_DOING:
            return {
                ...state,
                loadingIgnore: true,
            };
        case TYPES.FETCH_IGNORE_VERSION:
            return {
                ...state,
                loadingIgnore: false,
                ignoreData: action.payload,
            };
        default:
            return state;
    }
}
