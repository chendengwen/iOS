import * as TYPES from '../types';

const initialState = {
    data: null,
    result: false,
    toLearn: false,
    status: null,
    questionnaires: null,
    testPapers: null,
    startQa: 0,
    newPlayer: true,
    isPlayCourse: null,
    // modify by xukj - 1.28.0
    // 调整错误显示策略
    detailError: null, // e课详情失败
    addMessage: '',
    addError: null, // 加入待学失败
    addSending: false, // 加入待学请求中
    recordError: null, //记录失败
    nowNext: false, //为true的时候播放下一个视频
    isFull: false,
    // add by xukj - 1.40.0
    finishState: {
        finishQuestionnaire: true, // 完成问卷情况
        finishPaper: true, // 完成考试情况
        finishComment: true, // 完成评分情况
    },
};

export default function course(state = initialState, action) {
    let tmpPlayCourse;
    switch (action.type) {
        case TYPES.FETCH_COURSE_DETAIL_DOING:
            return {
                ...state,
                addSending: false,
                toLearn: false,
                result: false,
                isPlayCourse: null,
                detailError: null,
                addMessage: '',
                addError: null,
                recordError: null,
            };
        case TYPES.FETCH_COURSE_DETAIL_FINISH:
            return {
                ...state,
                data: action.data.courseDetail,
                questionnaires: action.data.questionnaires,
                testPapers: action.data.testpapers,
                result: true,
                isPlayCourse: findFirstPlayResource(action.data.courseDetail),
                detailError: null,
            };
        case TYPES.FETCH_COURSE_DETAIL_FAIL:
            return {
                ...state,
                result: false,
                detailError: action.error,
            };
        case TYPES.ADD_TO_LEARN_DOING:
            return {
                ...state,
                addSending: true,
                toLearn: false,
                result: false,
                addMessage: '',
                addError: null,
            };
        case TYPES.ADD_TO_LEARN_FINISH:
            return {
                ...state,
                addSending: false,
                toLearn: true,
                result: true,
                addMessage: '加入成功',
                addError: null,
            };
        case TYPES.ADD_TO_LEARN_FAIL:
            return {
                ...state,
                addSending: false,
                toLearn: false,
                result: false,
                addMessage: '加入失败',
                addError: action.error,
            };
        case TYPES.ADD_TO_PLAY:
            return {
                ...state,
                isPlayCourse: { ...action.data, jump: true },
                newPlayer: true,
            };
        case TYPES.INIT_NEW_PLAYER:
            return {
                ...state,
                newPlayer: false,
            };
        case TYPES.ADD_TO_PLAY_WITHOUT_JUMP: {
            return {
                isPlayCourse: action.data,
                newPlayer: true,
            };
        }
        case TYPES.START_QA:
            return {
                ...state,
                startQa: state.startQa + 1,
            };
        case TYPES.FINISH_QA:
            return {
                ...state,
                startQa: 0,
            };
        case TYPES.INIT_JUMP:
            tmpPlayCourse = {
                ...state.isPlayCourse,
                jump: false,
            };
            return {
                ...state,
                isPlayCourse: tmpPlayCourse,
            };
        case TYPES.UPDATE_FINISH_STATUS_DOING:
            tmpPlayCourse = {
                ...state.isPlayCourse,
                played: true,
            };
            return {
                ...state,
                isPlayCourse: tmpPlayCourse,
            };
        case TYPES.UPDATE_FINISH_STATUS_DONE:
            return state;
        case TYPES.UPDATE_FINISH_STATUS_FAIL:
            tmpPlayCourse = {
                ...state.isPlayCourse,
                played: false,
            };
            return {
                ...state,
                isPlayCourse: tmpPlayCourse,
            };
        case TYPES.PLAY_NEXT_VIDEO:
            return {
                ...state,
                nowNext: action.data,
            };
        case TYPES.SET_FULL_SCREEN:
            return {
                ...state,
                isFull: action.data,
            };
        case TYPES.SET_COURSE_FINISH_STATE:
            return {
                ...state,
                finishState: { ...state.finishState, ...action.data }, // 仅覆盖data中有的项
            };
        case TYPES.INIT_COURSE:
            return initialState;
        default:
            return state;
    }
}

let findFirstPlayResource = courseDetail => {
    let curricula = courseDetail.curricula;
    if (curricula != null) {
        let chapters = curricula.chapters;
        for (let i = 0; i < chapters.length; i++) {
            let chapter = chapters[i];
            let contents = chapter.contents;
            for (let j = 0; j < contents.length; j++) {
                let courseContent = contents[j];
                if (courseContent.contentType == '01') {
                    return {
                        ...courseContent,
                        snapshotId: curricula.id,
                        resourceId: courseDetail.id,
                        type: 1,
                    };
                }
                if (courseContent.contentType == '05') {
                    return {
                        ...courseContent,
                        snapshotId: curricula.id,
                        resourceId: courseDetail.id,
                        type: 5,
                    };
                }
                if (courseContent.contentType == '04') {
                    return {
                        ...courseContent,
                        snapshotId: curricula.id,
                        resourceId: courseDetail.id,
                        type: 4,
                    };
                }
            }
        }
    }
    return null;
};
