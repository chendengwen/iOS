/**
 * Created by zk on 2017/10/17.
 */
import * as TYPES from '../types';

const initState={
    timer:null,
    duration:1,
    time:0,
    status:null,
    watcher:null
}

export default function audio(state=initState,action){
    switch (action.type){
        case(TYPES.INIT_AUDIO_TIMER):
            return {
                ...state,
                timer:action.timer
            }
        case (TYPES.INIT_AUDIO_STATUS_WATCHER):
            return {
                ...state,
                watcher:action.watcher
            }
        case  (TYPES.UPDATE_AUDIO_DURATION):
            return {
                ...state,
                duration:action.duration
            }

        case (TYPES.UPDATE_AUDIO_TIME):
            return {
                ...state,
                time:action.time
            }
        case (TYPES.UPDATE_AUDIO_STATUS):
            return {
                ...state,
                status:action.status
            }

        default:
            return state
    }
}