/**
 * @author xukj
 * @date 2019/01/10
 * @description annualSummary 年度报告
 */
import { FETCH_ANNUALSUMMARY_SHOWN_DOING, FETCH_ANNUALSUMMARY_SHOWN_FINISH } from '../types';
const initialState = {
    loading: false,
    shown: false,
};

export default function annualSummary(state = initialState, action) {
    switch (action.type) {
        case FETCH_ANNUALSUMMARY_SHOWN_DOING:
            return {
                ...state,
                loading: true,
                shown: false,
            };
        case FETCH_ANNUALSUMMARY_SHOWN_FINISH:
            return {
                ...state,
                loading: false,
                shown: action.payload,
            };
        default:
            return state;
    };
}
