/**
 * @author xukj
 * @date 2019/08/20
 * @description points 积分redux
 * Created by zk on 2017/10/27.
 */
import * as TYPES from '../types';
const initialState = {
    total: 0,
};

export default function points(state = initialState, action) {
    switch (action.type) {
        case TYPES.INIT_USER_POINTS:
            return {
                ...state,
                ...initialState,
            };
        case TYPES.UPDATE_USER_POINTS:
            return {
                ...state,
                total: action.payload,
            };
        default:
            return state;
    }
}
