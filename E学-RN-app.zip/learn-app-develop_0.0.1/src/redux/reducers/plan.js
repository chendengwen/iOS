/**
 * Created by zk on 2017/10/17.
 */
import * as TYPES from '../types';

const initState={
    refreshTime:{
        eClass:0,
        training:0,
        read:0,
        exam:0,
        qa:0
    },
    latestTime:{
        eClass:0,
        training:0,
        read:0,
        exam:0,
        qa:0
    }
};

export default function audio(state=initState,action){
    switch (action.type){
        case(TYPES.SET_REFRESH_TIME):
            let tmp={
                ...state.refreshTime,
            };
            tmp[action.category]=action.time
            return {
                ...state,
                refreshTime:tmp
            };
        case(TYPES.SET_LATEST_TIME):
            return {
                ...state,
                latestTime:action.timeObj
            };
        case(TYPES.RESET_REFRESH_TIME):
            return {
                ...state,
                refreshTime:action.timeObj
            };
        default:
            return state
    }
}