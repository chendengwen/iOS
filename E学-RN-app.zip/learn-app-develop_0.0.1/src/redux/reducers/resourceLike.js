/**
 * Created by zk on 2017/7/3.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    exception:null,
    liking:false,
    likingFail:false
};

export default function resourceLike(state=initialState, action){
    let likeCount,like
    switch (action.type){
        case TYPES.FETCH_LIKE_DOING:
            return{
                ...state,
                data:null,
                exception:null,
                likingFail:false,

            }
        case TYPES.FETCH_LIKE_FINISH:
            return{
                ...state,
                data:action.data,
                exception: null,
                likingFail:false,

            }
        case TYPES.FETCH_LIKE_FAIL:
            return{
                ...state,
                data:null,
                exception:action.error,
                likingFail:false,
            }
        case TYPES.TOGGLE_LIKE_DOING:
            if(state.data){
                if(state.data.like){
                    likeCount=state.data.likeCount-1
                    like=false
                }
                else {
                    likeCount=state.data.likeCount+1
                    like=true
                }
            }
            else {
                likeCount=1
                like=true
            }

            return{
                ...state,
                data:{...state.data,
                likeCount:likeCount,
                like:like,
                },
                liking:true,
                likingFail:false,
            }
        case TYPES.TOGGLE_LIKE_FINISH:
            return{

                ...state,
                data:action.data,
                liking:false,
                likingFail:false,
            }
        case TYPES.TOGGLE_LIKE_FAIL:
            if(state.data){
                if(state.data.like){
                    likeCount=state.data.likeCount-1
                    like=false
                }
                else {
                    likeCount=state.data.likeCount+1
                    like=true
                }
            }
            else {
                likeCount=1
                like=true
            }
            return{
                ...state,
                data:{...state.data,
                    likeCount:likeCount,
                    like:like
                },
                likingFail:true,
                liking:false,
            }
        case TYPES.INIT_LIKE_DATA:
            return {
                likingFail:false,
                data: null,
                exception:null,
                liking:false
            }
        default:
            return state

    }

}