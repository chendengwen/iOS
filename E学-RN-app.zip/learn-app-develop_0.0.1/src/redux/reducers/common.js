/**
 * @author xukj
 * @date 2019/01/10
 * @description common 通用缓存
 */
import { SET_LOGINUSER_ALIAS } from '../types';
const initialState = {
    alias: null,
};

export default function common(state = initialState, action) {
    switch (action.type) {
        case SET_LOGINUSER_ALIAS:
            return {
                ...state,
                alias: action.payload,
            };
        default:
            return state;
    };
}
