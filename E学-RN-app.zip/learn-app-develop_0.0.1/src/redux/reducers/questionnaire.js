/**
 * Created by zk on 2017/9/21.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    loading: false,
    error: null,
};

export default function questionnaire(state = initialState, action) {
    switch (action.type) {
        case TYPES.FETCH_QA_DOING:
            return {
                loading: true,
                data: null,
                error: null,
            };
        case TYPES.FETCH_QA_FINISH:
            return {
                error: null,
                loading: false,
                data: action.data,
            };
        case TYPES.FETCH_QA_FAIL:
            return {
                data: null,
                loading: false,
                error: action.error,
            };
        case TYPES.INIT_QA:
            return {
                data: null,
                loading: false,
                error: null,
            };
        default:
            return state;
    }
}
