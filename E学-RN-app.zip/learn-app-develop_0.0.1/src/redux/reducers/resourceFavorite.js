/**
 * Created by songt2 on 2020/9/3.
 */
import * as TYPES from '../types';
const initialState = {
    data: null,
    exception:null,
    favoriting:false,
    favoritingFail:false
};

export default function resourceFavorite(state=initialState, action){
    let favoriteCount,favorite
    switch (action.type){
        case TYPES.FETCH_FAVORITE_DOING:
            return{
                ...state,
                data:null,
                exception:null,
                favoritingFail:false,

            }
        case TYPES.FETCH_FAVORITE_FINISH:
            return{
                ...state,
                data:action.data,
                exception: null,
                favoritingFail:false,

            }
        case TYPES.FETCH_FAVORITE_FAIL:
            return{
                ...state,
                data:null,
                exception:action.error,
                favoritingFail:false,
            }
        case TYPES.TOGGLE_FAVORITE_DOING:
            if(state.data){
                if(state.data.favorite){
                    favoriteCount=state.data.favoriteCount-1
                    favorite=false
                }
                else {
                    favoriteCount=state.data.favoriteCount+1
                    favorite=true
                }
            }
            else {
                favoriteCount=1
                favorite=true
            }

            return{
                ...state,
                data:{...state.data,
                favoriteCount:favoriteCount,
                favorite:favorite,
                },
                favoriting:true,
                favoritingFail:false,
            }
        case TYPES.TOGGLE_FAVORITE_FINISH:
            return{

                ...state,
                data:action.data,
                favoriting:false,
                favoritingFail:false,
            }
        case TYPES.TOGGLE_FAVORITE_FAIL:
            if(state.data){
                if(state.data.favorite){
                    favoriteCount=state.data.favoriteCount-1
                    favorite=false
                }
                else {
                    favoriteCount=state.data.favoriteCount+1
                    favorite=true
                }
            }
            else {
                favoriteCount=1
                favorite=true
            }
            return{
                ...state,
                data:{...state.data,
                    favoriteCount:favoriteCount,
                    favorite:favorite
                },
                favoritingFail:true,
                favoriting:false,
            }
        case TYPES.INIT_FAVORITE_DATA:
            return {
                favoritingFail:false,
                data: null,
                exception:null,
                favoriting:false
            }
        default:
            return state

    }

}