/**
 * @author xukj
 * @date 2019/11/26
 * @description 评价
 */
import * as TYPES from '../types';
const initialState = {
    isCommented: false, // 是否已评价
    resourceId: null, // 关联资源
};

export default function(state = initialState, action) {
    switch (action.type) {
        case TYPES.SET_RESOURCE_COMMENTED:
            return {
                isCommented: action.payload.isCommented,
                resourceId: action.payload.resourceId,
            };
        case TYPES.RESET_RESOURCE_COMMENTED:
            return initialState;
        default:
            return state;
    }
}
