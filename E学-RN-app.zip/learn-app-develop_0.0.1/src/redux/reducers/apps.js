/**
 * Created by zk on 2017/7/7.
 */
import * as TYPES from '../types';

const initState={
    loading:true,
}

export default function apps(state=initState,action){
    switch (action.type){
        case(TYPES.INIT_STORE_DOING):
            return { loading:true}
        case(TYPES.INIT_STORE_FINISH):
            return {loading:false}
        default:
            return state
    }
}
