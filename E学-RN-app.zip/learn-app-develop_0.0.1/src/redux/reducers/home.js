import * as TYPES from '../types';

const initialState = {
    result: false,
    message: '',

    loadingB: true, //banners是否在加载中
    loadingR: true, //推荐课程是否在加载中
    loadingN: true, //新闻是否在加载中
    loadingS: true, // 专题是否加载中,
    loadingC: true, // 频道是否加载中
    banners: [], //横幅
    news: [], // 首页新闻
    subject: {}, // 专题
    channel: null, // 频道，这里用null为了获取失败的时候显示占位图
    recommendResources: null, //推荐
    latestNotice: 0, // 未读消息
};

export default function trainingClass(state = initialState, action) {
    switch (action.type) {
        // 首页横幅位
        // ---
        case TYPES.FETCH_BANNER_DOING:
            return {
                ...state,
                loadingB: true,
            };
        case TYPES.FETCH_BANNER_FINISH:
            return {
                ...state,
                banners: action.data,
                loadingB: false,
            };
        case TYPES.FETCH_BANNER_FAIL:
            return {
                ...state,
                loadingB: false,
            };
        // 首页推荐位
        // ---
        case TYPES.FETCH_RECOMMEND_RESOURCE_DOING:
            return {
                ...state,
                loadingR: true,
            };
        case TYPES.FETCH_RECOMMEND_RESOURCE_FINISH:
            return {
                ...state,
                recommendResources: action.data,
                loadingR: false,
            };
        case TYPES.FETCH_RECOMMEND_RESOURCE_FAIL:
            return {
                ...state,
                loadingR: false,
            };
        // 首页新闻
        // ---
        case TYPES.FETCH_TOPNEWS_DOING:
            return {
                ...state,
                loadingN: true,
            };
        case TYPES.FETCH_TOPNEWS_FINISH:
            return {
                ...state,
                news: action.data,
                loadingN: false,
            };
        case TYPES.FETCH_TOPNEWS_FAIL:
            return {
                ...state,
                loadingN: false,
            };
        // 首页专题
        // ---
        case TYPES.FETCH_SUBJECTS_DOING:
            return {
                ...state,
                loadingS: true,
            };
        case TYPES.FETCH_SUBJECTS_FINISH:
            return {
                ...state,
                subject: action.data,
                loadingS: false,
            };
        case TYPES.FETCH_SUBJECTS_FAIL:
            return {
                ...state,
                loadingS: false,
            };
        // 频道
        case TYPES.FETCH_CHANNEL_DOING:
            return {
                ...state,
                loadingC: true,
            };
        case TYPES.FETCH_CHANNEL_FINISH:
            return {
                ...state,
                channel: action.data,
                loadingC: false,
            };
        case TYPES.FETCH_CHANNEL_FAIL:
            return {
                ...state,
                loadingC: false,
                channel: null,
            };
        // 最新的消息
        // ---
        case TYPES.FETCH_LATESTNOTICE_FINISH:
            // 保留之前状态, 仅更新未读数据。
            // 仅监听成功的情况
            return {
                ...state,
                latestNotice: action.data,
            };
        case TYPES.FETCH_LATESTNOTICE_RESET:
            // 保留之前状态, 仅更新未读数据。
            return {
                ...state,
                latestNotice: 0,
            };
        // 其他
        default:
            return state;
    }
}
