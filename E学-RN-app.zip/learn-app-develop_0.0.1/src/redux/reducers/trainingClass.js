import * as TYPES from '../types';

const initialState = {
    data: null,
    result: false,
    message: '',
    loading: true,
    listLoading: true,
    detail: null,
    detailError: null, // 期次详情获取失败
    classError: null, // 培训班获取失败 @deprecated
    // add by xukj - 1.40.0
    finishState: {
        finishQuestionnaire: true, // 完成问卷情况
        finishPaper: true, // 完成考试情况
        finishComment: true, // 完成评分情况
    },
};

export default function trainingClass(state = initialState, action) {
    switch (action.type) {
        case TYPES.FETCH_TRAINING_CLASS_DOING:
            return {
                ...state,
                message: '',
                result: false,
                listLoading: true,
                detailError: null,
                classError: null,
            };
        case TYPES.FETCH_TRAINING_CLASS_FINISH:
            return {
                ...state,
                data: action.data,
                result: true,
                listLoading: false,
                detailError: null,
                classError: null,
            };
        case TYPES.FETCH_TRAINING_CLASS_FAIL:
            return {
                ...state,
                result: false,
                listLoading: false,
                classError: action.error,
                detailError: null,
            };
        case TYPES.FETCH_TRAINING_CLASS_DETAIL_DOING:
            return {
                ...state,
                message: '',
                result: false,
                loading: true,
                detailError: null,
                classError: null,
            };
        case TYPES.FETCH_TRAINING_CLASS_DETAIL_FINISH:
            return {
                ...state,
                detail: action.data,
                result: true,
                loading: false,
                detailError: null,
                classError: null,
            };
        case TYPES.FETCH_TRAINING_CLASS_DETAIL_FAIL:
            return {
                ...state,
                result: false,
                loading: false,
                detailError: action.error,
                classError: null,
            };
        case TYPES.SET_TRAINING_FINISH_STATE:
            return {
                ...state,
                finishState: { ...state.finishState, ...action.data }, // 仅覆盖data中有的项
            };
        case TYPES.INIT_TRAINNING:
        case TYPES.INIT_DETAIL:
            return initialState;
        default:
            return state;
    }
}
