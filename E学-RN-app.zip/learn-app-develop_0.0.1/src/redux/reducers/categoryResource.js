import * as TYPES from '../types';

const initialState = {
    data: null,
    result: false,
    message: '',
    loading: false,
    sort: 0,
    status:null
};

export default function category(state=initialState, action){

    switch (action.type){
        case TYPES.FETCH_RESOURCE_DOING:
            return {
                ...state,
                reload: false,
                loading: true,
                result: false,
                status:null
            }
        case TYPES.FETCH_RESOURCE_FINISH:

            return {
                ...state,
                data: action.data,
                filterData: action.data,
                reload: false,
                loading: false,
                result: true,
                status:null,
                result: true,
                sort: -1,
            }
        case TYPES.FETCH_RESOURCE_FAIL:

            return {
                ...state,
                data:null,
                filterData:null,
                reload: false,
                loading: false,
                result: true,
                sort: -1,
                status:action.status
            }


        case TYPES.FILTER_RESOURCE:
            return {
                ...state,
                filterData: action.filterData,
                reload: false,
                result: true,
                sort: -1,
                status:null,
            }
        case TYPES.SORT_RESOURCE:
            return {
                ...state,
                filterData: action.filterData,
                sort: action.sort,
                reload: false,
                result: true,
                status:null,
            }
        case TYPES.FETCH_RESOURCE_INIT:
            return {
                data: null,
                result: false,
                message: '',
                loading: false,
                sort: 0,
                status:null
            }
        default:
            return state;
    }

}