/**
 * Created by zk on 2018/10/17.
 */
import * as TYPES from '../types';
const initialState = {
    status:null
};

export default function resource(state=initialState, action){
    switch (action.type){
        case TYPES.SET_PROJECT_STATUS:
            return{
                status:action.status
            }
        case TYPES.CLEAR_PROJECT_STATUS:
            return{
                status:null
            }
        default:
            return state

    }

}