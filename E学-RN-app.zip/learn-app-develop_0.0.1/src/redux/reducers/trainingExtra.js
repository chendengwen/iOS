/**
 * @author xukj
 * @date 2018/12/05
 * @description teachers redux reducer 讲师、班主任
 */
import { 
    FETCH_TEACHER_DETAIL_FINISH, 
    FETCH_SCHEDULE_FINISH,
    INIT_TEACHERS,
} from '../types';

const initialState = {
    teachers: null,
    master: null,
    schedule: null,
};

export default function trainingExtras(state = initialState, action) {
    switch (action.type) {
        case FETCH_TEACHER_DETAIL_FINISH:
            return {
                ...state,
                teachers: action.payload,
            };
        case FETCH_SCHEDULE_FINISH:
            return {
                ...state,
                schedule: action.payload,
            };
        case INIT_TEACHERS:
            return initialState;
        default:
            return state;
    }
}