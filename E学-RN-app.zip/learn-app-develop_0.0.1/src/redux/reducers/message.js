/**
 * @author xukj
 * @date 2020/01/13
 * @description message 消息
 */
import { SET_MESSAGE_GROUPS, LOADING_MESSAGE_GROUPS, RESET_MESSAGE_GROUPS } from '../types';
const initialState = {
    loading: true,
    groups: [], // 分组信息  {key, count, value, lastTime}
};

export default function message(state = initialState, action) {
    switch (action.type) {
        case SET_MESSAGE_GROUPS:
            return {
                ...state,
                groups: action.payload,
            };
        case LOADING_MESSAGE_GROUPS:
            return {
                ...state,
                loading: action.payload,
            };
        case RESET_MESSAGE_GROUPS:
            return initialState;
        default:
            return state;
    }
}
