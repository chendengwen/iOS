/**
 * @author xukj
 * @date 2018/12/11
 * @description index react-redux相关
 * 原则上，应该尽量避免直接操作redux中的数据；但是在某些情况下，无法避免通过外部直接操作redux中的数据，
 * 为了保证代码结构统一和隔离，这里专门设计一个extension来对外提供方法。请勿在外部直接操作redux，必须通过这里的extension来实现
 */
// store
import store from './store';

// action
// todo 待设计

// reducer
// todo 待设计

// extension
export { store };
export { default as CourseExtension } from './extension/CourseExtension';
export { default as IdentifyExtension } from './extension/IdentifyExtension';
export { default as MessageExtension } from './extension/MessageExtension';
export { default as MyInfoExtension } from './extension/MyInfoExtension';
export { default as OtherExtensions } from './extension/OtherExtensions';
export { default as ResourceExtension } from './extension/ResourceExtension';
