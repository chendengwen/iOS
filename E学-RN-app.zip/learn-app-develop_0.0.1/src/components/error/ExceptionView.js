/**
 * @author xukj
 * @date 2018/12/20
 * @description ExceptionView 图标 + 文字，多为list的空页面。
 * Refactoring by xukj - 1.24.0
 * Created by xukj on 2018/7/17.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Image, Text, ViewPropTypes } from 'react-native';
import { SeaScale, SeaColor, SeaTheme } from '../../asserts';

export default class ExceptionView extends React.PureComponent {
    static propTypes = {
        message: PropTypes.string,
        source: Image.propTypes.source,
        imageStyle: Image.propTypes.style,
        textStyle: Text.propTypes.style,
        style: ViewPropTypes.style,
    };

    static defaultProps = {
        message: '暂时没有获取到数据',
        source: require('../../asserts/images/exception.png'),
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { message, source, style, imageStyle, textStyle } = this.props;
        return (
            <View style={[styles.page, style && style]}>
                <Image style={[styles.image, imageStyle]} source={source} resizeMode="contain" />
                <Text style={[styles.text, textStyle]}>{message}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: 'transparent',
        width: SeaScale.screenWidth,
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: SeaScale.Layout(200),
        height: SeaScale.Layout(200),
    },
    text: {
        marginTop: SeaTheme.v_spacing_sm,
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
    },
});
