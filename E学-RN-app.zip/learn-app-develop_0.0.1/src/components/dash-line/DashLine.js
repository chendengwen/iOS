/**
 * Created by zk on 2019/11/29.
 */
import React, {Component} from 'react';
import {
    Text,
    View,
    StyleSheet,
} from 'react-native';
import {SeaScale,SeaTheme } from '../../asserts'


/*水平方向的虚线
 * len 虚线个数
 * width 总长度
 * backgroundColor 背景颜色
 * */
export default class DashLine extends Component {
    render() {
        let len = 24;
        let arr = [];
        for (let i = 0; i < len; i++) {
            arr.push(i);
        }
        return <View style={[styles.dashLine, {height:SeaScale.Layout(297) }]}>
            {
                arr.map((item, index) => {
                    return <Text style={[styles.dashItem, {backgroundColor: SeaTheme.color_grey_line}]}
                                 key={'dash' + index}> </Text>
                })
            }
        </View>
    }
}
const styles = StyleSheet.create({
    dashLine: {
        flexDirection: 'column',
    },
    dashItem: {
        height: SeaScale.Layout(6),
        width: StyleSheet.hairlineWidth,
        marginTop: SeaScale.Layout(6),
        flex: 1,
    }
})