/**
 * @author xukj
 * @date 2019/11/06
 * @description SeaButtonConnect button的扩展
 */
import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const connect = Component => {
    class WrapperComponent extends React.PureComponent {
        static propTypes = {
            throttle: PropTypes.bool, // 防重复点击
            throttleWait: PropTypes.number, // 默认200毫秒作为重复点击的判断
            onPress: PropTypes.func,
        };

        static defaultProps = {
            throttleWait: 300,
        };

        constructor(props) {
            super(props);
            const { throttleWait } = props;
            // 防止在 setState 的时候，重复点击失效
            this.handlePress = _.throttle(this._onPress, throttleWait, { leading: true });
        }

        componentWillUnmount() {
            this.handlePress && this.handlePress.cancel();
        }

        render() {
            const { onPress, throttle, ...restProps } = this.props;
            return <Component onPress={throttle ? this.handlePress : onPress} {...restProps} />;
        }

        _onPress = () => {
            const { onPress } = this.props;
            onPress && onPress();
        };
    }

    return WrapperComponent;
};

export default connect;
