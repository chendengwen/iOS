/**
 * @author zk
 * @date 2018/6/14
 * @description 未加入计划时的点赞按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Image, Text, StyleSheet, View } from 'react-native';
import { connect } from 'react-redux';
import { SeaColor, SeaScale, SeaTheme, SeaStyle } from '../../asserts';
import { AC_AsyToggleLike } from '../../redux/actions/resourceLike';
import SeaButton from './SeaButton';

@connect(mapStateToProps, mapDispatchToProps)
export default class SeaLikeButton extends React.PureComponent {
    static propTypes = {
        id: PropTypes.string.isRequired,
        enabled: PropTypes.bool,
        style: PropTypes.any,
        imageStyle: PropTypes.any,
        title: PropTypes.string,
        titleStyle: PropTypes.any,
    };

    state = {
        countX: SeaScale.Layout(130 / 2) + SeaScale.Layout(8),
    };

    render() {
        const like = _.get(this.props, 'likeData.like', false);
        const count = _.get(this.props, 'likeData.likeCount', 0);

        const { style, imageStyle, title, titleStyle } = this.props;
        const { countX } = this.state;

        return (
            <SeaButton
                style={[styles.container, SeaStyle.center, style && style]}
                onPress={this._onButtonPress}
                onLayout={this._onLayout}
            >
                <Image
                    style={[
                        styles.icon,
                        like && { tintColor: SeaColor.tag_01 },
                        imageStyle && imageStyle,
                    ]}
                    source={require('../../asserts/images/ic-bottom-like.png')}
                    resizeMode="contain"
                />
                {count > 0 && (
                    <View style={[styles.numContainer, { left: countX }]}>
                        <Text style={styles.num}>{count}</Text>
                    </View>
                )}
                {!_.isEmpty(title) && (
                    <Text style={[titleStyle && titleStyle, like && { color: SeaColor.tag_01 }]}>
                        {title}
                    </Text>
                )}
            </SeaButton>
        );
    }

    _onButtonPress = () => {
        if (this.props.enabled && !this.props.liking) {
            this.props.toggleLike(this.props.id);
        }
    };

    _onLayout = event => {
        this.setState({
            countX: event.nativeEvent.layout.width / 2 + SeaScale.Layout(8),
        });
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        training: store.trainingClassStore.detail,
        data: store.courseStore.data,
        likeData: store.likeStore.data,
        likeStatus: store.likeStore.exception,
        likingFail: store.likeStore.likingFail,
        liking: store.likeStore.liking,
        // message: store.courseStore.message,
    };
}
//store到action的action映射
function mapDispatchToProps(dispatch) {
    return {
        toggleLike: id => dispatch(AC_AsyToggleLike(id)),
    };
}

const styles = StyleSheet.create({
    container: {
        width: SeaScale.Layout(100),
        height: SeaScale.Layout(88),
    },
    icon: {
        width: SeaScale.Layout(40),
        height: SeaScale.Layout(40),
    },
    numContainer: {
        position: 'absolute',
        top: SeaScale.Layout(12),
        paddingHorizontal: SeaScale.Layout(8),
        minWidth: SeaScale.Layout(34),
        borderRadius: SeaTheme.raduis_md,
        backgroundColor: SeaColor.tag_01,
        justifyContent: 'center',
        alignItems: 'center',
    },
    num: {
        fontSize: SeaScale.Layout(18),
        color: SeaColor.white,
    },
});
