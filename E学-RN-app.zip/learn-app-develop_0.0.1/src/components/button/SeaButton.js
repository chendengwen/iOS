/**
 * @author xukj
 * @date 2019/06/27
 * @class
 * @description 通用按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLButton } from 'react-native-kpframework';
import connect from './connect';

export default connect(FSLButton);
