/**
 * @author songt2
 * @date 2020/9/2
 * @description 收藏按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Image, Text, StyleSheet, View } from 'react-native';
import { connect } from 'react-redux';
import { SeaColor, SeaScale, SeaTheme, SeaStyle, SeaConstant } from '../../asserts';
import {
    AC_AsyToggleFavorite,
    AC_AsyFetchFavoriteData,
} from '../../redux/actions/resourceFavorite';
import SeaButton from './SeaButton';

@connect(mapStateToProps, mapDispatchToProps)
export default class SeaFavoriteButton extends React.PureComponent {
    static propTypes = {
        id: PropTypes.string.isRequired,
        enabled: PropTypes.bool,
        style: PropTypes.any,
        imageStyle: PropTypes.any,
        title: PropTypes.string,
        titleStyle: PropTypes.any,
    };

    state = {
        countX: SeaScale.Layout(130 / 2) + SeaScale.Layout(8),
    };

    componentDidMount() {
        this.props.fetchFavorite(this.props.id, this.props.type);
    }

    render() {
        const favorite = _.get(this.props, 'favoriteData.favorite', false);
        const count = _.get(this.props, 'favoriteData.favoriteCount', 0);

        const { style, imageStyle, title, titleStyle } = this.props;
        const { countX } = this.state;

        return (
            <SeaButton
                style={[styles.container, SeaStyle.center, style && style]}
                onPress={this._onButtonPress}
                onLayout={this._onLayout}
            >
                <Image
                    style={[
                        styles.icon,
                        favorite && { tintColor: SeaColor.tag_01 },
                        
                        imageStyle && imageStyle,
                    ]}
                    source={require('../../asserts/images/ic_favorite.png')}
                    resizeMode="contain"
                />
                {count > 0 && (
                    <View style={[styles.numContainer, { left: countX }]}>
                        <Text style={styles.num}>{count}</Text>
                    </View>
                )}
                {!_.isEmpty(title) && (
                    <Text
                        style={[titleStyle && titleStyle, favorite && { color: SeaColor.tag_01 }]}
                    >
                        {title}
                    </Text>
                )}
            </SeaButton>
        );
    }

    _onButtonPress = () => {
        if (this.props.enabled && !this.props.favoriting) {
            this.props.toggleFavorite(this.props.id, this.props.type);
        }
    };

    _onLayout = (event) => {
        this.setState({
            countX: event.nativeEvent.layout.width / 2 + SeaScale.Layout(8),
        });
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        training: store.trainingClassStore.detail,
        data: store.courseStore.data,
        favoriteData: store.favoriteStore.data,
        favoriteStatus: store.favoriteStore.exception,
        favoritingFail: store.favoriteStore.favoritingFail,
        favoriting: store.favoriteStore.favoriting,
        // message: store.courseStore.message,
    };
}
//store到action的action映射
function mapDispatchToProps(dispatch) {
    return {
        fetchFavorite: (id, type) => dispatch(AC_AsyFetchFavoriteData(id, type)),
        toggleFavorite: (id, type) => dispatch(AC_AsyToggleFavorite(id, type)),
    };
}

const styles = StyleSheet.create({
    container: {
        width: SeaScale.Layout(80),
        height: SeaScale.Layout(88),
    },
    icon: {
        width: SeaScale.Layout(40),
        height: SeaScale.Layout(40),
    },
    numContainer: {
        position: 'absolute',
        top: SeaScale.Layout(12),
        paddingHorizontal: SeaScale.Layout(8),
        minWidth: SeaScale.Layout(34),
        borderRadius: SeaTheme.raduis_md,
        backgroundColor: SeaColor.tag_01,
        justifyContent: 'center',
        alignItems: 'center',
    },
    num: {
        fontSize: SeaScale.Layout(18),
        color: SeaColor.white,
    },
});
