/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件CommentButton 评论点击按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Image, Text, ViewPropTypes } from 'react-native';
import { SeaColor, SeaTheme, SeaScale } from '../../asserts';
import SeaButton from './SeaButton';

export default class SeaCommentButton extends React.PureComponent {
    static propTypes = {
        disable: PropTypes.bool,
        containerStyle: ViewPropTypes.style,
        textStyle: Text.propTypes.style,
        text: PropTypes.string,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        disabled: false,
        text: '点击评论',
    };

    render() {
        const { onPress, disabled, containerStyle, textStyle, text, ...restProps } = this.props;

        return (
            <SeaButton onPress={onPress} disabled={disabled} {...restProps}>
                <View style={[styles.containerStyle, containerStyle && containerStyle]}>
                    <Image
                        style={styles.icon}
                        source={require('../../asserts/images/makeComment.png')}
                    />
                    <Text style={[styles.textStyle, textStyle && textStyle]} numberOfLines={1}>
                        {text}
                    </Text>
                </View>
            </SeaButton>
        );
    }
}

const styles = StyleSheet.create({
    containerStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: SeaScale.Layout(20),
        paddingRight: SeaScale.Layout(40),
    },
    icon: {
        width: SeaScale.Layout(46),
        height: SeaScale.Layout(40),
    },
    textStyle: {
        marginLeft: SeaScale.Layout(16),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
});

// const styles = Platform.OS === 'ios' ? {
//     containerStyle: {
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     editor: {
//         height: 30,
//         borderRadius: 15,
//         borderWidth: StyleSheet.hairlineWidth,
//         borderColor: SeaColor.parting_line,
//         backgroundColor: 'white',
//         paddingLeft: 20,
//         paddingRight: 20,
//         fontSize: 14,
//     }
// };
