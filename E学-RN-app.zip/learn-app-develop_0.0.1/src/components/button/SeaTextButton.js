/**
 * @author xukj
 * @date 2019/06/18
 * @class
 * @description 文本按钮, 提供多种样式的订制
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, ViewPropTypes, Text } from 'react-native';
import { FSLTextButton } from 'react-native-kpframework';
import { SeaColor } from '../../asserts';
import connect from './connect';

// 按钮样式表
const SeaTheme = {
    main: {
        style: {
            backgroundColor: SeaColor.main,
        },
        titleStyle: {
            color: 'white',
            textAlign: 'center',
            fontSize: 14,
        },
        underlayColor: '#408FDF',
    },
    default: {
        style: {
            backgroundColor: 'white',
            borderColor: SeaColor.parting_line,
            borderWidth: StyleSheet.hairlineWidth,
        },
        titleStyle: {
            color: SeaColor.h2_text,
            textAlign: 'center',
            fontSize: 14,
        },
        underlayColor: 'white',
    },
    orange: {
        style: {
            backgroundColor: 'white',
            borderColor: SeaColor.orange,
            borderWidth: StyleSheet.hairlineWidth,
        },
        titleStyle: {
            color: SeaColor.orange,
            textAlign: 'center',
            fontSize: 14,
        },
        underlayColor: 'white',
    },
    blue: {
        style: {
            backgroundColor: 'white',
            borderColor: SeaColor.main,
            borderWidth: StyleSheet.hairlineWidth,
        },
        titleStyle: {
            color: SeaColor.main,
            textAlign: 'center',
            fontSize: 14,
        },
        underlayColor: 'white',
    },
    disable: {
        style: {
            backgroundColor: SeaColor.parting_line,
            borderWidth: 0,
        },
        titleStyle: {
            color: 'white',
            textAlign: 'center',
            fontSize: 14,
        },
        underlayColor: SeaColor.parting_line,
    },
    custom: {},
};

class SeaTextButton extends React.PureComponent {
    static propTypes = {
        // 样式
        theme: PropTypes.oneOf(['default', 'main', 'orange', 'blue', 'disable', 'custom']),
        // 圆角
        round: PropTypes.bool,
        disabled: PropTypes.bool,
        onPress: PropTypes.func.isRequired,
        title: PropTypes.string,
        titleColor: PropTypes.string,
        backgroundColor: PropTypes.string,
        style: ViewPropTypes.style,
        titleStyle: Text.propTypes.style,
        underlayColor: PropTypes.string,
    };

    static defaultProps = {
        theme: 'default',
        round: false,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { theme, round, style, titleStyle, ...restProps } = this.props;
        const themeStyle = SeaTheme[theme];

        return (
            <FSLTextButton
                style={[themeStyle.style, round && { borderRadius: 4 }, style && style]}
                titleStyle={[themeStyle.titleStyle, titleStyle && titleStyle]}
                underlayColor={themeStyle.underlayColor}
                {...restProps}
            />
        );
    }
}

export default connect(SeaTextButton);
