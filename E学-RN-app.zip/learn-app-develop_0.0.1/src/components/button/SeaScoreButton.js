/*
 * @Author: your name
 * @Date: 2020-07-13 14:56:50
 * @LastEditTime: 2020-08-14 16:15:44
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \learn\src\components\button\SeaScoreButton.js
 */
/**
 * @author xukj
 * @date 2019/11/26
 * @class
 * @description 评价按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Image } from 'react-native';
import { connect } from 'react-redux';
import SeaButton from './SeaButton';
import { SeaColor, SeaScale } from '../../asserts';
import { Actions } from 'react-native-router-flux';
import { AC_ResetResourceComment } from '../../redux/actions/resourceScore';

@connect(mapStateToProps, mapDispatchToProps)
export default class SeaScoreButton extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string.isRequired,
        initCommented: PropTypes.bool, // 默认是否已评价
        style: PropTypes.any,
        imageStyle: PropTypes.any,
        businessType:PropTypes.string,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { initCommented, scoreStore, style, imageStyle } = this.props;
        const isCommented = _.get(scoreStore, 'isCommented', false) || initCommented;
        return (
            <SeaButton style={[styles.scoreBtn, style && style]} onPress={this._onPress}>
                <Image
                    style={[
                        styles.scoreIcon,
                        isCommented && { tintColor: SeaColor.orange },
                        imageStyle && imageStyle,
                    ]}
                    resizeMode="contain"
                    source={require('../../asserts/images/ic-bottom-score.png')}
                />
            </SeaButton>
        );
    }

    _onPress = () => {
        const { initCommented, resourceId, scoreStore ,businessType} = this.props;
        // 默认已评价
        if (initCommented) return;
        // 已完成评价操作
        if (scoreStore.resourceId == resourceId && scoreStore.isCommented) return;
        Actions.show('addScore', { resourceId ,businessType});
    };
}

function mapStateToProps(store) {
    return {
        scoreStore: store.scoreStore,
    };
}

function mapDispatchToProps(dispatch) {
    return {
        reset: () => dispatch(AC_ResetResourceComment()),
    };
}

const styles = StyleSheet.create({
    scoreBtn: {
        width: SeaScale.Layout(130),
        alignItems: 'center',
        justifyContent: 'center',
    },
    scoreIcon: {
        width: SeaScale.Layout(40),
        height: SeaScale.Layout(40),
        overflow: 'hidden',
    },
});
