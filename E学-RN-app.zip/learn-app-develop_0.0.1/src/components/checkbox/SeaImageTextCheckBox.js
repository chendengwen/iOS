/**
 * @author xukj
 * @date 2019/01/03
 * @class
 * @description 界面展示组件SeaImageTextCheckBox 图片 + 文字的checkbox
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity } from 'react-native';
import styles from './DefaultCheckBoxStyles';
import DefaultCheckBox from './DefaultCheckBox';
import SeaReloadImage from '../image/SeaReloadImage';
import { SeaScale } from '../../asserts';

export default class SeaImageTextCheckBox extends React.PureComponent {
    static propTypes = {
        isMult: PropTypes.bool,
        containerStyle: PropTypes.any,
        title: PropTypes.string,
        checked: PropTypes.bool,
        onPress: PropTypes.func,
        onImagePress: PropTypes.func,
        source: PropTypes.any,
        imgWidth: PropTypes.number,
        imgHeight: PropTypes.number,
        checkedColor: PropTypes.string,
        textStyle: PropTypes.object, // 文字样式
    };

    static defaultProps = {
        imgWidth: SeaScale.Layout(400),
        imgHeight: SeaScale.Layout(400),
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            containerStyle,
            isMult,
            checked,
            title,
            onPress,
            onImagePress,
            imgWidth,
            imgHeight,
            source,
            checkedColor,
            textStyle,
            ...restProps
        } = this.props;

        return (
            <TouchableOpacity
                style={[styles.container, containerStyle && containerStyle]}
                activeOpacity={0.8}
                onPress={onPress}
                {...restProps}
            >
                <View style={{ flex: 1 }}>
                    <SeaReloadImage
                        width={imgWidth}
                        height={imgHeight}
                        source={source}
                        resizeMode="contain"
                        onPress={onImagePress}
                    />
                    <DefaultCheckBox
                        isMult={isMult}
                        checked={checked}
                        component={View}
                        containerStyle={[styles.checkbox, { marginTop: SeaScale.Layout(20) }]}
                        title={title}
                        checkedColor={checkedColor}
                        textStyle={textStyle}
                        disabled
                    />
                </View>
            </TouchableOpacity>
        );
    }
}
