/**
 * @author xukj
 * @date 2019/01/03
 * @description DefaultCheckBoxStyles 默认样式
 */
import { StyleSheet } from 'react-native';
import { SeaScale, SeaTheme } from '../../asserts';

const styles = StyleSheet.create({
    container: {
        margin: SeaScale.Layout(10),
        marginLeft: SeaScale.Layout(20),
        marginRight: SeaScale.Layout(20),
        backgroundColor: '#fafafa',
        borderColor: '#ededed',
        borderWidth: 1,
        padding: SeaScale.Layout(20),
        borderRadius: SeaScale.Layout(6),
        overflow: 'hidden',
    },
    input: {
        padding: SeaScale.Layout(16),
        backgroundColor: 'white',
        borderRadius: SeaScale.Layout(8),
        fontSize: SeaTheme.font_size_md,
    },
    checkbox: {
        margin: 0,
        marginLeft: 0,
        marginRight: 0,
        backgroundColor: 'transparent',
        borderWidth: 0,
        padding: 0,
    },
    textStyle: {
        fontSize: SeaTheme.font_size_md,
    },
});

export default styles;
