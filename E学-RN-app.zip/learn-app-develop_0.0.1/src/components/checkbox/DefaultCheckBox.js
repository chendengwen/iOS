/**
 * @author xukj
 * @date 2019/01/03
 * @class
 * @description 界面展示组件DefaultCheckBox
 */
import React from 'react';
import PropTypes from 'prop-types';
import { CheckBox } from 'react-native-elements';

const checkboxHoc = () => {
    class WrappedComponent extends React.PureComponent {
        static propTypes = {
            isMult: PropTypes.bool,
        };

        static defaultProps = {
            isMult: false,
        };

        constructor(props) {
            super(props);
        }

        componentDidMount() {}

        render() {
            const { isMult, ...restProps } = this.props;
            const iconProps = isMult
                ? {}
                : { checkedIcon: 'dot-circle-o', uncheckedIcon: 'circle-o' };
            return <CheckBox activeOpacity={0.8} {...iconProps} {...restProps} />;
        }
    }

    return WrappedComponent;
};

export default checkboxHoc();
