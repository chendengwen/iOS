/**
 * @author xukj
 * @date 2019/01/03
 * @class
 * @description 界面展示组件SeaImageCheckBox 图片checkbox
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity } from 'react-native';
import DefaultCheckBox from './DefaultCheckBox';
import styles from './DefaultCheckBoxStyles';
import SeaReloadImage from '../image/SeaReloadImage';
import { SeaScale } from '../../asserts';

export default class SeaImageCheckBox extends React.PureComponent {
    static propTypes = {
        isMult: PropTypes.bool,
        containerStyle: PropTypes.any,
        checked: PropTypes.bool,
        onPress: PropTypes.func,
        onImagePress: PropTypes.func,
        source: PropTypes.any,
        imgWidth: PropTypes.number,
        imgHeight: PropTypes.number,
        checkedColor: PropTypes.string,
        textStyle: PropTypes.object, // 文字样式
    };

    static defaultProps = {
        imgWidth: SeaScale.Layout(400),
        imgHeight: SeaScale.Layout(400),
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            containerStyle,
            isMult,
            checked,
            onPress,
            onImagePress,
            imgWidth,
            imgHeight,
            source,
            checkedColor,
            textStyle,
            ...restProps
        } = this.props;

        return (
            <TouchableOpacity
                style={[styles.container, containerStyle && containerStyle]}
                activeOpacity={0.8}
                onPress={onPress}
                {...restProps}
            >
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <DefaultCheckBox
                        isMult={isMult}
                        checked={checked}
                        component={View}
                        containerStyle={[styles.checkbox, { marginRight: SeaScale.Layout(20) }]}
                        checkedColor={checkedColor}
                        textStyle={textStyle}
                        disabled
                    />
                    <SeaReloadImage
                        width={imgWidth}
                        height={imgHeight}
                        source={source}
                        resizeMode="contain"
                        onPress={onImagePress}
                    />
                </View>
            </TouchableOpacity>
        );
    }
}
