/**
 * @author xukj
 * @date 2019/01/03
 * @class
 * @description 界面展示组件SeaInputCheckBox 有输入组件的checkbox
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, TextInput } from 'react-native';
import DefaultCheckBox from './DefaultCheckBox';
import styles from './DefaultCheckBoxStyles';
import { SeaScale } from '../../asserts';

export default class SeaInputCheckBox extends React.PureComponent {
    static propTypes = {
        isMult: PropTypes.bool,
        containerStyle: PropTypes.any,
        title: PropTypes.string,
        checked: PropTypes.bool,
        onPress: PropTypes.func,
        input: PropTypes.bool,
        inputPlaceholder: PropTypes.string,
        inputText: PropTypes.string,
        onChangeText: PropTypes.func,
        checkedColor: PropTypes.string,
        textStyle: PropTypes.object, // 文字样式
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            containerStyle,
            isMult,
            title,
            checked,
            onPress,
            input,
            inputPlaceholder,
            inputText,
            onChangeText,
            checkedColor,
            textStyle,
            ...restProps
        } = this.props;

        return (
            <View style={[styles.container, containerStyle && containerStyle]} {...restProps}>
                <DefaultCheckBox
                    isMult={isMult}
                    checked={checked}
                    containerStyle={styles.checkbox}
                    title={title}
                    onPress={onPress}
                    checkedColor={checkedColor}
                    textStyle={textStyle}
                />
                {input && checked && (
                    <TextInput
                        style={[styles.input, { marginTop: SeaScale.Layout(20) }]}
                        placeholder={inputPlaceholder}
                        defaultValue={inputText}
                        onChangeText={onChangeText}
                        underlineColorAndroid="transparent"
                        autoFocus
                        multiline
                    />
                )}
            </View>
        );
    }
}
