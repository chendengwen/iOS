/**
 * @author xukj
 * @date 2019/01/03
 * @description SeaCheckBox 自定义checkbox
 * 包括input、image、text等扩展功能
 * 1. 如果设置了input
 * @see SeaInputCheckBox
 * 2. 设置了source 和 title
 * @see SeaImageTextCheckBox
 * 3. 仅设置了source
 * @see SeaImageCheckBox
 * 4. 其他
 * @see DefaultCheckBox
 */
import React from 'react';
import PropTypes from 'prop-types';
import SeaInputCheckBox from './SeaInputCheckBox';
import SeaImageTextCheckBox from './SeaImageTextCheckBox';
import SeaImageCheckBox from './SeaImageCheckBox';
import DefaultCheckBox from './DefaultCheckBox';
import styles from './DefaultCheckBoxStyles';

export default class SeaCheckBox extends React.PureComponent {
    static propTypes = {
        isMult: PropTypes.bool,
        containerStyle: PropTypes.any,
        title: PropTypes.string,
        checked: PropTypes.bool,
        onPress: PropTypes.func,
        textStyle: PropTypes.object, // 文字样式
        // image类型的checkbox
        source: PropTypes.any,
        onImagePress: PropTypes.func,
        imgWidth: PropTypes.number,
        imgHeight: PropTypes.number,
        // input类型的checkbox
        input: PropTypes.bool,
        inputPlaceholder: PropTypes.string,
        inputText: PropTypes.string,
        onChangeText: PropTypes.func,
        // 回顾模式模式
        reviewMode: PropTypes.object, // { on: bool, checked: bool, answer: bool // 标准答案 }
    };

    static defaultProps = {
        textStyle: styles.textStyle,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { input, title, source, checked, reviewMode, ...restProps } = this.props;

        // 空字符会导致第三方组件崩溃，需要判断
        const desc = _.isEmpty(title) ? ' ' : title;

        let Component = DefaultCheckBox;
        if (input) Component = SeaInputCheckBox;
        else if (source && title) Component = SeaImageTextCheckBox;
        else if (source) Component = SeaImageCheckBox;

        if (reviewMode && reviewMode.on) {
            // 回顾模式
            const { answer, checked } = reviewMode;
            return (
                <Component
                    disabled={true}
                    checked={checked}
                    checkedColor="black"
                    input={input}
                    title={desc}
                    source={source}
                    {...restProps}
                />
            );
        } else {
            // 考试模式
            return (
                <Component
                    disabled={false}
                    checked={checked}
                    input={input}
                    checkedColor="black"
                    title={desc}
                    source={source}
                    {...restProps}
                />
            );
        }
    }
}
