/**
 * @author xukj
 * @date 2018/11/13
 * @class
 * @description 界面展示组件ImageZoomer 支持放大缩小
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ActivityIndicator, Text } from 'react-native';
import PhotoView from 'react-native-photo-view';

export default class ImageZoomer extends React.PureComponent {

    static propTypes = {
        url: PropTypes.string,
        width: PropTypes.number,
        height: PropTypes.number,
        onClose: PropTypes.func,
    };

    static defaultProps = {

    };

    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            error: false,
        };
    }

    componentDidMount() { }

    render() {
        const { url, width, height, onClose } = this.props;
        const { loading, error } = this.state;
        return (
            <View style={[styles.zoomer, { width, height }]} >
                <PhotoView
                    style={[styles.photoView, { width, height }]}
                    source={{ uri: url }}
                    minimumZoomScale={1}
                    maximumZoomScale={3}
                    androidScaleType="fitCenter"
                    onLoadStart={this._onLoadStart}
                    onLoadEnd={this._onLoadEnd}
                    onLoad={this._onLoadEnd}
                    onError={this._onError}
                    onTap={onClose}
                    onViewTap={onClose}
                />
                {loading && <ActivityIndicator animating={loading} color='white' size='large' />}
                {!loading && error && <Text style={styles.text}>图片加载失败</Text>}
            </View>
        );
    }

    _onLoadStart = () => {
        this.setState({ loading: true, error: false });
    };

    _onLoadEnd = () => {
        this.setState({ loading: false });
    };

    _onError = () => {
        this.setState({ loading: false, error: true });
    };
}

const styles = StyleSheet.create({
    zoomer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'black',
    },
    photoView: {
        position: 'absolute',
    },
    text: {
        fontSize: 16,
        color: 'white',
    },
});