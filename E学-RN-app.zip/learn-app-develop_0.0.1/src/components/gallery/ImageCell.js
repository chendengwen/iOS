/**
 * @author xukj
 * @date 2018/11/12
 * @class
 * @description 相册gallery cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ActivityIndicator, TouchableWithoutFeedback, Text } from 'react-native';
import { FSLCachedImage } from 'react-native-kpframework';

export default class ImageCell extends React.PureComponent {
    static propTypes = {
        width: PropTypes.number,
        height: PropTypes.number,
        item: PropTypes.object,
        onPress: PropTypes.func,
        enable: PropTypes.bool, // 只有enable的才能加载图片
    };

    static defaultProps = {
        item: {},
        onPress: path => {},
    };

    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            error: false,
            reloadCount: 0,
        };
        // 缓存成功后这里会替换成本地地址
        this.path = props.item ? props.item.url : undefined;
    }

    render() {
        const { error } = this.state;
        return error ? this._renderError(this.props) : this._renderImages(this.props, this.state);
    }

    _renderImages = (props, state) => {
        const { width, height, item, enable, onPress } = props;
        const { loading } = state;
        let Component = View;
        if (onPress) Component = TouchableWithoutFeedback;
        return (
            <Component style={[styles.cell, { width, height }]} onPress={this._onPress}>
                <View style={[styles.cell, { width, height }]}>
                    <FSLCachedImage
                        style={[styles.image, { width, height }]}
                        source={enable ? { uri: item.url } : undefined}
                        resizeMode="contain"
                        onImageLoadStart={this._onLoadStart}
                        onImageLoadEnd={this._onLoadEnd}
                        onImageError={this._onError}
                    />
                    {loading && (
                        <ActivityIndicator
                            style={styles.indicator}
                            animating={true}
                            color="white"
                            size="large"
                        />
                    )}
                </View>
            </Component>
        );
    };

    _renderError = props => {
        const { width, height } = props;
        return (
            <TouchableWithoutFeedback
                style={[styles.cell, { width, height }]}
                onPress={this._reload}
            >
                <View style={[styles.cell, { width, height }]}>
                    <Text style={styles.text}>点击重新获取图片</Text>
                </View>
            </TouchableWithoutFeedback>
        );
    };

    _onLoadStart = () => {
        this.setState({ loading: true, error: false });
    };

    _onLoadEnd = path => {
        if (path) this.path = 'file://' + path;
        this.setState({ loading: false });
    };

    _onError = () => {
        this.setState({ loading: false, error: true });
    };

    _reload = () => {
        this.setState({ reloadCount: this.state.reloadCount + 1, error: false });
    };

    _onPress = () => {
        const { onPress } = this.props;
        onPress(this.path);
    };
}

const styles = StyleSheet.create({
    cell: {
        backgroundColor: 'black',
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        position: 'absolute',
        margin: 'auto',
    },
    indicator: {
        position: 'absolute',
        margin: 'auto',
    },
    text: {
        fontSize: 16,
        color: 'white',
    },
});
