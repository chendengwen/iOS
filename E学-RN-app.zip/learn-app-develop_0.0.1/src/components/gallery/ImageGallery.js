/**
 * @author xukj
 * @date 2018/11/12
 * @class
 * @description 图片浏览器
 * imageUrls的结构
 * { url: http:// xxxx }
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, FlatList, Dimensions, Modal } from 'react-native';
import ImageCell from './ImageCell';
import ImageZoomer from './ImageZoomer';
import _ from 'lodash';

export default class ImageGallery extends React.PureComponent {

    static propTypes = {
        width: PropTypes.number,
        height: PropTypes.number,
        imageUrls: PropTypes.array,
        onIndexChanged: PropTypes.func,
    };

    static defaultProps = {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
        imageUrls: [],
        onIndexChanged: (index) => { },
    };

    constructor(props) {
        super(props);
        this.state = {
            zoom: false,
            path: undefined,
            currentIndex: 0,
        };
    }

    componentDidMount() { }

    render() {
        const { width, height, imageUrls } = this.props;
        const { zoom, path, currentIndex } = this.state;
        if (!imageUrls && imageUrls.length <= 0) return null;
        return (
            <View style={[styles.gallery, { width, height: height }]}>
                <FlatList
                    keyExtractor={(_, index) => index.toString()}
                    style={styles.list}
                    horizontal={true}
                    pagingEnabled={true}
                    data={imageUrls}
                    renderItem={this._renderItem}
                    onMomentumScrollEnd={this._onScrollEnd}
                    initialNumToRender={1}
                    removeClippedSubviews={true}
                    extraData={{currentIndex}}
                />
                <Modal
                    animationType='fade'
                    transparent={false}
                    visible={zoom}
                    supportedOrientations={['portrait', 'landscape-left', 'landscape-right']}
                    onRequestClose={this._hideZoomer}
                >
                    <ImageZoomer
                        url={path}
                        width={width}
                        height={height}
                        onClose={this._hideZoomer}
                    />
                </Modal>
            </View>
        );
    }

    _renderItem = ({ item, index }) => {
        const { width, height } = this.props;
        const { currentIndex } = this.state;
        // -2、-1、0、1、2渲染
        const enable = (index - currentIndex >= -2) && (index - currentIndex <= 2);
        return (
            <ImageCell
                index={index}
                currentIndex={currentIndex}
                width={width}
                height={height}
                item={item}
                enable={enable}
                onPress={this._showZoomer}
            />
        );
    };

    _onScrollEnd = (event) => {
        const { width, onIndexChanged } = this.props;
        // 在华为某些型号的手机上会出现计算误差
        const index = Math.round(event.nativeEvent.contentOffset.x / width);
        if (onIndexChanged) onIndexChanged(index);
        this.setState({ currentIndex: index });
    };

    _onViewableItemsChanged = ({ viewableItems, changed }) => {

    };

    _showZoomer = (path) => {
        this.setState({ zoom: true, path: path });
    };

    _hideZoomer = () => {
        this.setState({ zoom: false, path: '' });
    };
}

const styles = StyleSheet.create({
    gallery: {
        flex: 1,
        backgroundColor: 'black',
    },
    list: {
        backgroundColor: 'transparent',
        flex: 1,
    }
});