/**
 * @author xukj
 * @date 2018/11/09
 * @description SeaIconButton 自定义导航栏items
 */
import React from 'react';
import PropTypes from 'prop-types';
import { ViewPropTypes } from 'react-native';
import { SeaIcon } from '../../asserts';
import { FSLNavigationItems as Items } from 'react-native-kpframework';

const SeaIconButton = (props) => {

    const {
        containerStyle,
        size,
        name,
        color,
        onPress,
        ...restProps
    } = props;

    return (
        <Items.CustomButton
            containerStyle={[
                { width: 44 },
                containerStyle && containerStyle,
            ]}
            component={SeaIcon}
            itemProps={{
                size: size,
                name: name,
                color: color,
            }}
            onPress={onPress}
            {...restProps}
        />
    );
};

SeaIconButton.propTypes = {
    onPress: PropTypes.func,
    containerStyle: ViewPropTypes.style,
    itemStyle: ViewPropTypes.style,
    name: PropTypes.string,
    size: PropTypes.number,
    color: PropTypes.string,
    itemProps: PropTypes.object,
};

SeaIconButton.defaultProps = {
    containerStyle: { width: 44, height: 44 },
    size: 26,
};

export default SeaIconButton;