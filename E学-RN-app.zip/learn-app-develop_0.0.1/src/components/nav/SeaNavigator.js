/**
 * @author xukj
 * @date 2018/8/20
 * @description 通用导航栏
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Text as NativeText } from 'react-native';
import { SeaColor } from '../../asserts';
import { SeaDevice } from '../../util';
import { FSLLegacyNavigator } from 'react-native-kpframework';
import {
    renderBackButton,
    renderCloseButton,
    renderTextButton,
    renderIconButton,
    renderTitle,
} from './SeaNavigationItems';

// 是否iPhoneX类的异形屏
const isiOSProfiledScreen = SeaDevice.isIPhoneX();

const SeaNavigator = props => {
    const { style } = props;

    return (
        <FSLLegacyNavigator
            style={[styles.navigator, style && style]}
            iosisProfiledScreen={isiOSProfiledScreen}
            renderTitle={renderTitle}
            renderBackButton={renderBackButton}
            renderCloseButton={renderCloseButton}
            renderLeftTextButton={renderTextButton}
            renderLeftIconButton={renderIconButton}
            renderRightTextButton={renderTextButton}
            renderRightIconButton={renderIconButton}
            {...props}
        />
    );
};

SeaNavigator.propTypes = {
    iosisProfiledScreen: PropTypes.bool, // ios端有效，是否异形屏
    landscape: PropTypes.bool,
    title: PropTypes.string,
    titleStyle: NativeText.propTypes.style,
    renderTitle: PropTypes.func,
    itemTintColor: PropTypes.string, // 左右按钮的文字、图标颜色
    // 默认样式返回键，优先级最低
    backMode: PropTypes.bool,
    onBackPress: PropTypes.func,
    renderBackButton: PropTypes.func,
    // 默认样式关闭键，优先级中
    closeMode: PropTypes.bool,
    onClosePress: PropTypes.func,
    renderCloseButton: PropTypes.func,
    // 自定义icon或text样式左方按钮，优先级高
    leftIcon: PropTypes.string,
    leftText: PropTypes.string,
    onLeftPress: PropTypes.func,
    renderLeftIconButton: PropTypes.func,
    renderLeftTextButton: PropTypes.func,
    // 自定义icon或text样式右方按钮，优先级高
    rightIcon: PropTypes.string,
    rightText: PropTypes.string,
    onRightPress: PropTypes.func,
    renderRightIconButton: PropTypes.func,
    renderRightTextButton: PropTypes.func,
    // 自定义button，优先级最高
    renderLeftButton: PropTypes.func,
    renderRightButton: PropTypes.func,
};

 SeaNavigator.defaultProps = {
    itemTintColor: 'white',
};

const styles = StyleSheet.create({
    navigator: {
        backgroundColor: SeaColor.white,
        borderBottomWidth: 1,
        borderBottomColor: '#F6F6F6',
    },
}); 

export default SeaNavigator;
