/**
 * @author xukj
 * @date 2018/11/05
 * @description SeaNavigationItems 智学365定制的导航栏样式
 */
import React from 'react';
import { StyleSheet } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { SeaIcon, SeaTheme, SeaStyle } from '../../asserts';
import { FSLNavigationItems as Items } from 'react-native-kpframework';
import SeaIconButton from './SeaIconButton';

// 图标大小
const defaultIconSize = SeaTheme.icon_size_md;

/**
 * 定制导航栏title
 * @param {string} title 标题
 */
/* const renderTitle = title => {
    return <Items.Title style={SeaStyle.navTitle} title={title} />;
}; */

/**
 * 定制导航栏title
 * @param {string} title 标题
 * @param {object} style 自定义样式
 */
const renderTitle = (title, style) => {
    return <Items.Title style={style} title={title} />;
};

/**
 * 定制导航栏back按钮
 * @param {function} onPress 点击事件，默认pop
 */
const renderBackButton = (onPress = Actions.pop) => {
    return renderSeaIconButton(onPress, 'back', '#0C5FDD');
};

/**
 * 定制导航栏关闭按钮
 * @param {function} onPress 点击关闭，默认pop
 */
const renderCloseButton = (onPress = Actions.pop) => {
    return renderIconButton(onPress, 'close');
};

/**
 * 定制导航栏icon按钮
 * @param {function} onPress 点击事件
 * @param {string} name icon名称
 * @param {string} color icon颜色
 */
const renderIconButton = (onPress, name, color = '#0C5FDD', size = defaultIconSize) => {
    return (
        <Items.IconButton
            containerStyle={styles.navIconWrapStyle}
            name={name}
            size={size}
            color={color}
            onPress={onPress}
        />
    );
};

/**
 * 定制导航栏文字按钮
 * @param {function} onPress 点击事件
 * @param {string} text 按钮文字
 */
const renderTextButton = (onPress, text) => {
    return (
        <Items.TextButton
            containerStyle={styles.textWrapStyle}
            itemStyle={styles.textStyle}
            text={text}
            onPress={onPress}
        />
    );
};

/**
 * 定制导航栏icon按钮，因为遗留代码的问题，为了兼容以前的代码，这里专门提供一个SeaIcon样式的按钮
 * @param {function} onPress 点击事件
 * @param {string} name icon名称
 * @param {number} size icon大小
 * @param {object} containerStyle 自定义样式
 */
const renderSeaIconButton = (
    onPress,
    name,
    color = 'white',
    size = defaultIconSize,
    containerStyle
) => {
    return (
        <SeaIconButton
            containerStyle={[styles.navIconWrapStyle, containerStyle]}
            size={size}
            name={name}
            color={color}
            onPress={onPress}
        />
    );
};

/**
 * 定制导航栏image类型按钮，某些情况下会需要设置自定义图片
 * @param {function} onPress 点击事件
 * @param {*} source source图片
 * @param {*} imageStyle image 样式
 * @param {*} itemProps image property
 */
const renderImageButton = (onPress, source, imageStyle, itemProps) => {
    return (
        <Items.ImageButton
            containerStyle={styles.navIconWrapStyle}
            source={source}
            onPress={onPress}
            itemStyle={[{ width: defaultIconSize, height: defaultIconSize }, imageStyle]}
            itemProps={{ resizeMode: 'contain', ...itemProps }}
        />
    );
};

/**
 * 半透明的返回键样式，在部分界面会用到
 * @param {function} onPress 返回按钮
 */
const renderTransparentBackButton = (onPress = Actions.pop) => {
    return (
        <Items.CustomButton
            containerStyle={styles.transparentButtonStyle}
            component={SeaIcon}
            itemProps={{
                size: defaultIconSize,
                name: 'back',
                color: 'white',
            }}
            onPress={onPress}
        />
    );
};

/**
 * 半透明的图标样式，在某些特定界面会用到
 * @param {function} onPress 返回
 * @param {string} name 图标
 */
const renderTransparentSeaIconButton = (onPress, name, color, size = defaultIconSize) => {
    return (
        <Items.CustomButton
            containerStyle={styles.transparentButtonStyle}
            component={SeaIcon}
            itemProps={{
                size: size,
                name: name,
                color: color,
            }}
            onPress={onPress}
        />
    );
};

const styles = StyleSheet.create({
    transparentButtonStyle: {
        backgroundColor: 'rgba(1, 1, 1, 0.5)',
        borderRadius: 17,
        width: 34,
        height: 34,
        overflow: 'hidden',
        marginLeft: 5,
        marginRight: 5,
    },
    // 导航栏图标按钮框. ps: 导航栏高度dp不随屏幕变化而缩放
    navIconWrapStyle: {
        width: 44,
        height: 44,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
    },
    // 导航栏文字按钮框. ps: 导航栏高度dp不随屏幕变化而缩放
    textWrapStyle: {
        height: 44,
        marginLeft: 10,
        marginRight: 10,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',
    },
    textStyle: {
        fontSize: SeaTheme.font_size_xl,
        color: '#656565',
    },
});

export {
    renderBackButton,
    renderCloseButton,
    renderTitle,
    renderIconButton,
    renderTextButton,
    renderSeaIconButton,
    renderImageButton,
    renderTransparentBackButton,
    renderTransparentSeaIconButton,
};
