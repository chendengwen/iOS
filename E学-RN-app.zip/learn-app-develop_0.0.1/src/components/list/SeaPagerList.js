/**
 * @author xukj
 * @date 2018/10/9
 * @class
 * @description SeaPagerList
 */
import React from 'react';
import PropTypes from 'prop-types';
import {FSLPagerList} from 'react-native-kpframework';
import ExceptionView from '../error/ExceptionView';

export default class SeaPagerList extends React.PureComponent {

    static propTypes = {
        ...FSLPagerList.propTypes,
    };

    static defaultProps = {};

    reload = () => {
        this.refs.list.reload();
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {

    }

    render() {
        return (
            <FSLPagerList
                ref="list"
                FSLListEmptyComponent={this._renderEmptyComponent}
                {...this.props}
            />
        );
    }

    _renderEmptyComponent = () => {
        return (
            <ExceptionView />
        );
    };
}