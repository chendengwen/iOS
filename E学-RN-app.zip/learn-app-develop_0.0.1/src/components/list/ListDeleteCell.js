/**
 * @author xukj
 * @date 2018/7/3
 * @description 列表项通用控件 (带右边箭头、分割线 和 左滑删除)
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';
import { SwipeRow } from 'react-native-swipe-list-view';
import SeaListCell from './SeaListCell';
import { SeaColor, SeaScale, SeaTheme } from '../../asserts';
import SeaTextButton from '../button/SeaTextButton';

export default class ListDeleteCell extends React.PureComponent {
    static propTypes = {
        onPress: PropTypes.func, // cell点击
        onDeletePress: PropTypes.func, // 删除按钮点击
        onRowOpen: SwipeRow.propTypes.onRowOpen,
        onRowClose: SwipeRow.propTypes.onRowClose,
        disableDelete: PropTypes.bool,
    };

    static defaultProps = {
        onDeletePress: () => {},
        disableDelete: false,
    };

    constructor(props) {
        super(props);
    }

    /*
     * public
     * @method 关闭删除按钮
     * @param
     * @return
     */
    closeRow = () => {
        this.refs.swiper.closeRow();
    };

    render() {
        const {
            disableDelete,
            onRowOpen,
            onRowClose,
            onDeletePress,
            children,
            ...restProps
        } = this.props;

        return (
            <SwipeRow
                ref="swiper"
                onRowOpen={onRowOpen}
                onRowClose={onRowClose}
                disableRightSwipe
                disableLeftSwipe={disableDelete}
                rightOpenValue={0 - SeaScale.Layout(150)}
                stopRightSwipe={0 - SeaScale.Layout(200)}
            >
                <View style={styles.rightContainer}>
                    <SeaTextButton
                        theme="custom"
                        style={styles.deleteStyle}
                        titleStyle={styles.deleteTitleStyle}
                        onPress={onDeletePress}
                        title="删除"
                    />
                </View>
                <View style={{ flex: 1, backgroundColor: 'white' }}>
                    <SeaListCell {...restProps}>{children}</SeaListCell>
                </View>
                >
            </SwipeRow>
        );
    }
}

const styles = StyleSheet.create({
    rightContainer: {
        flex: 1,
        alignItems: 'flex-end',
        backgroundColor: SeaColor.red,
        marginLeft: SeaScale.Layout(40),
    },
    deleteStyle: {
        flex: 1,
        width: SeaScale.Layout(150),
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: SeaColor.red,
        marginLeft: SeaScale.Layout(40),
    },
    deleteTitleStyle: {
        fontSize: SeaTheme.font_size_md,
        color: 'white',
    },
});
