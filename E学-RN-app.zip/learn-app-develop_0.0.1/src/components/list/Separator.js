/**
 * Created by xukj on 2018/6/15.
 */
import React from 'react';
import {
    View,
    StyleSheet,
} from 'react-native';

/**
 * @author xukj 
 *
 * @date 2018/7/3
 * 
 * @description
 *
 * 通用分割线
*/
export default class Separator extends React.Component {
    render() {
        return (
            <View
                style={styles.sp}
                {...this.props}
            />
        );
    }
}

const styles = StyleSheet.create({
    sp: {
        height: 10,
        backgroundColor: 'transparent',
        flex: 1,
    },
});