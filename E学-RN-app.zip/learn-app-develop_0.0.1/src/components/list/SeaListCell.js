/**
 * @author xukj
 * @date 2018/12/21
 * @class
 * @description 界面展示组件SeaListCell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLListCell } from 'react-native-kpframework';
import { SeaColor, SeaTheme } from '../../asserts';

export default class SeaListCell extends React.PureComponent {
    static propTypes = {
        showArrow: PropTypes.bool, // 是否显示箭头
        showSeparator: PropTypes.bool,
        arrowColor: PropTypes.string,
        arrowSize: PropTypes.number,
        separatorColor: PropTypes.string,
        onPress: PropTypes.func, // 点击事件
        disabled: PropTypes.bool,
        backgroundColor: PropTypes.string, // 背景色
    };

    static defaultProps = {
        arrowSize: SeaTheme.icon_size_md,
        arrowColor: SeaColor.grey,
        separatorColor: SeaColor.parting_line,
        backgroundColor: 'transparent',
        showArrow: true,
        showSeparator: true,
    };

    render() {
        const { showArrow, showSeparator, ...restProps } = this.props;
        return (
            <FSLListCell
                activeOpacity={0.8}
                arrow={showArrow}
                separator={showSeparator}
                {...restProps}
            />
        );
    }
}
