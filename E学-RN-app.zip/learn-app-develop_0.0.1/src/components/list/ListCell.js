/**
 * Created by xukj on 2018/6/28.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { SeaIcon, SeaColor, SeaTheme, SeaScale } from '../../asserts';

/**
 * @author xukj
 *
 * @date 2018/7/3
 *
 * @description 列表项通用控件 (带右边箭头 和 分割线)
 */
export default class ListCell extends React.PureComponent {
    static propTypes = {
        showArrow: PropTypes.bool, // 是否显示箭头
        showSeparator: PropTypes.bool, // 是否显示分割线
        onPress: PropTypes.func, // 点击事件
        disabled: PropTypes.bool,
    };
    static defaultProps = {
        showArrow: true,
        showSeparator: true,
        onPress: () => {},
        disabled: false,
    };

    render() {
        const { showArrow, showSeparator, onPress, disabled, style } = this.props;
        return (
            <TouchableOpacity onPress={onPress} disabled={disabled} activeOpacity={0.8}>
                <View
                    style={[styles.contentView, showSeparator ? styles.separator : null]}
                    removeClippedSubviews={true}
                >
                    <View style={[styles.content, style]}>{this.props.children}</View>
                    {showArrow && (
                        <SeaIcon
                            style={styles.arrow}
                            name={'arrow-goto'}
                            size={SeaScale.Layout(34)}
                            color={SeaColor.grey}
                        />
                    )}
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    contentView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    content: {
        flex: 1,
        overflow: 'hidden',
    },
    arrow: {
        position: 'absolute',
        top: 'auto',
        bottom: 'auto',
        right: SeaScale.Layout(20),
    },
    separator: {
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: SeaColor.parting_line,
    },
});
