/**
 * @author xukj
 * @date 2018/10/9
 * @class
 * @description SeaNoPagerList 非分页加载list
 * 支持刷新操作
 * this.refs.list.reload()
 */
import React from 'react';
import PropTypes from 'prop-types';
import {FSLNoPagerList} from 'react-native-kpframework';
import ExceptionView from '../error/ExceptionView';

export default class SeaNoPagerList extends React.PureComponent {

    static propTypes = {
        ...FSLNoPagerList.propTypes,
    };

    static defaultProps = {};

    reload = () => {
        this.refs.list.reload();
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {

    }

    render() {
        return (
            <FSLNoPagerList
                ref="list"
                FSLListEmptyComponent={this._renderEmptyComponent}
                {...this.props}
            />
        );
    }

    _renderEmptyComponent = () => {
        return (
            <ExceptionView />
        );
    };
}