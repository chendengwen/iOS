/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件AddComment 提交回答
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, TextInput, Switch, Text, Alert } from 'react-native';
import SeaNavigator from '../nav/SeaNavigator';
import { SeaColor, SeaStyle, SeaTheme } from '../../asserts';

export default class AddComment extends React.PureComponent {
    static propTypes = {
        anonymous: PropTypes.bool,
        title: PropTypes.string,
        placeholder: PropTypes.string,
        onClosePress: PropTypes.func,
        onPublishPress: PropTypes.func,
    };

    static defaultProps = {
        title: '评论',
        placeholder: '请输入内容',
        onClosePress: () => {},
        onPublishPress: (content, anonymous) => {},
        anonymous: false,
    };

    constructor(props) {
        super(props);
        this.rightButton = fsl.debounce(() => this._checkValid(props.onPublishPress));
        this.content = '';
        this.state = { anonymous: props.anonymous };
    }

    componentDidMount() {}

    render() {
        const { title, placeholder, onClosePress } = this.props;
        const { anonymous } = this.state;
        return (
            <View style={SeaStyle.page}>
                <SeaNavigator
                    title={title}
                    closeMode={true}
                    onClosePress={onClosePress}
                    rightText="提交"
                    onRightPress={this.rightButton}
                />
                <TextInput
                    style={styles.input}
                    multiline={true}
                    placeholder={placeholder}
                    placeholderTextColor={SeaColor.content_text}
                    autoFocus={true}
                    autoCapitalize="none"
                    autoCompleteType="off"
                    autoCorrect={false}
                    underlineColorAndroid="transparent"
                    onChangeText={this._onChangeText}
                />
                <View style={styles.footer}>
                    <Switch
                        style={styles.switch}
                        value={anonymous}
                        onValueChange={this._onValueChanged}
                    />
                    <Text style={styles.anonymous}>匿名</Text>
                </View>
            </View>
        );
    }

    _onValueChanged = value => {
        this.setState({ anonymous: value });
    };

    _onChangeText = text => {
        this.content = text;
    };

    _checkValid = onPublish => {
        const value = _.trim(this.content);
        if (value.length > 0) {
            onPublish(value, this.state.anonymous);
        } else {
            Alert.alert('提示', '内容不能为空', [{ text: '取消', style: 'cancel' }], {
                cancelable: false,
            });
        }
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
    },
    leftItem: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
    },
    rightItem: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
    },
    rightTitle: {
        fontSize: 14,
        color: 'white',
    },
    input: {
        marginTop: 15,
        marginLeft: 15,
        marginRight: 15,
        marginBottom: 10,
        height: 200,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
        padding: SeaTheme.h_spacing_sm,
        fontSize: SeaTheme.font_size_md,
        textAlignVertical: 'top',
    },
    footer: {
        height: 44,
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row',
        marginLeft: 15,
        marginRight: 15,
    },
    switch: {
        width: 60,
        height: 30,
    },
    anonymous: {
        fontSize: SeaTheme.font_size_md,
    },
});
