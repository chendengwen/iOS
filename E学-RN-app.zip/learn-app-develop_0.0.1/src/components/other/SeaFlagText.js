/**
 * @author xukj
 * @date 2019/08/02
 * @class
 * @description 文字flag组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaColor, SeaScale, SeaTheme } from '../../asserts';

export default class SeaFlagText extends React.PureComponent {
    static propTypes = {
        theme: PropTypes.oneOf(['main', 'lightblue', 'green', 'orange', 'red']),
        style: Text.propTypes.style,
    };

    static defaultProps = {
        theme: 'main',
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { style, theme, ...restProps } = this.props;
        const themeStyle = FlagTheme[theme];
        return (
            <Text style={[styles.text, themeStyle && themeStyle, style && style]} {...restProps} />
        );
    }
}

// 按钮样式表
const FlagTheme = {
    main: {
        backgroundColor: SeaColor.main,
    },
    lightblue: {
        backgroundColor: SeaColor.tag_02,
    },
    green: {
        backgroundColor: SeaColor.tag_03,
    },
    orange: {
        backgroundColor: SeaColor.tag_01,
    },
    red: {
        backgroundColor: SeaColor.tag_04,
    },
};

const styles = StyleSheet.create({
    text: {
        fontSize: SeaTheme.font_size_sm,
        color: 'white',
        paddingLeft: SeaScale.Layout(8),
        paddingRight: SeaScale.Layout(8),
        paddingTop: SeaScale.Layout(4),
        paddingBottom: SeaScale.Layout(4),
        minWidth: SeaScale.Layout(60),
        minHeight: SeaScale.Layout(32),
    },
});
