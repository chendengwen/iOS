/**
 * @author xukj
 * @date 2018/7/3
 * @class
 * @description 全屏加载层( 菊花 + 文字 )
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ActivityIndicator, Text } from 'react-native';
import { SeaColor, SeaTheme } from '../../asserts';

export default class SeaLoading extends React.PureComponent {
    static propTypes = {
        size: PropTypes.string,
        color: PropTypes.string,
        text: PropTypes.string,
    };

    static defaultProps = {
        size: 'large',
        color: 'gray',
        text: '加载中...',
    };

    render() {
        const { size, color, text, ...restProps } = this.props;
        return (
            <View style={styles.container} {...restProps}>
                <ActivityIndicator style={styles.centering} size={size} color={color} />
                <Text style={styles.loadingText}>{text}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    loadingText: {
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
    },
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    centering: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 8,
        height: 80,
        marginTop: 50,
    },
});
