/**
 * @author xukj
 * @date 2019/07/08
 * @class
 * @description 弹出卡片
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Animated, Image, View } from 'react-native';
import { FSLButton, FSLPortal } from 'react-native-kpframework';
import { SeaScale } from '../../asserts';

// 为了保证关闭动画的执行，这里需要管理card
class CardManager {
    constructor() {
        this.cards = {};
    }

    add(key, comp) {
        this.cards[key] = comp;
    }

    remove(key) {
        this.cards[key] = null;
    }

    get(key) {
        return this.cards[key];
    }
}

const manager = new CardManager();

export default class SeaCard extends React.PureComponent {
    static propTypes = {
        close: PropTypes.bool,
        onAnimationEnd: PropTypes.func,
        onClose: PropTypes.func,
    };

    static defaultProps = {
        close: true,
    };

    static show(config = {}) {
        const { node, onClose } = config;
        const key = FSLPortal.add(
            <SeaCard
                ref={_comp => manager.add(key, _comp)}
                onClose={onClose}
                onAnimationEnd={() => SeaCard.remove(key)}
            >
                {node}
            </SeaCard>
        );
        return key;
    }

    static hide(key, animated = true) {
        const comp = animated ? manager.get(key) : null;
        if (comp) {
            comp._close();
        } else {
            SeaCard.remove(key);
        }
    }

    static remove(key) {
        FSLPortal.remove(key);
        manager.remove(key);
    }

    constructor(props) {
        super(props);
        this.state = {
            fadeAnim: new Animated.Value(0),
            springAnim: new Animated.Value(1.2),
        };
        this.anim = null;
    }

    componentDidMount() {
        this._startShowAnimate();
    }

    componentWillUnmount() {
        if (this.anim) {
            this.anim.stop();
            this.anim = null;
        }
    }

    render() {
        const { children, close } = this.props;
        return (
            <Animated.View
                style={[styles.mask, { opacity: this.state.fadeAnim }]}
                pointerEvents="box-none"
            >
                <Animated.View
                    style={[{ padding: 10 }, { transform: [{ scale: this.state.springAnim }] }]}
                >
                    <View style={styles.contentView}>{children}</View>
                    {close && (
                        <FSLButton style={styles.closeContainer} onPress={this._onClosePress}>
                            <Image
                                style={styles.close}
                                source={require('../../asserts/images/home/close.png')}
                            />
                        </FSLButton>
                    )}
                </Animated.View>
            </Animated.View>
        );
    }

    /**
     * 为了避免关闭动画不执行，直接调用该方法关闭
     */
    _close() {
        this._startHideAnimate();
    }

    _onClosePress = () => {
        this._startHideAnimate();
    };

    /**
     * 启动动画
     */
    _startShowAnimate = () => {
        if (this.anim) {
            this.anim = null;
        }

        this.anim = Animated.parallel(
            [
                // 渐显
                Animated.timing(this.state.fadeAnim, {
                    toValue: 1,
                    duration: 200,
                    useNativeDriver: true,
                }),
                // 弹框动画
                Animated.spring(this.state.springAnim, {
                    toValue: 1,
                    friction: 5,
                    useNativeDriver: true,
                    duration: 200,
                }),
            ],
            { stopTogether: true }
        );
        this.anim.start(() => {});
    };

    /**
     * 关闭动画
     */
    _startHideAnimate = () => {
        const { onClose, onAnimationEnd } = this.props;
        if (this.anim) {
            this.anim = null;
        }

        this.anim = Animated.sequence([
            Animated.timing(this.state.fadeAnim, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
            }),
        ]);

        this.anim.start(() => {
            this.anim = null;
            if (onClose) onClose();
            if (onAnimationEnd) onAnimationEnd();
        });
    };
}

const space = SeaScale.screenWidth > 320 ? 35 : 10;

const styles = StyleSheet.create({
    mask: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    contentView: {
        flexDirection: 'row',
        width: SeaScale.screenWidth - space * 2,
        minHeight: 200,
        paddingLeft: 20,
        paddingRight: 20,
        justifyContent: 'center',
        backgroundColor: 'white',
        borderRadius: 8,
    },
    closeContainer: {
        position: 'absolute',
        top: 0,
        right: 0,
        width: 30,
        height: 30,
    },
    close: {
        width: 30,
        height: 30,
    },
});
