/**
 * @author xukj
 * @date 2019/07/09
 * @class
 * @description 普通的提示card
 * 图标 + 标题 + 内容 + 确定按钮/取消按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Image, Text } from 'react-native';
import { SeaColor } from '../../asserts';
import SeaCard from './SeaCard';
import SeaTextButton from '../button/SeaTextButton';

export class SeaNormalCardView extends React.PureComponent {
    static propTypes = {
        title: PropTypes.string.isRequired,
        content: PropTypes.string.isRequired,
        icon: PropTypes.oneOfType(['number', 'object']),
        submitTitle: PropTypes.string, // 如果设置了显示该按钮
        cancelTitle: PropTypes.string, // 如果设置了显示该按钮
        onSubmitPress: PropTypes.func,
        onCancelPress: PropTypes.func,
    };

    static defaultProps = {
        icon: require('../../asserts/images/icon_card.png'),
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            title,
            content,
            icon,
            submitTitle,
            cancelTitle,
            onSubmitPress,
            onCancelPress,
        } = this.props;
        return (
            <View style={styles.contentView}>
                <Image style={styles.icon} resizeMode="contain" source={icon} />
                <Text style={styles.title}>{title}</Text>
                <Text style={styles.content}>{content}</Text>
                <View style={styles.footer}>
                    {submitTitle && (
                        <SeaTextButton
                            style={[styles.button, { backgroundColor: SeaColor.orange }]}
                            titleStyle={{ color: 'white' }}
                            title={submitTitle}
                            underlayColor={SeaColor.orange}
                            onPress={onSubmitPress}
                        />
                    )}
                    {cancelTitle && (
                        <SeaTextButton
                            theme="default"
                            style={[
                                styles.button,
                                { marginTop: 10, borderColor: SeaColor.content_text },
                            ]}
                            title={cancelTitle}
                            onPress={onCancelPress}
                        />
                    )}
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    contentView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    icon: {
        width: 168,
        height: 147,
    },
    title: {
        fontSize: 18,
        fontWeight: '600',
        color: SeaColor.h1_text,
        textAlign: 'center',
        marginTop: -20,
    },
    content: {
        marginTop: 8,
        fontSize: 14,
        color: SeaColor.h1_text,
        lineHeight: 26,
    },
    footer: {
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 20,
        paddingBottom: 20,
    },
    button: {
        width: '100%',
        height: 40,
        borderRadius: 8,
    },
});

/**
 * 显示card
 * @param {object} config
 * {
 *   title: PropTypes.string.isRequired,
 *   content: PropTypes.string.isRequired,
 *   icon: PropTypes.oneOfType([Number, Object])
 *   submitTitle: PropTypes.string,
 *   cancelTitle: PropTypes.string,
 *   onSubmitPress: PropTypes.func,
 *   onCancelPress: PropTypes.func,
 *   close: PropTypes.bool,
 *   onAnimationEnd: PropTypes.func,
 *   onClose: PropTypes.func,
 * }
 */
function show(config = {}) {
    const {
        title,
        content,
        icon,
        submitTitle,
        cancelTitle,
        onSubmitPress,
        onCancelPress,
        ...restProps
    } = config;

    const onInjectSubmitPress = key => {
        SeaCard.hide(key);
        if (onSubmitPress) onSubmitPress();
    };

    const onInjectCancelPress = key => {
        SeaCard.hide(key);
        if (onCancelPress) onCancelPress();
    };

    const key = SeaCard.show({
        node: (
            <SeaNormalCardView
                title={title}
                content={content}
                icon={icon}
                submitTitle={submitTitle}
                cancelTitle={cancelTitle}
                onSubmitPress={() => onInjectSubmitPress(key)}
                onCancelPress={() => onInjectCancelPress(key)}
            />
        ),
        ...restProps,
    });
    return key;
}

/**
 * 隐藏card
 */
function hide(key) {
    SeaCard.hide(key);
}

export default {
    show,
    hide,
};
