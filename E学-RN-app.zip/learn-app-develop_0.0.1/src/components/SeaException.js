/**
 * Created by zk on 2017/7/4.
 */
import React, { Component } from 'react';
import { Text, Image, View, StyleSheet } from 'react-native';
import { SeaScale, SeaColor, SeaTheme } from '../asserts';

export default class SeaException extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Image style={styles.image} source={require('../asserts/images/exception.png')} />
                <Text style={styles.text}>
                    {this.props.message ? this.props.message : '暂时没有获取到数据'}
                </Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: SeaScale.screenWidth,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    image: {
        width: 210 * SeaScale.scaleHorizontal,
        height: 210 * SeaScale.scaleVertical,
    },
    text: {
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
    },
    absContainer: {
        position: 'absolute',
        top: SeaScale.screenHeight / 2 - 150 * SeaScale.scaleVertical,
        left: SeaScale.screenWidth / 2 - 105 * SeaScale.scaleHorizontal,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
