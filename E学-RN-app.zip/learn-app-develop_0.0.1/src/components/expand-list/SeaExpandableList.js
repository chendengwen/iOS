/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description 可展开的list
 */
import React from 'react';
import PropTypes from 'prop-types';
import SeaLeafCell from './SeaLeafCell';
import SeaNodeCell from './SeaNodeCell';
import SeaExpandNode from './SeaExpandNode';
import SeaList from '../list/SeaList';
import { SeaStyle } from '../../asserts';

export default class SeaExpandableList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array,
        onNodePress: PropTypes.func,
        onLeafPress: PropTypes.func,
        NodeComponent: PropTypes.element, // 自定义的节点组件
        LeafCompnoent: PropTypes.element, // 自定义的叶子组件
    };

    static defaultProps = {
        defaultData: [],
        onNodePress: (item, index) => {},
        onLeafPress: (item, index) => {},
    };

    constructor(props) {
        super(props);
        this.state = { nodes: props.defaultData };
    }

    componentDidMount() {}

    render() {
        const { nodes } = this.state;
        return (
            <SeaList style={SeaStyle.list} ref="list" data={nodes} renderItem={this._renderItem} />
        );
    }

    _renderItem = ({ item, index }) => {
        // 显示叶子或子节点
        return item.isLeaf() ? this._renderLeaf(item, index) : this._renderNode(item, index);
    };

    _renderLeaf = (item, index) => {
        return (
            <SeaLeafCell
                Component={this.props.LeafCompnoent}
                item={item}
                index={index}
                onPress={() => this._onLeafPress(item, index)}
            />
        );
    };

    _renderNode = (item, index) => {
        return (
            <SeaNodeCell
                Component={this.props.NodeComponent}
                item={item}
                index={index}
                onPress={() => this._onNodePress(item, index)}
            />
        );
    };

    _onNodePress = (item, index) => {
        this.setState(previousState => {
            const newNodes = SeaExpandNode.OpenOrCloseNodes(item, previousState.nodes);
            return { nodes: newNodes };
        });
        this.props.onNodePress(item, index);
    };

    _onLeafPress = (item, index) => {
        this.props.onLeafPress(item, index);
    };
}
