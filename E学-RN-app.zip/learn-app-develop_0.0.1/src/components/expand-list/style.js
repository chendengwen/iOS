/**
 * @author xukj
 * @date 2019/09/05
 * @description style 可展开list的样式定义
 */
import { StyleSheet } from 'react-native';
import { SeaColor, SeaTheme } from '../../asserts';

export const CellHeight = SeaTheme.row_height_md;
export const IconSize = SeaTheme.icon_size_md;

export function leftIndent(level) {
    return {
        paddingLeft: SeaTheme.h_spacing_md + level * SeaTheme.h_spacing_md,
    };
}

export default StyleSheet.create({
    cell: {
        flex: 1,
        height: CellHeight,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingRight: SeaTheme.h_spacing_md,
        paddingLeft: SeaTheme.h_spacing_md,
        backgroundColor: 'white',
    },
    title: {
        flex: 1,
        fontSize: SeaTheme.font_size_md,
        height: CellHeight,
        lineHeight: CellHeight,
        color: SeaColor.h1_text,
    },
});
