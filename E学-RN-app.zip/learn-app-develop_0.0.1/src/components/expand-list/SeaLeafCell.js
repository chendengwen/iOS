/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description 叶子节点cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import styles, { leftIndent } from './style';
import SeaButton from '../button/SeaButton';
import SeaListCell from '../list/SeaListCell';

export default class SeaLeafCell extends React.PureComponent {
    static propTypes = {
        Component: PropTypes.element,
        item: PropTypes.object.isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, Component, onPress, ...restProps } = this.props;
        if (Component) {
            return (
                <SeaButton onPress={onPress} {...restProps}>
                    <Component item={item} />
                </SeaButton>
            );
        }
        return (
            <SeaListCell
                showArrow={false}
                style={[styles.cell, leftIndent(item.level)]}
                onPress={onPress}
                {...restProps}
            >
                <Text style={styles.title} numberOfLines={1}>{item.description}</Text>
            </SeaListCell>
        );
    }
}
