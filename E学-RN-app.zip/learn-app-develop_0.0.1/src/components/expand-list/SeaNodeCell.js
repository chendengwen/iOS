/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description 子节点cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { SeaColor } from '../../asserts';
import styles, { IconSize, leftIndent } from './style';
import SeaButton from '../button/SeaButton';
import SeaListCell from '../list/SeaListCell';

export default class SeaNodeCell extends React.PureComponent {
    static propTypes = {
        Component: PropTypes.element,
        item: PropTypes.object.isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, Component, onPress, ...restProps } = this.props;
        if (Component) {
            return (
                <SeaButton onPress={onPress} {...restProps}>
                    <Component item={item} />
                </SeaButton>
            );
        } else {
            return (
                <SeaListCell
                    style={[styles.cell, leftIndent(item.level)]}
                    showArrow={false}
                    onPress={onPress}
                    {...restProps}
                >
                    <Text style={styles.title} numberOfLines={1}>
                        {item.description}
                    </Text>
                    <Icon
                        name={item.expand ? 'expand-more' : 'chevron-right'}
                        size={IconSize}
                        color={SeaColor.content_text}
                    />
                </SeaListCell>
            );
        }
    }
}
