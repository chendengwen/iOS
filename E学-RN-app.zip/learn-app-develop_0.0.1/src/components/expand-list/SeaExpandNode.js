/**
 * @author xukj
 * @date 2019/09/04
 * @description 节点对象
 */
export default class SeaExpandNode {
    /**
     * 展开或收起节点
     * @param {SeaExpandNode} currentNode 需要展开或收起的节点
     * @param {array} listNodes 平铺后的节点数组
     */
    static OpenOrCloseNodes(currentNode, listNodes = []) {
        if (!(currentNode instanceof SeaExpandNode) || !currentNode.isValid()) {
            // 当前为无效节点
            return listNodes;
        }

        if (currentNode.isLeaf()) {
            // 叶子节点
            return listNodes;
        }

        if (currentNode.expand) {
            // 收起
            const nodeIdx = _.findIndex(listNodes, node => node.id == currentNode.id);
            if (nodeIdx < 0) return listNodes;
            // 递归计算已经展开的长度
            const getExpandNumbers = node => {
                if (node.isLeaf() || !node.expand) return 1;
                node.expand = false;
                return _.sumBy(node.subNodes, subNode => getExpandNumbers(subNode)) + 1;
            };
            const headPart = _.take(listNodes, nodeIdx + 1);
            const tailPart = _.drop(listNodes, nodeIdx + getExpandNumbers(currentNode));
            return _.concat([], headPart, tailPart);
        }

        // 展开
        const nodeIdx = _.findIndex(listNodes, node => node.id == currentNode.id);
        if (nodeIdx < 0) return listNodes;
        currentNode.expand = !currentNode.expand;
        const headPart = _.take(listNodes, nodeIdx + 1);
        const tailPart = _.drop(listNodes, nodeIdx + 1);
        return _.concat([], headPart, currentNode.subNodes, tailPart);
    }

    constructor(id, parentId, subNodes = [], level = 0, data, description) {
        this.id = id; // 当前节点id
        this.parentId = parentId; // 父节点id，没有为null
        this.subNodes = subNodes; // 子节点数组
        this.level = level; // 层级，根节点为0
        this.expand = false; // 是否展开
        this.data = data; // 节点数据
        this.description = description; // 节点描述
    }

    // 有效节点
    isValid() {
        return this.id && this.data != null;
    }

    // 是否叶子节点
    isLeaf() {
        return _.isEmpty(this.subNodes);
    }

    // 子节点数量
    numberOfSubNodes() {
        return this.subNodes.length;
    }

    static testData() {
        return createTestData();
    }
}

function createTestData() {
    let data = [];
    // 1级节点
    for (let i = 0; i < 3; i++) {
        const iId = `${i}`;
        let iNodes = [];

        // 2级节点
        for (let j = 0; j < 3; j++) {
            const jId = `${i}-${j}`;
            let jNodes = [];

            // 3级节点
            for (let k = 0; k < 3; k++) {
                const kId = `${i}-${j}-${k}`;
                let kNodes = [];

                // 4级节点
                for (let x = 0; x < 3; x++) {
                    const xId = `${i}-${j}-${k}-${x}`;
                    let xNodes = [];

                    // 5级节点
                    for (let y = 0; y < 3; y++) {
                        const yId = `${i}-${j}-${k}-${x}-${y}`;
                        let yNodes = [];

                        // 6级节点
                        for (let z = 0; z < 3; z++) {
                            const zId = `${i}-${j}-${k}-${x}-${y}-${z}`;
                            const zNode = new SeaExpandNode(zId, yId, [], 5, z, zId);
                            yNodes.push(zNode);
                        }

                        const yNode = new SeaExpandNode(yId, xId, yNodes, 4, y, yId);
                        xNodes.push(yNode);
                    }

                    const xNode = new SeaExpandNode(xId, kId, xNodes, 3, x, xId);
                    kNodes.push(xNode);
                }

                const kNode = new SeaExpandNode(kId, jId, kNodes, 2, k, kId);
                jNodes.push(kNode);
            }

            const jNode = new SeaExpandNode(jId, iId, jNodes, 1, j, jId);
            iNodes.push(jNode);
        }

        const iNode = new SeaExpandNode(iId, null, iNodes, 0, i, iId);
        data.push(iNode);
    }

    return data;
}
