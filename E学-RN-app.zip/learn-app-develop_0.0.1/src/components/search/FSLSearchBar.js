/**
 * @author xukj
 * @date 2018/7/25
 * @description 展示界面组件 FSLSearchBar
 * 通用搜索控件searchBar
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, TextInput, Text, TouchableOpacity, Image } from 'react-native';
import { SeaTheme, SeaScale } from '../../asserts';
import { SeaButton } from '../../components';

import { Icon } from 'react-native-elements';

export default class FSLSearchBar extends React.PureComponent {
    static propTypes = {
        round: PropTypes.bool,
        iconProps: PropTypes.object, // size name color style
        inputProps: PropTypes.object, // 如果不可点击，则TextInput.PropTypes
        textProps: PropTypes.object, // 如果可点击，则 Text.PropTypes
        onPress: PropTypes.func, // 点击事件
    };

    static defaultProps = {
        inputProps: { placeholderTextColor: 'gray' },
        textProps: {},
        iconProps: {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { onPress } = this.props;
        return onPress ? this._renderTouchMode(this.props) : this._renderEditMode(this.props);
    }

    /**
     * @private
     * @description 点击模式
     */
    _renderTouchMode = props => {
        const { onPress, iconProps, textProps, round, style } = props;
        return (
            <TouchableOpacity
                style={[styles.bar, style, this._borderStyle(round, style)]}
                activeOpacity={0.8}
                onPress={onPress}
            >
                {/*  <Icon
                    type="antdesign"
                    size={SeaScale.Layout(34)}
                    name="search1"
                    color="#b2b2b2"
                    {...iconProps}
                /> */}
                <Image source={require('../../asserts/images/ic_search.png')} style={styles.searchIcon} />
                <Text {...this._getInputProps(textProps)}>{_.get(textProps, 'value', '')}</Text>
            </TouchableOpacity>
        );
    };

    /**
     * @private
     * @description 输入模式
     */
    _renderEditMode = props => {
        const { iconProps, inputProps, round, style } = props;
        return (
            <View style={[styles.bar, style, this._borderStyle(round, style)]}>
                {/* <Icon
                    type="antdesign"
                    size={SeaScale.Layout(34)}
                    name="search1"
                    color="#b2b2b2"
                    {...iconProps}
                /> */}
                <Image source={require('../../asserts/images/ic_search.png')} style={styles.searchIcon} />
                <TextInput
                    {...this._getInputProps({
                        ...inputProps,
                        underlineColorAndroid: 'transparent',
                    })}
                    ref={input => {
                        this.txtClear = input
                      }}
                />
                <SeaButton
                    onPress={() => this.txtClear.clear()}>
                    <Image source={require('../../asserts/images/home/ic_clear.png')} style={styles.clear} />
                </SeaButton>
            </View>
        );
    };

    /**
     * @private
     * @description 输入框样式
     */
    _getInputProps = props => {
        const style = [styles.input, props.style];
        return { ...props, style };
    };

    /**
     * @private
     * @description 图标样式
     */
    _getIconProps = props => {
        const style = [styles.icon, props.style];
        return { ...props, style };
    };

    /**
     * @private
     * @description 边框样式
     */
    _borderStyle = (round, style) => {
        if (!round) {
            return;
        } else {
            return {
                borderRadius: style && style.height ? style.height / 2 : SeaScale.Layout(60),
            };
        }
    };
}

const styles = StyleSheet.create({
    bar: {
        flexDirection: 'row',
        alignItems: 'center',
        height: SeaScale.Layout(60),
        paddingHorizontal: SeaTheme.h_spacing_sm,
        backgroundColor: "#F9FAFB",
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: "#eee",
    },
    icon: {
        // marginLeft: 8,
    },
    input: {
        flex: 1,
        padding: 0,
        overflow: 'hidden',
        fontSize: SeaTheme.font_size_md,
        color: 'black',
        marginLeft: SeaScale.Layout(8),
    },
    searchIcon: {
        width: SeaScale.Layout(29),
        height: SeaScale.Layout(29),
        resizeMode: 'contain',
        marginLeft: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(15),
    },
    clear: {
        width: SeaScale.Layout(30),
        height: SeaScale.Layout(30),
        marginLeft: SeaScale.Layout(20),
    },
});
