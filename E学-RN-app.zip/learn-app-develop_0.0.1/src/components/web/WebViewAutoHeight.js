/**
 * Created by xukj on 2018/6/26.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, ViewPropTypes } from 'react-native';
import { WebView } from 'react-native-webview';

/**
 * @author xukjs
 *
 * @date 2018/7/11
 *
 * @description 自适应高度的webView组件
 */

const BODY_TAG_PATTERN = /\<\/ *body\>/;

// Do not add any comments to this! It will break because all line breaks will removed for
// some weird reason when this script is injected.
var script = `  
;(function() {  
var wrapper = document.createElement("div");  
wrapper.id = "height-wrapper";  
while (document.body.firstChild) {  
    wrapper.appendChild(document.body.firstChild);  
}  
document.body.appendChild(wrapper);  
var i = 0;  
function updateHeight() {  
    document.title = wrapper.clientHeight;  
    window.location.hash = ++i;  
}  
updateHeight();  
window.addEventListener("load", function() {  
    updateHeight();  
    setTimeout(updateHeight, 1000);  
});  
window.addEventListener("resize", updateHeight);  
}());  
`;

const style = `  
<style>  
body, html, #height-wrapper {  
    margin: 0;  
    padding: 0;  
}  
#height-wrapper {  
    position: absolute;  
    top: 0;  
    left: 0;  
    right: 0;  
}  
</style>  
<script>  
${script}  
</script>  
`;

const codeInject = html => html.replace(BODY_TAG_PATTERN, style + '</body>');

/**
 * Wrapped Webview which automatically sets the height according to the
 * content. Scrolling is always disabled. Required when the Webview is embedded
 * into a ScrollView with other components.
 *
 * Inspired by this SO answer http://stackoverflow.com/a/33012545
 * */

export default class WebViewAutoHeight extends React.Component {
    static propTypes = {
        source: PropTypes.object.isRequired,
        injectedJavaScript: PropTypes.string,
        minHeight: PropTypes.number,
        onNavigationStateChange: PropTypes.func,
        style: ViewPropTypes.style,
    };

    static defaultProps = {
        minHeight: 100,
    };

    constructor(props) {
        super(props);
        this.state = {
            realContentHeight: props.minHeight,
        };
    }

    render() {
        const { source, style, minHeight, ...otherProps } = this.props;
        const html = source.html;

        if (!html) {
            throw new Error('WebViewAutoHeight supports only source.html');
        }

        if (!BODY_TAG_PATTERN.test(html)) {
            throw new Error('Cannot find </body> from: ' + html);
        }

        return (
            <View>
                <WebView
                    {...otherProps}
                    originWhitelist={['*']}
                    source={{ html: codeInject(html), baseUrl: '' }}
                    scrollEnabled={false}
                    style={[style, { height: Math.max(this.state.realContentHeight, minHeight) }]}
                    javaScriptEnabled
                    onNavigationStateChange={this._handleNavigationChange}
                />
                {/*process.env.NODE_ENV !== "production" &&
                 <Text>Web content height: {this.state.realContentHeight}</Text>*/}
            </View>
        );
    }

    _handleNavigationChange = navState => {
        if (navState.title) {
            const realContentHeight = parseInt(navState.title, 10) || 0; // turn NaN to 0
            this.setState({ realContentHeight });
        }
        if (typeof this.props.onNavigationStateChange === 'function') {
            this.props.onNavigationStateChange(navState);
        }
    };
}
