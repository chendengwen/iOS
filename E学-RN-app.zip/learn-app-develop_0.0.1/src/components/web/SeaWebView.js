/**
 * @author xukj
 * @date 2018/12/20
 * @class
 * @description 界面展示组件SeaWebView webview扩展
 */
import React from 'react';
import PropTypes from 'prop-types';
import { WebView } from 'react-native-webview';

const webViewHoc = Component => {
    const _injectedJavaScript =
        "window.onscroll=function(){scrollTop=document.body.scrollTop||document.documentElement.scrollTop;scrollHeight=document.documentElement.scrollHeight||document.body.scrollHeight;clientHeight=document.documentElement.clientHeight||documentElement.body.clientHeight;if(scrollHeight - scrollTop ==clientHeight){window.postMessage('endReached')}}" +
        '\n' +
        'window.onload=function(){scrollTop=document.body.scrollTop||document.documentElement.scrollTop;scrollHeight=document.documentElement.scrollHeight||document.body.scrollHeight;clientHeight=document.documentElement.clientHeight||documentElement.body.clientHeight;if(scrollHeight<=clientHeight){window.postMessage("endReached")}} ';

    class WrappedComponent extends React.PureComponent {
        static propTypes = {
            onEndReached: PropTypes.func,
        };

        static defaultProps = {};

        render() {
            const { source, ...restProps } = this.props;
            return (
                <Component
                    originWhitelist={['*']}
                    onMessage={this._onMessage}
                    injectedJavaScript={_injectedJavaScript}
                    source={this._encode(source)}
                    {...restProps}
                />
            );
        }

        _onMessage = e => {
            const { onEndReached } = this.props;
            if (onEndReached && e.nativeEvent.data == 'endReached') {
                onEndReached();
            }
        };

        /**
         * @private
         * @description android某些设备，html展示时会发生乱码
         */
        _encode = source => {
            if (source && source.html) {
                return { ...source, baseUrl: '' };
            } else {
                return source;
            }
        };
    }

    return WrappedComponent;
};

export default webViewHoc(WebView);
