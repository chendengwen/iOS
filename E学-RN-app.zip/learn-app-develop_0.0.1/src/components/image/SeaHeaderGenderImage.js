/**
 * @author xukj
 * @date 2018/11/02
 * @class
 * @description 界面展示组件SeaHeaderGenderImage 头像按钮组件
 * 默认显示性别图片，如果设置了source或defaultSource，则会覆盖
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Platform } from 'react-native';
import { FSLCachedImage } from 'react-native-kpframework';
import { SeaColor } from '../../asserts';

const imageHoc = Component => {
    class WrappedComponent extends React.PureComponent {
        static propTypes = {
            sex: PropTypes.string,
            size: PropTypes.number,
            style: PropTypes.any,
        };

        static defaultProps = {
            size: 40,
        };

        render() {
            const { sex, size, source, style, ...restProps } = this.props;
            const female = this._isFemale(sex);
            const borderRadiusStyle = { borderRadius: size / 2, width: size, height: size };
            // android defaultSource无效
            let imageSource = source;
            if (_.isEmpty(source) && Platform.OS == 'android') {
                imageSource = female
                    ? require('../../asserts/images/myView/female.png')
                    : require('../../asserts/images/myView/male.png');
            }

            return (
                <Component
                    style={[styles.header, style, borderRadiusStyle]}
                    width={size}
                    height={size}
                    resizeMode="contain"
                    androidStyle={borderRadiusStyle}
                    source={imageSource}
                    defaultSource={
                        female
                            ? require('../../asserts/images/myView/female.png')
                            : require('../../asserts/images/myView/male.png')
                    }
                    {...restProps}
                />
            );
        }

        _isFemale = sex => {
            return sex != '男' && sex != 'M';
        };
    }

    return WrappedComponent;
};

const styles = StyleSheet.create({
    header: {
        overflow: 'hidden',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
    },
});

export default imageHoc(FSLCachedImage);
