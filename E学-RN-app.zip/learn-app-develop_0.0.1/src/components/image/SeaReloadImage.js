/**
 * @author xukj
 * @date 2018/11/29
 * @description SeaReloadImage 可以重新加载的图片
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ActivityIndicator, TouchableOpacity, Text } from 'react-native';
import { FSLCachedImage } from 'react-native-kpframework';

const imageHoc = Component => {
    class WrapperComponent extends React.PureComponent {
        static propTypes = {
            width: PropTypes.number,
            height: PropTypes.number,
            source: PropTypes.any,
            onPress: PropTypes.func,
            containerStyle: PropTypes.any,
            indicatorColor: PropTypes.string,
            textColor: PropTypes.string,
        };

        static defaultProps = {
            indicatorColor: 'grey',
            textColor: 'grey',
        };

        constructor(props) {
            super(props);
            this.state = {
                loading: false,
                error: false,
                reloadCount: 0,
            };
            // 缓存成功后这里会替换成本地地址
            this.path = props.item ? props.item.url : undefined;
        }

        render() {
            const { error } = this.state;
            return error
                ? this._renderError(this.props)
                : this._renderImages(this.props, this.state);
        }

        _renderImages = (props, state) => {
            const {
                width,
                height,
                source,
                onPress,
                containerStyle,
                indicatorColor,
                ...restProps
            } = props;
            const { loading } = state;

            let Container = View;
            if (onPress) Container = TouchableOpacity;
            return (
                <Container
                    style={[styles.container, { width, height }, containerStyle && containerStyle]}
                    activeOpacity={1}
                    onPress={this._onPress}
                    {...restProps}
                >
                    <View style={[styles.container, { width, height }]}>
                        <Component
                            style={[styles.image, { width, height }]}
                            width={width}
                            height={height}
                            source={source}
                            resizeMode="contain"
                            onImageLoadStart={this._onLoadStart}
                            onImageLoadEnd={this._onLoadEnd}
                            onImageError={this._onError}
                        />
                        {loading && (
                            <ActivityIndicator
                                style={styles.indicator}
                                animating={true}
                                color={indicatorColor}
                                size="large"
                            />
                        )}
                    </View>
                </Container>
            );
        };

        _renderError = props => {
            const { width, height, containerStyle, textColor } = props;

            return (
                <TouchableOpacity
                    style={[styles.container, { width, height }, containerStyle && containerStyle]}
                    activeOpacity={1}
                    onPress={this._reload}
                >
                    <View style={[styles.container, { width, height }]}>
                        <Text style={[styles.text, { color: textColor }]}>点击重新获取图片</Text>
                    </View>
                </TouchableOpacity>
            );
        };

        _onLoadStart = () => {
            this.setState({ loading: true, error: false });
        };

        _onLoadEnd = path => {
            if (path) this.path = 'file://' + path;
            this.setState({ loading: false });
        };

        _onError = () => {
            this.setState({ loading: false, error: true });
        };

        _reload = () => {
            this.setState({ reloadCount: this.state.reloadCount + 1, error: false });
        };

        _onPress = () => {
            const { onPress } = this.props;
            onPress(this.path);
        };
    }

    return WrapperComponent;
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        position: 'absolute',
        margin: 'auto',
    },
    indicator: {
        position: 'absolute',
        margin: 'auto',
    },
    text: {
        fontSize: 16,
    },
});

export default imageHoc(FSLCachedImage);
