/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-09-15 20:05:59
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-22 14:00:21
 */
/**
 * @author xukj
 * @date 2018/10/9
 * @description 学习平台封面图片组件，新增功能
 * 1.无效状态展示
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Image, View } from 'react-native';
import { FSLCachedImage } from 'react-native-kpframework';
import { SeaColor } from '../../asserts';

export default class SeaCoverImage extends React.PureComponent {
    static propTypes = {
        invalid: PropTypes.bool,
        style: Image.propTypes.style,
        source: PropTypes.object,
        defaultSource: PropTypes.any,
        backgroundColor: PropTypes.string,
    };

    static defaultProps = {
        backgroundColor: SeaColor.img_background,
    };

    state = {
        imgW: 0,
        imgH: 0,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const {
            style,
            backgroundColor,
            invalid,
            source,
            defaultSource,
            children,
            ...restProps
        } = this.props;
        const imageSources = invalid ? {} : { source, defaultSource };
        return (
            <FSLCachedImage
                style={[{ backgroundColor }, style && style]}
                imageStyle={{ backgroundColor }}
                {...imageSources}
                {...restProps}
                onLayout={this._onLayout}
            >
                {typeof (source) == "undefined" &&
                    <this._defaultImage />}
                {invalid && <this._invalidComponent />}
                {children}
            </FSLCachedImage>
        );
    }

    _invalidComponent = props => {
        const { imgW, imgH } = this.state;
        return (
            <Image
                style={[
                    StyleSheet.absoluteFill,
                    { width: imgW, height: imgH, backgroundColor: SeaColor.img_background },
                ]}
                resizeMode="contain"
                source={require('../../asserts/images/inValid.png')}
            />
        );
    };

    _defaultImage = prps => {
        const { imgW, imgH } = this.state;
        return (
            <Image
                style={[
                    StyleSheet.absoluteFill,
                    { width: imgW, height: imgH, backgroundColor: SeaColor.img_background },
                ]}
                resizeMode='stretch'
                source={require('../../asserts/images/default_image.jpg')}
            />
        );
    };

    _onLayout = event => {
        // console.log('layout', event.nativeEvent.layout);
        const { width, height } = event.nativeEvent.layout;
        this.setState({ imgW: parseInt(width), imgH: parseInt(height) });
    };
}
