/**
 * @author xukj
 * @date 2018/7/11
 * @description CustomTopTabBar 自定义样式的上方tabbar, 每个tab之间用竖线隔开
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
    StyleSheet,
    Text,
    View,
    ViewPropTypes,
    TouchableWithoutFeedback,
    Animated,
} from 'react-native';
import { SeaColor, SeaScale, SeaTheme } from '../../asserts';

export default class CustomTopTabBar extends React.PureComponent {
    static propTypes = {
        goToPage: PropTypes.func,
        activeTab: PropTypes.number,
        tabs: PropTypes.array,
        backgroundColor: PropTypes.string,
        activeTextColor: PropTypes.string,
        inactiveTextColor: PropTypes.string,
        textStyle: Text.propTypes.style,
        tabStyle: ViewPropTypes.style,
        renderTab: PropTypes.func,
        underlineStyle: ViewPropTypes.style,
        underlineColor: PropTypes.string,
        underline: PropTypes.bool,
    };

    static defaultProps = {
        activeTextColor: 'navy',
        inactiveTextColor: 'black',
        backgroundColor: null,
        underlineColor: SeaColor.main,
    };

    renderTab(name, page, isTabActive, onPressHandler) {
        const textColor = isTabActive ? SeaTheme.tab_active_font_color : SeaTheme.tab_aside_font_color;
        const textSize = isTabActive ? SeaTheme.tab_active_font_size : SeaTheme.tab_aside_font_size;

        return (
            <TouchableWithoutFeedback
                key={name}
                style={{ flex: 1 }}
                onPress={() => onPressHandler(page)}
            >
                <View style={styles.tab}>
                    <View style={styles.content}>
                        <Text style={{ color: textColor, fontSize: textSize }}>
                            {name}
                        </Text>
                    </View>
                </View>
            </TouchableWithoutFeedback>
        );
    }

    render() {
        const containerWidth = this.props.containerWidth;
        const numberOfTabs = this.props.tabs.length;
        const itemWidth = containerWidth / numberOfTabs;
        const itemHeight = SeaScale.Layout(2);
        const tabUnderlineStyle = {
            position: 'absolute',
            width: itemWidth,
            alignItems: 'center',
            justifyContent: 'flex-end',
            backgroundColor: 'transparent',
            bottom: 0,
        };

        const translateX = this.props.scrollValue.interpolate({
            inputRange: [0, 1],
            outputRange: [0, itemWidth],
        });

        return (
            <View
                style={[
                    styles.tabs,
                    { backgroundColor: this.props.backgroundColor },
                    this.props.style,
                ]}
            >
                {this.props.tabs.map((name, page) => {
                    const isTabActive = this.props.activeTab === page;
                    const renderTab = this.props.renderTab || this.renderTab;
                    return renderTab(name, page, isTabActive, this.props.goToPage);
                })}
                {this.props.underline && (
                    <Animated.View style={[tabUnderlineStyle, { transform: [{ translateX }] }]}>
                        <View
                            style={[
                                {
                                    width: itemWidth / 1.5,
                                    height: SeaTheme.tab_line_width,
                                    backgroundColor: SeaTheme.tab_line_color,
                                    borderRadius: SeaTheme.tab_line_radius,
                                },
                                this.props.underlineStyle,
                            ]}
                        />
                    </Animated.View>
                )}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    tab: {
        flex: 1,
        justifyContent: 'center',
    },
    tabs: {
        height: SeaScale.Layout(90),
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
    content: {
        height: SeaScale.Layout(50),
        // borderRightWidth: StyleSheet.hairlineWidth,
        // borderRightColor: SeaColor.parting_line,
        alignItems: 'center',
        justifyContent: 'center',
    },
    sp: {
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: SeaColor.parting_line,
    },
});
