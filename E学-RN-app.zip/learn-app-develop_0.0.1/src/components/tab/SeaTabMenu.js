/**
 * @author xukj
 * @date 2019/04/26
 * @class
 * @description 主界面tab按钮
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet, Image } from 'react-native';
import { SeaColor, SeaScale, SeaTheme } from '../../asserts';
import { FSLBadge } from 'react-native-kpframework';
import { connect } from 'react-redux';
import { hasBottomPoint } from '../../view/toLearn/PlanManager';

@connect(mapStateToProps)
export default class SeaTabMenu extends React.PureComponent {
    static propTypes = {
        title: PropTypes.string,
        focused: PropTypes.bool,
        // iconName: PropTypes.oneOf(['home', 'tolearn', 'message', 'personal']),subject
        iconName: PropTypes.oneOf(['home', 'subject', 'personal','learn']),
    };

    static defaultProps = {
        iconName: 'home',
    };

    TabUnselectedIcons = {
        home: require('../../asserts/images/homeIcon/home.png'),
        // home: require('../../asserts/images/homeIcon/learn.png'),
        tolearn: require('../../asserts/images/homeIcon/plan.png'),
        message: require('../../asserts/images/homeIcon/category.png'),
        // personal: require('../../asserts/images/homeIcon/personal.png'),
        personal: require('../../asserts/images/homeIcon/personal_new.png'),
        subject:require('../../asserts/images/homeIcon/subject.png'),
        learn:require('../../asserts/images/homeIcon/learn.png')
    };

    TabSelectedIcons = {
        home: require('../../asserts/images/homeIcon/home_selected.png'),
        // home: require('../../asserts/images/homeIcon/learn_selected.png'),
        tolearn: require('../../asserts/images/homeIcon/plan_selected.png'),
        message: require('../../asserts/images/homeIcon/category_selected.png'),
        // personal: require('../../asserts/images/homeIcon/personal_selected.png'),
        personal: require('../../asserts/images/homeIcon/personal_new_selected.png'),
        subject:require('../../asserts/images/homeIcon/subject_selected.png'),
        learn:require('../../asserts/images/homeIcon/learn_selected.png')
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { title, focused } = this.props;
        return (
            <View style={styles.container}>
                <Image source={this._getIconImage()} style={styles.icon} resizeMode="contain" />
                <Text style={[styles.text, { color: focused ? SeaColor.main : SeaColor.h2_text }]}>
                    {title}
                </Text>
                {this._renderBadge()}
            </View>
        );
    }

    _getIconImage = () => {
        const { focused, iconName } = this.props;
        return focused ? this.TabSelectedIcons[iconName] : this.TabUnselectedIcons[iconName];
    };

    _renderBadge = () => {
        const { iconName, refreshTime, latestTime, unreadUpgrade } = this.props;

        if (iconName == 'home') {
            // 首页不显示badge
            return null;
        }

        if (iconName == 'tolearn') {
            // 判断是否显示计划红点
            return hasBottomPoint(refreshTime, latestTime) ? (
                <FSLBadge.Dot style={styles.dot} size={SeaScale.Layout(16)} show />
            ) : null;
        }

        if (iconName == 'message') {
            // 判断是否显示未读消息数字
            const count = _.sumBy(this.props.groups, value => value.count);
            return (
                <FSLBadge.Text
                    style={styles.notice}
                    titleStyle={styles.noticeTitle}
                    text={count > 999 ? '···' : String(count)}
                    show={count > 0}
                />
            );
        }

        if (iconName == 'personal') {
            // 判断是否显示更新红点
            return unreadUpgrade > 0 ? (
                <FSLBadge.Dot style={styles.dot} size={SeaScale.Layout(16)} show />
            ) : null;
        }

        return null;
    };

    // _getUnreadFlag = () => {
    //     let unread = false;
    //     const { refreshTime, latestTime } = this.props;
    //     switch (this.props.iconName) {
    //         case 'home':
    //             unread = false;
    //             break;
    //         case 'category':
    //             unread = false;
    //             break;
    //         case 'tolearn':
    //             unread = hasBottomPoint(refreshTime, latestTime);
    //             break;
    //         case 'personal':
    //             unread = this.props.unreadUpgrade > 0;
    //             break;
    //     }
    //     return unread;
    // };
}

export function mapStateToProps(store) {
    return {
        unreadUpgrade: store.unreadStore.unreadUpgrade,
        refreshTime: store.planStore.refreshTime,
        latestTime: store.planStore.latestTime,
        groups: store.messageStore.groups,
    };
}

const styles = StyleSheet.create({
    container: {
        width: SeaScale.Layout(128),
        justifyContent: 'center',
        alignItems: 'center',
        height: SeaScale.Layout(100),
    },
    text: {
        // marginTop: SeaScale.Layout(4),
        fontSize: SeaTheme.font_size_md,
    },
    icon: {
        width: SeaScale.Layout(40),
        height: SeaScale.Layout(40),
    },
    dot: {
        top: SeaScale.Layout(8),
        right: SeaScale.Layout(24),
    },
    notice: {
        top: SeaScale.Layout(8),
        right: null,
        left: SeaScale.Layout(80),
    },
    noticeTitle: {
        fontSize: SeaTheme.font_size_xxs,
        paddingHorizontal: SeaScale.Layout(4),
    },
});
