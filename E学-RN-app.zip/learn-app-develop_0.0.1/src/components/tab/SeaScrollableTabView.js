/**
 * @author xukj
 * @date 2019/11/21
 * @class
 * @description 界面展示组件SeaScrollableTabView
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import ScrollableTabView, { DefaultTabBar } from 'react-native-scrollable-tab-view';
import { SeaColor, SeaScale, SeaTheme } from '../../asserts';

export default class SeaScrollableTabView extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { children, restProps } = this.props;

        const count = _.isEmpty(children) ? 1 : children.length;
        const width = SeaScale.screenWidth / count - SeaScale.Layout(50) * 2;

        return (
            <ScrollableTabView
                renderTabBar={() => <DefaultTabBar style={styles.tabbar} />}
                tabBarUnderlineStyle={[
                    styles.tabbar_underline,
                    { width, marginLeft: SeaScale.Layout(50) },
                ]}
                tabBarActiveTextColor={SeaColor.main}
                tabBarTextStyle={styles.tabbar_text}
                {...restProps}
                children={children}
            />
        );
    }
}

const styles = StyleSheet.create({
    tabbar: {
        backgroundColor: SeaColor.back,
        height: SeaScale.Layout(70),
        borderColor: SeaColor.parting_line,
        borderWidth: SeaTheme.line_width_xs,
        alignItems: 'center',
    },
    tabbar_underline: {
        backgroundColor: SeaColor.main,
        // width: SeaScale.Layout(250),
        height: SeaScale.Layout(4),
    },
    tabbar_text: {
        marginTop: SeaScale.Layout(16),
        fontSize: SeaTheme.font_size_md,
    },
});
