/**
 * @author xukj
 * @date 2019/06/28
 * @description 通用组件模块
 */

// button
// ---
// 收藏按钮
export { default as SeaFavoriteButton } from './button/SeaFavoriteButton';
// 点赞按钮
export { default as SeaLikeButton } from './button/SeaLikeButton';
// 评价按钮
export { default as SeaScoreButton } from './button/SeaScoreButton';
// 评论按钮
export { default as SeaCommentButton } from './button/SeaCommentButton';
// 选项按钮
export { default as SeaCheckBox } from './checkbox/SeaCheckBox';
// add by xukj - 1.32.0
// 订制文本按钮
export { default as SeaTextButton } from './button/SeaTextButton';
// 通用按钮
export { default as SeaButton } from './button/SeaButton';

// list
// ---
// 通用列表项
export { default as SeaListCell } from './list/SeaListCell';
// 左滑删除列表项
export { default as ListDeleteCell } from './list/ListDeleteCell';
// 分割线
export { default as Separator } from './list/Separator';
// 分页器
export { FSLPager as Pager } from 'react-native-kpframework';
// 与分页器搭配使用的分页list
export { default as SeaPagerList } from './list/SeaPagerList';
// 无分页功能的list
export { default as SeaNoPagerList } from './list/SeaNoPagerList';
// 统一列表功能, 在将来SeaPagerList会被废弃掉，请使用SeaList
export { default as SeaList } from './list/SeaList';
// 可展开列表
export { default as SeaExpandableList } from './expand-list/SeaExpandableList';
export { default as SeaExpandNode } from './expand-list/SeaExpandNode';

// 提示框
// ---
// 加载提示框，全覆盖
export { default as SeaLoading } from './alert/SeaLoading';
export { default as SeaCard } from './alert/SeaCard';
// 提示框
export { default as SeaNormalCard } from './alert/SeaNormalCard';

// web
// ---
export { default as WebViewAutoHeight } from './web/WebViewAutoHeight';
export { default as SeaWebView } from './web/SeaWebView';

// 其他
// ---

// 提示页面(多为空页面)
export { default as ExceptionView } from './error/ExceptionView';

// 搜索框
export { default as FSLSearchBar } from './search/FSLSearchBar';

// 导航栏
// ---
export { default as SeaNavigator } from './nav/SeaNavigator';
export { default as SeaSearchNavigator } from './nav/SeaSearchNavigator';
import * as SeaNavigationItems from './nav/SeaNavigationItems';
export { SeaNavigationItems };

// 资源封面图片
// ---
export { default as SeaCoverImage } from './image/SeaCoverImage';
export { default as SeaReloadImage } from './image/SeaReloadImage';
export { default as SeaGenderHeader } from './image/SeaHeaderGenderImage';
export { default as SeaImageGallery } from './gallery/ImageGallery';
export { default as SeaImageZoomer } from './gallery/ImageZoomer';

// 评论界面组件
// ---
export { default as AddComment } from './other/AddComment';

// 分享
// ---
export { default as SeaSharePanel } from './share/SeaSharePanel';

// tab
// ---
export { default as CustomTopTabBar } from './tab/CustomTopTabBar';
export { default as SeaScrollableTabView } from './tab/SeaScrollableTabView';
export { default as SeaTabMenu } from './tab/SeaTabMenu';

// 标签组件
// ---
export { default as SeaFlagText } from './other/SeaFlagText';

// add by xukj 1.36.0
export { default as SeaActionSheet } from './actionsheet/SeaActionSheet';

export { default as DashLine } from './dash-line/DashLine';
