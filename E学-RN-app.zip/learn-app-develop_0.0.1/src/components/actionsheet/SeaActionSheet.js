/**
 * @author xukj
 * @date 2019/09/26
 * @class
 * @description ActionSheet
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, InteractionManager } from 'react-native';
import SeaButton from '../button/SeaButton';
import ActionSheet from 'react-native-actionsheet';

export default class SeaActionSheet extends React.PureComponent {
    static propTypes = {
        options: PropTypes.array, // [{ name, value }]
        cancelIndex: PropTypes.number,
        selectedIndex: PropTypes.number,
        onSelected: PropTypes.func, // 选中项
        children: PropTypes.any,
        enable:PropTypes.bool,//是否启用
    };

    static defaultProps = {
        options: [],
        cancelIndex: -1,
        selectedIndex: -1,
        onSelected: (option, index) => {},
        enable: true,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            options,
            cancelIndex,
            selectedIndex,
            children,
            onSelected,
            enable,
            ...restProps
        } = this.props;
        const names = _.map(options, 'name');

        return (
            <SeaButton {...restProps} onPress={enable ? this._onShowPress: null}>
                {children}
                <ActionSheet
                    ref="actionSheet"
                    options={names}
                    cancelButtonIndex={cancelIndex}
                    destructiveButtonIndex={selectedIndex}
                    onPress={this._onSheetPress}
                />
            </SeaButton>
        );
    }

    _onShowPress = () => {
        InteractionManager.runAfterInteractions(() => {
            this.refs.actionSheet && this.refs.actionSheet.show();
        });
    };

    _onSheetPress = index => {
        const { options, cancelIndex, onSelected } = this.props;
        if (index == cancelIndex || index >= options.length) {
            // do nothing
            return;
        }

        onSelected && onSelected(options[index], index);
    };
}
