/**
 * @author xukj
 * @date 2019/06/27
 * @description 分享面板样式
 */
import { StyleSheet } from 'react-native';
import { SeaScale, SeaColor, SeaTheme } from '../../asserts';

const styles = StyleSheet.create({
    panel: {
        width: SeaScale.screenWidth,
        flex: 1,
        backgroundColor: 'white',
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaTheme.row_height_md,
        textAlign: 'center',
        height: SeaTheme.row_height_md,
    },
    contentContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    button: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: SeaScale.Layout(40),
    },
    icon: {
        width: SeaScale.Layout(88),
        height: SeaScale.Layout(88),
    },
    iconTitle: {
        marginTop: SeaScale.Layout(24),
        fontSize: SeaTheme.font_size_sm,
    },
});

export default styles;
