/**
 * @author xukj
 * @date 2019/06/03
 * @class
 * @description 分享面板
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, Image, BackHandler } from 'react-native';
import resolveAssetSource from 'react-native/Libraries/Image/resolveAssetSource';
import { FSLDrawer, FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { SeaShareUtil, SeaSharePlatform, SeaShareCode, SeaImageUtil } from '../../util';
import { IdentifyExtension } from '../../redux';
import styles from './style';
import SeaButton from '../button/SeaButton';
import { SeaLinking } from '../../view/resource';
import { SeaTheme } from '../../asserts';

let drawerKey = null;

/**
 * 分享按钮配置
 */
const ShareConfigs = {
    unsupport: {
        name: '暂不支持',
        source: undefined,
        type: -1,
    },
    qq: {
        name: 'QQ分享',
        source: undefined,
        type: SeaSharePlatform.QQ,
    },
    wxSession: {
        name: '微信',
        source: require('../../asserts/images/wechat_session.png'),
        type: SeaSharePlatform.WechatSessoin,
    },
    wxTL: {
        name: '朋友圈',
        source: require('../../asserts/images/wechat_tl.png'),
        type: SeaSharePlatform.WeChatTimeLine,
    },
    recommend: {
        name: '推荐',
        source: require('../../asserts/images/share_recommend.png'),
        type: -2,
    },
};

/**
 * 分享按钮
 */
const ShareButton = props => {
    const { style, type, onPress } = props;
    const configs = ShareConfigs[type] ? ShareConfigs[type] : ShareConfigs['unsupport'];
    let Component = View;
    if (onPress) Component = SeaButton;

    return (
        <Component style={[styles.button, style && style]} onPress={() => onPress(configs.type)}>
            <Image style={styles.icon} source={configs.source} />
            <Text style={styles.iconTitle}>{configs.name}</Text>
        </Component>
    );
};

ShareButton.propTypes = {
    // weixin - 微信; qq - QQ;
    type: PropTypes.string.isRequired,
    onPress: PropTypes.func,
};

ShareButton.defaultProps = {
    type: 'unsupport',
};

class SeaSharePanel extends React.PureComponent {
    static propTypes = {
        value: PropTypes.object,
    };

    static defaultProps = {
        value: {},
    };

    constructor(props) {
        super(props);
        this.backHandler;
    }

    componentDidMount() {
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
            hide();
            return true;
        });
    }

    componentWillUnmount() {
        this.backHandler && this.backHandler.remove();
    }

    render() {
        const { recommend, wxSession, wxTL, qq } = this.props.value;
        return (
            <View style={styles.panel}>
                <Text style={styles.title}>分享到</Text>
                <View style={styles.contentContainer}>
                    {wxSession && <ShareButton type="wxSession" onPress={this._onSharePress} />}
                    {wxTL && (
                        <ShareButton
                            style={{ marginLeft: SeaTheme.h_spacing_md }}
                            type="wxTL"
                            onPress={this._onSharePress}
                        />
                    )}
                    {qq && (
                        <ShareButton
                            style={{ marginLeft: SeaTheme.h_spacing_md }}
                            type="qq"
                            onPress={this._onSharePress}
                        />
                    )}
                    {recommend && (
                        <ShareButton
                            style={{ marginLeft: SeaTheme.h_spacing_md }}
                            type="recommend"
                            onPress={this._onSharePress}
                        />
                    )}
                </View>
            </View>
        );
    }

    _onSharePress = type => {
        if (type == -1) {
            // 不支持
            hide();
            return;
        }

        if (type == -2) {
            // 推荐
            Actions.show('recommendUserSelection', { resourceId: this.props.value.resourceId });
            hide();
            return;
        }

        const { title, content, imageUrl, url } = this.props.value;

        SeaShareUtil.share(
            this._getContent(content),
            this._getImageUrl(imageUrl),
            url,
            title,
            type,
            (code, message) => {
                hide();
                if (code == SeaShareCode.SUCCESS) {
                    FSLToast.show('分享成功');
                } else if (code == SeaShareCode.CANCEL) {
                    FSLToast.show('已取消分享');
                } else {
                    FSLToast.show(message);
                }
            }
        );
    };

    /**
     * @private
     * @description 如果图片没有，则使用默认图片
     */
    _getImageUrl = imageUrl => {
        const url = imageUrl
            ? imageUrl
            : resolveAssetSource(require('../../asserts/images/icon.png')).uri;
        // 本地 file:///xxxxx => /xxxxx
        return _.replace(url, 'file://', '');
    };

    /**
     * @private
     * @description 如果内容没有，则使用默认内容
     */
    _getContent = content => {
        return content ? content : '博观而约取，厚积而薄发';
    };
}

/**
 * 分享面板
 * @param {object} value 分享内容
 * title - 标题
 * content - 内容
 * imageUrl - 图片地址
 * url - 地址
 * resourceId - 资源id
 * recommend - 推荐按钮
 * wxSession - 微信好友按钮
 * wxTL - 微信朋友圈按钮
 * qq - qq按钮
 */
function show(value) {
    drawerKey = FSLDrawer.bottom(<SeaSharePanel value={value} />, 220);
}

/**
 * 隐藏分享面板
 */
function hide() {
    FSLDrawer.hide(drawerKey);
}

/**
 * 分享详情页内容
 * @param {string} title 详情页名称
 * @param {string} name 分享人名称
 */
function detailContent(title, name = IdentifyExtension.getLoginUserInfo().userName) {
    return `${name}为您推荐了一门课程《${title}》`;
}

/**
 * 分享详情页图片
 * @param {string} imageId 图片id
 * @param {string} imageUrl 默认图片地址
 */
function detailImageUrl(imageId, imageUrl) {
    return SeaImageUtil.getImageUri(imageId, imageUrl, 's');
}

/**
 * 分享详情页地址
 * @param {number} type 资源类型
 * @param {*} value 其他信息
 */
function detailUrl(type, ...value) {
    return new SeaLinking().openDetail(type, ...value).toShareH5();
}

export default {
    show,
    hide,
    detailContent,
    detailImageUrl,
    detailUrl,
};
