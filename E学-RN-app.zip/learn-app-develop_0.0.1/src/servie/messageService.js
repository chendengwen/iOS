/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-09-03 16:10:37
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-07 17:30:01
 */
/**
 * @author xukj
 * @date 2020/01/10
 * @description messageService 消息api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * 查询条件
 * @param {object} map {key: lastTime}
 */
function getMessageGroups(map = {}) {
    const api = dataApi.getUrl(dataApi.common.postMessageType);
    return SeaHttpApi.postHttpApi(api, { ...map });
}

function getMessageNormalList(queryContent, classType, pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.common.postMessageList);
    return SeaHttpApi.postHttpApi(api, {
        criteria: { queryContent, classType },
        pageNum,
        pageSize,
    });
}

function getMessageCommentList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.common.postMessageCommentList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

function getMessageLikeList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.common.postMessageLikeList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}
/**
 * @name: 未读消息
 * @param {type} 
 * @return {type} 
 */
function getUnRead() {
    const api = dataApi.getUrl(dataApi.messageCenter.getUnRead);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 15天内未读消息
 * @param {type} 
 * @return {type} 
 */
function getUnReadMessage() {
    const api = dataApi.getUrl(dataApi.messageCenter.getUnReadMessage);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @name:消息类型
 * @param {type} 
 * @return {type} 
 */
function getMessageType() {
    const api = dataApi.getUrl(dataApi.messageCenter.getMessageType);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description: 根据分类获取未读消息列表
 * @param {type} 
 * @return {type} 
 */
function getMessageByType(obj) {
    const api = dataApi.getUrl(dataApi.messageCenter.getMessageByType + '/' + obj.messageType +
        '?pageNo=' + obj.pageNo + '&pageSize=' + obj.pageSize);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 搜索消息
 * @param {type} 
 * @return {type} 
 */
function serachMessage(obj) {
    const api = dataApi.getUrl(dataApi.messageCenter.searchMessage + '?messageType=' + obj.messageType +
        '&title=' + obj.title);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 已读15天内未读消息
 * @param {type} 
 * @return {type} 
 */
function updateIsRead(){
    const api = dataApi.getUrl(dataApi.messageCenter.updateIsRead);
    return SeaHttpApi.putHttpApi(api);
}
/**
 * @description: 更新已读
 * @param {type} 
 * @return {type} 
 */
function updateIsReadById(messageId){
    const api = dataApi.getUrl(dataApi.messageCenter.updateIsReadById+'?messageId='+messageId);
    return SeaHttpApi.putHttpApi(api);
}

export default {
    getMessageGroups,
    getMessageNormalList,
    getMessageCommentList,
    getMessageLikeList,
    getUnRead,
    getMessageType,
    getMessageByType,
    serachMessage,
    getUnReadMessage,
    updateIsRead,
    updateIsReadById,
};
