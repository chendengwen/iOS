/**
 * @author xukj
 * @date 2019/08/21
 * @description courseService e课api
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaUserUtil } from '../util';
import { SeaConstant } from '../asserts';
/**
 * @description 查询所有课程
 * @param {number} [pageTo] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getAllCourseResource(pageTo, pageSize) {
    const param = {
        pageNum: pageTo,
        pageSize: pageSize,
        criteria: {
            plateCode: SeaUserUtil.getChosenPlateCode(), 
            businessType: SeaConstant.ResourceType.ONLINE_COURSE
        },
    };
    const fetchApi = dataApi.getUrl(dataApi.resource.postCourse);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * @description 获取e课详情
 * @param {string} [id] e课id
 * @return {Promise}
 */
function getCourseById(id) {
    const api = dataApi.getUrl(dataApi.course.getCourseDetail, { id });
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getAllCourseResource,
    getCourseById,
};
