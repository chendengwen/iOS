/*
 * @Author: ouyfm
 * @Date: 2020-06-18 09:49:40
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-25 14:24:25
 * @Descripttion: 案例评价网络请求
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';


// 获取评价列表
function getCaseEvalate(obj) {
    const api = dataApi.getUrl(dataApi.evalate.getCaseEvalate);
    return SeaHttpApi.postHttpApi(api, obj);
}

/**
 *
 *
 * @param {*} obj
 * @returns
 */
function getLectureEvaluation(obj) {

    const api = dataApi.getUrl(dataApi.evalate.getLectureEvaluation);
    return SeaHttpApi.postHttpApi(`${api}?lecturerId=${obj.businessId}&pageNo=${obj.pageNo}&pageSize=${obj.pageSize}`);
}
// 新增
function addCaseEvalate(obj) {
    const api = dataApi.getUrl(dataApi.evalate.addCaseEvalate);
    return SeaHttpApi.postHttpApi(api, obj);
}
// 删除
function detetCaseEvalate(id) {
    const api = dataApi.getUrl(dataApi.evalate.detetCaseEvalate + id);
    return SeaHttpApi.deleteHttpApi(api);
}
/**
 * @description: 
 * @param {type} 
 * @return {type} 
 */
function deleteByCondition(obj) {
    const api = dataApi.getUrl(dataApi.evalate.deleteByCondition);
    return SeaHttpApi.deleteHttpApi(api, {
        businessType: obj.businessType,
        // businessId: obj.businessId,
        evaluateParentId: obj.id,
    });
}
// 点赞
function setCaseLike(obj) {
    const api = dataApi.getUrl(dataApi.evalate.setCaseLike);
    if (obj.isLike) {
        // 取消点赞
        return SeaHttpApi.deleteHttpApi(api, { evaluateId: obj.evaluateId, likeUser: obj.likeUser });
    } else {
        // 点赞
        return SeaHttpApi.postHttpApi(api, { evaluateId: obj.evaluateId, likeUser: obj.likeUser });
    }
}
export default {
    getCaseEvalate,
    addCaseEvalate,
    detetCaseEvalate,
    setCaseLike,
    getLectureEvaluation,
    deleteByCondition,
};
