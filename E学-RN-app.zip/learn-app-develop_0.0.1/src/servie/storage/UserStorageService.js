/**
 * @author xukj
 * @date 2018/12/10
 * @description UserStorageService 用户的持久化
 * 持久化key的格式为 
 * USER前缀 + 用户id: 例如 USER10101-22313-123131-22222
 */
import { DEFAULT_CURRENTUSER_ID, USERKEY } from './StorageConstant';

/**
 * @private
 * @description 持久化key
 */
function userInfoKey(userId = DEFAULT_CURRENTUSER_ID) {
    return USERKEY + userId;
}

/**
 * 保存用户信息
 * @param {string} userId 用户id
 * @param {object} data 用户信息
 */
function saveUserInfo(userId, data) {
    return storage.save({
        key: userInfoKey(userId),
        data: data,
        expires: null,
    });
}

/**
 * 获取用户信息
 * @param {string} userId 用户id
 */
function loadUserInfo(userId) {
    return storage.load({ key: userInfoKey(userId) });
}

/**
 * 删除用户信息
 * @param {string} userId 用户id
 */
function removeUserInfo(userId) {
    return storage.remove({key: userInfoKey(userId)});
}

export default {
    saveUserInfo,
    loadUserInfo,
    removeUserInfo,
};