/**
 * @author xukj
 * @date 2019/01/03
 * @description SettingStorageService 设置
 */
import { NETWORK_SWITCH, IGNORE_UPGRADE_VERSION } from './StorageConstant';

/**
 * @description 获取2G/3G下的网络设置
 * @return {Promise}
 */
function loadSettingNetCtrlPromise() {
    return storage.load({ key: NETWORK_SWITCH });
}

/**
 * @description 2G/3G下的网络设置
 * @param {bool} [ctrl] 开关
 * @return {Promise}
 */
function saveSettingNetCtrlPromise(ctrl = false) {
    return storage.save({
        key: NETWORK_SWITCH,
        data: ctrl,
        expires: null,
    });
}

/**
 * 获取忽略的升级信息
 */
function loadIgnoreUpgradeVersion() {
    return storage.load({ key: IGNORE_UPGRADE_VERSION });
}

function saveIgnoreUpgradeVersion(info) {
    return storage.save({
        key: IGNORE_UPGRADE_VERSION,
        data: info,
        expires: null,
    });
}

export default {
    loadSettingNetCtrlPromise,
    saveSettingNetCtrlPromise,
    loadIgnoreUpgradeVersion,
    saveIgnoreUpgradeVersion,
};
