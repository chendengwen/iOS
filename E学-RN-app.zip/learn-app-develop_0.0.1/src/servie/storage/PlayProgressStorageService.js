/**
 * @author xukj
 * @date 2018/12/11
 * @description PlayProgressStorageService 播放进度
 * 
 * modify by xukj - 1.27.0
 * 统计不需要根据用户来分表
 */
import { DEFAULT_CURRENTUSER_ID, PLAYPROGRESSKEY } from './StorageConstant';

/**
 * 获取学习进度
 */
function loadPlayProgress() {
    return storage.load({ key: PLAYPROGRESSKEY });
}

/**
 * 保存进度
 * @param {object} data 进度数据
 */
function savePlayProgress(data) {
    return storage.save({
        key: PLAYPROGRESSKEY,
        data: data,
        expires: null,
    });
}

/**
 * 删除进度
 */
function resetPlayProgress() {
    return storage.remove({ key: PLAYPROGRESSKEY });
}

export default {
    loadPlayProgress,
    savePlayProgress,
    resetPlayProgress,
};