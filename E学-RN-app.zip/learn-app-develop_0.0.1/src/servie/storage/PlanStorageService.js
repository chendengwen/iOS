/**
 * @author xukj
 * @date 2019/01/03
 * @description NoticeStorageService 最近的消息获取时间持久化
 */
import { LATEST_PLAN_TIME,REFRESH_PLAN_TIME} from "./StorageConstant";

let defaultTimeObj={
    eClass:0,
    training:0,
    read:0,
    exam:0,
    qa:0
};
/**
 * @description 获取最近的计划获取时间
 * @return {Promise}
 */
function loadLatestTimeForPlanPromise() {
    return storage.load({key: LATEST_PLAN_TIME});
}

/**
 * @description 保存最近的计划获取时间
 * @param {object} time 对象
 * @return {Promise}
 */
function saveLatestTimeForPlanPromise(time=defaultTimeObj) {
    return storage.save({
        key: LATEST_PLAN_TIME,
        data: time,
        expires: null
    });
}

/**
 * @description 获取最近的计划刷新时间
 * @return {Promise}
 */
function loadRefreshTimeForPlanPromise() {
    return storage.load({key: REFRESH_PLAN_TIME});
}

/**
 * @description 保存最近的计划刷新时间
 * @param {object} time 对象
 * @return {Promise}
 */
function saveRefreshTimeForPlanPromise(time=defaultTimeObj) {
    return storage.save({
        key: REFRESH_PLAN_TIME,
        data: time,
        expires: null
    });
}

export default {
    loadLatestTimeForPlanPromise,
    saveLatestTimeForPlanPromise,
    loadRefreshTimeForPlanPromise,
    saveRefreshTimeForPlanPromise
};