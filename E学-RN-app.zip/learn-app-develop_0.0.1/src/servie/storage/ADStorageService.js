/**
 * @author xukj
 * @date 2019/12/27
 * @description ADStorageService 广告信息
 */
import { ADKEY } from './StorageConstant';

/**
 * 获取广告数据
 */
function load() {
    return storage.load({ key: ADKEY });
}

/**
 * 保存广告信息
 * @param {*} value
 */
function save(value) {
    return storage.save({
        key: ADKEY,
        data: value,
        expires: null,
    });
}

/**
 * 重置广告信息
 */
function reset() {
    return storage.remove({ key: ADKEY });
}

export default { load, save, reset };
