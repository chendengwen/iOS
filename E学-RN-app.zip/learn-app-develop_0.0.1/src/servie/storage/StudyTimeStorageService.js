/**
 * @author xukj
 * @date 2018/12/11
 * @description StudyTimeStorageService 学时统计
 * 
 * modify by xukj - 1.27.0
 * 统计不需要根据用户来分表
 */
import { DEFAULT_CURRENTUSER_ID, STUDYTIMEKEY } from './StorageConstant';

/**
 * @description 获取学习时长统计，因为历史代码的原因这里直接返回Promise
 */
function loadStudyTime() {
    return storage.load({ key: STUDYTIMEKEY });
}

/**
 * @description 保存学习时长统计，因为历史代码的原因这里直接返回Promise
 * @param {*} [data] 对象
 */
function saveStudyTime(data) {
    return storage.save({
        key: STUDYTIMEKEY,
        data: data,
        expires: null,
    });
}

/**
 * @description 重置学习时长
 */
function resetStudyTime() {
    return storage.remove({ key: STUDYTIMEKEY });
}

export default {
    loadStudyTime,
    saveStudyTime,
    resetStudyTime,
};
