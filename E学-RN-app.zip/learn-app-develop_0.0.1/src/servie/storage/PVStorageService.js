/**
 * @author xukj
 * @date 2018/12/11
 * @description PVStorageService pv统计
 */
import { PVKEY } from "./StorageConstant";

/**
 * @description 获取本地的pv统计
 * @param {string} [key] 数据库查询key
 * @return {Promise}
 */
function loadPVStorage(key = PVKEY) {
    return storage.load({ key: key });
}

/**
 * @description 保存本地pv统计
 * @param {*} [value] 保存的value
 * @param {string} [key] 数据库查询key
 * @return {Promise}
 */
function savePVStorage(value, key = PVKEY) {
    return storage.save({
        key: key,
        data: value,
        expires: null,
    });
}

/**
 * @description 重置pv统计
 * @param {string} [key] 需要重置的key
 * @return {Promise}
 */
function resetPVStorage(key = PVKEY) {
    return storage.remove({ key });
}

export default {
    loadPVStorage,
    savePVStorage,
    resetPVStorage,
};