/**
 * @author xukj
 * @date 2018/12/10
 * @description SessionStorageService 登录信息的持久化
 */
import { SESSIONKEY } from "./StorageConstant";
const forceSignInValue = 2;

/**
 * 保存最近登录的用户信息。在用户登录成功后调用。
 * @param {object} session 登录信息
 */
function saveLatestLoginSession(session) {
    return storage.save({
        key: SESSIONKEY,
        data: {
            user: session,
            forceSignIn: forceSignInValue, // 如果小于该值，则强制登录
            loginTime: (new Date()).getTime(),
        },
        expires: null
    });
}

/**
 * 获取最近登录的用户信息。用于自动登录。
 */
function loadLatestLoginSession() {
    return new Promise((resolve, reject) => {
        storage.load({key: SESSIONKEY}).then(session => {
            resolve(session.user);
        }).catch(error => {
            reject(error);
        });
    });
}

/**
 * 删除最近登录的用户信息
 */
function removeLatesLoginSession() {
    return storage.remove({key: SESSIONKEY});
}

export default {
    saveLatestLoginSession,
    loadLatestLoginSession,
    removeLatesLoginSession,
};