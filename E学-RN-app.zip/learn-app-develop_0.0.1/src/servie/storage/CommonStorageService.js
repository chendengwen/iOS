/**
 * @author xukj
 * @date 2019/01/02
 * @description CommonStorageService 通用的存储
 */
import { ANNUAL_PERSONAL_SUMMARY, GUIDE_SHOWN_VERSION } from './StorageConstant';

/**
 * 设置个人年度报告已缓存
 */
function setAnnualSummaryShown() {
    return storage.save({
        key: ANNUAL_PERSONAL_SUMMARY,
        data: true,
        expires: null,
    });
}

/**
 * 获取个人年度报告是否缓存
 */
function loadAnnualSummaryShown() {
    return storage.load({ key: ANNUAL_PERSONAL_SUMMARY }).catch(() => {
        return Promise.resolve(false);
    });
}

/**
 * @description 获取引导页显示的最近版本
 * @param {function} [onSuccess] 加载成功
 * @param {function} [onFail] 加载失败
 */
function loadGuideLatestVersion(onSuccess, onFail) {
    (async () => {
        try {
            const result = await storage.load({key: GUIDE_SHOWN_VERSION});
            if (onSuccess) onSuccess(result);
        } catch (error) {
            if (onFail) onFail(error);
        }
    })();
}

/**
 * @description 保存引导页显示的最近版本
 * @param {string} [version] 版本号
 * @param {function} [onSuccess] 加载成功
 * @param {function} [onFail] 加载失败
 */
function saveGuideLatestVersion(version, onSuccess, onFail) {
    (async () => {
        try {
            const result = await storage.save({
                key: GUIDE_SHOWN_VERSION,
                data: version,
                expires: null,
            });
            if (onSuccess) onSuccess(result);
        } catch (error) {
            if (onFail) onFail(error);
        }
    })();
}

export default {
    setAnnualSummaryShown,
    loadAnnualSummaryShown,
    loadGuideLatestVersion,
    saveGuideLatestVersion,
};