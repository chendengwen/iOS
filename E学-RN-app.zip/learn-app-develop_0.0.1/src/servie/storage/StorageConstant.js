/**
 * @author xukj
 * @date 2018/12/12
 * @description StorageConstant 持久化相关需要的数据
 */

// 默认的当前用户id
export const DEFAULT_CURRENTUSER_ID = '00000000-0000-0000-0000-00000000';
// 年度报告key
export const ANNUAL_PERSONAL_SUMMARY = 'ANNUAL_PERSONAL_SUMMARY';
// 用户信息key
export const USERKEY = 'USER';
// PV key
export const PVKEY = 'PAGEPV';
// 学习时长key
export const STUDYTIMEKEY = 'STIME';
// 登录信息key
export const SESSIONKEY = 'SESSION';
// 播放进度key
export const PLAYPROGRESSKEY = 'PPROGRESS';
// 最近获取的消息key（已废弃）
export const LATEST_NOTICE_TIME = 'latestTimeForNotice';
// 引导页展示key
export const GUIDE_SHOWN_VERSION = 'guideShownVersion';
// 2G/3G/4G 流量选择key
export const NETWORK_SWITCH = 'netCtrl';
// 考试答题记录 key
export const EXAMKEY = 'EXAM';
// 忽略的升级信息
export const IGNORE_UPGRADE_VERSION = 'ignoreUpgradeVersion';
// 最近获取的计划key
export const LATEST_PLAN_TIME = 'latestTimeForPlan';
// 最近刷新的计划key
export const REFRESH_PLAN_TIME = 'refreshTimeForPlan';
// 广告key
export const ADKEY = 'ADs';
// 消息分组key
export const MESSAGE_GROUP_KEY = 'MESSAGE_GROUP_KEY';
