/**
 * @author xukj
 * @date 2019/01/03
 * @description NoticeStorageService 最近的消息获取时间持久化
 */
import { LATEST_NOTICE_TIME, MESSAGE_GROUP_KEY } from './StorageConstant';

/**
 * 获取用户消息分组信息
 */
function loadMessageGroups() {
    return storage.load({ key: MESSAGE_GROUP_KEY });
}

/**
 * 保存消息分组信息
 * @param {object} data 消息分组数据
 */
function saveMessageGroups(data) {
    return storage.save({
        key: MESSAGE_GROUP_KEY,
        data,
        expires: null,
    });
}

/**
 * 移除消息分组信息
 */
function removeMessageGroups() {
    return storage.remove({ key: MESSAGE_GROUP_KEY });
}

export default {
    loadMessageGroups,
    saveMessageGroups,
    removeMessageGroups,
};
