/**
 * @author xukj
 * @date 2019/02/28
 * @description ExamStorageService 考试记录
 */
import { DEFAULT_CURRENTUSER_ID, EXAMKEY } from './StorageConstant';

/**
 * 本地持久化的key
 * @param {string} paperId 试卷id
 * @param {string} userId 考试用户id
 */
function examKey(paperId, userId = DEFAULT_CURRENTUSER_ID) {
    return EXAMKEY + userId + paperId;
}

/**
 * 获取本地保存的用户的试卷答题记录
 * @param {string} paperId 试卷id
 * @param {string} userId 考试用户id
 */
function loadExamData(paperId, userId) {
    return storage.load({ key: examKey(paperId, userId) });
}

/**
 * 本地保存的用户的试卷答题记录
 * @param {string} paperId 试卷id
 * @param {string} userId 考试用户id
 * @param {any} data 答题记录
 */
function saveExamData(paperId, userId, data) {
    return storage.save({
        key: examKey(paperId, userId),
        data: data,
        expires: null,
    });
}

/**
 * 移除本地保存的用户的试卷答题记录
 * @param {string} paperId 试卷id
 * @param {string} userId 考试用户id
 */
function removeExamData(paperId, userId) {
    return storage.remove({ key: examKey(paperId, userId) });
}

export default {
    loadExamData,
    saveExamData,
    removeExamData,
}