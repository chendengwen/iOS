/**
 * @author xukj
 * @date 2019/09/09
 * @description 审批service
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * 获取我的审批列表
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @param {bool} pending 是否待审批
 * @reutrn {Promise}
 */
function getMyApprovalList(pageNum, pageSize, pending) {
    const api = dataApi.getUrl(
        pending ? dataApi.approval.postApprovalTodoList : dataApi.approval.postApprovalDoneList
    );
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * 获取待审批的E课详情
 * @param {string} resourceId 面授id
 * @reutrn {Promise}
 */
function getApproveEClassDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveEClassDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待审批的E课详情（新）
 * @param {string} bussSerialNo 业务id
 * @reutrn {Promise}
 */
function getApprovalEClassDetail(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.eClassManagement.getApprovalDetailInfo, { bussSerialNo });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 根据业务ID获取E课的在线课程（新）
 * @param {string} bussSerialNo 业务id
 * @reutrn {Promise}
 */
function getCurriculas(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.eClassManagement.getCurriculas, { bussSerialNo });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 根据业务ID获取E课的试卷（新）
 * @param {string} bussSerialNo 业务id
 * @reutrn {Promise}
 */
function getQuestionnaires(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.eClassManagement.getQuestionnaires, { bussSerialNo });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待审批的面授详情
 * @param {string} resourceId 面授id
 * @reutrn {Promise}
 */
function getApproveTrainingDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveTrainingDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待新闻的详情
 * @param {string} resourceId 面授id
 * @reutrn {Promise}
 */
function getApproveNewsDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveNewsDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待审批的考试详情
 * @param {string} resourceId 考试id
 * @reutrn {Promise}
 */
function getApproveTestDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveTestDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待审批的问卷详情
 * @param {string} resourceId 问卷id
 */
function getApproveQuestionDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveQuestionDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取待审批的阅读详情
 * @param {string} resourceId 阅读id
 */
function getApproveReaderDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApproveReaderDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取资源的可见性
 * @param {string} resourceId 资源id
 */
function getResourceVisibleList(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getResourceVisibleList, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 提交审批结果
 * @param {string} resourceId 审批项目id
 * @param {string} content 审批意见
 * @param {bool} agree 审批结果
 */
function submitApprovalResult(resourceId, content, agree) {
    const api = dataApi.getUrl(dataApi.approval.postApproval);
    const reviewResult = agree ? '1' : '2';
    return SeaHttpApi.postHttpApi(api, {
        resourceId,
        reviewContent: content,
        reviewResult,
    });
}

/**
 * 获取审批信息
 * @param {string} resourceId 资源id
 */
function getApprovalInfo(resourceId) {
    const api = dataApi.getUrl(dataApi.approval.getApprovalInfo, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 发布E课
 * @param {string} bussSerialNo   业务ID
 */
function publishEClass(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.approval.publishEClass, { bussSerialNo });
    return SeaHttpApi.putHttpApi(api);
}

/**
 * 发布培训
 * @param {string} bussSerialNo   业务ID
 */
function publishTrain(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.approval.publishTrain, { bussSerialNo });
    return SeaHttpApi.putHttpApi(api);
}

/**
 * 发布考试
 * @param {string} bussSerialNo   业务ID
 */
function publishExam(bussSerialNo) {
    const api = dataApi.getUrl(dataApi.approval.publishExam, { bussSerialNo });
    return SeaHttpApi.putHttpApi(api);
}

export default {
    getApproveEClassDetail,
    getApproveNewsDetail,
    getMyApprovalList,
    getApproveTrainingDetail,
    getApproveTestDetail,
    getApproveQuestionDetail,
    getApproveReaderDetail,
    getResourceVisibleList,
    submitApprovalResult,
    getApprovalInfo,
    getApprovalEClassDetail,
    getCurriculas,
    getQuestionnaires,
    publishEClass,
    publishTrain,
    publishExam
};
