/**
 * @author xukj
 * @date 2019/08/21
 * @description trainingService 面授api
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaUserUtil } from '../util';
import { SeaConstant } from '../asserts';

/**
 * @description 查询所有的面授
 * @param {number} [pageTo] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getAllTrainingResource(pageTo, pageSize) {
    const param = {
        pageNum: pageTo,
        pageSize: pageSize,
        criteria: {
            plateCode: SeaUserUtil.getChosenPlateCode(),
            businessType: SeaConstant.ResourceType.TRAINING_CLASS,
        },
    };
    const fetchApi = dataApi.getUrl(dataApi.resource.postTrainning);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * @description 获取期次详情
 * @param {string} [id] 期次id
 * @return {Promise}
 */
function getTraclassDetail(id) {
    const api = dataApi.getUrl(dataApi.traClass.getTraclassDetail, { id });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 获取预开课详情
 * @param {string} [resourceId] 预开课id
 * @return {Promise}
 */
function getSurveyDetailById(resourceId) {
    const api = dataApi.getUrl(dataApi.project.getSurveyDetail, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 提交预开课结果
 * @param {string} [resourceId] 预开课id
 * @return {Promise}
 */
function submitSurveyById(resourceId) {
    const api = dataApi.getUrl(dataApi.project.putSurvey, { resourceId });
    return SeaHttpApi.putHttpApi(api);
}

/**
 * 获取大纲
 * @param {string} resourceId 资源id
 * @return {Promise}
 */
function getScheduleByResourceId(resourceId) {
    const api = dataApi.getUrl(dataApi.offline.getSchedule, { classId: resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取未完成问卷的面授数量
 * @return {Promise}
 */
function getNofinishTranQuestionCount() {
    const api = dataApi.getUrl(dataApi.traClass.getQuestionNoFinish);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 通过签到码签到
 * @param {number} code 签到码
 * @return {Promise}
 */
function assignResourceWithCode(code) {
    const fetchApi = dataApi.getUrl(dataApi.signIn.postSignInWithCode, { code });
    return SeaHttpApi.postHttpApi(fetchApi);
}

/**
 * 通过签到ID签到
 * @param {string} signId 签到id
 * @return {Promise}
 */
function assignResourceWithSignId(id) {
    const fetchApi = dataApi.getUrl(dataApi.signIn.postSignInWithId, { id });
    return SeaHttpApi.postHttpApi(fetchApi);
}

/**
 * 获取签到人员信息列表
 * @param {string} resourceId 面授id
 * @param {number} pageTo 页码
 * @param {number} pageSize 每页数量
 */
function getSignUserList(resourceId, pageTo, pageSize) {
    const param = {
        pageNum: pageTo,
        pageSize: pageSize,
        criteria: { resourceId },
    };
    const api = dataApi.getUrl(dataApi.signIn.postTrainingSignUserList);
    return SeaHttpApi.postHttpApi(api, param);
}

/**
 * 获取签到人员的签到详情
 * @param {string} resourceId
 * @param {string} userId
 */
function getSignUserDetail(resourceId, userId) {
    const api = dataApi.getUrl(dataApi.signIn.getTrainingSignUserDetail, { resourceId, userId });
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getAllTrainingResource,
    getTraclassDetail,
    getSurveyDetailById,
    submitSurveyById,
    getScheduleByResourceId,
    getNofinishTranQuestionCount,
    assignResourceWithCode,
    assignResourceWithSignId,
    getSignUserList,
    getSignUserDetail,
};
