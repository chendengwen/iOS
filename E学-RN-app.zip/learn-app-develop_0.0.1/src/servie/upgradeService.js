/**
 * @author xukj
 * @date 2019/08/20
 * @description upgradeService 版本相关api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 验证是否有新的版本
 * @param {number} [build] 当前版本build号
 * @param {string} [platform] 当前平台信息 ios/android
 * @return {Promise}
 */
function verifyVersion(build, platform) {
    const api = dataApi.getUrl(dataApi.upgrade.postVerify);
    return SeaHttpApi.postHttpApi(
        api,
        { build, platform },
        { headers: SeaHttpApi.noTokenHeaders() }
    );
}

/**
 * @description 新版本信息
 * @param {string} [platform] 平台 ios/android
 * @return {Promise}
 */
function getInfo(platform) {
    const api = dataApi.getUrl(dataApi.upgrade.postInfo);
    return SeaHttpApi.postHttpApi(api, { platform }, { headers: SeaHttpApi.noTokenHeaders() });
}

export default {
    verifyVersion,
    getInfo,
};
