/**
 * Created by xukj on 2018/7/18.
 * service模块：网络api/storage api/...
 * @providesModule learn-service
 */

import { format } from 'url';

// 网络 api
export { default as CategoryService } from './categoryService';
export { default as TestPaperService } from './testpaperService';
export { default as NewsService } from './newsService';
export { default as PersonalService } from './personalService';
export { default as ResourceService } from './resourceService';
export { default as ToLearnService } from './toLearnService';
export { default as ExceptionService } from './exceptionService';
export { default as UpgradeService } from './upgradeService';
export { default as CommonService } from './commonService';
export { default as LoginService } from './loginService';
export { default as QuestionnaireService } from './questionnaireService';
export { default as RewardPointsService } from './rewardPointsService';
export { default as UserService } from './userService';
export { default as QAService } from './qaService';
export { default as SubjectService } from './subjectService';
export { default as BookService } from './bookService';
export { default as TrainingService } from './trainingService';
export { default as CourseService } from './courseService';
export { default as ApproveService } from './approveService';
export { default as TeacherCourseService } from './teacherCourseService';
export { default as MessageService } from './messageService';
export { default as EvaluateService } from './evaluateService';
// storage api
export { default as SessionStorageService } from './storage/SessionStorageService';
export { default as UserStorageService } from './storage/UserStorageService';
export { default as PVStorageService } from './storage/PVStorageService';
export { default as StudyTimeStorageService } from './storage/StudyTimeStorageService';
export { default as PlayProgressStorageService } from './storage/PlayProgressStorageService';
export { default as CommonStorageService } from './storage/CommonStorageService';
export { default as NoticeStorageService } from './storage/NoticeStorageService';
export { default as SettingStorageService } from './storage/SettingStorageService';
export { default as ExamStorageService } from './storage/ExamStorageService';
export { default as PlanStorageService } from './storage/PlanStorageService';
export { default as ADStorageService } from './storage/ADStorageService';

//案例
export { default as CasesService } from './casesService';
//讲师
export { default as TeacherService } from './teacherService';