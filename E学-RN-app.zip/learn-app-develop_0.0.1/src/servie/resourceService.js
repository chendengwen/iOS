/**
 * Created by zk on 2017/6/1.
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaUserUtil } from '../util';
import placeholder from 'rn-placeholder/src/placeholder';
import { IdentifyExtension } from '../redux';

/**
 * @deprecated
 * @description 所有项目搜索，一个项目一条数据不分页
 * @param {keyword} [keyword] - 关键字
 * @param {function} [onSuccess] - 成功
 * @param {function} [onFail] - 失败
 */
function searchAllResource(keyword, onSuccess, onFail) {
    // (async () => {
    //     try {
    //         const fetchApi = dataApi.getUrl(dataApi.lecquery.searchResourceAll);
    //         const data = {
    //             key: keyword,
    //             clientType: 'app',
    //         };
    //         const result = await SeaHttpApi.postHttpApi(fetchApi, data);
    //         onSuccess(result);
    //     } catch (error) {
    //         onFail(error);
    //     }
    // })();
}

/**
 * @description 项目搜索，根据类型和关键字，分页
 * @param {keyword} [keyword] - 关键字
 * @param {string} [type] - 类型 train/news/read/eclass/exam
 * @param {string} [orderBy] - likes/frequency/timeForOrder  对应点赞数/热度/时间 默认不传为按匹配度排序
 * @param {number} [pageTo] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function searchListResource(keyword, type, orderBy, pageTo, pageSize) {
    const param = {
        page: pageTo,
        pageSize: pageSize,
        key: keyword,
        bizTypes: type,
        orderBy: orderBy,
        clientType: 'app',
        plateCode: SeaUserUtil.getChosenPlateCode(),
    };
    const fetchApi = dataApi.getUrl(dataApi.lecquery.searchResourceList);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * @description 获取资源评论
 * @param {string} [id] 资源id
 * @return {Promise}
 */
function getResourceComment(id) {
    const api = dataApi.getUrl(dataApi.comment.getComment, id);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 添加评论
 * @param {string} resourceId
 * @param {string} content 内容
 * @param {bool} anonymous 匿名
 * @param {number} rate 评分
 * @return {Promise}
 */
function addComment(resourceId, content, anonymous, rate) {
    const api = dataApi.getUrl(dataApi.comment.postComment);
    return SeaHttpApi.postHttpApi(api, { resourceId, content, anonymous, rate });
}

/**
 * @description 获取点赞状态
 * @param {string} [id] 资源id
 * @return {Promise}
 */
function getLikeStatusById(id) {
    const fetchApi = dataApi.getUrl(dataApi.like.getLike, id);
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * @description 反转点赞状态
 * @param {string} [id] 资源id
 * @return {Promise}
 */
function toggleLikeStatusById(id) {
    const fetchApi = dataApi.getUrl(dataApi.like.postToggle, id);
    return SeaHttpApi.postHttpApi(fetchApi);
}

/**
 * @description 推荐资源给用户
 * @param {array} [userIds] 用户ids
 * @param {string} [resourceId] 资源id
 * @return {Promise}
 */
function recommendResourceToUser(userIds, resourceId) {
    const api = dataApi.getUrl(dataApi.recommendpersonal.postSave);
    return SeaHttpApi.postHttpApi(api, {
        resourceId: resourceId,
        toUserIdList: userIds,
    });
}

/**
 * @description 获取搜索关键字历史
 * @param {array<int>} [types] 类型
 * @return {Promise}
 */
function getSearchKeywords(types) {
    const api = dataApi.getUrl(dataApi.lecquery.getSearchKeywords);
    return SeaHttpApi.postHttpApi(api, { conditons: { types } });
}

/**
 * @description 清空搜索关键字历史
 * @return {Promise}
 */
function clearSearchKeywords() {
    const api = dataApi.getUrl(dataApi.lecquery.deleteSearchKeywords);
    return SeaHttpApi.deleteHttpApi(api);
}

/**
 * 获取资源下的问卷列表(非问卷项目)
 * @param {string} resourceId 面授id
 * @return {Promise}
 */
function getQResourceList(resourceId) {
    const api = dataApi.getUrl(dataApi.traClass.getQuestionList, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 获取首页广告栏banner
 * @return {Promise}
 */
function getADBannerResource(plateCode) {
    const fetchApi = dataApi.getUrl(dataApi.setting.getBanners + '1' + '/' + plateCode);
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * @description 获取首页推荐资源
 * @return {Promise}
 */
function getRecommendResource(columnType, plateCode) {
    const fetchApi = dataApi.getUrl(dataApi.recommend.getHomeResources + '?columnType=' + columnType
        + '&plateCode=' + plateCode);
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * @description 分页查找某个栏目的推荐资源
 * @param {string} [columnId] - 栏目id
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getColumnResources(columnId, pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.recommend.getColumnResources);
    return SeaHttpApi.postHttpApi(fetchApi, { criteria: { columnId }, pageNum, pageSize });
}

/**
 * 获取频道列表
 * @return {Promise}
 */
function getChannelList() {
    const fetchApi = dataApi.getUrl(dataApi.common.getChannelList);
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * 获取资源是否有未完成项（考试、问卷）
 * @param {string} id
 */
function getResourceFinishStatus(id) {
    const fetchApi = dataApi.getUrl(dataApi.common.getResourceFinishStatus, { id });
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * @description 获取收藏状态
 * @param {string} [businessId] 资源id
 * @param {string} [businessType] 资源类型 1：E课 2：培训管理 3：考试 4：阅读 5：新闻 6：预开课 7：问卷 8：讲师 9：案例 10：专题 11：意见反馈 12：学吧
 * @return {Promise}
 */
function getFavoriteStatus(businessId, businessType) {
    const api = dataApi.getUrl(dataApi.favorite.getFavoriteStatus);
    return SeaHttpApi.postHttpApi(api, businessId, businessType + '');
}

/**
 * @description 反转收藏状态
 * @param {string} [businessId] 资源id
 * @param {string} [businessType] 资源类型 1：E课 2：培训管理 3：考试 4：阅读 5：新闻 6：预开课 7：问卷 8：讲师 9：案例 10：专题 11：意见反馈 12：学吧
 * @return {Promise}
 */
function toggleFavoriteStatus(businessId, businessType) {
    const api = dataApi.getUrl(dataApi.favorite.toggleFavoriteStatus);
    return SeaHttpApi.postHttpApi(api, businessId, businessType + '');
}

export default {
    // 已重构
    searchAllResource,
    searchListResource,
    getResourceComment,
    getLikeStatusById,
    toggleLikeStatusById,
    recommendResourceToUser,
    getSearchKeywords,
    clearSearchKeywords,
    // add by xukj - 1.32.0
    getQResourceList,
    getADBannerResource,
    getRecommendResource,
    getChannelList,
    // add by xukj - 1.37.0
    getColumnResources,
    // modify by xukj - 1.39.0
    addComment,
    // add by xukj - 1.40.0
    getResourceFinishStatus,
    getFavoriteStatus,
    toggleFavoriteStatus,
};
