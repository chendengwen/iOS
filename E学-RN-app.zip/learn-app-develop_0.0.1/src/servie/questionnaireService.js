/**
 * Created by zk on 2017/9/21.
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * 获取问卷项目历史
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @return {Promise}
 */
function getQProjectHistory(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.questionnaire.postQuestionnaireHistory);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * 获取问卷项目列表
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @return {Promise}
 */
function getQProjectChannelList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.questionnaire.postQChannelList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * 获取问卷项目的详情。PS：问卷项和问卷是2个概念，问卷是需要调查的题目集合；问卷项是问卷的集合；
 * @param {string} id 问卷项目id
 */
function getQuestionnaireProjectDesc(id) {
    const api = dataApi.getUrl(dataApi.question.getProjectDetail, { id });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取问卷题目简介
 * @param {string} id 问卷id
 */
function getQuestionnairePaperDesc(id) {
    const fetchApi = dataApi.getUrl(dataApi.questionnaire.getQuestionnaire, { id });
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * 提交问卷答案
 * @param {string} id 问卷id
 * @param {string} resourceId 问卷id
 * @param {*} answer 问卷答案
 * @return {Promise}
 */
function submitAnswer(id, resourceId, answer) {
    const fetchApi = dataApi.getUrl(dataApi.questionnaire.postAnswer, { id, resourceId });
    return SeaHttpApi.postHttpApi(fetchApi, answer);
}

export default {
    // modify by xukj - 1.32.0
    getQuestionnairePaperDesc,
    getQuestionnaireProjectDesc,
    // modify by xukj - 1.35.0
    submitAnswer,
    getQProjectHistory,
    getQProjectChannelList,
};
