/*
 * @Author: gaojq
 * @Date: 2020-07-13 14:56:50
 * @LastEditTime: 2020-09-29 10:10:58
 * @LastEditors: Please set LastEditors
 * @Description: 
 * @FilePath: \learn\src\servie\teacherService.js
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';
import { IdentifyExtension } from '../redux';

/**
 * 获取讲师列表
 * @param {number} pageTo 页码
 * @param {number} pageSize 每页数量
 * @param {boolean} recommend 是否推荐
 * @return {Promise}
 */
function getTeacherList(pageNo, pageSize, teacherStatus, teacherLevel) {
    const param = {
        pageNo: pageNo,
        pageSize: pageSize,
        teacherStatus: teacherStatus,
        teacherLevel: teacherLevel,
    };
    const api = dataApi.getUrl(dataApi.teacherCenter.getTeacherList, { pageNo, pageSize });

    return SeaHttpApi.postHttpApi(api, param);
}

function searcheTeacher(pageNo, pageSize, userName) {
    const param = {
        pageNo: pageNo,
        pageSize: pageSize,
        userName: userName,
        // teacherLevel:teacherLevel,
    };
    const api = dataApi.getUrl(dataApi.teacherCenter.getTeacherList, { pageNo, pageSize });

    return SeaHttpApi.postHttpApi(api, param);
}

/**
 * 点赞
 * @param {string} resourceId 
 * @param {} giveLike 
 */
function giveLikeCase(resourceId, giveLike) {
    const param = {
        caseId: resourceId,
        userId: IdentifyExtension.getLoginUserInfo().id,
        giveLike: giveLike
    }
    const fetchApi = dataApi.getUrl(dataApi.cases.giveLikeCease);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}
/**
 * @description: 
 * @param {type} 
 * @return {type} 
 */
function getADBannerResource(place, plateCode) {
    const fetchApi = dataApi.getUrl(dataApi.setting.getBanners + place + '/' + plateCode);
    return SeaHttpApi.getHttpApi(fetchApi);
}
/**根据讲师id获取信息
 * @description: 
 * @param {type} 
 * @return {type} 
 */
function lecturerInfoBylecturerId(lecturerId) {
    const fetchApi = dataApi.getUrl(dataApi.teacherCenter.getLecturerInfoByID + lecturerId);
    return SeaHttpApi.getHttpApi(fetchApi);
}
export default {
    getTeacherList,
    searcheTeacher,
    getADBannerResource,
    lecturerInfoBylecturerId,
}