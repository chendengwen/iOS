
/**
 * @author xukj
 * @date 2019/08/21
 * @description subjectService api
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaUserUtil } from '../util';
import { IdentifyExtension } from '../redux';

/**
 * 获取专题列表
 * @param {number} pageTo 页码
 * @param {number} pageSize 每页数量
 * @param {boolean} recommend 是否推荐
 * @return {Promise}
 */
function getSubjectList(pageTo, pageSize, recommend = false) {
    const param = {
        pageNum: pageTo,
        pageSize: pageSize,
        criteria: { recommend: recommend ? 1 : null },
    };
    // const fetchApi = dataApi.getUrl(dataApi.common.postSubjectList);
    //  return SeaHttpApi.postHttpApi(fetchApi, param);
    const fetchApi = dataApi.getUrl(dataApi.common.postSubjectList + '?pageNo=' + pageTo + '&pageSize=' + pageSize +
        '&plateCode=' + SeaUserUtil.getChosenPlateCode());// + '&plateCode=' + (IdentifyExtension.getLoginUserInfo() ? IdentifyExtension.getLoginUserInfo().chosenPlateCode: ''));
    return SeaHttpApi.getHttpApi(fetchApi);

}

/**
 * 获取专题详细信息
 * @param {string} resourceId 专题id
 */
function getSubjectDetail(resourceId) {
    // const api = dataApi.getUrl(dataApi.common.getSubjectInfo, { id: resourceId });
    const api = dataApi.getUrl(dataApi.common.getSubjectInfo + '?topicId=' + resourceId);
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getSubjectList,
    getSubjectDetail,
}