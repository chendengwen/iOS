/**
 * @author xukj
 * @date 2019/08/20
 * @description rewardPointsService 积分api
 * Created by zk on 2017/10/26.
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * 获取积分列表
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function queryMyPointsDetail(resourceType, startTime, endTime, pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.integral.getList);
    const criteria = {
        resourceType,
        startTime,
        endTime,
    };
    return SeaHttpApi.postHttpApi(fetchApi, { criteria, pageNum, pageSize });
}

/**
 * 上报完成
 * @param {any} param 数据
 * @return {Promise}
 */
function reportCourseFinish(param) {
    const fetchApi = dataApi.getUrl(dataApi.common.putFinishCourse, param);
    return SeaHttpApi.putHttpApi(fetchApi);
}

/**
 * 上报课件播放完成
 * @param {any} param
 * @return {Promise}
 */
function reportPlayFinish(param) {
    const fetchApi = dataApi.getUrl(dataApi.common.putFinishCourseware, param);
    return SeaHttpApi.putHttpApi(fetchApi);
}

export default {
    queryMyPointsDetail,
    reportCourseFinish,
    reportPlayFinish,
};
