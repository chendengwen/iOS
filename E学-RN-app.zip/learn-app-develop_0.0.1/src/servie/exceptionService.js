import dataApi from '../config/api';
import { SeaHttpApi } from '../util';
import { IdentifyExtension } from '../redux';
import _ from 'lodash';

function sendException(data, onSuccess, onFail) {
    (async () => {
        try {
            // 未登录不执行
            const token = _.get(IdentifyExtension.getLoginSessionData(), 'authToken', '');
            if (!!!token) return;
            const api = dataApi.getUrl(dataApi.common.postException);
            const result = await SeaHttpApi.postHttpApi(api, data);
            if (onSuccess) onSuccess(result);
        } catch (error) {
            // do nothing
            if (onFail) onFail(error);
        }
    })();
}

export default {
    sendException,
};
