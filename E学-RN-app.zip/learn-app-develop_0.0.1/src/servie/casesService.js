/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-17 09:03:48
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';
import { web } from 'react-native-communications';
// import { IdentifyExtension } from '../../redux';
import { IdentifyExtension } from '../redux';

/**
 * 获取案例列表
 * @param {number} pageTo 页码
 * @param {number} pageSize 每页数量
 * @param {boolean} recommend 是否推荐
 * @return {Promise}
 */
function getCasesList(pageTo, pageSize, orderBy, orderByType, dictionaryCode, categoryId, recommend = false) {
    const param = {
        page: pageTo,
        pageSize: pageSize,
        // clientType: 'web',
        bizTypes: 'case',
        orderBy: orderBy,
        orderByType: orderByType,
        caseType: dictionaryCode,
        publishStatus: 1,
        categoryId: categoryId,
        criteria: { recommend: recommend ? 1 : null },
        plateCode: SeaUserUtil.getChosenPlateCode(),
    };
    const fetchApi = dataApi.getUrl(dataApi.common.postCasesList);
    // debugger
    return SeaHttpApi.postHttpApi(fetchApi, param);
}
/**
 * @description: 查询案例列表
 * @param {type} 
 * @return {type} 
 */
function queryCaseList(obj) {
    const api = dataApi.getUrl(dataApi.cases.queryCaseList);
    return SeaHttpApi.postHttpApi(api, obj)
}

/**
 * 获取专题详细信息
 * @param {string} resourceId 专题id
 */
function getSubjectDetail(resourceId) {
    const api = dataApi.getUrl(dataApi.common.getSubjectInfo, { id: resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 点赞
 * @param {string} resourceId 
 * @param {} giveLike 
 */
function giveLikeCase(resourceId, giveLike) {
    const param = {
        caseId: resourceId,
        userId: IdentifyExtension.getLoginUserInfo().id,
        giveLike: giveLike
    }
    const fetchApi = dataApi.getUrl(dataApi.cases.giveLikeCease);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * 所有分类
 */
function getAllSort() {
    const api = dataApi.getUrl(dataApi.cases.getAllSort);
    return SeaHttpApi.getHttpApi(api)
}

export default {
    getCasesList,
    getSubjectDetail,
    giveLikeCase,
    getAllSort,
    queryCaseList,
}