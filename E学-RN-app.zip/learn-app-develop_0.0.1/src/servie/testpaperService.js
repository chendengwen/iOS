/**
 * @author zk
 * @date 2017/7/26.
 * @description testpaperService 考试api
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaUserUtil } from '../util';
import { SeaConstant } from '../asserts';

/**
 * @description 根据考试项获取试卷列表
 * @param {string} [resourceId] - 考试项
 * @return {Promise}
 */
function getPapersByResourceId(resourceId) {
    const api = dataApi.getUrl(dataApi.testPaper.getList, { resourceId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取所有的试卷列表
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getTestPaperList(categoryId, pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.testPaper.postTestPaperList);
    const data = {
        criteria: { categoryId,
            plateCode: SeaUserUtil.getChosenPlateCode(),
            businessType: SeaConstant.ResourceType.EXAM, },
        pageNum: pageNum,
        pageSize: pageSize,
    };
    return SeaHttpApi.postHttpApi(api, data);
}

/**
 * @description 获取试卷详细内容
 * @param {string} [id] - 试卷id
 * @return {Promise}
 */
function getPaperBaseInfo(id) {
    const api = dataApi.getUrl(dataApi.testPaper.getSummary, { id });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 开始考试
 * @param {string} [id] - 试卷id
 * @param {string} [resourceId] - 试卷项目id
 */
function startPaperTestPromise(id, resourceId) {
    const api = dataApi.getUrl(dataApi.testPaper.postStart, { id, resourceId });
    return SeaHttpApi.postHttpApi(api);
}

/**
 * 手动提交答卷
 * @param {string} resourceId 考试项id
 * @param {string} id 由开始考试api返回 考试结果id
 * @param {object} data 答题数据
 */
function submitPaperTestManual(resourceId, id, data) {
    const api = dataApi.getUrl(dataApi.testPaper.putManualSubmit, { resourceId, id });
    return SeaHttpApi.putHttpApi(api, data);
}

/**
 * 自动提交答卷
 * @param {string} resourceId 考试项id
 * @param {string} id 由开始考试api返回 考试结果id
 * @param {object} data 答题数据
 */
function submitPaperTestAuto(resourceId, id, data) {
    const api = dataApi.getUrl(dataApi.testPaper.putAutoSubmit, { resourceId, id });
    return SeaHttpApi.putHttpApi(api, data);
}

/**
 * @description 回顾答案
 * @param {string} id 考试结果id
 */
function reviewTestResult(id) {
    const api = dataApi.getUrl(dataApi.testPaper.getTestResultReview, { id });
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 加入待考
 * @param {type} 
 * @return {type} 
 */
function addtoPlan(resourceId){
   const api = dataApi.getUrl(dataApi.testPaper.addtoPlan);
   return SeaHttpApi.postHttpApi(api,{resourceId:resourceId})
}

export default {
    getPapersByResourceId,
    getPaperBaseInfo,
    startPaperTestPromise,
    // modify by xukj - 1.32.0
    submitPaperTestManual,
    submitPaperTestAuto,
    reviewTestResult,
    // add by xukj - 1.34.0
    getTestPaperList,
    addtoPlan,
};
