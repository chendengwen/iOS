/**
 * @author xukj
 * @date 2019/04/11
 * @description 通用api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 上传文件
 * @param {*} [file] 文件对象必须要具备 uri, name, type 3个值
 * @return {Promise}
 */
function uploadFileToServer(file) {
    const api = dataApi.getResourceUrl(dataApi.file.upload);
    let formData = new FormData();
    formData.append('files', file);
    return SeaHttpApi.formHttpApi(api, formData);
}

/**
 * 获取文件的图片ids
 * @param {string} fileId 文件id
 * @return {Promise}
 */
function getImageIds(fileid) {
    const api = dataApi.getUrl(dataApi.resource.getImageIds, { fileid });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取文件的图片ids
 * @param {string} fileId 文件id
 * @return {Promise}
 */
function getPdfImageIds(fileid) {
    const api = dataApi.getUrl(dataApi.resource.getPdfImageIds,  { fileid });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 上报数据
 * @param {object} value 上报数据
 * @return {Promise}
 */
function reportData(value) {
    const api = dataApi.getUrl(dataApi.common.postUploadData);
    return SeaHttpApi.postHttpApi(api, value);
}

/**
 * 获取当前用户的别名
 * @return {Promise}
 */
function getPersonalAlias() {
    const api = dataApi.getUrl(dataApi.common.getPersonalAlias);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 个人时光机地址
 * @param {string} alias 别名
 * @return {string}
 */
function getTimeMachineUrl(alias) {
    // // TOFIX
    // return 'http://192.168.3.159:7002/h5/time-machine/' + alias;
    const api = dataApi.getH5Url(dataApi.h5.getTimeMachine, { user: alias });
    return api;
}

/**
 * 提交反馈
 * @param {string} content 内容
 * @param {string} type 分类
 * @param {array} fileIds 附件ids
 * @return {Promise}
 */
function addFeedback(content, type, fileIds) {
    const api = dataApi.getUrl(dataApi.common.postFeedbackInfo);
    return SeaHttpApi.postHttpApi(api, { content, type, fileIds });
}

/**
 * 获取意见反馈列表
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @return {Promise}
 */
function getFeedbackList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.common.postFeedbackList);
    const data = { pageNum, pageSize };
    return SeaHttpApi.postHttpApi(api, data);
}

/**
 * 获取反馈详情
 * @param {string} id 反馈id
 * @return {Promise}
 */
function getFeedbackDetail(id) {
    const api = dataApi.getUrl(dataApi.common.getFeedbackInfo, { id });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取中转页分享链接
 * @return {string}
 */
function getShareAppDiscoverUrl(value) {
    let api = dataApi.getH5Url(dataApi.h5.getAppDiscover);
    if (!_.isEmpty(value)) {
        api = `${api}?qp=${value}`;
    }
    return api;
}

/**
 * 获取广告
 */
function getADList() {
    const api = dataApi.getUrl(dataApi.upgrade.getADList);
    return SeaHttpApi.getHttpApi(api);
}

export default {
    uploadFileToServer,
    getImageIds,
    getPdfImageIds,
    reportData,
    getPersonalAlias,
    getTimeMachineUrl,
    addFeedback,
    getFeedbackList,
    getFeedbackDetail,
    getShareAppDiscoverUrl,
    // add by xukj - 1.40.0
    getADList,
};
