/**
 * @author xukj
 * @date 2019/08/20
 * @description newsService 新闻api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 获取首页推荐新闻
 * @return {Promise}
 */
function getTopNews() {
    const api = dataApi.getUrl(dataApi.news.getTopNews);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 获取新闻列表
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getNewsList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.news.postListApp);
    const data = { pageNum, pageSize };
    return SeaHttpApi.postHttpApi(api, data);
}

/**
 * @description 获取新闻详情
 * @param {string} [newsId] - 新闻id
 * @return {Promise}
 */
function getNewsDetail(newsId) {
    const api = dataApi.getUrl(dataApi.news.getDetail, { id: newsId });
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getTopNews,
    getNewsList,
    getNewsDetail,
};
