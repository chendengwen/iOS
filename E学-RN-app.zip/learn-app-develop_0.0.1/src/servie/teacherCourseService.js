/**
 * @author xukj
 * @date 2019/08/21
 * @description courseService e课api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';


/**
 * @description 获取栏目列表
 * @return {Promise}
 */
function getColumns() {
    const api = dataApi.getUrl(dataApi.teacherCourse.getColumns);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 查询讲师列表
 * @param {number} [pageTo] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getTeachers(pageTo, pageSize) {
    const param = {
        pageNum: pageTo,
        pageSize: pageSize,
        criteria: {
            queryStatus:'1',
            type:'0'
        },
    };
    const fetchApi = dataApi.getUrl(dataApi.teacherCourse.getTeachers);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * @description 获取讲师详情
 * @return {Promise}
 */
function getTeacherDetail(id) {
    const api = dataApi.getUrl(dataApi.teacherCourse.getTeacherDetail);
    return SeaHttpApi.postHttpApi(api,[id]);
}

/**
 * @description 获取栏目详情
 * @return {Promise}
 */
function getColumnDetail(id) {
    const api = dataApi.getUrl(dataApi.teacherCourse.getColumnDetail,{id:id});
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getColumns,
    getTeachers,
    getTeacherDetail,
    getColumnDetail
};
