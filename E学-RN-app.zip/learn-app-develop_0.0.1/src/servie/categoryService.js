/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-09-04 16:53:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-16 09:02:24
 */

/**
 * @author xukj
 * @date 2019/08/20
 * @description categoryService 分类api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 获取分类list
 * @param {string} [type] 分类id  1：E课 2：培训管理 3：考试 4：阅读 5：新闻 6：预开课 7：问卷 8：讲师 9：案例 10：专题 11：意见反馈 12：学吧
 * @return {Promise}
 */
function getCategories(type) {
    const api = dataApi.getUrl(dataApi.common.getCatgories, {type});
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 根据板块获取分类
 * @param {type} 
 * @return {type} 
 */
function getCatgoriesByPlatCode(obj) {
    const api = dataApi.getUrl(dataApi.common.getCatgoriesByPlatCode+'?plateCode='+obj.plateCode+'&type='+obj.type);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description: 获取板块列表
 * @param {type} 
 * @return {type} 
 */
function getDeptCode(){
    const api = dataApi.getUrl(dataApi.common.getDeptCode);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 根据分类和类型，分页查询资源
 * @param {string} [category] 分类id
 * @param {number} [resourceType] 类型
 * @param {boolean} [isLoadAll] 是否查询全部
 * @param {number} [pageTo] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getResourceList(category, resourceType, isLoadAll, pageTo, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.resource.postCategory);
    const param = {
        criteria: {
            category: category,
            resourceTypes: JSON.stringify([resourceType]),
            isLoadAll: isLoadAll,
        },
        pageNum: pageTo,
        pageSize: pageSize,
    };
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

export default {
    getCategories,
    // modify by xukj - 1.35.0
    getResourceList,
    getCatgoriesByPlatCode,
    getDeptCode,
};
