/**
 * @author xukj
 * @date 2018/8/17
 * @description 人员相关api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 获取人员列表
 * @param {string} [resourceId] 资源id
 * @param {string} [nameOrCode] 姓名或编号
 * @return {Promise}
 */
function getUserList(resourceId, nameOrCode = '') {
    const api = dataApi.getUrl(dataApi.recommendpersonal.getRecommendUserList);
    return SeaHttpApi.postHttpApi(api, {
        resourceId,
        recommendNameOrCode: nameOrCode,
    });
}

/**
 * 获取多个教师的详细信息
 * @param {array} teacherIds 教师ids
 * @return {Promise}
 */
function getTeacherDetails(teacherIds) {
    const api = dataApi.getUrl(dataApi.teacher.postTeacherDetails);
    return SeaHttpApi.postHttpApi(api, teacherIds);
}

/**
 * 获取班主任详情
 * @param {string} teacherId 班主任id
 * @return {Promise}
 */
function getMasterTeacherDetail(teacherId) {
    const api = dataApi.getUrl(dataApi.teacher.getMasterTeacherDetail, { id: teacherId });
    return SeaHttpApi.getHttpApi(api);
}

export default {
    getUserList,
    getTeacherDetails,
    getMasterTeacherDetail,
};
