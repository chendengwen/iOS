/**
 * @author xukj
 * @date 2019/08/21
 * @description bookService 阅读api
 */
import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 获取书籍列表
 * @param {string} [categoryId] 默认all
 * @param {number} [pageNum] 页码
 * @param {number} [pageSize] 每页数量
 * @return {Promise}
 */
function getAllBookList(categoryId = 'all', pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.reader.postList);
    return SeaHttpApi.postHttpApi(fetchApi, {
        pageNum,
        pageSize,
        category: categoryId,
    });
}

/**
 * @description 根据resourceId，查询book资源的详细信息
 * @param {string} [resourceId] - book的资源id
 * @return {Promise}
 */
function getBookDetail(resourceId) {
    const fetchApi = dataApi.getUrl(dataApi.reader.getDetail, { resourceId });
    return SeaHttpApi.getHttpApi(fetchApi);
}

export default {
    getBookDetail,
    getAllBookList,
};
