import dataApi from '../config/api';
import { SeaHttpApi } from '../util';
import { IdentifyExtension } from '../redux';
import { SeaUserUtil } from '../util';

/**
 * @description 获取个人信息
 * @return {Promise}
 */
function getMyInfo() {
    const fetchApi = dataApi.getUrl(dataApi.myInfo.getMyInfo);
    return SeaHttpApi.getHttpApi(fetchApi);
}

/**
 * @description 获取阅读历史
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getUserReadHistory(pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.personal.postReadRecordPage);
    return SeaHttpApi.postHttpApi(fetchApi, { pageNum, pageSize });
}

/**
 * @description 获取用户的E课学习历史
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getUserCourseHistory(pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.personal.postPagePlayList);
    return SeaHttpApi.postHttpApi(fetchApi, { pageNum, pageSize });
}

/**
 * @description 删除E课学习记录
 * @param {string} [id] 资源id(目前仅支持E课、面授和阅读)
 * @return {Promise}
 */
function deleteUserResourceHistory(id) {
    const fetchApi = dataApi.getUrl(dataApi.personal.deletePlayList, { id });
    return SeaHttpApi.deleteHttpApi(fetchApi);
}

/**
 * @description 获取用户的面授记录
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getUserTrainingHistory(pageNum, pageSize) {
    const fetchApi = dataApi.getUrl(dataApi.personal.postTrainingPage);
    return SeaHttpApi.postHttpApi(fetchApi, { pageNum, pageSize });
}

/**
 * @description 更新用户数据
 * @param {*} [data] - 需要更新的数据
 * @return {Promise}
 */
function updateUserInfo(data = {}) {
    const api = dataApi.getUrl(dataApi.user.putModifyUserInfo);
    return SeaHttpApi.putHttpApi(api, data);
}

/**
 * @description 获取消息信息
 * @param {number} [pageNum] - 页码
 * @param {number} [pageSize] - 每页数量
 * @return {Promise}
 */
function getNoticeMessage(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.noticePage.postNoticePage);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * @description 获取最新的消息数量
 * @param {number} [lastTime] 时间戳
 * @return {Promise}
 */
function getLatestNoticeMessage(lastTime = 0) {
    const api = dataApi.getUrl(dataApi.newnotices.postNewNotices);
    return SeaHttpApi.postHttpApi(api, { lastTime }).then((result) => {
        let count = 0;
        if (result && result.length > 0) count = result[0];
        return Promise.resolve(count);
    });
}

/**
 * @description 获取贡献值
 * @return {Promise}
 */
function getContributionSum() {
    const api = dataApi.getUrl(dataApi.contribution.getSum);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description 获取贡献值list
 * @param {number} [pageNum] 页码
 * @param {number} [pageSize] 每页数量
 * @return {Promise}
 */
function getContributionDetailList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.contribution.postPageList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}
/**
 * @description 我的推荐list
 * @param {number} [pageNum] 页码
 * @param {number} [pageSize] 每页数量
 * @return {Promise}
 */
function getMyRecommendlList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.recommendpersonal.postMyRecommend);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}
/**
 * @description 收到的推荐list
 * @param {number} [pageNum] 页码
 * @param {number} [pageSize] 每页数量
 * @return {Promise}
 */
function getReceivedRecommendList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.recommendpersonal.postReceivedRecommend);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * @description 我的学时统计list
 * @param {number} [year] 年
 * @param {number} [pageNum] 页码
 * @param {number} [pageSize] 每页数量
 * @return {Promise}
 */
function getMyStudyPeriodList(year, pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.personal.postPeriod);
    const data = {
        criteria: { queryYear: year },
        pageNum,
        pageSize,
    };
    return SeaHttpApi.postHttpApi(api, data);
}

/**
 * @description 获取我的学时统计详情
 * @param {string} [resourceId] 对应的id
 * @param {number} [year] 年
 * @return {Promise}
 */
function getMyStudyPeriodDetail(resourceId, year) {
    const api = dataApi.getUrl(dataApi.personal.getPeriodDetail, { resourceId, year });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取我的已考记录
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @reutrn {Promise}
 */
function getMyExamHistoryList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.user.postTestedList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * 获取我的职业班列表
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getMyCareerList(pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.user.postCareerList);
    return SeaHttpApi.postHttpApi(api, { pageNum, pageSize });
}

/**
 * 获取我的职业班详情
 * @param {string} id 职业班id
 */
function getMyCareerDetail(id) {
    const api = dataApi.getUrl(dataApi.user.getCareerDetail, { id });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * manage部分获取验证码
 * @param {string} phone 手机号
 * @return {Promise}
 */
function manageSendCode(phone) {
    const api = dataApi.getUrl(dataApi.account.manageSendCode);
    return SeaHttpApi.postHttpApi(api, { newPhone: phone });
}

/**
 * manage部分修改手机号
 * @param {string} phone 手机号
 * @param {string} code 验证码
 * @param {string} password 密码
 * @return {Promise}
 */
function manageModifyPhone(phone, code, password) {
    const api = dataApi.getUrl(dataApi.account.manageModifyPhone);
    return SeaHttpApi.postHttpApi(api, { newPhone: phone, code, password });
}

/**
 * 获取(案例管理)审核列表
 * @param {string} empId 员工ID
 * @param {string} applyStatus 申请状态 0:草稿,1:待审批,2:审批中,3:已完成
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getMyCaseApprovalList(applyStatus, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getCaseApprovalList) +
        '?empId=' +
        IdentifyExtension.getLoginUserInfo().id +
        '&applyStatus=' +
        applyStatus +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取(案例管理)已审核详情页信息和基本信息
 * @param {string} caseId 案例ID
 */
function getCaseDetailInfo(caseId) {
    const api = dataApi.getUrl(dataApi.caseManagement.getCaseDetailInfo) + '?caseId=' + caseId;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 案例审批
 * @param {string} applyStatus 审批评语
 * @param {string} auditInfo 审批评语
 * @param {string} auditStatus 审批意见(状态)：-1：提交申请,0:审核人未操作，1：同意,2:不同意,3:发起会签;4:发起或签
 * @param {string} backNodeId 退回节点信息,退回到申请人或者前一节点,部门领导返回1（申请人），宝能大学返回节点为1（申请人）或者2（部门领导审批）
 * @param {string} flowApplyId 流程申请id
 * @param {Array} extraUserIds 会签者或者或签者
 */
function updateCaseAudit(
    applyStatus,
    auditInfo,
    auditStatus,
    backNodeId,
    flowApplyId,
    extraUserIds
) {
    const param = {
        auditEmpId: IdentifyExtension.getLoginUserInfo().id,
        auditInfo: auditInfo,
        auditStatus: auditStatus,
        backNodeId: backNodeId,
        flowApplyId: flowApplyId,
        loginEmp: IdentifyExtension.getLoginUserInfo().id,
        applyStatus: applyStatus, //当前审批状态 0:草稿,1:待审批,2:审批中,3:已完成
        extraUserIds: extraUserIds,
    };
    const fetchApi = dataApi.getUrl(dataApi.caseManagement.updateCaseAudit);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * 获取(案例管理-个人提交记录)列表
 * @param {string} applyStatus 申请状态 0:草稿,1:待审批,2:审批中,3:已完成
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getMyCaseRecordsList(applyStatus, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getRecordsList) +
        '?empId=' +
        IdentifyExtension.getLoginUserInfo().id +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 保存案例草稿信息
 * @param {*} obj
 */
function saveCaseInfo(obj) {
    const api = dataApi.getUrl(dataApi.caseManagement.saveCaseInfo);
    return SeaHttpApi.putHttpApi(api, obj);
}

/**
 * 提交案例信息
 * @param {*} obj
 */
function submitCaseInfo(obj) {
    const api = dataApi.getUrl(dataApi.caseManagement.submitCaseInfo);
    return SeaHttpApi.putHttpApi(api, obj);
}

/**
 * 提交案例个人记录时，获取审批人信息
 * @param {string} userId
 */
function getCaseApproverByUserId(userId) {
    const api = dataApi.getUrl(dataApi.caseManagement.getApproverByUserId) + '?userId=' + userId;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 提交案例个人记录时，更新审批人信息
 * @param {string} caseId
 * @param {string} approvelUser
 * @param {string} applyUser
 */
function updateCaseApprover(caseId, approvelUser, applyUser) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.updateApprover) +
        '?caseId=' +
        caseId +
        '&approvelUser=' +
        approvelUser +
        '&applyUser=' +
        applyUser;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 撤回案例
 * @param {string} caseId
 */
function recallCase(caseId) {
    const api = dataApi.getUrl(dataApi.caseManagement.recallCase);
    return SeaHttpApi.postHttpApi(api, {
        caseId: caseId,
        userId: IdentifyExtension.getLoginUserInfo().id,
    });
}

/**
 * 根据业务id和业务类型获取流程详细记录
 * @param {string} businessId 业务id
 * @param {string} businessType 业务类型：2-案例，1-讲师
 */
function queryFlowAuditByBidAndType(businessId, businessType) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.queryFlowAuditByBidAndType) +
        '?businessId=' +
        businessId +
        '&businessType=' +
        businessType;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * (讲师管理)获取审批列表(不区分部门和宝能大学)
 * @param {string} applyStatus 申请状态 1:待审批,2:审批中,3:已完成
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getLecturerApprovalList(applyStatus, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.lecturerManagement.getApprovalList) +
        '?empId=' +
        IdentifyExtension.getLoginUserInfo().id +
        '&applyStatus=' +
        applyStatus +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * (讲师管理)获取个人提交记录
 * @param {string} applyStatus 申请状态 0:草稿,1:待审批,2:审批中,3:已完成
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getLecturerRecordsList(applyStatus, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.lecturerManagement.getRecordsList) +
        '?empId=' +
        IdentifyExtension.getLoginUserInfo().id +
        '&applyStatus=' +
        applyStatus +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * @description (讲师管理)根据申请ID获取记录详情
 * @param {string} [lecturerApplyId] 申请ID
 * @return {Promise}
 */
function getLecturerDetailInfo(lecturerApplyId) {
    const api = dataApi.getUrl(dataApi.lecturerManagement.getApprovalDetailInfo, {
        lecturerApplyId,
    });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 讲师审批
 * @param {string} applyStatus 审批评语
 * @param {string} auditInfo 审批评语
 * @param {string} auditStatus 审批意见(状态)：-1：提交申请,0:审核人未操作，1：同意,2:不同意,3:发起会签;4:发起或签
 * @param {string} backNodeId 退回节点信息,退回到申请人或者前一节点,部门领导返回1（申请人），宝能大学返回节点为1（申请人）或者2（部门领导审批）
 * @param {string} lecturerApplyId 讲师历史申请ID
 * @param {Array} extraUserIds 会签者或者或签者
 */
function updateLecturerAudit(
    applyStatus,
    auditInfo,
    auditStatus,
    backNodeId,
    lecturerApplyId,
    extraUserIds
) {
    const param = {
        auditEmpId: IdentifyExtension.getLoginUserInfo().id,
        auditInfo: auditInfo,
        auditStatus: auditStatus,
        backNodeId: backNodeId,
        lecturerApplyId: lecturerApplyId,
        loginEmp: IdentifyExtension.getLoginUserInfo().id,
        applyStatus: applyStatus, //当前审批状态 0:草稿,1:待审批,2:审批中,3:已完成
        extraUserIds: extraUserIds,
    };
    const fetchApi = dataApi.getUrl(dataApi.lecturerManagement.updateLecturerAudit);
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * 提交讲师信息
 * @param {string} empId 申请的讲师对应的id[实际对应的是用户的id]
 * @param {string} userId
 * @param {string} applyReason 申请理由
 * @param {string} applyStatus 认证申请状态:0:草稿，1:提交
 * @param {string} applyTeachLevel 拟申请讲师级别：1,初级讲师，2：中级讲师,3:高级讲师,4:资深讲师
 * @param {string} auditEmpId 提交的审批人EMPID
 * @param {string} createEmp
 * @param {string} goodAtTeach 擅长授课方向
 * @param {string} insideStatus 是否内部讲师,0:否,1:是，默认传1
 * @param {string} loginEmpId 创建人[登录的用户emp_id]
 * @param {string} mainCourse 主讲课程
 * @param {string} personalIntroduce 讲师个人介绍
 * @param {string} teacherLevel 当前讲师级别：1,初级讲师，2：中级讲师,3:高级讲师,4:资深讲师
 * @param {string} lecturerApplyId 讲师申请记录ID
 *
 */
function submitLecturerInfo(obj) {
    const api = dataApi.getUrl(dataApi.lecturerManagement.submitLecturerInfo);
    return SeaHttpApi.postHttpApi(api, obj);
}

/**
 * 更新讲师申请信息(删除或撤回)
 * @param {string} lecturerApplyId 记录ID
 * @param {int} type 类型：1：删除，2：撤回
 */
function updateLecturerApplyStatus(lecturerApplyId, type) {
    const api = dataApi.getUrl(dataApi.lecturerManagement.updateApplyStatus, {
        lecturerApplyId,
        type,
    });
    return SeaHttpApi.postHttpApi(api);
}

/**
 * 根据姓名搜索用户
 * @param {string} userName 用户姓名
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getUserListByName(userName, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getUserListByName) +
        '?userName=' +
        userName +
        '&pageNum=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取个人提交记录列表（新）
 * @param {string} bussType 发布类型(业务类型) 1:E课、2:面授、3:考试、4:阅读、5:新闻、6:预开课、7:问卷、8:讲师、9:案例
 * @param {string} state 申请状态 0:待提交,1:待审批,2:审批中,3:已完成（不传返回全部）
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getUserRecordsList(bussType, state, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getUserRecordsList) +
        '?bussType=' +
        bussType +
        '&state=' +
        state +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取我的审批列表（新）
 * @param {string} bussType 发布类型(业务类型) 1:E课、2:面授、3:考试、4:阅读、5:新闻、6:预开课、7:问卷、8:讲师、9:案例
 * @param {string} approveCategory 审批分类编码 1-待审批;2-已审批
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 */
function getUserApprovalList(bussType, approveCategory, pageNum, pageSize) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getUserApprovalList) +
        '?bussType=' +
        bussType +
        '&approveCategory=' +
        approveCategory +
        '&pageNo=' +
        pageNum +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取审批流详情（新）
 * @param {string} bussSerialNo 业务流水号（关联业务资源）
 * @param {string} flowSerialNo 工作流申请号（审批流程唯一编码）
 */
function getFlowDetailList(bussSerialNo, flowSerialNo) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getFlowDetailList) +
        '?bussSerialNo=' +
        bussSerialNo +
        '&flowSerialNo=' +
        flowSerialNo;
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 提交审批意见（新）
 * @param {string} definitionCode 审批链编码，从获取我的审批获取
 * @param {string} bussSerialNo 业务流水号（关联业务资源）
 * @param {string} flowSerialNo 工作流申请号（审批流程唯一编码）
 * @param {string} approveOpinion 审批意见 1:同意,2:不同意,3:发起会签;4:发起或签
 * @param {string} approveComment 审批评语
 * @param {string} rejectTo 驳回位置 1:申请人,2:第一审批人
 * @param {string} extraHandledBy 会签者或者或签者用户ID，审批意见取值3,4时,此字段需要传入至少一个元素
 */
function submitApproval(obj) {
    const api = dataApi.getUrl(dataApi.caseManagement.submitApproval);
    //!obj.approveComment || obj.approveComment == '' ? obj.approveComment = '同意' : obj.approveComment;
    return SeaHttpApi.postHttpApi(api, obj);
}

/**
 *根据用户ID个人荣誉
 *
 * @param {*} userId
 * @returns
 */
function getHonorById(userId) {
    const api = dataApi.getUrl(dataApi.honorRoll.getHonorById, { userId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 获取前5的热门课程
 *
 * @returns
 */
function getHotCourse() {
    const api = dataApi.getUrl(dataApi.honorRoll.getHotCourse);
    return SeaHttpApi.getHttpApi(api);
}

/**
 *根据用户ID个人获取所发布资源的评论
 * @param {*} userId
 * @returns
 */
function getEvaluateByUserId(userId) {
    const api = dataApi.getUrl(dataApi.honorRoll.getEvaluateByUserId, { userId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 *根据用户ID个人获取所发布资源的点赞
 * @param {*} userId
 * @returns
 */
function getLikeByUserId(userId) {
    const api = dataApi.getUrl(dataApi.honorRoll.getLikeByUserId, { userId });
    return SeaHttpApi.getHttpApi(api);
}

/**
 *课程记录分页查询
 *
 * @param {*} userId
 * @param {*} pageTo
 * @param {*} pageSize
 * @returns
 */
function queryByPageCourse(userId, pageTo, pageSize) {
    const api = dataApi.getUrl(
        dataApi.honorRoll.queryByPageCourse + userId + '?pageNo=' + pageTo + '&pageSize=' + pageSize
    );
    return SeaHttpApi.postHttpApi(api);
}

/**
 *授课记录分页查询
 *
 * @param {*} userId
 * @param {*} pageTo
 * @param {*} pageSize
 * @returns
 */
function queryByPageTrainingClass(userId, pageTo, pageSize) {
    const api = dataApi.getUrl(
        dataApi.honorRoll.queryByPageTrainingClass +
        userId +
        '?pageNo=' +
        pageTo +
        '&pageSize=' +
        pageSize
    );
    return SeaHttpApi.postHttpApi(api);
}
/**
 *获取用户证书列表
 * @param {*} userId
 * @returns
 */
function userCertificate(userId) {
    const api = dataApi.getUrl(dataApi.honorRoll.userCertificate + '?uid=' + userId);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 我的订阅
 * @param {type}
 * @return {type}
 */
function mySubscribe(type, pageTo, pageSize) {
    const param = {
        pageNum: pageTo,
        pageSize: pageTo,
        criteria: { type: type },
    };
    const api = dataApi.getUrl(dataApi.honorRoll.mySubscribe);
    return SeaHttpApi.postHttpApi(api, param);
}
/**
 * @description: 获取资源档案
 * @param {type}
 * @return {type}
 */
function queryResourceById(resourceId) {
    const param = {
        businessId: resourceId,
        userId: IdentifyExtension.getLoginUserInfo().id,
    };
    const api = dataApi.getUrl(dataApi.honorRoll.queryResourceById);
    return SeaHttpApi.postHttpApi(api, param);
}

/**
 * 获取敏感词列表
 */
function getSensitiveWordsList() {
    const api = dataApi.getUrl(dataApi.caseManagement.getSensitiveWordsList);
    return SeaHttpApi.getHttpApi(api);
}

/**统计学时
 * @description:
 * @param {type}
 * @return {type}
 */
function getMyStudyPeriodListByMonth(year, month, pageNum, pageSize) {
    const api = dataApi.getUrl(dataApi.personal.postPeriod);
    const data = {
        criteria: { queryYear: year, queryMonth: month },
        pageNum,
        pageSize,
    };
    return SeaHttpApi.postHttpApi(api, data);
}

/**
 * 获取敏感词列表
 */
function getLoginUserInfo() {
    const api = dataApi.getUrl(dataApi.common.getLoginUserInfo);
    return SeaHttpApi.getHttpApi(api);
}

/**
 * 评论审批获取记录
 * @param {string} businessType 业务类型( 1:E课、2:面授、3:考试、4:阅读、5:新闻、6:预开课、7:问卷 8:讲师 9：案例)
 * @param {string} plateCode 所属板块 所属板块筛选菜单仅开放给超级管理员可用；板块管理员无该筛选菜单
 * @param {string} status 审核状态 0:未审核 1:审核通过 2:审核不通过
 * @param {string} pageNo 
 * @param {string} pageSize 
 */
function getCommentApproveList(businessType, pageNo, pageSize) {
    const api = dataApi.getUrl(dataApi.comment.getCommentApproveList);
    const param = {
        businessType: businessType,
        plateCode: IdentifyExtension.getLoginUserInfo().chosenPlateCode,
        status: 0,
        pageNo,
        pageSize
    }
    return SeaHttpApi.postHttpApi(api, param);
}

/**
 * 评论审批操作
 * @param {Array} evaluateIdList 评论ID集合
 * @param {string} status   审核状态 1:审核通过 2:审核不通过
 */
function commitCommentApproval(evaluateIdList, status) {
    const api = dataApi.getUrl(dataApi.comment.commitApproval);
    return SeaHttpApi.postHttpApi(api, { evaluateIdList, status });
}
/**
 * @description: 我的收藏
 * @param {type} 
 * @return {type} 
 */
function getMyCollection(pageNo, pageSize) {
    const api = dataApi.getUrl(dataApi.personal.getMyCollection + '?pageNo=' + pageNo + '&pageSize=' + pageSize);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 系统消息审批详情
 * @param {type} 
 * @return {type} 
 */
function getMessageApprovalDetail(messageId) {
    const api = dataApi.getUrl(dataApi.messageCenter.getMessageApprovalDetail + '/' + messageId);
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 保存/更新/发布消息
 * @param {type} 
 * @return {type} 
 */
function saveOrUpdate(obj) {
    const api = dataApi.getUrl(dataApi.messageCenter.saveOrUpdate);
    return SeaHttpApi.postHttpApi(api, obj)
}
/**
 * @description: 撤回消息审批
 * @param {type} 
 * @return {type} 
 */
function recallMessage(id) {
    const api = dataApi.getUrl(dataApi.messageCenter.recallMessage + '?id=' + id);
    return SeaHttpApi.putHttpApi(api)
}
/**
 * @description: 获取个人提交记录
 * @param {type} 
 * @return {type} 
 */
function getMessageRecordsList(state, pageNo, pageSize) {
    const api =
        dataApi.getUrl(dataApi.messageCenter.getMessageRecordsList) +
        '?state=' +
        state +
        '&pageNo=' +
        pageNo +
        '&pageSize=' +
        pageSize;
    return SeaHttpApi.getHttpApi(api);
}
/**
 * @description: 审批校验
 * @param {type} 
 * @return {type} 
 */
function checkApproval(messageId) {
    const api = dataApi.getUrl(dataApi.messageCenter.checkApproval + '?id=' + messageId);
    return SeaHttpApi.getHttpApi(api)
}

/**
 * 获取驳回选项列表
 * @param {string} flowSerialNo 工作流申请号（审批流程唯一编码）
 */
function getRejectOptionsList(flowSerialNo) {
    const api =
        dataApi.getUrl(dataApi.caseManagement.getRejectOptionsList) +
        '?flowSerialNo=' +
        flowSerialNo;
    return SeaHttpApi.getHttpApi(api);
}

export default {
    // 已重构
    // getUserCdourseHistory,
    deleteUserResourceHistory,
    getUserTrainingHistory,
    getUserReadHistory,
    getUserCourseHistory,
    updateUserInfo,
    getNoticeMessage,
    getLatestNoticeMessage,
    getContributionSum,
    getContributionDetailList,
    getReceivedRecommendList,
    getMyRecommendlList,
    getMyStudyPeriodList,
    getMyStudyPeriodDetail,
    getMyExamHistoryList,
    getMyCareerList,
    getMyCareerDetail,
    getMyInfo,
    // add by xukj - 1.36.0
    manageSendCode,
    manageModifyPhone,
    getMyCaseApprovalList,
    getCaseDetailInfo,
    updateCaseAudit,
    getMyCaseRecordsList,
    saveCaseInfo,
    submitCaseInfo,
    getLecturerApprovalList,
    getLecturerDetailInfo,
    queryFlowAuditByBidAndType,
    recallCase,
    updateLecturerAudit,
    getUserListByName,
    getLecturerRecordsList,
    getUserRecordsList,
    getUserApprovalList,
    getFlowDetailList,
    submitApproval,
    getHonorById,
    getHotCourse,
    getEvaluateByUserId,
    getLikeByUserId,
    updateCaseApprover,
    submitLecturerInfo,
    getCaseApproverByUserId,
    updateLecturerApplyStatus,
    queryByPageCourse,
    queryByPageTrainingClass,
    userCertificate,
    mySubscribe,
    queryResourceById,
    getSensitiveWordsList,
    getMyStudyPeriodListByMonth,
    getLoginUserInfo,
    getCommentApproveList,
    commitCommentApproval,
    getMyCollection,
    getMessageApprovalDetail,
    saveOrUpdate,
    recallMessage,
    getMessageRecordsList,
    getRejectOptionsList,
    checkApproval,
};
