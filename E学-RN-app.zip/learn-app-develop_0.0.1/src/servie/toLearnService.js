import dataApi from '../config/api';
import { SeaHttpApi } from '../util';

/**
 * @description 加入计划
 * @param {string} resourceId - 资源id
 * @param {string} classId - 期次id
 * @param {boolean} hasAddStudyPlan - 试读
 * @return {Promise}
 */
function addToLearn(resourceId, classId, hasAddStudyPlan) {
    const fetchApi = dataApi.getUrl(dataApi.assignment.postAssignment);
    let param = {};
    if (resourceId) param['resourceId'] = resourceId;
    if (classId) param['classId'] = classId;
    if (hasAddStudyPlan) param['required'] = '4';
    return SeaHttpApi.postHttpApi(fetchApi, param);
}

/**
 * @description 获取计划列表
 * @param {number} [pageNum]
 * @param {number} [pageSize]
 * @param {number} [type] 资源类型
 * @return {Promise}
 */
function getToLearnResourceList(pageNum, pageSize, type) {
    const fetchApi = dataApi.getUrl(dataApi.assign.postAssignmentPage);
    const data = {
        pageNum: pageNum,
        pageSize: pageSize,
        criteria: {
            type: type,
        },
    };
    return SeaHttpApi.postHttpApi(fetchApi, data);
}

/**
 * 移除计划项
 * @param {string} resourceId 资源id
 */
function deleteToLearn(resourceId) {
    const fetchApi = dataApi.getUrl(dataApi.assign.deleteResource, { id: resourceId });
    return SeaHttpApi.deleteHttpApi(fetchApi);
}

/**
 * 面授取消报名
 * @param {string} id 面授id
 * @return {Promise}
 */
function cancelEnrol(id) {
    const api = dataApi.getUrl(dataApi.cancel.postEnrol, { id: id });
    return SeaHttpApi.postHttpApi(api);
}

/**
 * @description 获取计划刷新时间
 * @return {Promise}
 */
function getLatestPlan() {
    const fetchApi = dataApi.getUrl(dataApi.assign.getLatestPlan);
    return SeaHttpApi.getHttpApi(fetchApi);
}

export default {
    addToLearn,
    getToLearnResourceList,
    cancelEnrol,
    // add by xukj - 1.34.0
    deleteToLearn,
    getLatestPlan
};
