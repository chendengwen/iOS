/**
 * Created by zk on 2018/2/7.
 */
import dataApi from '../config/api';
import { SeaHttpApi, SeaDevice } from '../util';

/**
 * 系统信息
 */
const deviceInformation = {
    'mobile-type': SeaDevice.deviceBrand(),
    'mobile-version': SeaDevice.deviceModel(),
    'os-type': SeaDevice.deviceOS(),
    'os-version': SeaDevice.deviceOSVersion(),
    'app-version': SeaDevice.appVersion(),
};

/**
 * @description 发送验证码
 * @param {*} [param]
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function identifySendCode(param, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.identify.sendCode);
            const result = await SeaHttpApi.postHttpApi(api, param, {
                headers: SeaHttpApi.noTokenHeaders(),
            });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

/**
 * @description 手机验证码登录
 * @param {*} [data] 信息 {phone, orgId, code}
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function mobileIdentify(data, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.identify.mobileIdentify);
            const headers = {
                ...SeaHttpApi.noTokenHeaders(),
                ...deviceInformation,
            };
            const result = await SeaHttpApi.postHttpApi(api, data, { headers });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

/**
 * @description 用户名 + 密码 登录
 * @param {*} [data] 用户名 + 密码 {userName, pwd}
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function userNameIdentify(data, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.identify.userNameIdentify);
            const headers = {
                ...SeaHttpApi.noTokenHeaders(),
                ...deviceInformation,
            };
            const result = await SeaHttpApi.postHttpApi(api, data, { headers });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

/**
 * @description 发送激活验证码
 * @param {*} [params]
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function activeSendCode(params, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.active.sendCode);
            const result = await SeaHttpApi.postHttpApi(api, params, {
                headers: SeaHttpApi.noTokenHeaders(),
            });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

/**
 * @description 外勤激活并登录
 * @param {*} [data] 信息 {userId, pwd, code}
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function outActive(data, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.active.outer);
            const headers = {
                ...SeaHttpApi.noTokenHeaders(),
                ...deviceInformation,
            };
            const result = await SeaHttpApi.postHttpApi(api, data, { headers });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

/**
 * @description 域账号激活并登录
 * @param {*} [data] 信息 {userId, pwd, code} / {userId, phone, pwd, code}
 * @param {function} [onSuccess]
 * @param {function} [onFail]
 */
function domainActive(data, onSuccess, onFail) {
    (async () => {
        try {
            const api = dataApi.getUrl(dataApi.active.domain);
            const headers = {
                ...SeaHttpApi.noTokenHeaders(),
                ...deviceInformation,
            };
            const result = await SeaHttpApi.postHttpApi(api, data, { headers });
            onSuccess(result);
        } catch (error) {
            onFail(error);
        }
    })();
}

export default {
    // 已重构
    identifySendCode,
    mobileIdentify,
    userNameIdentify,
    activeSendCode,
    domainActive,
    outActive,
};
