/**
 * @author xukj
 * @date 2018/10/30
 * @description qaService 问吧api
 */
import { SeaHttpApi } from '../util';
import api from '../config/api.js';

/**
 * 获取问吧问题列表，支持分页
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @return {Promise}
 */
function getQAQuestionList(pageNum, pageSize) {
    const dataApi = api.getUrl(api.ask.postList);
    return SeaHttpApi.postHttpApi(dataApi, { pageNum, pageSize });
}

/**
 * 获取问吧问题回答列表，支持分页
 * @param {string} askid 问题id
 * @param {number} pageNum 页码
 * @param {number} pageSize 每页数量
 * @return {Promise}
 */
function getQAAnswerList(askid, pageNum, pageSize) {
    const dataApi = api.getUrl(api.ask.postReplyList, { askid });
    return SeaHttpApi.postHttpApi(dataApi, { askid, pageNum, pageSize });
}

/**
 * 获取问吧问题详情
 * @param {string} askid 问题id
 * @return {Promise}
 */
function getQAQuestionDetail(askid) {
    const dataApi = api.getUrl(api.ask.getDetail, { askid });
    return SeaHttpApi.getHttpApi(dataApi);
}

/**
 * 发布问吧问题
 * @param {string} title 问题主题
 * @param {string} content 问题内容
 * @param {string} category 分类id
 * @param {bool} anonymous 是否匿名
 * @return {Promise}
 */
function publishQAQuestion(title, content, category, anonymous) {
    const dataApi = api.getUrl(api.ask.postSave);
    return SeaHttpApi.postHttpApi(dataApi, {
        title,
        content,
        anonymous: anonymous ? '1' : '0',
        category,
    });
}

/**
 * 回答问吧问题
 * @param {string} askid 问题id
 * @param {string} content 回答内容
 * @param {bool} anonymous 是否匿名
 * @param {string} replyToId 回复的目标评论id(回复评论时使用)
 * @param {string} belongReplyId 所属的回答id(回复评论时使用)
 * @return {Promise}
 */
function answerQAQuestion(askid, content, anonymous, replyToId, belongReplyId) {
    const dataApi = api.getUrl(api.ask.postReplySave, { askid });
    return SeaHttpApi.postHttpApi(dataApi, {
        content,
        anonymous: anonymous ? '1' : '0',
        askid,
        replyToId,
        belongReplyId,
    });
}

/**
 * 删除问吧问题
 * @param {stirng} askid 问题id
 * @return {Promise}
 */
function deleteQAQuestion(askid) {
    const dataApi = api.getUrl(api.ask.deleteAsk, { askid });
    return SeaHttpApi.deleteHttpApi(dataApi, { askid });
}

/**
 * 删除问吧回答
 * @param {stirng} id 回答id
 * @param {stirng} askid 问题id
 * @return {Promise}
 */
function deleteQAAnswer(id, askid) {
    const dataApi = api.getUrl(api.ask.deleteReply, { id, askid });
    return SeaHttpApi.deleteHttpApi(dataApi, { id, askid });
}

export default {
    getQAQuestionList,
    getQAQuestionDetail,
    publishQAQuestion,
    answerQAQuestion,
    deleteQAQuestion,
    deleteQAAnswer,
    getQAAnswerList,
};
