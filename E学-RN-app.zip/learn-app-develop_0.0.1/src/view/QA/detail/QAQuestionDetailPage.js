/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面交互组件QAQuestionDetailPage 问吧详情
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, DeviceEventEmitter } from 'react-native';
import QAQuestionDetail from './QAQuestionDetail';
import { QAService } from '../../../servie';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { FSLError } from '../../../util';
import { SeaConstant, SeaStyle } from '../../../asserts';

export default class QAQuestionDetailPage extends React.PureComponent {
    static propTypes = {
        askId: PropTypes.string,
        item: PropTypes.any,
    };

    constructor(props) {
        super(props);
        this._loadingKey; //等待框
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QAREPLY,
            this._reloadDetail
        );
    }

    componentWillUnmount() {
        this.listener && this.listener.remove();
    }

    render() {
        const { item, title, askId } = this.props;
        return (
            <View style={SeaStyle.page}>
                <QAQuestionDetail
                    title={title}
                    ref="detail"
                    item={item}
                    onFetch={this._loader(askId)}
                    onQuestionDeletePress={this._onQuestionDeletePress}
                    onAnswerMorePress={this._onAnswerMorePress}
                    onAnswerDeletePress={this._onAnswerDeletePress}
                    onAddAnswerPress={this._onAddAnswerPress}
                    onAddReplyPress={this._onAddReplyPress}
                />
            </View>
        );
    }

    _onQuestionDeletePress = () => {
        this._deleteQuestion(this.props.askId);
    };

    _onAnswerMorePress = item => {
        const count = _.get(item, 'secList', []).length;
        Actions.show('qaReplyList', { data: item, title: `${count} 条回复` });
    };

    _onAnswerDeletePress = item => {
        this._deleteAnswer(item.id, item.askId);
    };

    _onAddAnswerPress = () => {
        Actions.show('qaAddReply', { askId: this.props.askId });
    };

    _onAddReplyPress = item => {
        const askId = _.get(this.props, 'askId');
        const answerId = _.get(item, 'id');
        Actions.show('qaAddReply', { title: '回复', askId, answerId, answerId });
    };

    _startLoading = () => {
        this._loadingKey = FSLPrompt.loading('正在删除');
    };

    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };

    _loader = askId => (pageTo, pageSize) => {
        if (pageTo === 1) {
            // 刷新时需要刷新详情
            return Promise.all([
                QAService.getQAQuestionDetail(askId),
                QAService.getQAAnswerList(askId, pageTo, pageSize),
            ])
                .then(value => {
                    const other = value[0];
                    const responseJson = value[1];
                    return Promise.resolve({
                        data: responseJson.data,
                        totalPage:
                            responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                        other: this._mapUserDataToDisplay(other),
                    });
                })
                .catch(error => {
                    FSLToast.show(error.message);
                    return Promise.reject(error);
                });
        } else {
            // 请求更多回答
            return QAService.getQAAnswerList(askId, pageTo, pageSize)
                .then(responseJson => {
                    return Promise.resolve({
                        data: responseJson.data,
                        totalPage:
                            responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                    });
                })
                .catch(error => {
                    FSLToast.show(error.message);
                    return Promise.reject(error);
                });
        }
    };

    _deleteQuestion = async askId => {
        try {
            this._startLoading();
            await QAService.deleteQAQuestion(askId);
            this._stopLoading();
            //通知QA列表刷新
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QALIST);
            Actions.pop();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };

    _deleteAnswer = async (id, askid) => {
        try {
            this._startLoading();
            await QAService.deleteQAAnswer(id, askid);
            this._stopLoading();
            this._reloadDetail();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };

    _reloadDetail = () => {
        this.refs.detail && this.refs.detail.reload();
    };

    /**
     * @private
     * @description 在显示前转换数据
     */
    _mapUserDataToDisplay = data => {
        if (!data) {
            // 抛出异常
            throw new FSLError('获取问题详情失败', -9999);
        }

        return {
            ...data,
            owner: data.isSelf == '1',
        };
    };
}
