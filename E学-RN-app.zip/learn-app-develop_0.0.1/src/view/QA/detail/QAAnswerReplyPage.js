/**
 * @author xukj
 * @date 2019/10/24
 * @class
 * @description 查看回答的回复界面
 */
import React from 'react';
import { Alert, DeviceEventEmitter } from 'react-native';
import PropTypes from 'prop-types';
import QAAnswerReply from './QAAnswerReply';
import { Actions } from 'react-native-router-flux';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { QAService } from '../../../servie';
import { SeaConstant } from '../../../asserts';

export default class QAAnswerReplyPage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 回复信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey;
        this.state = { replyList: _.get(props, 'data.secList', []) };
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QAREPLY,
            this._reloadList
        );
    }

    componentWillUnmount() {
        this.listener && this.listener.remove();
    }

    render() {
        const { data } = this.props;
        const { replyList } = this.state;
        return (
            <QAAnswerReply
                answer={data}
                replyList={replyList}
                onReplyPress={this._onReplyPress}
                onReplyToPress={this._onReplyToPress}
                onDeletePress={this._onDeletePress}
            />
        );
    }

    _onReplyToPress = item => {
        const askId = _.get(this.props, 'data.askId');
        const answerId = _.get(this.props, 'data.id');
        const replyToId = _.get(item, 'id');
        const replyToName = _.get(item, 'userName');
        Actions.show('qaAddReply', { title: '回复', askId, answerId, replyToId, replyToName });
    };

    _onReplyPress = () => {
        const askId = _.get(this.props, 'data.askId');
        const answerId = _.get(this.props, 'data.id');
        Actions.show('qaAddReply', { title: '回复', askId, answerId });
    };

    _onDeletePress = (item, index) => {
        Alert.alert(
            '警告',
            '确定要删除这条回复吗？',
            [
                { text: '取消', style: 'cancel' },
                {
                    text: '删除',
                    style: 'destructive',
                    onPress: () => this._deleteReply(item, index),
                },
            ],
            { cancelable: false }
        );
    };

    _reloadList = data => {
        if (data) {
            this.setState({ replyList: data });
        }
    };

    _deleteReply = async (item, index) => {
        try {
            const askId = _.get(this.props, 'data.askId');
            const replyId = _.get(item, 'id');
            this._loadingKey = FSLPrompt.loading('正在删除');
            await QAService.deleteQAAnswer(replyId, askId);
            this.setState(prevState => ({
                replyList: _.chain(prevState.replyList)
                    .clone()
                    .remove((_, idx) => index != idx)
                    .value(),
            }));
            // 通知刷新回答列表
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QAREPLY);
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show('删除成功');
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };
}
