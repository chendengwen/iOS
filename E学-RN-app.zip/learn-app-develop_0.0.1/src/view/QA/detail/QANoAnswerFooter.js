/**
 * @author xukj
 * @date 2018/11/02
 * @class
 * @description 界面展示组件QANoAnswerFooter 当没有答案的时候展示
 * 因为问答详情界面需要有header的同时展示emptyComponent，不能直接使用通用的组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import {StyleSheet, View} from 'react-native';
import {ExceptionView} from '../../../components';

export default class QANoAnswerFooter extends React.PureComponent {

    static propTypes = {};

    static defaultProps = {};

    constructor(props){
        super(props);
    }

    componentDidMount() {}

    render() {
        return (
            <View style={styles.footer}>
                <ExceptionView />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    footer: {
        height: 400,
    }
});