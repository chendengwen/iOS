/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件QAAnswerCell 回答cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaListCell, SeaGenderHeader, SeaButton } from '../../../components';
import { SeaColor, SeaIcon, SeaTheme, SeaScale, SeaStyle } from '../../../asserts';
import { SeaImageUtil, SeaString } from '../../../util';
import { FSLWhiteSpace } from 'react-native-kpframework';

export default class QAAnswerCell extends React.PureComponent {
    static propTypes = {
        onDeletePress: PropTypes.func,
        onReplyPress: PropTypes.func,
        onMorePress: PropTypes.func,
        item: PropTypes.any,
        remove: PropTypes.bool, // 删除按钮
        more: PropTypes.bool, // 更多按钮
        reply: PropTypes.bool, // reply按钮
    };

    static defaultProps = {
        onDeletePress: () => {},
        onReplyPress: () => {},
        onMorePress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, remove, more, reply, onMorePress, onReplyPress, onDeletePress } = this.props;
        let moreUser = '';
        let moreCount = 0;
        if (more) {
            moreUser = _.get(item, 'secList[0].userName', '');
            moreUser = SeaString.subString(moreUser, 6); // 最多6个字符
            moreCount = _.get(item, 'secList', []).length;
        }
        const content = SeaString.utf16Encoding(item.content);

        return (
            <View style={styles.cell}>
                <SeaGenderHeader
                    style={styles.header}
                    size={SeaScale.Layout(80)}
                    sex={item.sex}
                    source={this._imageSource(item)}
                />
                <View style={styles.contentView}>
                    <View style={styles.contentHeadContainer}>
                        <Text style={styles.name}>{item.userName}</Text>
                        <View style={SeaStyle.row}>
                            {reply && (
                                <SeaButton style={styles.icon} onPress={onReplyPress}>
                                    <SeaIcon
                                        name="message"
                                        size={SeaScale.Layout(32)}
                                        color={SeaColor.h2_text}
                                    />
                                </SeaButton>
                            )}
                            {remove && (
                                <SeaButton style={styles.icon} onPress={onDeletePress}>
                                    <SeaIcon
                                        name="delete1"
                                        size={SeaScale.Layout(32)}
                                        color={SeaColor.h2_text}
                                    />
                                </SeaButton>
                            )}
                        </View>
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(12)} />
                    <Text style={styles.date}>
                        {SeaString.subDateString(item.replyTime, '未知')}
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(8)} />
                    <Text style={styles.content}>{content}</Text>
                    {more && (
                        <View>
                            <FSLWhiteSpace key="space" size={SeaScale.Layout(16)} />
                            <SeaButton style={styles.moreContainer} onPress={onMorePress}>
                                <Text style={[styles.more, { flex: 1 }]} numberOfLines={1}>
                                    <Text style={{ color: SeaColor.main }}>{moreUser}</Text>
                                    等人&nbsp;
                                    <Text style={{ color: SeaColor.main }}>
                                        共{moreCount}条回复＞
                                    </Text>
                                </Text>
                            </SeaButton>
                        </View>
                    )}
                </View>
            </View>
        );
    }

    _imageSource = item => {
        return SeaImageUtil.getImageSource(item.userImageId, item.userImageUrl);
    };
}

const styles = StyleSheet.create({
    cell: {
        backgroundColor: 'white',
        paddingHorizontal: SeaTheme.h_spacing_md,
        paddingVertical: SeaTheme.v_spacing_sm,
        flexDirection: 'row',
        borderBottomColor: SeaColor.parting_line,
        borderBottomWidth: SeaTheme.line_width_xs,
    },
    contentView: {
        paddingLeft: SeaTheme.h_spacing_sm,
        flex: 1,
    },
    header: {
        width: SeaScale.Layout(88),
        height: SeaScale.Layout(88),
    },
    contentHeadContainer: {
        flexDirection: 'row',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    name: {
        fontSize: SeaTheme.font_size_md,
    },
    date: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
    },
    moreContainer: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        height: SeaScale.Layout(80),
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: SeaTheme.h_spacing_sm,
    },
    more: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.h2_text,
    },
    icon: {
        paddingLeft: SeaScale.Layout(32),
    },
});
