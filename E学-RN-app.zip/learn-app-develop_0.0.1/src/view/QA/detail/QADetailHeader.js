/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件QADetailHeader 问题详情头部
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaButton, Separator } from '../../../components';
import { SeaColor, SeaIcon, SeaTheme, SeaScale, SeaStyle } from '../../../asserts';
import { SeaString } from '../../../util';
import { FSLWhiteSpace } from 'react-native-kpframework';
import { Icon } from 'react-native-elements';

export default class QADetailHeader extends React.PureComponent {
    static propTypes = {
        item: PropTypes.any,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item } = this.props;
        return (
            <View style={styles.contentView}>
                <FSLWhiteSpace size={SeaTheme.v_spacing_md} />
                <Text style={styles.title}>{item.title}</Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <View style={SeaStyle.row}>
                    <Icon
                        name="user"
                        type="antdesign"
                        size={SeaScale.Layout(28)}
                        color={SeaColor.content_text}
                    />
                    <FSLWhiteSpace vertical size={SeaScale.Layout(8)} />
                    <Text style={styles.author}>提问人：{item.userName}</Text>
                </View>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <Text style={styles.content}>{item.content}</Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <View style={styles.infoContainer}>
                    <Text style={styles.count}>{item.replyCount} 个回答</Text>
                    <Text style={styles.date}>{SeaString.subDateString(item.askTime, '未知')}</Text>
                </View>
                <FSLWhiteSpace size={SeaTheme.v_spacing_md} />
                <Separator style={styles.sp2} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    contentView: {
        flex: 1,
        backgroundColor: 'white',
        justifyContent: 'center',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
        fontWeight: '400',
    },
    author: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h3_text,
        lineHeight: SeaScale.Layout(40),
    },
    infoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    count: {
        fontSize: SeaTheme.font_size_xs,
        color: SeaColor.content_text,
    },
    date: {
        fontSize: SeaTheme.font_size_xs,
        color: SeaColor.content_text,
    },
    sp2: {
        height: StyleSheet.hairlineWidth,
        backgroundColor: SeaColor.parting_line,
    },
});
