/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件QAQuestionDetail 问吧问题详情
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Alert } from 'react-native';
import { SeaCommentButton, SeaNavigator, SeaList } from '../../../components';
import QAAnswerCell from './QAAnswerCell';
import QADetailHeader from './QADetailHeader';
import QANoAnswerFooter from './QANoAnswerFooter';
import { SeaColor, SeaStyle } from '../../../asserts';
import { SeaDevice } from '../../../util';

export default class QAQuestionDetail extends React.PureComponent {
    static propTypes = {
        item: PropTypes.any,
        onFetch: PropTypes.func,
        onQuestionDeletePress: PropTypes.func,
        onAnswerMorePress: PropTypes.func,
        onAnswerDeletePress: PropTypes.func,
        onAddAnswerPress: PropTypes.func,
        onAddReplyPress: PropTypes.func,
    };

    static defaultProps = {
        item: {},
        onQuestionDeletePress: resourceId => {},
        onAnswerMorePress: (item, index) => {},
        onAnswerDeletePress: (item, index) => {},
        onAddAnswerPress: () => {},
        onAddReplyPress: (item, index) => {},
    };

    constructor(props) {
        super(props);
        // 头部绘制
        this.state = { item: props.item ? props.item : {} };
    }

    componentDidMount() {}

    render() {
        const {
            title,
            onFetch,
            onAnswerMorePress,
            onAnswerDeletePress,
            onAddAnswerPress,
            onQuestionDeletePress,
            onAddReplyPress,
        } = this.props;
        const { item } = this.state;
        const renderHeader = _.curry(this._renderHeader)(item);
        const renderItem = _.curry(this._renderItem)(onAnswerMorePress)(onAddReplyPress)(
            onAnswerDeletePress
        );
        // 这里需要保留header部分，同时展示emptyComponent，只能通过footer来处理，使用mapDataToProps来达到目的
        return (
            <View style={styles.page}>
                <SeaNavigator title={title} {...this._navProps(onQuestionDeletePress, item)} />
                <SeaList
                    style={SeaStyle.list}
                    ref="list"
                    onFetch={onFetch}
                    renderItem={renderItem}
                    ListHeaderComponent={renderHeader}
                    FSLListEmptyComponent={null}
                    mapDataToProps={this._mapDataToProps}
                    mapOtherToProps={this._mapOtherToProps}
                    onLoadStateChanged={this._onLoadStateChanged}
                />
                <View style={styles.footer}>
                    <SeaCommentButton
                        style={{ flex: 1 }}
                        containerStyle={styles.footerContainer}
                        onPress={onAddAnswerPress}
                        text="点击回复"
                    />
                </View>
            </View>
        );
    }

    /**
     * 刷新列表
     */
    reload = () => {
        this.refs.list && this.refs.list.reload();
    };

    _renderHeader = item => () => {
        return <QADetailHeader item={item} />;
    };

    _renderItem = (onCellMorePress, onCellReplyPress, onCellDeletePress, { item, index }) => {
        const showAlert = this._deleteAlert('警告', '确定要删除这条回答吗？', () =>
            onCellDeletePress(item, index)
        );
        const count = _.get(item, 'secList', []).length;

        return (
            <QAAnswerCell
                remove={item.isSelf == '1'}
                reply
                more={count > 0}
                item={item}
                onMorePress={() => onCellMorePress(item, index)}
                onReplyPress={() => onCellReplyPress(item, index)}
                onDeletePress={showAlert}
            />
        );
    };

    _navProps = (onQuestionDeletePress, item) => {
        const showAlert = this._deleteAlert('警告', `确定要删除这条问题吗？`, () =>
            onQuestionDeletePress(item)
        );
        return !!item && item.owner
            ? {
                  rightIcon: 'delete',
                  onRightPress: showAlert,
              }
            : {};
    };

    _onLoadStateChanged = ({ loading, other }) => {
        if (!loading && other) this.setState({ item: other });
    };

    _mapDataToProps = data => {
        if (_.isEmpty(data)) {
            return {
                data: [],
                ListFooterComponent: () => <QANoAnswerFooter />,
            };
        } else {
            return { data };
        }
    };

    _mapOtherToProps = other => {
        let otherProps = {};
        if (other) {
            otherProps = {
                ListHeaderComponent: this._renderHeader(other),
            };
        }
        return {
            ...otherProps,
            other,
        };
    };

    _deleteAlert = (title, content, onPress) => () => {
        Alert.alert(
            title,
            content,
            [
                { text: '取消', style: 'cancel' },
                { text: '删除', style: 'destructive', onPress: onPress },
            ],
            { cancelable: false }
        );
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    list: {
        flex: 1,
    },
    footer: {
        height: SeaDevice.bottomHeight() + 44,
        paddingBottom: SeaDevice.bottomHeight(),
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 15,
        paddingRight: 15,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: SeaColor.parting_line,
        flexDirection: 'row',
    },
    footerContainer: {
        height: 30,
        backgroundColor: 'white',
        borderRadius: 15,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
    },
});
