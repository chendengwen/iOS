/**
 * @author xukj
 * @date 2019/08/15
 * @description QAQuestionData 问吧问题数据模型
 */
export default class QAQuestionData {
    constructor() {
        this.id;
        this.name;
        this.userName;
        this.summary;
        this.replyCount;
        this.publishTime;
        this._sourceData;
    }

    /**
     * 创建新闻数据对象,数据来源:频道
     * @param {object} value
     * @return {QAQuestionData}
     */
    static channel(value) {
        const question = new QAQuestionData();
        question._sourceData = value;

        question.id = value.id;
        question.name = value.title;
        question.userName = value.userName;
        question.summary = value.content;
        question.replyCount = value.replyCount;
        question.publishTime = value.askTime;
        return question;
    }

    /**
     * 创建问吧问题数据对象,数据来源:搜索
     * @param {object} value
     * @return {QAQuestionData}
     */
    static search(value) {
        const question = new QAQuestionData();
        question._sourceData = value;

        question.id = value.id;
        question.name = value.name;
        question.userName = value.userName;
        question.summary = value.summary;
        question.replyCount = value.replyCount;
        question.publishTime = value.publishTime;
        return question;
    }
}
