/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面交互组件QAQuestionListPage 问吧问题列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, DeviceEventEmitter } from 'react-native';
import { FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import QAQuestionList from './QAQuestionList';
import { ResourceSearchHistoryPage } from '../../resource';
import { QAService } from '../../../servie';
import { SeaConstant, SeaStyle } from '../../../asserts';

export default class QAQuestionListPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { search: false };
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QALIST,
            this._reloadList
        );
    }

    componentWillUnmount() {
        this.listener && this.listener.remove();
    }

    render() {
        const { search } = this.state;
        const doSearch = _.curry(this._doSearch)(SeaConstant.SearchType.QA);
        return (
            <View style={SeaStyle.page}>
                <QAQuestionList
                    ref="list"
                    onFetch={this._loader}
                    onCellPress={this._onCellPress}
                    onSearchPress={this._showSearchHistory}
                    placeholder="请输入您的问题关键词"
                />
                <ResourceSearchHistoryPage
                    show={search}
                    onSearch={doSearch}
                    onCancel={this._hideSearchHistory}
                    placeholder="请输入您的问题关键词"
                />
            </View>
        );
    }

    /*
     * @private
     * @description 展示搜索历史
     */
    _showSearchHistory = () => {
        this.setState({ search: true });
    };

    /*
     * @private
     * @description 关闭搜索历史
     */
    _hideSearchHistory = () => {
        this.setState({ search: false });
    };

    /*
     * @private
     * @description 执行搜索
     */
    _doSearch = (category, keyword) => {
        this.setState({ search: false });
        const text = _.trim(keyword);
        if (text.length > 0) {
            Actions.show('searchResourceList', { keyword: text, category: category });
        }
    };

    _onCellPress = item => {
        Actions.show('qaQuestionDetail', { item: item, askId: item.id });
    };

    _reloadList = () => {
        this.refs.list && this.refs.list.reload();
    };

    _loader = (pageTo, pageSize) => {
        return QAService.getQAQuestionList(pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data,
                    totalPage:
                        responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}
