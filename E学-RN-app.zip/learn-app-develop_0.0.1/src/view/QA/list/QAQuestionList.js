/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 问吧问题列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import QAQuestionCell from './QAQuestionCell';
import { FSLSearchBar, SeaList } from '../../../components';
import { SeaColor, SeaTheme, SeaScale, SeaStyle } from '../../../asserts';
import QAQuestionData from '../data/QAQuestionData';

export default class QAQuestionList extends React.PureComponent {
    static propTypes = {
        placeholder: PropTypes.string,
        onCellPress: PropTypes.func,
        onSearchPress: PropTypes.func,
        onFetch: PropTypes.func,
    };

    static defaultProps = {
        placeholder: '',
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { onFetch, placeholder, onCellPress, onSearchPress } = this.props;
        const renderItem = _.curry(this._renderItem)(onCellPress);
        return (
            <View style={styles.page}>
                <View style={styles.header}>
                    <FSLSearchBar
                        style={styles.search}
                        textProps={{ ...search.textProps, value: placeholder }}
                        icon={search.iconProps}
                        onPress={onSearchPress}
                    />
                </View>
                <SeaList
                    style={SeaStyle.list}
                    ref="list"
                    renderItem={renderItem}
                    onFetch={onFetch}
                    FSLListEmptyComponent={null}
                />
            </View>
        );
    }

    /**
     * 刷新列表
     */
    reload = () => {
        this.refs.list && this.refs.list.reload();
    };

    _renderItem = (onCellPress, { item }) => {
        return (
            <QAQuestionCell onPress={() => onCellPress(item)} item={QAQuestionData.channel(item)} />
        );
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    header: {
        height: SeaTheme.row_height_md,
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        paddingHorizontal: SeaTheme.h_spacing_md,
    },
    search: {
        height: SeaScale.Layout(66),
        flex: 1,
        backgroundColor: 'white',
        borderRadius: SeaTheme.raduis_md,
        borderColor: SeaColor.parting_line,
        borderWidth: SeaTheme.line_width_xs,
    },
    input: {
        fontSize: SeaTheme.font_size_md,
        color: '#b2b2b2',
    },
    icon: {
        color: '#b2b2b2',
    },
});

const search = {
    textProps: {
        style: styles.input,
    },
    iconProps: {
        style: styles.icon,
    },
};
