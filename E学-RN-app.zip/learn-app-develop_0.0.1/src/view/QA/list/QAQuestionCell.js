/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面展示组件QAQuestionCell 提问列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaListCell, Separator } from '../../../components';
import { SeaColor, SeaTheme, SeaScale, SeaStyle } from '../../../asserts';
import { SeaString } from '../../../util';
import QAQuestionData from '../data/QAQuestionData';
import { Icon } from 'react-native-elements';
import { FSLWhiteSpace } from 'react-native-kpframework';

export default class QAQuestionCell extends React.PureComponent {
    static propTypes = {
        onPress: PropTypes.func,
        item: PropTypes.instanceOf(QAQuestionData).isRequired,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress, ...restProps } = this.props;
        return (
            <SeaListCell
                style={styles.cell}
                showSeparator={false}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <Text style={styles.title} numberOfLines={1}>
                    {item.name}
                </Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <View style={SeaStyle.row}>
                    <Icon
                        type="antdesign"
                        name="user"
                        size={SeaScale.Layout(28)}
                        color={SeaColor.content_text}
                    />
                    <FSLWhiteSpace size={SeaScale.Layout(8)} vertical />
                    <Text style={styles.author} numberOfLines={1}>
                        提问人：{item.userName}
                    </Text>
                </View>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <Text style={styles.content} numberOfLines={2}>
                    {item.summary}
                </Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_sm} />
                <View style={styles.infoContainer}>
                    <Text style={styles.count}>{item.replyCount} 个回答</Text>
                    <Text style={styles.date}>
                        {SeaString.subDateString(item.publishTime, '未知')}
                    </Text>
                </View>
                <FSLWhiteSpace size={SeaTheme.v_spacing_md} />
                <Separator style={styles.sp2} />
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        flex: 1,
        backgroundColor: 'white',
        justifyContent: 'center',
        paddingHorizontal: SeaTheme.h_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(40),
        fontWeight: '400',
    },
    author: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h3_text,
        lineHeight: SeaScale.Layout(40),
    },
    infoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    count: {
        fontSize: SeaTheme.font_size_xs,
        color: SeaColor.content_text,
    },
    date: {
        fontSize: SeaTheme.font_size_xs,
        color: SeaColor.content_text,
    },
    sp2: {
        height: StyleSheet.hairlineWidth,
        backgroundColor: SeaColor.parting_line,
    },
});
