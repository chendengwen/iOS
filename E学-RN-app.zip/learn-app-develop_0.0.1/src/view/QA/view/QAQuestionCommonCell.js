/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 问吧问题通用cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaListCell, Separator, SeaFlagText } from '../../../components';
import { SeaColor, SeaTheme, SeaScale } from '../../../asserts';
import { SeaString } from '../../../util';
import QAQuestionData from '../data/QAQuestionData';

export default class QAQuestionCommonCell extends React.PureComponent {
    static propTypes = {
        onPress: PropTypes.func,
        item: PropTypes.instanceOf(QAQuestionData).isRequired,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress, ...restProps } = this.props;
        return (
            <SeaListCell
                style={styles.cell}
                backgroundColor="white"
                showSeparator={false}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View>
                    <SeaFlagText style={styles.flag}>问吧</SeaFlagText>
                    <Text style={styles.title}>&emsp;&emsp;&emsp;{item.name}</Text>
                    <Text style={styles.author} numberOfLines={1}>
                        提问人：{item.userName ? item.userName : '匿名'}
                    </Text>
                    <Text style={styles.content} numberOfLines={2}>
                        {item.summary}
                    </Text>
                    <View style={styles.infoContainer}>
                        <Text style={styles.count}>{item.replyCount} 个回答</Text>
                        <Separator style={styles.sp1} />
                        <Text style={styles.date}>
                            {SeaString.subDateString(item.publishTime, '未知')}
                        </Text>
                    </View>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        backgroundColor: 'white',
        justifyContent: 'space-between',
        padding: SeaTheme.h_spacing_md,
    },
    flag: {
        position: 'absolute',
        top: 0,
        left: 0,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(42),
        color: SeaColor.h1_text,
    },
    author: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
        marginTop: SeaTheme.v_spacing_md,
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
        marginTop: SeaTheme.v_spacing_md,
    },
    infoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: SeaTheme.v_spacing_md,
    },
    count: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
        marginRight: SeaScale.Layout(40),
    },
    date: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
        marginLeft: SeaScale.Layout(40),
    },
    sp1: {
        width: StyleSheet.hairlineWidth,
        height: SeaScale.Layout(32),
        backgroundColor: SeaColor.parting_line,
    },
});
