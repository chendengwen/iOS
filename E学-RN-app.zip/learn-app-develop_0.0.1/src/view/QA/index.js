/**
 * @author xukj
 * @date 2018/10/30
 * @description index 问吧
 */
// 问吧问题数据模型
export { default as QAQuestionData } from './data/QAQuestionData';
// 问吧问题通用cell
export { default as QAQuestionCommonCell } from './view/QAQuestionCommonCell';

export { default as QAQuestionListPage } from './list/QAQuestionListPage';
export { default as QAQuestionDetailPage } from './detail/QAQuestionDetailPage';
export { default as QAAddAnswerPage } from './add/QAAddAnswerPage';
export { default as QAAddQuestionPage } from './add/QAAddQuestionPage';
// 回答的回复
export { default as QAAnswerReplyPage } from './detail/QAAnswerReplyPage';
// 添加回答的回复
export { default as QAAddReplyPage } from './add/QAAddReplyPage';
