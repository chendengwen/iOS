/**
 * @author xukj
 * @date 2018/10/31
 * @class
 * @description 添加问吧问题页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Keyboard, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { QAService, CategoryService } from '../../../servie';
import QAAddQuestion from './QAAddQuestion';
import { SeaString } from '../../../util';
import { SeaConstant, SeaStyle } from '../../../asserts';

export default class QAAddQuestionPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { categoryTitle: '', categoryValue: '' };
        this._loadingKey; // 等待框
    }

    componentDidMount() {}

    render() {
        const { title } = this.props;
        const { categoryTitle } = this.state;
        return (
            <View style={SeaStyle.page}>
                <QAAddQuestion
                    title={title}
                    onClosePress={this._onClosePress}
                    onPublishPress={this._onPublishPress}
                    onCategoryPress={this._onCategoryPress}
                    category={categoryTitle}
                />
            </View>
        );
    }

    _onClosePress = () => {
        Keyboard.dismiss();
        Actions.pop();
    };

    _onPublishPress = (subject, content, anonymous) => {
        Keyboard.dismiss();
        const { categoryValue } = this.state;
        this._publishQuestion(subject, content, categoryValue, anonymous);
    };

    _onCategoryPress = () => {
        Keyboard.dismiss();
        Actions.show('multiLevelList', {
            title: '选择分类',
            loader: this._categoryLoader,
            onSelect: this._setCategory,
            backKey: 'qaAddQuestion',
        });
    };

    _startLoading = () => {
        this._loadingKey = FSLPrompt.loading('正在提交');
    };

    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };

    _setCategory = item => {
        this.setState({ categoryTitle: item.title, categoryValue: item.value });
    };

    _publishQuestion = async (subject, content, categoryId, anonymous) => {
        try {
            this._startLoading();
            const subjectValue = SeaString.utf16Decoding(subject);
            const contentValue = SeaString.utf16Decoding(content);
            await QAService.publishQAQuestion(subjectValue, contentValue, categoryId, anonymous);
            this._stopLoading();
            // 通知QA列表刷新
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QALIST);
            Actions.pop();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };

    /**
     * @private
     * @description 分类loader
     */
    _categoryLoader = () => {
        return CategoryService.getCategories()
            .then(responseJson => {
                return Promise.resolve({
                    data: this._categoryDataMap(responseJson),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    /**
     * @private
     * @description multilevel界面对数据有严格要求，这里需要转换
     */
    _categoryDataMap = data => {
        if (_.isEmpty(data)) {
            return [];
        } else {
            return data.map(value => {
                const subs = this._categoryDataMap(value.subCategory);
                return {
                    key: value.id,
                    title: value.name,
                    subs: subs,
                    value: value.id,
                    hasNext: !_.isEmpty(subs),
                };
            });
        }
    };
}
