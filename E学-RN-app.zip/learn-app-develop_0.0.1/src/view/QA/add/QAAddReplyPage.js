/**
 * @author xukj
 * @date 2019/10/24
 * @class
 * @description 创建回复
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Keyboard, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { QAService } from '../../../servie';
import { AddComment } from '../../../components';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaString } from '../../../util';
import { SeaStyle, SeaConstant } from '../../../asserts';

export default class QAAddReplyPage extends React.PureComponent {
    static propTypes = {
        askId: PropTypes.string.isRequired,
        answerId: PropTypes.string, // 回复评论时使用
        replyToId: PropTypes.string, // 回复评论的评论时使用
        replyToName: PropTypes.string, // 回复评论的评论时使用
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey; //等待框
    }

    componentDidMount() {}

    render() {
        const { replyToId, replyToName } = this.props;
        const placeholder = replyToId ? `回复 ${replyToName}：` : '请输入您的评论';
        return (
            <View style={SeaStyle.page}>
                <AddComment
                    title="回复"
                    placeholder={placeholder}
                    onClosePress={this._onClosePress}
                    onPublishPress={this._onPublishPress}
                />
            </View>
        );
    }

    _onClosePress = () => {
        Keyboard.dismiss();
        Actions.pop();
    };

    _onPublishPress = (content, anonymous) => {
        const { askId, replyToId, answerId } = this.props;
        Keyboard.dismiss();
        this._publishAnswer(askId, replyToId, answerId, content, anonymous);
    };

    _startLoading = () => {
        this._loadingKey = FSLPrompt.loading('正在提交');
    };

    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };

    _publishAnswer = async (askId, replyToId, belongReplyId, text, anonymous) => {
        try {
            this._startLoading();
            const value = SeaString.utf16Decoding(text);
            const result = await QAService.answerQAQuestion(
                askId,
                value,
                anonymous,
                replyToId,
                belongReplyId
            );
            this._stopLoading();
            // 通知QA详情刷新
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QAREPLY, result);
            Actions.pop();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };
}
