/**
 * @author xukj
 * @date 2018/10/31
 * @class
 * @description 添加问吧问题
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, ScrollView, View, TextInput, Switch, Text, Alert } from 'react-native';
import { Icon } from 'react-native-elements';
import { SeaNavigator, SeaButton, Separator, SeaTextButton } from '../../../components';
import { SeaColor, SeaIcon, SeaTheme, SeaScale } from '../../../asserts';

export default class QAAddQuestion extends React.PureComponent {
    static propTypes = {
        title: PropTypes.string,
        category: PropTypes.string,
        onClosePress: PropTypes.func,
        onPublishPress: PropTypes.func,
        onCategoryPress: PropTypes.func,
    };

    static defaultProps = {
        title: '提问',
        placeholder: '请输入内容',
        category: '',
        onClosePress: () => {},
        onPublishPress: (subject, content, anonymous) => {},
        onCategoryPress: () => {},
    };

    constructor(props) {
        super(props);
        this._onRightPress = fsl.debounce(() => this._checkValid(props.onPublishPress));
        this._onLeftPress = () => this._onClosePress(props.onClosePress);
        this.content = '';
        this.subject = '';
        this.state = { anonymous: false };
    }

    componentDidMount() {}

    render() {
        const { title, category, onCategoryPress } = this.props;
        const { anonymous } = this.state;
        return (
            <View style={styles.page}>
                <SeaNavigator
                    title={title}
                    closeMode
                    onClosePress={this._onLeftPress}
                    rightText="发表"
                    onRightPress={this._onRightPress}
                />
                <ScrollView style={{ flex: 1 }}>
                    <View style={styles.contentView}>
                        <TextInput
                            style={styles.inputTitle}
                            placeholder="请输入你的问题主题"
                            placeholderTextColor={SeaColor.content_text}
                            autoFocus={true}
                            autoCapitalize="none"
                            underlineColorAndroid="transparent"
                            onChangeText={this._onChangeSubject}
                        />
                        <Separator
                            style={[
                                styles.sp,
                                {
                                    marginLeft: SeaTheme.h_spacing_md,
                                    marginRight: SeaTheme.h_spacing_md,
                                },
                            ]}
                        />
                        <TextInput
                            style={styles.inputContent}
                            multiline={true}
                            placeholder="请输入你的问题详情"
                            placeholderTextColor="#c9c9c9"
                            autoCapitalize="none"
                            underlineColorAndroid="transparent"
                            onChangeText={this._onChangeContent}
                        />
                        <Separator
                            style={[
                                styles.sp,
                                {
                                    height: SeaScale.Layout(20),
                                    backgroundColor: SeaColor.defaultBackgroudColor_3,
                                },
                            ]}
                        />
                        <View style={styles.footer}>
                            <SeaButton onPress={onCategoryPress}>
                                <View style={styles.categoryContainer}>
                                    {category.length > 0 ? (
                                        <Text style={styles.cateogrySelect}>{category}</Text>
                                    ) : (
                                        <Text style={styles.category}>选择分类</Text>
                                    )}
                                    <Icon
                                        containerStyle={styles.arrow}
                                        size={SeaTheme.icon_size_md}
                                        color={SeaColor.parting_line}
                                        type="font-awesome"
                                        name="angle-right"
                                    />
                                </View>
                            </SeaButton>
                        </View>
                        <View
                            style={[
                                styles.footer,
                                { backgroundColor: SeaColor.defaultBackgroudColor_3 },
                            ]}
                        >
                            <Switch value={anonymous} onValueChange={this._onValueChanged} />
                            <Text style={styles.anonymous}>匿名</Text>
                        </View>
                    </View>
                </ScrollView>
            </View>
        );
    }

    _onValueChanged = value => {
        this.setState({ anonymous: value });
    };

    _onChangeSubject = text => {
        this.subject = text;
    };

    _onChangeContent = text => {
        this.content = text;
    };

    _onClosePress = onPress => {
        const valueSubject = _.trim(this.subject);
        const valueContent = _.trim(this.content);
        if (valueSubject.length > 0 || valueContent.length > 0) {
            Alert.alert(
                '警告',
                '您还有尚未编辑完成的提问，是否确定退出',
                [
                    { text: '取消', style: 'cancel' },
                    { text: '退出', onPress: onPress, style: 'destructive' },
                ],
                { cancelable: false }
            );
        } else {
            onPress();
        }
    };

    _checkValid = onSuccess => {
        const valueSubject = _.trim(this.subject);
        if (valueSubject.length <= 0) {
            Alert.alert('提示', '主题不能为空', [{ text: '取消', style: 'cancel' }], {
                cancelable: false,
            });
            return;
        }

        const valueContent = _.trim(this.content);
        if (valueContent.length <= 0) {
            Alert.alert('提示', '内容不能为空', [{ text: '取消', style: 'cancel' }], {
                cancelable: false,
            });
            return;
        }

        const { category } = this.props;
        if (category.length <= 0) {
            Alert.alert('提示', '请选择分类', [{ text: '取消', style: 'cancel' }], {
                cancelable: false,
            });
            return;
        }

        onSuccess(valueSubject, valueContent, this.state.anonymous);
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    contentView: {
        backgroundColor: 'white',
    },
    inputTitle: {
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        height: SeaScale.Layout(100),
        padding: 0,
        fontSize: SeaTheme.font_size_md,
    },
    inputContent: {
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_sm,
        height: SeaScale.Layout(320),
        padding: 0,
        fontSize: SeaTheme.font_size_md,
        textAlignVertical: 'top',
    },
    footer: {
        height: SeaScale.Layout(100),
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    anonymous: {
        marginLeft: SeaScale.Layout(16),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
    categoryContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        flex: 1,
    },
    arrow: {
        marginLeft: SeaScale.Layout(16),
    },
    category: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
        height: SeaScale.Layout(40),
        lineHeight: SeaScale.Layout(40),
    },
    cateogrySelect: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.main,
        height: SeaScale.Layout(40),
        lineHeight: SeaScale.Layout(40),
    },
    sp: {
        height: StyleSheet.hairlineWidth,
        backgroundColor: SeaColor.parting_line,
    },
});
