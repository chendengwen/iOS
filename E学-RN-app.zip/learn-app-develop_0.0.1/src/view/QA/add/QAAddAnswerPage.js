/**
 * @author xukj
 * @date 2018/10/30
 * @class
 * @description 界面交互组件QAAddAnswerPage 回答问答
 * @deprecated 已废弃，替代 @see QAAddReplyPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Keyboard, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { QAService } from '../../../servie';
import { AddComment } from '../../../components';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaString } from '../../../util';
import { SeaConstant, SeaStyle } from '../../../asserts';

export default class QAAddAnswerPage extends React.PureComponent {
    static propTypes = {
        askId: PropTypes.string,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey; //等待框
    }

    componentDidMount() {}

    render() {
        const { title } = this.props;
        return (
            <View style={SeaStyle.page}>
                <AddComment
                    title={title}
                    onClosePress={this._onClosePress}
                    onPublishPress={this._onPublishPress}
                />
            </View>
        );
    }

    _onClosePress = () => {
        Keyboard.dismiss();
        Actions.pop();
    };

    _onPublishPress = (content, anonymous) => {
        Keyboard.dismiss();
        this._publishAnswer(this.props.askId, content, anonymous);
    };

    _startLoading = () => {
        this._loadingKey = FSLPrompt.loading('正在提交');
    };

    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };

    _publishAnswer = async (askId, text, anonymous) => {
        try {
            this._startLoading();
            const value = SeaString.utf16Decoding(text);
            await QAService.answerQAQuestion(askId, value, anonymous);
            this._stopLoading();
            // 通知QA详情刷新
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QAREPLY);
            Actions.pop();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message ? error.message : '提交回答失败');
        }
    };
}
