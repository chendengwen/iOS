/**
 * @author xukj
 * @date 2019/09/12
 * @class
 * @description 问卷预览页
 */
import React from 'react';
import PropTypes from 'prop-types';
import QuestionReview from './QuestionReview';
import { SeaImageGalleryControl } from '../../common';

export default class QuestionReviewPage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array.isRequired, // 问卷题目数据
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._galleryControl; // 图片浏览器
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        return <QuestionReview data={data} onImagePress={this._onImagePress} />;
    }

    _onImagePress = (index, optionIndex, source) => {
        if (!this._galleryControl) {
            this._galleryControl = new SeaImageGalleryControl();
        }
        this._galleryControl.start([{ source }]);
    };
}
