/**
 * @author xukj
 * @date 2019/09/12
 * @class
 * @description 问卷预览
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text, ScrollView, TextInput } from 'react-native';
import { SeaStyle, SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import Swiper from 'react-native-swiper';
import { Icon } from 'react-native-elements';
import styles from '../detail/DetailStyles';
import { SeaCheckBox } from '../../../components';
import { SeaImageUtil } from '../../../util';
import RadioButtons from 'react-native-radio-buttons';

export default class QuestionReview extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array, // 题目数据
        onImagePress: PropTypes.func,
    };

    static defaultProps = {
        data: [],
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data, onImagePress } = this.props;
        return (
            <View style={SeaStyle.page}>
                <Swiper
                    scrollEnabled
                    loop={false}
                    showsButtons
                    loadMinimal
                    loadMinimalSize={5}
                    showsPagination={false}
                    buttonWrapperStyle={styles.buttonWrapper}
                    nextButton={this._renderNextButton()}
                    prevButton={this._renderPreviousButton()}
                >
                    {_.map(data, (value, index, array) => {
                        const count = array.length;
                        switch (value.type) {
                            case '01':
                                return this._renderSingleSelect(value, index, count, onImagePress);
                            case '02':
                                return this._renderMultipleSelect(
                                    value,
                                    index,
                                    count,
                                    onImagePress
                                );
                            case '03':
                                return this._renderQA(value, index, count);
                            default:
                                return this._renderOther(value, index, count);
                        }
                    })}
                </Swiper>
            </View>
        );
    }

    /**
     * @private
     * @description 标题、题干、说明部分
     */
    _renderQuestionDesc = (title, description, required, progress) => {
        return (
            <View>
                <Text style={styles.label}>{title}</Text>
                <Text style={styles.topicText}>&emsp;&emsp;&emsp;{description} </Text>
                <View style={styles.subTitleContainer}>
                    <Text style={styles.subTitle}>{required}</Text>
                    <Text style={styles.progress}>进度 {progress}</Text>
                </View>
                <View style={styles.line} />
            </View>
        );
    };

    /**
     * @private
     * @description 单选题
     */
    _renderSingleSelect = (value, index, count, onImagePress) => {
        const title = '单选';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${count}`;

        // 单选
        const renderContainer = optionNodes => {
            return <View>{optionNodes}</View>;
        };

        const renderOption = (option, selected, onSelect, optionIndex) => {
            const source = SeaImageUtil.getImageSource(option.optionPicture);
            return (
                <SeaCheckBox
                    key={optionIndex}
                    title={option.description}
                    source={source}
                    onImagePress={() => onImagePress(index, optionIndex, source)}
                    input={option.otherFlag == 1}
                    reviewMode={{ on: true }} // 预览模式
                />
            );
        };

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(title, description, required, progress)}
                <RadioButtons
                    options={value.options}
                    renderOption={renderOption}
                    renderContainer={renderContainer}
                />
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 多选题
     */
    _renderMultipleSelect = (value, index, count, onImagePress) => {
        const title = '多选';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${count}`;

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(title, description, required, progress)}
                <View>
                    {value.options.map((u, i) => {
                        const source = SeaImageUtil.getImageSource(u.optionPicture);
                        return (
                            <SeaCheckBox
                                isMult
                                key={i}
                                title={u.description}
                                source={source}
                                onImagePress={() => onImagePress(index, i, source)}
                                input={u.otherFlag == 1}
                                reviewMode={{ on: true }} // 预览模式
                            />
                        );
                    })}
                </View>
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 问答题
     */
    _renderQA = (value, index, count) => {
        const title = '问答';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${count}`;

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(title, description, required, progress)}
                <View style={styles.header}>
                    <TextInput
                        maxLength={200}
                        style={[styles.contentText, { textAlignVertical: 'top' }]}
                        ref="textInput"
                        placeholder="谈一谈你的看法吧"
                        placeholderTextColor={SeaColor.tag_text}
                        multiline={true}
                        underlineColorAndroid="transparent"
                        returnKeyType="done"
                        blurOnSubmit={true}
                        editable={false}
                    />
                </View>
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 其他类型题型
     */
    _renderOther = (value, index, count) => {
        const title = '未知';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${count}`;

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(title, description, required, progress)}
                <Text style={styles.info}>未知题型，请更新app</Text>
            </ScrollView>
        );
    };

    _renderPreviousButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-start', paddingLeft: SeaTheme.h_spacing_md },
                ]}
            >
                <Icon
                    type="ionicon"
                    name="ios-arrow-back"
                    size={SeaScale.Layout(40)}
                    color="white"
                />
                <Text style={[styles.buttonText, { marginLeft: SeaScale.Layout(16) }]}>上一题</Text>
            </View>
        );
    };

    _renderNextButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-end', paddingRight: SeaTheme.h_spacing_md },
                ]}
            >
                <Text style={[styles.buttonText, { marginRight: SeaScale.Layout(16) }]}>
                    下一题
                </Text>
                <Icon
                    type="ionicon"
                    name="ios-arrow-forward"
                    size={SeaScale.Layout(40)}
                    color="white"
                />
            </View>
        );
    };
}
