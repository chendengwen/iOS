/**
 * @author xukj
 * @date 2018/8/17
 * @description 问卷
 */
// 问卷项目数据模型
export { default as QProjectData } from './data/QProjectData';
// 问卷项目通用cell
export { default as QProjectCommonCell } from './view/QProjectCommonCell';

// 面授、E课的问卷
export { default as QDetailPage } from './detail/QDetailPage';
export { default as QResourceListPage } from './list/QResourceListPage';

// 问卷项目
export { default as QProjectListPage } from './list/QProjectListPage';
export { default as QProjectToLearnListPage } from './tolearn/QProjectToLearnListPage';
export { default as QProjectHistoryListPage } from './history/QProjectHistoryListPage';

// modify by xukj - 1.32.0统一问卷界面
export { default as QPaperDescPage } from './desc/QPaperDescPage';
export { default as QProjectDescPage } from './desc/QProjectDescPage';

// 问卷审批预览
export { default as QuestionApprovePage } from './approve/QuestionApprovePage';
// 问卷题目预览
export { default as QuestionReviewPage } from './review/QuestionReviewPage';
// 问卷审批题目预览
export { default as QuestionPaperApprovePage } from './approve/QuestionPaperApprovePage';
