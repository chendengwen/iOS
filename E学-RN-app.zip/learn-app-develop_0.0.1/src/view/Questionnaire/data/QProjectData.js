/**
 * @author xukj
 * @date 2019/08/15
 * @description QProjectData 问卷项目数据模型
 */
import { SeaImageUtil } from '../../../util';
import moment from 'moment';

export default class QProjectData {
    constructor() {
        this.id;
        this.name;
        this.summary;
        this.submitNum;
        this.publisher;
        this.publishTime;
        this._sourceData;
    }

    /**
     * 创建问卷项目数据对象,数据来源:频道
     * @param {object} value
     * @return {QProjectData}
     */
    static channel(value) {
        // const book = new BookData();
        // book._sourceData = value;
        // book.id = value.id;
        // book.name = value.name;
        // book.publisher = value.publisher;
        // book.publishTime = value.publishTime;
        // book.finishStudy = value.finishStudy;
        // return book;
    }

    /**
     * 创建问卷项目数据对象,数据来源:搜索
     * @param {object} value
     * @return {QProjectData}
     */
    static search(value) {
        const qProject = new QProjectData();
        qProject._sourceData = value;

        qProject.id = value.id;
        qProject.name = value.name;
        qProject.summary = value.summary;
        qProject.submitNum = value.submitNum;
        qProject.publisher = value.publisher;
        qProject.publishTime = value.publishTime;
        return qProject;
    }

    /**
     * 创建问卷项目数据对象,数据来源:专题
     * @param {object} value
     * @return {QProjectData}
     */
    static subject(value) {
        const qProject = new QProjectData();
        qProject._sourceData = value;

        qProject.id = value.id;
        qProject.name = value.name;
        qProject.summary = value.summary;
        qProject.submitNum = value.submitNum;
        qProject.publisher = value.publisher;
        qProject.publishTime = moment(value.publishTime).format('YYYY-MM-DD HH:mm:ss');
        return qProject;
    }
}
