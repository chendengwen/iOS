/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 学习计划中的问卷列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLToast } from 'react-native-kpframework';
import QProjectToLearn from './QProjectToLearn';
import { Actions } from 'react-native-router-flux';
import { ToLearnService } from '../../../servie';
import { SeaConstant } from '../../../asserts';
import qProjectMapper from '../QProjectMapper';

export default class QProjectToLearnListPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        return <QProjectToLearn onFetch={this._loader} onCellPress={this._onCellPress} />;
    }

    _loader = (pageTo, pageSize) => {
        return ToLearnService.getToLearnResourceList(
            pageTo,
            pageSize,
            SeaConstant.ResourceType.QUESTIONNAIRE
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: this._mapDataForDisplay(responseJson.data),
                    totalPage:
                        responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = item => {
        Actions.show('QProjectDesc', { resourceId: item.qId });
    };

    _mapDataForDisplay = data => {
        return data.map(value => {
            return qProjectMapper(
                value.resourceId,
                value.resourceName,
                value.publishTime,
                value.endTime
            );
        });
    };
}
