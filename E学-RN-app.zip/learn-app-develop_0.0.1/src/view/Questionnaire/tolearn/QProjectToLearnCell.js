/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 界面展示组件QProjectListCell 问卷项目列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaListCell } from '../../../components';
import { SeaColor, SeaTheme, SeaScale } from '../../../asserts';
import { SeaString } from '../../../util';

export default class QProjectToLearnCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object,
    };

    static defaultProps = {
        item: {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, title, content01, content02, ...restProps } = this.props;
        return (
            <SeaListCell backgroundColor="white" style={styles.cell} {...restProps}>
                <Text style={styles.title} numberOfLines={2}>
                    {item.qName}
                </Text>
                <Text style={styles.time}>
                    发布时间：
                    {item.qPublishTime ? SeaString.subDateString(item.qPublishTime) : '未知'}
                </Text>
                <Text style={styles.author}>
                    有效期截止：{item.qEndTime ? item.qEndTime : '长期有效'}
                </Text>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(250),
        padding: SeaTheme.h_spacing_md,
        paddingRight: 0,
        justifyContent: 'space-between',
    },
    title: {
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(42),
    },
    time: {
        color: SeaColor.content_text,
        fontSize: SeaTheme.font_size_md,
    },
    author: {
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
    },
});
