/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 计划问卷项目列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { SeaList } from '../../../components';
import QProjectToLearnCell from './QProjectToLearnCell';
import { SeaStyle } from '../../../asserts';

export default class QProjectToLearn extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaList
                style={SeaStyle.list}
                onFetch={onFetch}
                data={defaultData}
                renderItem={this._renderItem}
            />
        );
    }

    /*
     * @private
     * @description 列表项
     */
    _renderItem = ({ item, index }) => {
        return <QProjectToLearnCell item={item} onPress={() => this.props.onCellPress(item, index)} />;
    };
}

