/**
 * @author xukj
 * @date 2019/06/26
 * @class
 * @description 面授问卷页、E课问卷页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Alert } from 'react-native';
import { FSLPrompt } from 'react-native-kpframework';
import { Actions, ActionConst } from 'react-native-router-flux';
import { QuestionnaireService } from '../../../servie';
import DescComponent from './DescComponent';

export default class QPaperDescPage extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string, // 资源id
        snapshotId: PropTypes.any, // 问卷描述信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { data: null };
        this._loadingKey;
    }

    componentDidMount() {
        this._loadDesc();
    }

    render() {
        const { data } = this.state;
        return <DescComponent data={data} onStartPress={this._onStartPress} />;
    }

    _onStartPress = () => {
        try {
            const { data } = this.state;
            // 验证合法性
            this._checkValide(data);
            // 开始答卷
            Actions.show('QDetail', {
                id: data.id,
                resourceId: data.boundId,
                type: ActionConst.REPLACE,
            });
        } catch (error) {
            this._showAlert(error.message);
        }
    };

    _loadDesc = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            const result = await QuestionnaireService.getQuestionnairePaperDesc(
                this.props.snapshotId
            );
            FSLPrompt.hide(this._loadingKey);
            this.setState({ data: this._mapDataToDesc(result) });

            // 设置界面信息
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            this._showAlert(error.message, Actions.pop);
        }
    };

    _showAlert = (content, onPress = () => {}) => {
        Alert.alert('提示', content, [{ text: '确定', onPress: onPress }], { cancelable: false });
    };

    /**
     * @private
     * @description 转换数据封装为 DescComponent 需要的数据
     */
    _mapDataToDesc = data => {
        return {
            ...data,
            name: data.name,
            questionNumber: data.stems.length,
            description: data.description,
        };
    };

    /**
     * @private
     * @description 判断是否合法的面授
     */
    _checkValide = data => {
        // 问卷项的逻辑与以前的逻辑不通，需要特殊处理
        // 1. 已完成
        if (data.finished == true) {
            throw new Error('你已经完成了该问卷哦');
        }

        // 2. 可见性，由接口判断

        // 4. 时效
        if (data.isValid != 1) {
            throw new Error('对不起，现在不是问卷填写时间哦');
        }
    };
}
