/**
 * Created by zk on 2017/9/21.
 * 问卷信息
 */
import React from 'react';
import PropTypes from 'prop-types';
import { ScrollView, Text, View, Alert, StyleSheet } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { SeaScale, SeaColor, SeaTheme, SeaStyle } from '../../../asserts';
import { SeaNavigator, SeaNavigationItems as Items, SeaTextButton } from '../../../components';

export default class DescComponent extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string, // 资源id
        data: PropTypes.any, // 问卷描述信息
        onStartPress: PropTypes.func, // 开始考试
        onSharePress: PropTypes.func, // 开始分享
    };

    static defaultProps = {
        onStartPress: () => {},
    };

    render() {
        const { data, onSharePress, onStartPress } = this.props;
        // 分享按钮
        const renderRightButton =
            data && onSharePress
                ? () => Items.renderSeaIconButton(onSharePress, 'share', '#0C5FDD')
                : null;

        return (
            <View style={SeaStyle.page}>
                <SeaNavigator title="问卷详情" renderRightButton={renderRightButton} />
                {data && [
                    <ScrollView key="scroll" style={styles.container}>
                        <Text style={styles.title}>{data.name}</Text>
                        <Text style={styles.content}>题目数量： {data.questionNumber}</Text>
                        <View style={styles.line} />
                        <Text style={styles.title1}>问卷说明</Text>
                        {data.validStart && data.validEnd && (
                            <Text style={styles.desc}>
                                {data.description +
                                    `\n问卷有效时间为 ${data.validStart} ~ ${data.validEnd} ，请在此期间填写问卷。`}
                            </Text>
                        )}
                        {!(data.validStart && data.validEnd) && (
                            <Text style={styles.desc}>{data.description}</Text>
                        )}
                    </ScrollView>,
                    <SeaTextButton
                        key="button"
                        style={styles.button}
                        theme="main"
                        title="开始填写问卷"
                        onPress={onStartPress}
                    />,
                ]}
            </View>
        );
    }

    _onStartPress = () => {
        const { data, resourceId, onPress } = this.props;
        if (onPress) {
            onPress(resourceId, data);
            return;
        }

        if (data.questionnaireStatus != 2) {
            Alert.alert('提示', '现在不是问卷填写时间哦', [{ text: '确定' }], { cancelable: true });
        } else if (data.finished == true) {
            Alert.alert('提示', '你已经完成了该问卷哦', [{ text: '确定' }], { cancelable: true });
        } else {
            Actions.show('QDetail', { id: data.id, resourceId: resourceId });
        }
    };
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: SeaScale.screenWidth,
    },
    title: {
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_md,
        color: SeaColor.h1_text,
        fontSize: SeaScale.Layout(40),
        lineHeight: SeaScale.Layout(52),
    },
    content: {
        marginLeft: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_md,
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
    },
    title1: {
        marginLeft: SeaTheme.h_spacing_md,
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_lg,
        marginTop: SeaTheme.v_spacing_md,
    },
    desc: {
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_md,
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_md,
        lineHeight: SeaScale.Layout(40),
    },
    line: {
        width: SeaScale.screenWidth,
        height: SeaScale.Layout(30),
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: SeaColor.parting_line,
    },
    button: {
        height: SeaTheme.row_height_md,
        width: SeaScale.screenWidth,
        borderTopWidth: 1,
        borderTopColor: SeaColor.parting_line,
    },
});
