/**
 * @author xukj
 * @date 2018/12/04
 * @description QProjectMapper 因为接口返回的样式不一致，需要前端进行转换为一致的再返回
 */

/**
 * 初始化问卷项结构
 * @param {string} id 问卷项id
 * @param {string} name 问卷项名称
 * @param {string} publishTime 问卷项发布时间
 * @param {string} endTime 问卷项截止时间
 * @param {object} other 其他
 * @return {{qId: string, qName: string, qPublishTime: string, qEndTime: string, ...other}}
 */
export default (id, name, publishTime, endTime, other) => {
    return {
        qId: id,
        qName: name,
        qPublishTime: publishTime,
        qEndTime: endTime,
        ...other,
    };
};
