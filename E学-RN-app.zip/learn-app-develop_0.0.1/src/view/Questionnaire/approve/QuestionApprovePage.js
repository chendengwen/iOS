/**
 * @author xukj
 * @date 2019/09/12
 * @class
 * @description 问卷待审批预览页
 */
import React from 'react';
import { DeviceEventEmitter, View, Alert } from 'react-native';
import PropTypes from 'prop-types';
import QuestionApprove from './QuestionApprove';
import { SeaStyle, SeaConstant } from '../../../asserts';
import { Actions } from 'react-native-router-flux';
import { FSLToast, FSLPrompt } from 'react-native-kpframework';
import { ApproveService } from '../../../servie';

export default class QuestionApprovePage extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string.isRequired,
        review: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { data: null };
        this._loadingKey;
    }

    componentDidMount() {
        this._load();
    }

    render() {
        const { data } = this.state;
        const { review } = this.props;
        return data ? (
            <QuestionApprove
                review={review}
                data={data}
                onVisibilityPress={this._onVisibilityPress}
                onPassPress={this._onApprovePress(true)}
                onRefusePress={this._onApprovePress(false)}
                onPreviewPress={this._onPreviewPress}
            />
        ) : (
            <View style={SeaStyle.page} />
        );
    }

    _onVisibilityPress = () => {
        Actions.show('visibilityList', { resourceId: this.props.resourceId });
    };

    _onApprovePress = result => () => {
        // 需要二次确认
        Alert.alert(
            '提示',
            result ? '是否同意该审批' : '是否驳回该审批',
            [
                {
                    text: '确定',
                    onPress: () => this._onSendApproval(this.props.resourceId, result),
                    style: result ? 'default' : 'destructive',
                },
                { text: '取消', style: 'cancel' },
            ],
            { cancelable: false }
        );
    };

    _onPreviewPress = async () => {
        const stems = _.get(this.state, 'data.questionnaireSnapshot.stems', []);
        // 进入预览界面
        Actions.show('QReview', { data: stems });
    };

    // 提交审批结果
    _onSendApproval = async (resourceId, result) => {
        try {
            const content = result ? '同意' : '不同意';
            this._loadingKey = FSLPrompt.loading('正在提交审批结果');
            await ApproveService.submitApprovalResult(resourceId, content, result);
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show('提交成功');
            // 通知其他界面审批完成
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_APPROVELIST);
            Actions.pop();
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /**
     * @private
     * @description 获取待审批面授详情
     */
    _load = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('加载中');
            const result = await ApproveService.getApproveQuestionDetail(this.props.resourceId);
            this.setState({ data: result });
            FSLPrompt.hide(this._loadingKey);
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };
}
