/**
 * @author xukj
 * @date 2019/09/11
 * @class
 * @description 问卷审批
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView, Text } from 'react-native';
import { SeaTextButton, SeaListCell } from '../../../components';
import { SeaColor, SeaScale, SeaTheme, SeaConstant, SeaStyle } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';

/**
 * 分组头部标题组件
 */
const HeadRowComp = props => {
    const { title } = props;
    return (
        <View style={styles.infoHeadContainer}>
            <View style={styles.infoHeadFlag} />
            <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{title}</Text>
        </View>
    );
};

/**
 * 头部组件
 */
const HeadComp = props => {
    const { style, data } = props;
    const name = _.get(data, 'name', '问卷');
    const publisher = _.get(data, 'publisher', '佚名');
    const category = _.get(data, 'categoriesDesc', '暂无');

    return (
        <View style={style}>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textLg, { color: SeaColor.h1_text }]}>{name}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textSm, { color: SeaColor.h2_text }]}>发布人：{publisher}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textSm, { color: SeaColor.content_text }]}>分类：{category}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );
};

/**
 * 基本信息组件
 */
const InfoComp = props => {
    const { style, data } = props;
    const summary = _.get(data, 'questionnaireSnapshot.description', '暂无');
    // 题目数量
    const questionNumber = _.get(data, 'questionnaireSnapshot.stems', []).length;

    // 答题时间
    let time = '无限制';
    const starttime = _.get(data, 'questionnaireSnapshot.validStart', '');
    const endtime = _.get(data, 'questionnaireSnapshot.validEnd', '');
    if (starttime && endtime) time = `${starttime} 至 ${endtime}`;
    else if (starttime) time = `${starttime}开始`;
    else if (endtime) time = `${endtime}截止`;

    const InfoRow = props => {
        const { title, content } = props;
        return (
            <View style={{ flexDirection: 'row' }}>
                <Text style={styles.infoTitleText}>{title}</Text>
                <Text style={[styles.infoContentText, { flex: 1 }]}>{content}</Text>
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="问卷信息" />
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="题目数量：" content={questionNumber} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="答题时间：" content={time} />
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={[styles.infoTitleText, { color: SeaColor.h1_text }]}>问卷说明</Text>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={styles.infoContentText}>{summary}</Text>
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
        </View>
    );
};

/**
 * 题型分布
 */
const TopicsComp = props => {
    const { style, data } = props;

    // 单选题统计
    const singleChoiceArray = _.chain(data)
        .get('questionnaireSnapshot.stems', [])
        .filter(value => value.type == SeaConstant.QuestionTopicType.SINGLE)
        .value();
    const singleChoiceCount = singleChoiceArray.length;
    const signleChoiceRequired = _.sumBy(singleChoiceArray, value => (value.required ? 0 : 1));
    // 多选题统计
    const multipleChoiceArray = _.chain(data)
        .get('questionnaireSnapshot.stems', [])
        .filter(value => value.type == SeaConstant.QuestionTopicType.MULTIPLE)
        .value();
    const multipleChoiceCount = multipleChoiceArray.length;
    const multipleChoiceRequired = _.sumBy(multipleChoiceArray, value => (value.required ? 0 : 1));
    // 问答题统计
    const essayQuestionArray = _.chain(data)
        .get('questionnaireSnapshot.stems', [])
        .filter(value => value.type == SeaConstant.QuestionTopicType.ESSAY)
        .value();
    const essayQuestionCount = essayQuestionArray.length;
    const essayQuestionRequired = _.sumBy(essayQuestionArray, value => (value.required ? 0 : 1));

    // 分割线
    const VerticalSp = () => (
        <View style={[styles.spTable, { height: SeaScale.Layout(70), width: tableLineSize }]} />
    );

    // 头部
    const TopicRow = props => {
        const { title, number, required, head } = props;
        const cellStyle = { backgroundColor: head ? SeaColor.defaultBackgroudColor_3 : 'white' };
        const textStyle = [styles.textMd, { color: SeaColor.h1_text }];
        return (
            <View style={SeaStyle.row}>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{title}</Text>
                </View>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{number}</Text>
                </View>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{required}</Text>
                </View>
                <VerticalSp />
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="题型分布" />
            <FSLWhiteSpace style={styles.borderTop} size={vSpaceSize} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="题型" number="数量" required="必填" head />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="单选题" number={singleChoiceCount} required={signleChoiceRequired} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow
                title="多选题"
                number={multipleChoiceCount}
                required={multipleChoiceRequired}
            />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="问答题" number={essayQuestionCount} required={essayQuestionRequired} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );
};

/**
 * 可见性
 */
const VisibilityComp = props => {
    const { style, data, onPress } = props;
    return (
        <View style={style}>
            <SeaListCell
                showArrow
                showSeparator
                arrowSize={SeaTheme.icon_size_md}
                onPress={Number(data.visibility)=== 1 ? null: onPress}
                style={styles.visibility}
            >
                <Text style={[styles.textMd, { color: SeaColor.h1_text, flex: 1 }]}>
                    可见性：{SeaConstant.getVisibilityTypeString(_.get(data, 'visibility'))}
                </Text>
            </SeaListCell>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text
                style={[
                    styles.textMd,
                    { color: SeaColor.h2_text, marginLeft: SeaTheme.h_spacing_md },
                ]}
            >
                {data.preStaffHidden ? '岗前人员不可见' : '岗前人员可见'}
            </Text>
        </View>
    );
};

const TopicViewComp = props => {
    const { style, onPress } = props;
    return (
        <View style={[style, SeaStyle.center, { height: SeaScale.Layout(300) }]}>
            <SeaTextButton
                round
                style={{ height: SeaScale.Layout(80), width: SeaScale.Layout(300) }}
                theme="main"
                title="查看问卷内容"
                titleStyle={styles.textMd}
                onPress={onPress}
            />
        </View>
    );
};

export default class QuestionApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.func,
        onPassPress: PropTypes.func,
        onRefusePress: PropTypes.func,
        onVisibilityPress: PropTypes.func,
        onPreviewPress: PropTypes.func,
        review: PropTypes.bool, // 预览
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            data,
            review,
            onVisibilityPress,
            onPassPress,
            onRefusePress,
            onPreviewPress,
        } = this.props;
        return (
            <View style={SeaStyle.page}>
                <ScrollView style={{ flex: 1 }}>
                    <View style={{ width: SeaScale.screenWidth }}>
                        <HeadComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <InfoComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        {/* <TopicsComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} /> */}
                        <VisibilityComp
                            style={{ backgroundColor: 'white' }}
                            data={data}
                            onPress={onVisibilityPress}
                        />
                        <TopicViewComp style={styles.section} onPress={onPreviewPress} />
                    </View>
                </ScrollView>
                {!review && (
                    <View style={[styles.footer, styles.borderTop]}>
                        <SeaTextButton
                            style={{ flex: 1 }}
                            theme="main"
                            titleStyle={SeaTheme.font_size_lg}
                            title="审批通过"
                            onPress={onPassPress}
                        />
                        <SeaTextButton
                            style={{ flex: 1, backgroundColor: SeaColor.defaultBackgroudColor_3 }}
                            theme="disable"
                            titleStyle={[SeaTheme.font_size_lg, { color: SeaColor.h2_text }]}
                            title="退回修改"
                            onPress={onRefusePress}
                        />
                    </View>
                )}
            </View>
        );
    }
}

const vSpaceSize = SeaScale.Layout(24);
const tableLineSize = SeaScale.spWidth;

const styles = StyleSheet.create({
    // 字体
    // ---
    textLg: {
        fontSize: SeaTheme.font_size_lg,
    },
    textMd: {
        fontSize: SeaTheme.font_size_md,
    },
    textSm: {
        fontSize: SeaTheme.font_size_sm,
    },

    // 分割线
    // ---
    sp: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    spTable: {
        backgroundColor: SeaColor.parting_line,
    },

    // 分割线
    // ---
    borderTop: {
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },

    // 其他
    // ---
    section: {
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    infoHeadContainer: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
    },
    infoHeadFlag: {
        height: SeaScale.Layout(26),
        width: SeaScale.Layout(4),
        backgroundColor: SeaColor.main,
        marginRight: SeaTheme.h_spacing_md,
    },
    infoTitleText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        minWidth: SeaScale.Layout(150),
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
    },
    infoContentText: {
        fontSize: SeaTheme.font_size_md,
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
        color: SeaColor.h2_text,
    },
    tableCell: {
        height: SeaScale.Layout(70),
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    visibility: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
        paddingLeft: SeaTheme.h_spacing_md,
    },
    footer: {
        flexDirection: 'row',
        height: SeaScale.Layout(100),
    },
});
