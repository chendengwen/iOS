/**
 * @author xukj
 * @date 2019/09/11
 * @class
 * @description 问卷试题审批前查看
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView, Text } from 'react-native';
import { SeaTextButton } from '../../../components';
import { SeaColor, SeaScale, SeaTheme, SeaConstant, SeaStyle } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';

/**
 * 分组头部标题组件
 */
const HeadRowComp = props => {
    const { title } = props;
    return (
        <View style={styles.infoHeadContainer}>
            <View style={styles.infoHeadFlag} />
            <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{title}</Text>
        </View>
    );
};

/**
 * 基本信息组件
 */
const InfoComp = props => {
    const { style, data } = props;
    const summary = _.get(data, 'questionnaireSnapshotDTO.description', '暂无');
    // 题目数量
    const questionNumber = _.get(data, 'questionnaireSnapshotDTO.stems', []).length;

    // 答题时间
    let time = '无限制';
    const starttime = _.get(data, 'questionnaireSnapshotDTO.validStart', '');
    const endtime = _.get(data, 'questionnaireSnapshotDTO.validEnd', '');
    if (starttime && endtime) time = `${starttime} 至 ${endtime}`;
    else if (starttime) time = `${starttime}开始`;
    else if (endtime) time = `${endtime}截止`;

    const InfoRow = props => {
        const { title, content } = props;
        return (
            <View style={{ flexDirection: 'row' }}>
                <Text style={styles.infoTitleText}>{title}</Text>
                <Text style={[styles.infoContentText, { flex: 1 }]}>{content}</Text>
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="问卷信息" />
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="题目数量：" content={questionNumber} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="答题时间：" content={time} />
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={[styles.infoTitleText, { color: SeaColor.h1_text }]}>问卷说明</Text>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={styles.infoContentText}>{summary}</Text>
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
        </View>
    );
};

const TopicViewComp = props => {
    const { style, onPress } = props;
    return (
        <View style={[style, SeaStyle.center, { height: SeaScale.Layout(300) }]}>
            <SeaTextButton
                round
                style={{ height: SeaScale.Layout(80), width: SeaScale.Layout(300) }}
                theme="main"
                title="查看问卷内容"
                titleStyle={styles.textMd}
                onPress={onPress}
            />
        </View>
    );
};

export default class QuestionPaperApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.func,
        onPreviewPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data, onPreviewPress } = this.props;
        return (
            <View style={SeaStyle.page}>
                <ScrollView style={{ flex: 1 }}>
                    <View style={{ width: SeaScale.screenWidth }}>
                        <InfoComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <TopicViewComp style={styles.section} onPress={onPreviewPress} />
                    </View>
                </ScrollView>
            </View>
        );
    }
}

const vSpaceSize = SeaScale.Layout(24);
const tableLineSize = SeaScale.spWidth;

const styles = StyleSheet.create({
    // 字体
    // ---
    textLg: {
        fontSize: SeaTheme.font_size_lg,
    },
    textMd: {
        fontSize: SeaTheme.font_size_md,
    },
    textSm: {
        fontSize: SeaTheme.font_size_sm,
    },

    // 分割线
    // ---
    sp: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    spTable: {
        backgroundColor: SeaColor.parting_line,
    },

    // 分割线
    // ---
    borderTop: {
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },

    // 其他
    // ---
    section: {
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    infoHeadContainer: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
    },
    infoHeadFlag: {
        height: SeaScale.Layout(26),
        width: SeaScale.Layout(4),
        backgroundColor: SeaColor.main,
        marginRight: SeaTheme.h_spacing_md,
    },
    infoTitleText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        minWidth: SeaScale.Layout(150),
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
    },
    infoContentText: {
        fontSize: SeaTheme.font_size_md,
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
        color: SeaColor.h2_text,
    },
});
