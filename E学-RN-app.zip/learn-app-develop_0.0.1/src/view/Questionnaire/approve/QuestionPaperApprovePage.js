/**
 * @author xukj
 * @date 2019/09/12
 * @class
 * @description 问卷试题审批前查看
 */
import React from 'react';
import PropTypes from 'prop-types';
import QuestionPaperApprove from './QuestionPaperApprove';
import { Actions } from 'react-native-router-flux';

export default class QuestionPaperApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷审批预览信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        return <QuestionPaperApprove data={data} onPreviewPress={this._onPreviewPress} />;
    }

    _onPreviewPress = async () => {
        const stems = _.get(this.props, 'data.questionnaireSnapshotDTO.stems', []);
        // 进入预览界面
        Actions.show('QReview', { data: stems });
    };
}
