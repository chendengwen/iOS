/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 问卷项目列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { DeviceEventEmitter } from 'react-native';
import { FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { QuestionnaireService } from '../../../servie';
import QProjectList from './QProjectList';
import { SeaConstant } from '../../../asserts';

export default class QProjectListPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._listener;
        this._comp;
    }

    componentDidMount() {
        this._listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QLIST,
            this._reload
        );
    }

    componentWillUnmount() {
        this._listener && this._listener.remove();
    }

    render() {
        return (
            <QProjectList
                ref={comp => (this._comp = comp)}
                onFetch={this._loader}
                onCellPress={this._onCellPress}
            />
        );
    }

    _loader = (pageTo, pageSize) => {
        return QuestionnaireService.getQProjectChannelList(pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data,
                    totalPage:
                        responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = item => {
        Actions.show('QProjectDesc', { resourceId: item.boundId });
    };

    _reload = () => {
        this._comp && this._comp.reload();
    };
}
