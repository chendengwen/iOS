/**
 * @author xukj
 * @date 2018/9/17
 * @description 问卷项目列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text, Image } from 'react-native';
import { SeaListCell } from '../../../components/index';
import { SeaColor, SeaIcon, SeaScale, SeaTheme } from '../../../asserts';

export default class QProjectListCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress, disable, remark } = this.props;
        const { name, publishTime, feedbackStatus, feedbackNum } = item;
        const flagSource =
            item && feedbackStatus === 1
                ? require('../../../asserts/images/resource/feedback.png')
                : null;

        return (
            <SeaListCell
                style={[styles.cell, remark && { height: SeaScale.Layout(280) }]}
                showArrow={false}
                showSeparator={false}
                disabled={disable}
                onPress={onPress}
            >
                <View style={styles.cellTopContainer}>
                    <Text style={styles.cellTopName} numberOfLines={1}>
                        课程名称：{name}
                    </Text>
                    {this._renderShowDetailIfEnable()}
                </View>
                <View style={styles.cellMiddleContainer}>
                    <Text style={styles.cellMiddleOther}>
                        发布时间：
                        <Text style={styles.cellMiddleOther}>{publishTime}</Text>
                    </Text>
                    <View style={styles.cellMiddleRow}>
                        <Text style={styles.cellMiddleOther}>
                            已&thinsp;&thinsp;反&thinsp;&thinsp;馈 :
                            <Text style={styles.cellMiddleOther}>{`  ${feedbackNum}人`}</Text>
                        </Text>
                        {item && item.feedbackStatus !== 1 && (
                            <Text style={styles.noFeedback}>未反馈</Text>
                        )}
                    </View>
                </View>

                {item && <Image style={styles.flag} source={flagSource} />}
            </SeaListCell>
        );
    }

    _renderShowDetailIfEnable = disable => {
        return (
            <View style={styles.cellTopDetailContainer}>
                <SeaIcon
                    style={styles.cellTopDetailArrow}
                    size={SeaScale.Layout(32)}
                    color={SeaColor.h3_text}
                    name="arrow-goto"
                />
            </View>
        );
    };
}

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(220),
        borderTopWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
        backgroundColor: 'white',
    },
    cellTopContainer: {
        height: SeaScale.Layout(88),
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
        flexDirection: 'row',
        alignItems: 'center',
    },
    cellMiddleContainer: {
        flex: 1,
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        // borderBottomWidth: StyleSheet.hairlineWidth,
        // borderColor: SeaColor.parting_line,
        justifyContent: 'center',
    },
    cellTopName: {
        fontSize: SeaScale.Font(30),
        color: SeaColor.h1_text,
        flex: 1,
    },
    cellTopDetailContainer: {
        width: SeaScale.Layout(80),
        height: SeaScale.Layout(32),
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    cellTopDetailArrow: {
        width: SeaScale.Layout(32),
        height: SeaScale.Layout(32),
    },
    cellMiddleRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: SeaScale.Layout(16),
    },
    cellMiddleOther: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    noFeedback: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.red_text,
    },
    flag: {
        width: SeaScale.Layout(170),
        height: SeaScale.Layout(156),
        position: 'absolute',
        right: 0,
        bottom: 0,
    },
});
