/**
 * @author xukj
 * @date 2019/08/08
 * @description 非问卷项目列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { SeaList } from '../../../components';
import QResourceListCell from './QResourceListCell';
import { SeaStyle } from '../../../asserts';

export default class QResourceList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => {},
    };

    reload = () => {
        this._comp && this._comp.reload();
    };

    constructor(props) {
        super(props);
        this._comp;
    }

    componentDidMount() {}

    render() {
        const { defaultData, onFetch, ...restProps } = this.props;
        return (
            <SeaList
                style={SeaStyle.list}
                ref={comp => (this._comp = comp)}
                data={defaultData}
                onFetch={onFetch}
                renderItem={this._renderItem}
                {...restProps}
            />
        );
    }

    /*
     * @private
     * @description 列表项
     */
    _renderItem = ({ item, index }) => {
        return (
            <QResourceListCell item={item} onPress={() => this.props.onCellPress(item, index)} />
        );
    };
}
