/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 问卷项目列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { SeaList, Separator } from '../../../components';
import QProjectListCell from './QProjectListCell';
import { SeaTheme, SeaStyle } from '../../../asserts';

export default class QProjectList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => {},
    };

    reload = () => {
        this._comp && this._comp.reload();
    };

    constructor(props) {
        super(props);
        this._comp;
    }

    componentDidMount() {}

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaList
                ref={comp => (this._comp = comp)}
                style={SeaStyle.list}
                onFetch={onFetch}
                data={defaultData}
                ItemSeparatorComponent={() => <Separator style={styles.sp} />}
                renderItem={this._renderItem}
            />
        );
    }

    /*
     * @private
     * @description 列表项
     */
    _renderItem = ({ item, index }) => {
        return <QProjectListCell item={item} onPress={() => this.props.onCellPress(item, index)} />;
    };
}

const styles = StyleSheet.create({
    sp: {
        height: SeaTheme.v_spacing_sm,
        backgroundColor: 'transparent',
    },
});
