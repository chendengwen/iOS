/**
 * @author xukj
 * @date 2019/06/17
 * @description 非问卷项目的问卷列表
 * Created by zk on 2017/9/21.
 * modify by xukj - 1.32.0
 * 重构，修正为网络请求
 * modify by xukj - 1.35.0
 * 重构
 */
import React from 'react';
import { Alert, StyleSheet, DeviceEventEmitter } from 'react-native';
import PropTypes from 'prop-types';
import { Actions } from 'react-native-router-flux';
import { ResourceService } from '../../../servie';
import QResourceList from './QResourceList';
import { FSLToast } from 'react-native-kpframework';
import { SeaConstant } from '../../../asserts';

export default class QResourceListPage extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string.isRequired, // 面授期次/e课的id
        data: PropTypes.array, // 问卷数组, 如果没有传递则会通过resourceId去获取
    };

    static defaultProps = {
        data: [],
    };

    constructor(props) {
        super(props);
        this._listener;
        this._comp;
    }

    componentDidMount() {
        this._listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QLIST,
            this._reload
        );
    }

    componentWillUnmount() {
        this._listener && this._listener.remove();
    }

    render() {
        return (
            <QResourceList
                ref={comp => (this._comp = comp)}
                defaultData={this.props.data}
                onFetch={this._onFetch}
                onCellPress={this._onCellPress}
            />
        );
    }

    _onCellPress = item => {
        if (item.finished) {
            Alert.alert('提示', '已经完成了该问卷了哦', [{ text: '确定' }], { cancelable: false });
        } else {
            Actions.show('QDesc', { snapshotId: item.id, resourceId: this.props.resourceId });
        }
    };

    _reload = () => {
        this._comp && this._comp.reload();
    };

    _onFetch = () => {
        return ResourceService.getQResourceList(this.props.resourceId)
            .then(responseJson => {
                return Promise.resolve(
                    _.isEmpty(responseJson)
                        ? { data: [], totalPage: 0 }
                        : { data: responseJson, totalPage: 1 }
                );
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}
