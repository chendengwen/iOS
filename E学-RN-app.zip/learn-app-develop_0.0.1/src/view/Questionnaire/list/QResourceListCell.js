/**
 * @author xukj
 * @date 2019/08/08
 * @description 非问卷项目列表的cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell } from '../../../components/index';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';

export default class QResourceListCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, ...restProps } = this.props;
        return (
            <SeaListCell
                style={styles.itemContainer}
                arrow
                separator
                backgroundColor="white"
                {...restProps}
            >
                <View style={styles.leftContainer}>
                    <Text style={styles.title}> {item.name}</Text>
                    <Text style={[styles.desc, { marginTop: SeaScale.Layout(32) }]}>
                        {' '}
                        {item.questionNumber}道
                    </Text>
                </View>
                <Text style={[styles.desc, { width: SeaScale.Layout(160), textAlign: 'right' }]}>
                    {item.finished ? '已完成' : '待完成'}
                </Text>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    itemContainer: {
        flex: 1,
        height: SeaScale.Layout(180),
        flexDirection: 'row',
        alignItems: 'center',
    },
    leftContainer: {
        marginLeft: SeaTheme.h_spacing_md,
        flex: 1,
        justifyContent: 'space-around',
    },
    title: {
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_md,
    },
    desc: {
        color: SeaColor.h2_text,
        fontSize: SeaTheme.font_size_sm,
    },
});
