/**
 * @author xukj
 * @date 2018/6/28
 * @class
 * @description 我的问卷列表样式，标注通过、未通过
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet, Image } from 'react-native';
import { SeaConstant, SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import { SeaListCell } from '../../../components';

export default class QHistoryCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        item: {},
        onPress: () => {},
    };

    componentDidMount() {}

    render() {
        const { item, onPress } = this.props;

        return (
            <View style={styles.container}>
                <SeaListCell
                    backgroundColor="white"
                    showArrow
                    arrowSize={SeaTheme.icon_size_md}
                    showSeparator={false}
                    style={styles.cell}
                    onPress={onPress}
                >
                    <View style={{ flex: 1 }}>
                        <Text style={styles.title} numberOfLines={1}>
                            {item.name}
                        </Text>
                        <Text
                            style={[styles.subTitle, { marginTop: SeaScale.Layout(16) }]}
                            numberOfLines={1}
                        >
                            发布时间：
                            <Text style={{ color: SeaColor.h2_text }}>{item.publishTime}</Text>
                        </Text>
                        <Text
                            style={[styles.subTitle, { marginTop: SeaScale.Layout(20) }]}
                            numberOfLines={1}
                        >
                            回答时间：{item.answerTime}
                        </Text>
                        <View style={styles.tagContainer}>
                            <Text style={[styles.subTitle, { marginTop: 0 }]}>来源:</Text>
                            <Text style={styles.tag}>
                                {SeaConstant.getResourceTypeString(parseInt(item.sourceType))}
                            </Text>
                        </View>
                    </View>
                </SeaListCell>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        paddingTop: SeaScale.Layout(10),
        paddingLeft: SeaScale.Layout(20),
        paddingRight: SeaScale.Layout(20),
        backgroundColor: 'transparent',
    },
    cell: {
        height: SeaScale.Layout(274),
        padding: SeaScale.Layout(30),
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
    },
    subTitle: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h1_text,
    },
    tagContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: SeaScale.Layout(16),
        alignItems: 'center',
    },
    tag: {
        fontSize: SeaTheme.font_size_md,
        height: SeaScale.Layout(40),
        lineHeight: SeaScale.Layout(40),
        borderRadius: SeaScale.Layout(6),
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.tag_01,
        color: SeaColor.tag_01,
        textAlign: 'center',
        paddingLeft: SeaScale.Layout(12),
        paddingRight: SeaScale.Layout(12),
        marginLeft: SeaScale.Layout(16),
    },
    flag: {
        width: SeaScale.Layout(106),
        height: SeaScale.Layout(106),
        position: 'absolute',
        right: 0,
        top: 0,
        overflow: 'hidden',
    },
});
