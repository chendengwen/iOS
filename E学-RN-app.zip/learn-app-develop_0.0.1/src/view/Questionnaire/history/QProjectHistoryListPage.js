/**
 * @author xukj
 * @date 2018/11/27
 * @class
 * @description 个人的问卷列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import QProjectHistoryList from './QProjectHistoryList';
import { QuestionnaireService } from '../../../servie';
import { SeaConstant } from '../../../asserts';

export default class QProjectHistoryListPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        return <QProjectHistoryList onFetch={this._loader} onCellPress={this._onCellPress} />;
    }

    _loader = (pageTo, pageSize) => {
        return QuestionnaireService.getQProjectHistory(pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data,
                    totalPage:
                        responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = item => {
        if (item.sourceType == SeaConstant.ResourceType.QUESTIONNAIRE) {
            Actions.show('QProjectDesc', { resourceId: item.boundId });
        } else {
            Actions.show('QDesc', { snapshotId: item.id, resourceId: item.boundId });
        }
    };
}
