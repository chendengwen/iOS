/**
 * @author xukj
 * @date 2019/08/16
 * @description 问卷项目通用cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell, SeaFlagText } from '../../../components';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import QProjectData from '../data/QProjectData';

export default class QProjectCommonCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(QProjectData).isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress, ...restProps } = this.props;
        return (
            <SeaListCell
                style={styles.cell}
                backgroundColor="white"
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.content}>
                    <SeaFlagText style={styles.flag}>问卷</SeaFlagText>
                    <Text style={styles.title} numberOfLines={2}>
                        &emsp;&emsp;&emsp;{item.name}
                    </Text>
                    <Text style={styles.tag} numberOfLines={2}>
                        简介：{item.summary}
                    </Text>
                    <Text style={styles.time}>发布时间：{item.publishTime}</Text>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        minHeight: SeaScale.Layout(250),
    },
    content: {
        flex: 1,
        alignItems: 'flex-start',
        margin: SeaTheme.h_spacing_md,
    },
    flag: {
        position: 'absolute',
        left: 0,
        top: 0,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(42),
        color: SeaColor.h1_text,
    },
    keyword: {
        fontSize: SeaTheme.font_size_md,
        color: 'red',
    },
    tag: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
        marginTop: SeaTheme.v_spacing_md,
    },
    time: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
        marginTop: SeaTheme.v_spacing_md,
    },
});
