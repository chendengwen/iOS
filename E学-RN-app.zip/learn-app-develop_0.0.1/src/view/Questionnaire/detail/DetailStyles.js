/**
 * Created by zk on 2017/7/20.
 */
import { StyleSheet } from 'react-native';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';

const imgWidth = SeaScale.screenWidth - SeaTheme.h_spacing_md * 2;
const imgHeight = parseInt((imgWidth * 480) / 642);
export { imgWidth, imgHeight };

export default StyleSheet.create({
    container: {
        flex: 1,
        width: SeaScale.screenWidth,
    },
    contentContainer: {
        flex: 1,
        marginBottom: SeaTheme.row_height_md,
        width: SeaScale.screenWidth,
    },
    label: {
        position: 'absolute',
        left: SeaScale.Layout(30),
        top: SeaScale.Layout(30),
        color: SeaColor.main,
        fontSize: SeaTheme.font_size_md,
        paddingLeft: SeaScale.Layout(8),
        paddingRight: SeaScale.Layout(8),
        height: SeaScale.Layout(40),
        borderColor: SeaColor.main,
        borderWidth: 1,
        lineHeight: SeaScale.Layout(40),
    },
    topicText: {
        marginTop: SeaTheme.v_spacing_md,
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(40),
    },
    subTitleContainer: {
        justifyContent: 'space-between',
        flexDirection: 'row',
    },
    subTitle: {
        marginLeft: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_sm,
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    progress: {
        marginRight: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_sm,
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    topicImg: {
        marginLeft: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_sm,
    },
    line: {
        marginTop: SeaTheme.v_spacing_md,
        width: SeaScale.screenWidth,
        height: 1,
        borderBottomWidth: SeaTheme.line_width_xs,
        borderBottomColor: SeaColor.parting_line,
    },
    buttonWrapper: {
        backgroundColor: SeaColor.main,
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        top: 'auto',
        bottom: 0,
    },
    buttonText: {
        backgroundColor: SeaColor.main,
        fontSize: SeaTheme.font_size_lg,
        color: 'white',
    },
    buttonContainer: {
        width: SeaScale.Layout(240),
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        alignItems: 'center',
    },
    contentText: {
        borderColor: SeaColor.grey5,
        borderWidth: 1,
        padding: SeaScale.Layout(10),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.black,
        flex: 1,
        height: SeaScale.Layout(300),
    },
    header: {
        flexDirection: 'row',
        width: SeaScale.screenWidth,
        justifyContent: 'center',
        alignItems: 'center',
        padding: SeaTheme.h_spacing_md,
    },
    loadingText: {
        color: SeaColor.back,
        fontSize: SeaTheme.font_size_md,
    },
    info: {
        marginTop: SeaScale.Layout(40),
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
    },
});
