/**
 * @author xukj
 * @date 2019/04/02
 * @description Detail 问卷答题页UI
 * modify by xukj - 1.35.0
 * 重构
 * modify by xukj - 1.27.0
 * 替换等待框
 * Created by zk on 2017/9/21.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, ScrollView, View, TextInput } from 'react-native';
import Swiper from 'react-native-swiper';
import { Icon } from 'react-native-elements';
import { RadioButtons } from 'react-native-radio-buttons';
import styles, { imgWidth, imgHeight } from './DetailStyles';
import {
    SeaNavigator,
    SeaNavigationItems as Items,
    SeaCheckBox,
    SeaReloadImage,
} from '../../../components';
import { SeaColor, SeaScale, SeaTheme, SeaStyle } from '../../../asserts';
import { SeaImageUtil } from '../../../util';

export default class QADetail extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array.isRequired,
        onBackPress: PropTypes.func,
        onOptionPress: PropTypes.func,
        onOptionImagePress: PropTypes.func,
        onOptionTextChanged: PropTypes.func,
        onQuestionTextChanged: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            data,
            onSubmitPress,
            onBackPress,
            onOptionPress,
            onOptionTextChanged,
            onQuestionTextChanged,
            onOptionImagePress,
        } = this.props;
        return (
            <View style={SeaStyle.page}>
                <SeaNavigator
                    title="填写问卷"
                    onBackPress={onBackPress}
                    renderRightButton={() => Items.renderTextButton(onSubmitPress, '提交')}
                />
                <Swiper
                    scrollEnabled
                    loop={false}
                    showsButtons
                    loadMinimal
                    loadMinimalSize={5}
                    showsPagination={false}
                    buttonWrapperStyle={styles.buttonWrapper}
                    nextButton={this._renderNextButton()}
                    prevButton={this._renderPreviousButton()}
                >
                    {data.map((value, index) => {
                        switch (value.type) {
                            case '01':
                                return this._renderSingleSelect(
                                    value,
                                    index,
                                    onOptionPress,
                                    onOptionTextChanged,
                                    onOptionImagePress
                                );
                            case '02':
                                return this._renderMultipleSelect(
                                    value,
                                    index,
                                    onOptionPress,
                                    onOptionTextChanged,
                                    onOptionImagePress
                                );
                            case '03':
                                return this._renderQA(
                                    value,
                                    index,
                                    onQuestionTextChanged,
                                    onOptionImagePress
                                );
                            default:
                                return this._renderOther(value, index);
                        }
                    })}
                </Swiper>
            </View>
        );
    }

    /**
     * @private
     * @description 标题、题干、说明部分
     */
    _renderQuestionDesc = (title, description, required, progress, picture, onImagePress) => {
        const source = SeaImageUtil.getImageSource(picture, null, 'l');
        return (
            <View>
                <Text style={styles.label}>{title}</Text>
                <Text style={styles.topicText}>&emsp;&emsp;&emsp;{description} </Text>
                {!_.isEmpty(picture) && (
                    <SeaReloadImage
                        width={imgWidth}
                        height={imgHeight}
                        containerStyle={styles.topicImg}
                        source={source}
                        resizeMode="contain"
                        onPress={() => onImagePress(null, null, source)}
                    />
                )}
                <View style={styles.subTitleContainer}>
                    <Text style={styles.subTitle}>{required}</Text>
                    <Text style={styles.progress}>进度 {progress}</Text>
                </View>
                <View style={styles.line} />
            </View>
        );
    };

    /**
     * @private
     * @description 单选题
     */
    _renderSingleSelect = (value, index, onOptionPress, onTextChanged, onImagePress) => {
        const title = '单选';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${this.props.data.length}`;
        const picture = value.stemPicture;

        // 单选
        const renderContainer = optionNodes => {
            return <View>{optionNodes}</View>;
        };

        const renderOption = (option, selected, onSelect, optionIndex) => {
            return (
                <SeaCheckBox
                    key={optionIndex}
                    title={option.description}
                    checked={selected}
                    onPress={onSelect}
                    source={SeaImageUtil.getImageSource(option.optionPicture)}
                    onImagePress={() =>
                        onImagePress(
                            index,
                            optionIndex,
                            SeaImageUtil.getImageSource(option.optionPicture)
                        )
                    }
                    input={option.otherFlag == 1}
                    onChangeText={text => onTextChanged(index, optionIndex, text)}
                />
            );
        };

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(
                    title,
                    description,
                    required,
                    progress,
                    picture,
                    onImagePress
                )}
                <RadioButtons
                    options={value.options}
                    renderOption={renderOption}
                    renderContainer={renderContainer}
                    selectedIndex={value.options.findIndex((letV, letI, letA) => {
                        return letV.checked === true;
                    })}
                    onSelection={(_, selectedIndex) => onOptionPress(index, selectedIndex, true)}
                />
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 多选题
     */
    _renderMultipleSelect = (value, index, onOptionPress, onTextChanged, onImagePress) => {
        const title = '多选';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${this.props.data.length}`;
        const picture = value.stemPicture;
        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(
                    title,
                    description,
                    required,
                    progress,
                    picture,
                    onImagePress
                )}
                <View>
                    {value.options.map((u, i) => {
                        return (
                            <SeaCheckBox
                                isMult
                                checked={this.props.data[index].options[i].checked}
                                key={i}
                                title={u.description}
                                onPress={() => onOptionPress(index, i, false)}
                                source={SeaImageUtil.getImageSource(u.optionPicture)}
                                onImagePress={() =>
                                    onImagePress(
                                        index,
                                        i,
                                        SeaImageUtil.getImageSource(u.optionPicture)
                                    )
                                }
                                input={u.otherFlag == 1}
                                onChangeText={text => onTextChanged(index, i, text)}
                            />
                        );
                    })}
                </View>
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 问答题
     */
    _renderQA = (value, index, onTextChanged, onImagePress) => {
        const title = '问答';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${this.props.data.length}`;
        const picture = value.stemPicture;

        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(
                    title,
                    description,
                    required,
                    progress,
                    picture,
                    onImagePress
                )}
                <View style={styles.header}>
                    <TextInput
                        maxLength={200}
                        style={[styles.contentText, { textAlignVertical: 'top' }]}
                        ref="textInput"
                        placeholder="谈一谈你的看法吧"
                        placeholderTextColor={SeaColor.tag_text}
                        multiline={true}
                        underlineColorAndroid="transparent"
                        returnKeyType="done"
                        blurOnSubmit={true}
                        // onEndEditing={()=>this.endEdit()}
                        // value={value.options[0].optionText}
                        defaultValue={value.options[0].optionText}
                        onChangeText={text => onTextChanged(index, text)}
                    />
                </View>
            </ScrollView>
        );
    };

    /**
     * @private
     * @description 其他类型题型
     */
    _renderOther = (value, index) => {
        const title = '未知';
        const description = value.description;
        const required = value.required == 1 ? '选填' : '必填';
        const progress = `${index + 1}/${this.props.data.length}`;
        return (
            <ScrollView style={styles.contentContainer} key={index}>
                {this._renderQuestionDesc(title, description, required, progress)}
                <Text style={styles.info}>未知题型，请更新app</Text>
            </ScrollView>
        );
    };

    _renderPreviousButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-start', paddingLeft: SeaTheme.h_spacing_md },
                ]}
            >
                <Icon
                    type="ionicon"
                    name="ios-arrow-back"
                    size={SeaScale.Layout(40)}
                    color="white"
                />
                <Text style={[styles.buttonText, { marginLeft: SeaScale.Layout(16) }]}>上一题</Text>
            </View>
        );
    };

    _renderNextButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-end', paddingRight: SeaTheme.h_spacing_md },
                ]}
            >
                <Text style={[styles.buttonText, { marginRight: SeaScale.Layout(16) }]}>
                    下一题
                </Text>
                <Icon
                    type="ionicon"
                    name="ios-arrow-forward"
                    size={SeaScale.Layout(40)}
                    color="white"
                />
            </View>
        );
    };
}
