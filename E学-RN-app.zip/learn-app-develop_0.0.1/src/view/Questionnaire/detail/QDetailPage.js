/**
 * @author xukj
 * @date 2019/08/07
 * @class
 * @description 问卷答题页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, ScrollView, View, Alert, BackHandler, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import QDetail from './QDetail';
import { QuestionnaireService } from '../../../servie';
import { SeaString } from '../../../util';
import { SeaImageGalleryControl } from '../../common';
import { SeaConstant } from '../../../asserts';

export default class QDetailPage extends React.PureComponent {
    static propTypes = {
        id: PropTypes.string.isRequired, // 问卷题id
        resourceId: PropTypes.string.isRequired, // 问卷项目id
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._backHandler; // 按键监听
        this._loadingKey; // 等待框
        this._galleryControl; // 图片浏览器
        this.state = { data: null };
    }

    componentDidMount() {
        this._getQuestionDetail();
        this._backHandler = BackHandler.addEventListener('hardwareBackPress', this._onBackPress);
    }

    componentWillUnmount() {
        this._backHandler && this._backHandler.remove();
    }

    render() {
        if (this.state.data) {
            return (
                <QDetail
                    data={this.state.data}
                    onOptionPress={this._onOptionPress}
                    onOptionTextChanged={this._onOptionTextChanged}
                    onQuestionTextChanged={this._onQuestionTextChanged}
                    onOptionImagePress={this._onOptionImagePress}
                    onSubmitPress={this._onSubmitPress}
                    onBackPress={this._onBackPress}
                />
            );
        } else {
            return null;
        }
    }

    // 选项选择
    _onOptionPress = (qIndex, oIndex, isRadio) => {
        this.setState(previousState => {
            let [...tempData] = previousState.data;
            if (isRadio) {
                // 单选需要重置其他选项状态
                tempData[qIndex].options.forEach((value, index) => {
                    const checked = index == oIndex;
                    value.checked = checked;
                    value.optionText = checked ? value.optionText : null;
                });
            } else {
                let option = tempData[qIndex].options[oIndex];
                const checked = !option.checked;
                option.checked = checked;
                option.optionText = checked ? option.optionText : null;
            }
            return { data: tempData };
        });
    };

    // 选项文字修改
    _onOptionTextChanged = (qIndex, oIndex, text) => {
        this.setState(previousState => {
            let [...tempData] = previousState.data;
            let option = tempData[qIndex].options[oIndex];
            option.optionText = text;
            return { data: tempData };
        });
    };

    // 问答题修改
    _onQuestionTextChanged = (qIndex, text) => {
        if (text === '') {
            let [...tempData] = this.state.data;
            tempData[qIndex].options[0].optionText = text;
            tempData[qIndex].options[0].checked = false;
            this.setState({ data: tempData });
        } else {
            let [...tempData] = this.state.data;
            tempData[qIndex].options[0].optionText = text;
            tempData[qIndex].options[0].checked = true;
            this.setState({ data: tempData });
        }
    };

    // 查看图片详情
    _onOptionImagePress = (qIndex, oIndex, source) => {
        // qIndex - 问题index
        // oIndex - 选项index
        // path - 图片地址
        console.log({ qIndex, oIndex, source });
        if (!this._galleryControl) {
            this._galleryControl = new SeaImageGalleryControl();
        }
        this._galleryControl.start([{ source }]);
    };

    // 提交
    _onSubmitPress = () => {
        // 是否还有未完成的问卷题目
        const finished = _.reduce(
            this.state.data,
            (result, value) => {
                let valueResult = true;
                if (!value.required) {
                    // 因为web端required设置反了，所以这里只能将就web端
                    // 必选项判断是否有选择
                    valueResult = _.find(value.options, option => option.checked) != undefined;
                }
                return result && valueResult;
            },
            true
        );

        if (!finished) {
            Alert.alert('提示', '您有必答的问题没有完成，请完成后提交', [{ text: '确定' }], {
                cancelable: false,
            });
            return;
        }

        Alert.alert(
            '提示',
            '是否现在提交问卷？',
            [{ text: '继续做题', style: 'cancel' }, { text: '提交', onPress: this._submitAnswer }],
            { cancelable: false }
        );
    };

    // 取消
    _onBackPress = () => {
        Alert.alert(
            '警告',
            '您确定要放弃回答问卷吗？',
            [
                { text: '取消', style: 'cancel' },
                { text: '退出', style: 'destructive', onPress: Actions.pop },
            ],
            { cancelable: false }
        );
        return true;
    };

    // api
    // 获取问卷信息
    _getQuestionDetail = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            const result = await QuestionnaireService.getQuestionnairePaperDesc(this.props.id);
            this.setState({ data: result.stems });
            FSLPrompt.hide(this._loadingKey);
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    // 提交问卷
    _submitAnswer = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('正在提交');

            // 封装答案
            const answers = _.chain(this.state.data)
                .flatMap(answer => answer.options) // 只选择选项部分
                .filter(answer => answer.checked) // 只选择checked的选项
                .map(answer => {
                    // 文字编码转换
                    let result = answer;
                    if (result.optionText)
                        result.optionText = SeaString.utf16Decoding(result.optionText);
                    return result;
                })
                .value();

            await QuestionnaireService.submitAnswer(this.props.id, this.props.resourceId, answers);

            FSLPrompt.hide(this._loadingKey);
            const goback = () => {
                // 通知刷新
                DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QLIST);
                Actions.pop();
            };
            Alert.alert(
                '提示',
                '感谢您参与本次问卷调研，谢谢！',
                [{ text: '确定', onPress: goback }],
                { cancelable: false }
            );
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };
}
