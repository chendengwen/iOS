/**
* 案例数据模型
 */
import { SeaImageUtil } from '../../../util';
// import SourceBeen from '../data/source';

export default class CasesData {
    constructor() {
        this.score;
        this.hitId;
        this.hitIndex;
        this.hitType;
        this.totalSubHits;
        this.hitVersion;
        this.mysource;
        this._sourceData ;
    }

    /**
     * 创建专题数据对象,数据来源:频道
     * @param {object} value
     * @return {CasesData}
     */
    static channel(value) {
        const subject = new CasesData();
        subject._sourceData = value;

        subject.score = value.score;
        subject.hitId = value.hitId;
        subject.hitIndex = value.hitIndex;
        subject.hitType = value.hitType;
        subject.totalSubHits = value.totalSubHits;
        subject.hitVersion = value.hitVersion;
        subject.mysource = value.mysource;
    

        // SourceBeen.channel(this.source);
        return subject;
    }

    /**
     * 创建专题数据对象,数据来源:频道
     * @param {object} value
     * @return {CasesData}
     */
    static search(value) {
        const subject = new CasesData();
        subject._sourceData = value;

        subject.score = value.score;
        subject.hitId = value.hitId;
        subject.hitIndex = value.hitIndex;
        subject.hitType = value.hitType;
        subject.totalSubHits = value.totalSubHits;
        subject.hitVersion = value.hitVersion;
        subject.mysource = value.mysource;
        return subject;
    }


    coverSource(size = 's') {
        return SeaImageUtil.getImageSource(this.coverImageId, this.coverImageUrl, size);
    }

    // coverItem(){
    //     return SourceBeen.channel(this.source)
    // }
}
