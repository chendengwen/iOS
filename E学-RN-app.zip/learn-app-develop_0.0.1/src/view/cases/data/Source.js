
import { SeaImageUtil } from '../../../util';

export default class Source {
    constructor() {
        this.id;                      //案例Id
        this.name;                   //案例名称
        // this.coverImageId;
        // this.coverImageUrl;
        // this.creator;
        // this.resourceNum;
        // this.recommend;
        // this.createdTime;
        this._sourceData;
        this.summary;                //概要信息
        this.publishTime;             //发布时间
        this.deptName;                //部门名称
        this.resourceId;              //pdf文件id
        this.isLike;                  //是否点赞  0：未点赞  1：点赞
        this.author;                  //作者
        this.type;                    //案例类型
        this.categoryName;            //范畴
        this.tags;                    //标签
        this.frequency;
        this.phone;
        this.postName;
        this.comment;
        this.createUser;                //创建人
        this.timeForOrder;
        this.email;
        this.status;
        this.likes;
        this.pageViews;    
    }

    /**
 * 创建专题数据对象,数据来源:频道
 * @param {object} value
 * @return {Source}
 */
    static channel(value) {
        const subject = new Source();
        subject._sourceData = value;


        // subject.coverImageId = value.coverImageId;
        // subject.coverImageUrl = value.coverImageUrl;
        // subject.creator = value.creator;
        // subject.resourceNum = value.resourceNum;
        // subject.recommend = value.recommend;
        // subject.createdTime = value.createdTime;

        subject.summary = value.summary;                //概要信息
        subject.publishTime = value.publishTime;             //发布时间
        subject.deptName = value.deptName;                //部门名称
        subject.resourceId = value.resourceId;              //pdf文件id
        subject.isLike = value.isLike;                  //是否点赞  0：未点赞  1：点赞
        subject.author = value.author;                  //作者
        subject.type = value.type;                    //案例类型
        subject.categoryName = value.categoryName;            //范畴
        subject.tags = value.tags;                    //标签
        subject.frequency = value.frequency;
        subject.phone = value.phone;
        subject.postName = value.postName;
        subject.name = value.name;                     //
        subject.comment = value.comment;
        subject.id = value.id;                         //
        subject.createUser = value.createUser;                //创建人
        subject.timeForOrder = value.timeForOrder;
        subject.email = value.email;
        subject.status = value.status;
        subject.likes = value.likes;
        subject.pageViews = value.pageViews;
        return subject;
    }

    /**
     * 创建专题数据对象,数据来源:频道
     * @param {object} value
     * @return {Source}
     */
    static search(value) {
        const subject = new Source();
        subject._sourceData = value;


        // subject.coverImageId = value.coverImageId;
        // subject.creator = value.createdUser;
        // subject.resourceNum = value.resourceNum;
        // subject.createdTime = value.createdTime;


        subject.summary = value.summary;                //概要信息
        subject.publishTime = value.publishTime;             //发布时间
        subject.deptName = value.deptName;                //部门名称
        subject.resourceId = value.resourceId;              //pdf文件id
        subject.isLike = value.isLike;                  //是否点赞  0：未点赞  1：点赞
        subject.author = value.author;                  //作者
        subject.type = value.type;                    //案例类型
        subject.categoryName = value.categoryName;            //范畴
        subject.tags = value.tags;                    //标签
        subject.frequency = value.frequency;
        subject.phone = value.phone;
        subject.postName = value.postName;
        subject.name = value.name;
        subject.comment = value.comment;
        subject.id = value.id;
        subject.createUser = value.createUser;                //创建人
        subject.timeForOrder = value.timeForOrder;
        subject.email = value.email;
        subject.status = value.status;
        subject.likes = value.likes;
        subject.pageViews = value.pageViews;

        return subject;
    }

    coverSource(size = 's') {
        return SeaImageUtil.getImageSource(this.coverImageId, this.coverImageUrl, size);
    }
}