/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-22 11:27:48
 */
/**
 *  案例cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet } from 'react-native';
import { SeaListCell } from '../../../components';
import CasesCellView from '../view/CasesCellView';
import CasesData from '../data/CasesData';
import Source from '../data/Source';
import { SeaImageUtil } from '../../../util';

export default class CasesListCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => { },
    };

    constructor(props) {
        super(props);
        // if(props.item.caseId==='503899388809052160'){
        //     alert(JSON.stringify(props.item))
        // }
    }

    render() {
        const { item, onPress, ...restProps } = this.props;
        const img = item.imageId || item.coverImageUrl ? SeaImageUtil.getImageSource(item.imageId, item.coverImageUrl)
            : require('../../../asserts/images/list_default_img.jpg');
        return (
            <SeaListCell
                backgroundColor="white"
                showArrow={false}
                showSeparator
                onPress={onPress}
                {...restProps}
            >
                <CasesCellView
                    tags={item.tags ? item.tags : '11111'}
                    id={item.resourceId ? item.resourceId : 'id'}
                    name={item.caseName ? item.caseName : 'xxxx'}
                    summary={item.caseResume ? item.caseResume : '111'}
                    likes={item.likes ? item.likes : 0}
                    comment={item.comment ? item.comment : 0}
                    isLike={item.isLike ? item.isLike : 0}
                    pageViews={item.pageViews ? item.pageViews : 0}
                    caseId={item.caseId ? item.caseId : '1112'}
                    source={img}
                    favorite={item.favorites ? item.favorites == 1 : false}
                    favoriteCount={item.favoriteCount ? item.favoriteCount : 0}
                />
            </SeaListCell>
        );
    }
}
