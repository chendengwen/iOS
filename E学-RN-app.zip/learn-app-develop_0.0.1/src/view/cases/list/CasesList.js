/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-17 09:25:14
 */
/**
 * 案例列表页UI
 */
import React from 'react';
import PropTypes, { number } from 'prop-types';
import { SeaList } from '../../../components';
import CasesListCell from './CasesListCell';
import CasesData from '../data/CasesData';
import { SeaStyle, SeaTheme } from '../../../asserts';
import { View } from 'react-native';
import Source from '../data/Source';
import { CasesService } from '../../../servie';
import SeaListCopy from './SeaListCopy';


export default class CasesList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {

    }

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaListCopy
                ref="list"
                refreshing={true}
                style={SeaStyle.cassList}
                onFetch={onFetch}
                data={defaultData}
                renderItem={this._renderItem}
                ItemSeparatorComponent={() => <View style={{ height: SeaTheme.v_spacing_sm }} />}
            />
        );
    }

    /*
     * @private
     * @description 列表项
     */
    _renderItem = ({ item, index }) => {
        return (
            <CasesListCell
                item={item}
                onPress={() => this.props.onCellPress(item, index)}
                keyword={''}
            />
        );
    };

     /*
     * @private
     * @description 强制控制刷新
     */
    reload = ()=>{
        this.refs.list && this.refs.list.reload();
    }

    scrollToEnd=()=>{
        this.refs.list && this.refs.list.scrollToEnd();
    }

}
