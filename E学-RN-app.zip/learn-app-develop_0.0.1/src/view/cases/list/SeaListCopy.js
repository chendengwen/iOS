/**
 * @author xukj
 * @date 2019/03/04
 * @class
 * @description 统一列表
 * 1.如果设置了onFetch，则使用分页列表
 * 2.如果没设置onFetch，则为普通的FlatList
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, FlatList, Text, InteractionManager } from 'react-native';
import { FSLPagerList, FSLPager } from 'react-native-kpframework';
import ExceptionView from '../../../components/error/ExceptionView';
import { SeaColor, SeaScale } from '../../../asserts';
import FSLPagerListCopy from './FSLPagerListCopy';

export default class SeaListCopy extends React.PureComponent {
    static propTypes = {
        onFetch: PropTypes.func, // 列表网络请求
        data: PropTypes.array, // 默认数据
        emptyTitle: PropTypes.string, // 空文案
        // 只有设置了onFetch才会有效
        loadFirst: PropTypes.bool,
        mapDataToProps: PropTypes.func,
        mapOtherToProps: PropTypes.func,
        onLoadStateChanged: PropTypes.func,
        // ... 其他props与FlatList一致
        numColumns:PropTypes.number,
    };

    static defaultProps = {
        data: [],
        loadFirst: true,
        emptyTitle: '暂时没有获取到数据',
        numColumns:1,
    };

    constructor(props) {
        super(props);
        // 这里有bug，重新render会导致pager重新创建，因此需要提前创建pager
        this.pager = new FSLPager(25);
        this.state = { width: 0, height: 0 };
    }

    componentDidMount() {}

    render() {
        const { onFetch } = this.props;
        return onFetch ? this._renderPageList() : this._renderNormalList();
    }

    /**
     * 分页列表
     */
    _renderPageList = () => {
        const { data, emptyTitle, loadFirst, onFetch, style,numColumns, ...restProps } = this.props;
        this.pager.loader = onFetch;
        
        return (
            <FSLPagerListCopy
                ref={_comp => (this._comp = _comp)}
                style={[{ backgroundColor: SeaColor.defaultBackgroudColor_3 }, style && style]}
                pager={this.pager}
                defaultData={data}
                reload={loadFirst}
                numColumns={numColumns}
                FSLListEmptyComponent={() => <ExceptionView message={emptyTitle} />}
                FSLListNoMoreComponent={() => <Text style={styles.noMore}>没有更多数据</Text>}
                {...restProps}
            />
        );
    };

    /**
     * 普通列表
     */
    _renderNormalList = () => {
        const { data, emptyTitle, style,numColumns, ...restProps } = this.props;
        const { width, height } = this.state;
        return (
            <FlatList
                style={[{ backgroundColor: SeaColor.defaultBackgroudColor_3 }, style && style]}
                data={data}
                keyExtractor={(item, index) => index.toString()}
                ListEmptyComponent={
                    <ExceptionView message={emptyTitle} style={{ width, height }} />
                }
                onLayout={this._onLayout}
                numColumns={numColumns}
                {...restProps}
            />
        );
    };

    /**
     * @private
     * @description 计算组件高度
     */
    _onLayout = event => {
        this.setState({
            width: event.nativeEvent.layout.width,
            height: event.nativeEvent.layout.height,
        });
    };

    /**
     * 受控组件，可直接调用该方法来刷新界面
     */
    reload = () => {
        InteractionManager.runAfterInteractions(() => {
            this._comp && this._comp.reload();
        });
    };
}

const styles = StyleSheet.create({
    noMore: {
        flex: 1,
        textAlign: 'center',
        marginTop: SeaScale.Layout(28),
        marginBottom: SeaScale.Layout(28),
        color: SeaColor.content_text,
        fontSize: SeaScale.Font(28),
    },
});
