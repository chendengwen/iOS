/**
 * 案例列表页
 */
import React from 'react';
import { CasesService, CategoryService } from '../../../servie';
import { Actions } from 'react-native-router-flux';
import { FSLToast, FSLWhiteSpace } from 'react-native-kpframework';
import CasesList from './CasesList';
import { View, StyleSheet, DeviceEventEmitter, Text, TouchableOpacity, BackHandler } from 'react-native';
// import Dropdownmenu from 'react-native-dropdownmenus';
import Dropdownmenu from '../view/DropdownMenu';
import { SeaConstant, SeaScale } from '../../../asserts';
import CasesListCell from './CasesListCell';
import Source from '../data/Source';
import PropTypes from 'prop-types';

let orderBy = '';
let orderByType = 0;
let allSortKey = ['全部'];
let allSortValue = [''];
let dictionaryCode = '';
export default class CasesListPage extends React.PureComponent {
    // 提供给外部的属性
    static propTypes = {
        categoryId: PropTypes.string,
        from: PropTypes.string,
    };

    // 需要设置默认值的属性
    static defaultProps = {
        onCellPress: (item, index) => { },
        categoryId: '',
    };

    constructor(props) {
        super(props);
        // this.state = {
        //     list: [],
        //     pageTo: 1,
        //     pageSize: 25,
        //     changeLoad: false,
        //     dictionaryCode:'',
        // }
        // this._AllSort();
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_CASE,
            this._reloadDetail
        );
        console.log(this.refs);
    }
    _reloadDetail = () => {
        this.refs.detail && this.refs.detail.reload();
    }

    componentWillUnmount() {
        this.listener.remove();
        orderBy = '';
        orderByType = 0;
        allSortKey = ['全部'];
        allSortValue = [''];
        dictionaryCode = '';
    }

    changeSort(selection, position, title) {

        if (title.indexOf('点赞') > 0) {
            // this.setState({ orderBy: 'likes' })
            orderBy = 'likes'
        }
        if (title.indexOf('评论') > 0) {
            // this.setState({ orderBy: 'comment' })
            orderBy = 'comment'
        }
        if (title.indexOf('升序') > 0) {
            // this.setState({ orderByType: 1 })
            orderByType = 1
        }
        if (title.indexOf('降序') > 0) {
            // this.setState({ orderByType: 0 })
            orderByType = 0
        }
        if (selection === 2) {
            dictionaryCode = allSortValue[position]
        }

        // this._AllLoader(this.state.pageTo, this.state.pageSize);
        this._reloadDetail()
    }

    render() {
        let sort = ["按点赞数升序", "按点赞数降序", "按评论数升序", "按评论数降序"]
        let conditionData = [
            ["综合排序", sort],
            // ["上传部门", []],
            // ["全部分类", allSortKey],
            // ["全部分类", []],
        ];

        const { from } = this.props;
        return (
            <View style={from != 'category' ? styles.parent : styles.category}>
                {from != 'category' &&
                    <View style={styles.caseArt}>
                        <Text style={{ height: 80, marginLeft: 20, marginTop: 12, fontSize: 16, color: '#000000' }}>案例中心</Text>
                        {/* <Dropdownmenu
                            style={styles.caseDropdown}
                            bgColor={'white'}
                            tintColor={'#666666'}
                            activityTintColor={'blue'}
                            topic={'案例中心'}
                            // arrowImg={}
                            // checkImage={}
                            // optionTextStyle={{color: '#f00'}}
                            // titleStyle={{color: '#0f0'}}
                            maxHeight={300}
                            handler={(selection, row, title) =>
                                this.changeSort(selection, row, title)
                                // console.log('00000000000', selection, row, title)
                            }

                            data={conditionData}
                        // selectIndex={[0,2,0]}
                        /> */}
                        <TouchableOpacity
                            style={{
                                position: 'absolute', bottom: 2, height: 40, justifyContent: 'center',
                                width: SeaScale.screenWidth / 2, left: 20
                            }}
                            onPress={this._toCategory}
                        >
                            <Text style={{ fontSize: 14, color: '#000000' }}>全部分类</Text>
                        </TouchableOpacity>
                    </View>
                }
                { from != 'category' && <FSLWhiteSpace size={SeaScale.Layout(24)} ></FSLWhiteSpace>}
                <CasesList
                    ref="detail"
                    onFetch={this._AllLoader}
                    onCellPress={this._onCellPress}
                />

            </View>
        );

    }

    _toCategory = () => {
        Actions.show('categoryChoose', { index: 3, from: 'caseCenter' });
    }

    // _renderItem = ({ item, index }) => {
    //     return (
    //         <CasesListCell
    //             item={item}
    //             onPress={() => this.props.onCellPress(item, index)}
    //         />
    //     );
    // };
    /*
     * @private
     * @description 点击事件，查看详情
     */
    _onCellPress = item => {
        Actions.show('caseDetail', { caseId: item.caseId, showComment: false });

    };

    /*
     * @private
     * @description 获取案例列表
     */
    _AllLoader = (pageTo, pageSize) => {
        const { categoryId, from } = this.props
        // return CasesService.getCasesList(pageTo, pageSize, orderBy, orderByType, dictionaryCode, categoryId)
        //     .then(responseJson => {
        //         const result = convertToTableData(responseJson.data.hitList);
        //         const totalPage =
        //             responseJson.data.totalHits === 0 ? 0 : Math.ceil(responseJson.data.totalHits / pageSize);

        //         // this.setState({ list: result, pageTo: pageTo, pageSize: pageSize });
        //         return Promise.resolve({
        //             data: result,
        //             totalPage: totalPage,
        //         })
        //     })
        //     .catch(() => {
        //         FSLToast.show(error.message);
        //         return Promise.reject(error);
        //     });

        return CasesService.queryCaseList({
            "caseName": "",
            "categoryId": categoryId,
            "pageNo": pageTo,
            "pageSize": pageSize,
            "status": "1",
            "userName": ""
        })
            .then(responseJson => {
                const result = convertToTableData(responseJson.data.list);
                const totalPage =
                    responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize);
                return Promise.resolve({
                    data: result,
                    totalPage: totalPage,
                })
            })
            .catch(() => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });

    };

    /**
 * 所有分类
 */
    _AllSort = () => {
        return CasesService.getAllSort()
            .then(responseJson => {
                convertSort(responseJson.data)
                return Promise.resolve({
                    data: responseJson.data
                })
            })
            .catch(() => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            })
    }
}



const convertSort = (list) => {
    if (list && list.length) {
        for (let i = 0; i < list.length; i++) {
            const key = list[i].dictionaryCodeName;
            const value = list[i].dictionaryCode;

            allSortKey.isShowComment = false;
            allSortValue.isShowComment = false;
            allSortKey.push(key);
            allSortValue.push(value);
        }
    }
}

const convertToTableData = (list) => {
    console.log('0000', '列表长度' + list.length)
    let sourceData = [];
    if (list && list.length) {
        for (let i = 0; i < list.length; i++) {
            const item = list[i];
            // 将tags转为数组 
            if (item.tags && item.tags.length) {
                item.tags = item.tags.replace(/[\uff0c]/g, ",");
                item.tags = item.tags.split(',');
            }
            trimSpace(item.tags);
            item.isShowComment = false;
            sourceData.push(item);
        }
    }
    return sourceData;
};

function trimSpace(array) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == "" || array[i] == null || typeof (array[i]) == "undefined") {
            array.splice(i, 1);
            i = i - 1;

        }
    }
    return array;
}

const styles = StyleSheet.create({
    parent: {
        flex: 1,
        position: 'relative',
        paddingTop: 80,
        flexDirection: 'column',
        backgroundColor: '#eeeeee'
    },
    category: {
        flex: 1,
        position: 'relative',
        flexDirection: 'column',
        backgroundColor: '#eeeeee'
    },
    caseArt: {
        position: 'absolute',
        flexDirection: 'column',
        top: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        // marginVertical: 5,
        // justifyContent: 'center',
        // alignContent:'center',
        zIndex: 1
    },
    caseDropdown: {
        zIndex: 9999999999,
        backgroundColor: '#f0f',
        position: 'absolute',
    },
    caseTitle: {
        position: 'absolute',
        top: 10,
        fontSize: 16,
        color: '#000000',
        marginLeft: 20,
        flex: 1,
        height: 20
    },
    caseSort: {
        flexDirection: 'row',
        marginTop: 12,
        alignItems: 'center',
        marginLeft: 20,
        marginRight: 20,
        justifyContent: 'space-between'
    },
    caseSortContent: {
        position: 'absolute',
        flexDirection: 'column',
        marginLeft: 20,
        bottom: 12
    },
    caseList: {
        paddingLeft: 20,
        flex: 1,
        backgroundColor: '#ffffff',
    },
    itemText: {
        height: '75',
    },
})
