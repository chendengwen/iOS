/**
 * @author xukj
 * @date 2018/7/25
 * @description SeaSearchNavigator
 * 搜索栏
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text, Platform, Dimensions } from 'react-native';
import { SeaColor, SeaTheme ,SeaIcon,SeaScale} from '../../../asserts';
import { SeaDevice } from '../../../util';
// import FSLSearchBar from '../../../search/FSLSearchBar';
import SeaButton from '../../../components/button/SeaButton';
import FSLSearchBar from '../../../components/search/FSLSearchBar';
import BackButton from '../../login/BackButton';

export default class SearchWithBack extends React.PureComponent {
    static propTypes = {
        mode: PropTypes.string, // edit / touch 默认edit
        onChangeText: PropTypes.func, // edit mode
        onSubmitEditing: PropTypes.func, // edit mode
        onSearchPress: PropTypes.func, // touch mode

        placeholder: PropTypes.string,
        text: PropTypes.string,
        onCancelPress: PropTypes.func,
    };

    static defaultProps = {
        mode: 'edit',
        onChangeText: event => { },
        onSubmitEditing: event => { },
        onSearchPress: () => { },
        onCancelPress: () => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { onCancelPress, mode } = this.props;
        return (
            <View style={styles.navigator}>
                <SeaButton style={styles.backButton,styles.cancel} onPress={onCancelPress}>
                            <SeaIcon color={'#0C5FDD'} size={SeaScale.Layout(50)} name="back" />
                        </SeaButton>
                {mode === 'edit'
                    ? this._renderEditMode(this.props)
                    : this._renderTouchMode(this.props)}

            </View>
        );
    }

    /*
     * @private
     * @description 编辑模式
     */
    _renderEditMode = props => {
        return (
            <FSLSearchBar
                style={styles.searchBar}
                round
                inputProps={this._inputProps(
                    props.onSubmitEditing,
                    props.onChangeText,
                    props.text,
                    props.placeholder,
                    true
                )}
                iconProps={this._iconProps()}
            />
        );
    };

    /*
     * @private
     * @description 触摸模式
     */
    _renderTouchMode = props => {
        return (
            <FSLSearchBar
                style={styles.searchBar}
                round
                textProps={this._textProps(props.placeholder)}
                iconProps={this._iconProps()}
                onPress={props.onSearchPress}
            />
        );
    };

    _inputProps = (onSubmitEditing, onChangeText, text, placeholder, editable) => {
        return {
            style: styles.input,
            returnKeyType: 'search',
            returnKeyLabel: 'search',
            onSubmitEditing: onSubmitEditing,
            onChangeText: onChangeText,
            defaultValue: text,
            placeholder: placeholder,
            placeholderTextColor: '#999999',
            editable: editable,
            autoFocus: editable,
        };
    };

    _textProps = text => {
        return {
            style: [styles.input, { color: '#999999' }],
            value: text,
        };
    };

    _iconProps = () => {
        return {
            color: '#999999',
        };
    };
}

const { width } = Dimensions.get('window');

// 因为导航栏的特殊性，框架结构不能随屏幕变化而变化
const styles = StyleSheet.create({
    navigator: {
        paddingRight: 50,
        ...Platform.select({
            ios: {
                height: 44 + SeaDevice.iosStatusBarHeight(),
                paddingTop: SeaDevice.iosStatusBarHeight(),
            },
            android: {
                height: 50,
            },
        }),
        width: width,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        elevation: 1,
    },
    touch: {
        height: 30,
        flex: 1,
    },
    searchBar: {
        height: 30,
        flex: 1,
        backgroundColor: '#eeeeee',
    },
    input: {
        color: 'white',
        fontSize: SeaTheme.font_size_md,
    },
    cancel: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 60,
        height: 30,
    },
    cancel_title: {
        fontSize: SeaTheme.font_size_lg,
        color: 'white',
    },
    backButton: {
        position: 'absolute',
        width: 44,
        height: 44,
        left: 0,
        ...Platform.select({
            ios: {
                top: SeaDevice.iosStatusBarHeight(),
            },
        }),
        alignItems: 'center',
        justifyContent: 'center',
    },
});
