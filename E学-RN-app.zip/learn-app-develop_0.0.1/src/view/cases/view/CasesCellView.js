/*
 * @Author: ouyfm
 * @Date: 2020-06-22 13:47:35
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-17 18:04:12
 * @Descripttion:
 */
/**
 * 案例Cell样式view
 */
import React from 'react';
import PropTypes, { arrayOf } from 'prop-types';
import { StyleSheet, View, Text, Image, DeviceEventEmitter } from 'react-native';
import { SeaColor, SeaScale, SeaTheme, SeaConstant } from '../../../asserts';
import { SeaCoverImage, SeaButton, SeaFavoriteButton } from '../../../components';
import { CasesService } from '../../../servie';
import { FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { toArray } from 'lodash';
import { ResourceService } from '../../../servie';

export default class CasesCellView extends React.PureComponent {
    static propTypes = {
        name: PropTypes.string,
        author: PropTypes.string,
        time: PropTypes.string,
        source: PropTypes.object,
        coverChildren: PropTypes.node,
        score: PropTypes.string,

        summary: PropTypes.string,
        likes: PropTypes.number,
        comment: PropTypes.number,
        tags: PropTypes.array,
        id: PropTypes.string,
        isLike: PropTypes.string,
        pageViews: PropTypes.number,
        caseId: PropTypes.string,
        keyword: PropTypes.string,
        favorite: PropTypes.bool,
        favoriteCount: PropTypes.number,
    };

    static defaultProps = {
    };

    constructor(props) {
        super(props);
    }
    componentDidMount() {
        // if (this.props.from === 'search') {
        //     this._getFavoriteInfo();
        // }
    }

    _keywordName = (keyword, strins) => {
        let data = strins; //   获取文本
        // let keys = toArray(keyword)
        let newData = data.split(keyword); //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.title} numberOfLines={1}>
                {newData.map((item, index) => {
                    return (
                        <Text key={index}>
                            {item}
                            {index < newData.length - 1 && (
                                <Text style={{ color: 'red' }}>{keyword}</Text>
                            )}
                        </Text>
                    );
                })}
            </Text>
        );
    };

    _keywordTag = (keyword, strins) => {
        let data = strins; //   获取文本
        let newData = data.split(keyword); //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.tagText} numberOfLines={1}>
                {newData.map((item, index) => {
                    return (
                        <Text key={index}>
                            {item}
                            {index < newData.length - 1 && (
                                <Text style={{ color: 'red' }}>{keyword}</Text>
                            )}
                        </Text>
                    );
                })}
            </Text>
        );
    };

    _keywordSummary = (keyword, strins) => {
        let data = strins; //   获取文本
        let newData = data.split(keyword); //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.time} numberOfLines={2}>
                概要：
                {newData.map((item, index) => {
                    return (
                        <Text key={index}>
                            {item}
                            {index < newData.length - 1 && (
                                <Text style={{ color: 'red' }}>{keyword}</Text>
                            )}
                        </Text>
                    );
                })}
            </Text>
        );
    };

    render() {
        const {
            name,
            source,
            coverChildren,
            comment,
            summary,
            likes,
            tags,
            isLike,
            pageViews,
            keyword,
            favorite,
            favoriteCount
        } = this.props;

        return (
            <View style={styles.parent}>
                <View style={styles.content}>
                    <SeaCoverImage style={styles.cover} source={source}>
                        {coverChildren && coverChildren}
                    </SeaCoverImage>
                    <View style={styles.rightContent}>
                        {/* <Text style={styles.title} numberOfLines={1}>
                           {name}
                        </Text> */}
                        <View>
                            {name.includes(keyword) ? (
                                this._keywordName(keyword, name)
                            ) : (
                                    <Text style={styles.title} numberOfLines={1}>
                                        {name}
                                    </Text>
                                )}
                        </View>
                        {/* <Text style={styles.desc}>创建人：{summary}</Text> */}

                        <View style={styles.tagContainer}>
                            {tags && tags.length >= 1 && (
                                // <Text style={styles.tagText} numberOfLines={1}>{tags[0]} </Text>
                                <View>
                                    {tags[0].includes(keyword) ? (
                                        this._keywordTag(keyword, tags[0])
                                    ) : (
                                            <Text style={styles.tagText} numberOfLines={1}>
                                                {tags[0]}{' '}
                                            </Text>
                                        )}
                                </View>
                            )}
                            {tags && tags.length >= 2 && (
                                // <Text style={styles.tagText} numberOfLines={1}>{tags[1]} </Text>
                                <View>
                                    {tags[1].includes(keyword) ? (
                                        this._keywordTag(keyword, tags[1])
                                    ) : (
                                            <Text style={styles.tagText} numberOfLines={1}>
                                                {tags[1]}{' '}
                                            </Text>
                                        )}
                                </View>
                            )}
                            {tags && tags.length >= 3 && (
                                // <Text style={styles.tagText} numberOfLines={1}>{tags[2]} </Text>
                                <View>
                                    {tags[2].includes(keyword) ? (
                                        this._keywordTag(keyword, tags[2])
                                    ) : (
                                            <Text style={styles.tagText} numberOfLines={1}>
                                                {tags[2]}{' '}
                                            </Text>
                                        )}
                                </View>
                            )}
                        </View>

                        {/* <Text style={styles.time} numberOfLines={2}>概要：{summary}</Text> */}
                        <View>
                            {summary.includes(keyword) ? (
                                this._keywordSummary(keyword, summary)
                            ) : (
                                    <Text style={styles.time} numberOfLines={2}>
                                        概要：{summary}
                                    </Text>
                                )}
                        </View>
                    </View>
                </View>

                <View style={styles.divider}></View>

                <View style={styles.bottomContent}>
                    <SeaButton style={styles.bar_button} onPress={this._onPageViewsPress}>
                        <Image
                            style={styles.bar_icon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/case/preview.png')}
                        />
                        <Text style={styles.num}>{pageViews}</Text>
                    </SeaButton>

                    <SeaButton style={styles.bar_button} onPress={this._onCommentPress}>
                        <Image
                            style={styles.bar_icon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/case/comment.png')}
                        />
                        <Text style={styles.num}>{comment}</Text>
                    </SeaButton>

                    <SeaButton style={styles.bar_button} onPress={this._onLikPress}>
                        <Image
                            style={[styles.bar_icon, isLike == 1 && { tintColor: SeaColor.main }]}
                            ref="imagelike"
                            resizeMode="contain"
                            source={require('../../../asserts/images/case/likes.png')}
                        />
                        <Text
                            style={[styles.num, isLike == 1 && { color: SeaColor.main }]}
                            ref="textlike"
                        >
                            {likes}
                        </Text>
                    </SeaButton>

                    <SeaButton style={styles.bar_button} onPress={this._onFavoritePress}>
                        <Image
                            style={[
                                styles.bar_icon,
                                favorite && { tintColor: SeaColor.main },
                            ]}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic_favorite_grey.png')}
                        />
                        <Text style={[styles.num, favorite && { color: SeaColor.main }]}>
                            {favoriteCount}
                        </Text>
                    </SeaButton>
                </View>
            </View>
        );
    }
    _onLikPress = () => {
        var myid = this.props.caseId;
        var myislike = this.props.isLike == 1 ? 0 : 1;

        return CasesService.giveLikeCase(myid, myislike) //'1c205f12-9a8e-11ea-9830-005056b49f85'
            .then((responseJson) => {
                if (responseJson.code === '000000') {
                    DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASE);
                } else {
                    FSLToast.show(responseJson.msg);
                }
            })
            .catch((error) => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onFavoritePress = () => {
        this._toggleFavorite();
    };

    // _getFavoriteInfo = () => {
    //     ResourceService.getFavoriteStatus({ businessId: this.props.caseId, businessType: SeaConstant.ResourceType.CASE })
    //         .then((responseJson) => {
    //             if (responseJson.code === '000000') {
    //                 DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASE);
    //             } else {
    //                 FSLToast.show(responseJson.msg);
    //             }
    //         })
    //         .catch((error) => {
    //             FSLToast.show(error.message);
    //         });
    // };

    _toggleFavorite = () => {
        ResourceService.toggleFavoriteStatus({ businessId: this.props.caseId, businessType: SeaConstant.ResourceType.CASE })
            .then((responseJson) => {
                if (responseJson.code === '000000') {
                    DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASE);
                } else {
                    FSLToast.show(responseJson.msg);
                }
            })
            .catch((error) => {
                FSLToast.show(error.message);
            });
    };

    _onPageViewsPress = () => {
        Actions.show('caseDetail', { caseId: this.props.caseId, showComment: false });
    };

    _onCommentPress = () => {
        //业务类型(8：讲师 9:案例)businessId:"b962a7b7-2724-47fd-8559-9619da752f53"
        // alert(JSON.stringify(this.props.id))
        Actions.show('caseEvaluateDetailPage', { businessType: '9', businessId: this.props.caseId });
    };
}

const BAR_HEIGHT = SeaScale.Layout(88);
const IMAGE_BTN_WIDTH = SeaScale.Layout(150);
const IMAGE_BTN_HEIGHT = SeaScale.Layout(60);
const ICON_SIZE = SeaScale.Layout(38);

const styles = StyleSheet.create({
    parent: {
        flexDirection: 'column',
        borderRadius: 5,
        color: '#ffffff',
    },
    content: {
        flex: 1,
        flexDirection: 'row',
        height: SeaScale.Layout(250),
        marginTop: 31,
        color: '#fff',
    },
    divider: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: SeaColor.parting_line,
        height: 0.5,
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    rightContent: {
        flex: 1,
        height: SeaScale.Layout(176),
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    bottomContent: {
        flex: 1,
        flexDirection: 'row',
        height: SeaScale.Layout(66),
        justifyContent: 'space-between',
        alignItems: 'center',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    child1: {
        flex: 1,
        textAlign: 'center',
    },
    cover: {
        width: SeaScale.Layout(160),
        height: SeaScale.Layout(100),
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        borderRadius: SeaTheme.raduis_sm,
        marginLeft: SeaTheme.h_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    desc: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    time: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
    bar_icon: {
        width: ICON_SIZE,
        height: ICON_SIZE,
    },
    bar_button: {
        width: IMAGE_BTN_WIDTH,
        height: IMAGE_BTN_HEIGHT,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
    },
    bar_txt: {
        color: SeaColor.content_text,
        marginRight: SeaScale.Layout(6),
        fontSize: SeaTheme.font_size_xxs,
    },
    num: {
        marginLeft: 5,
        color: SeaColor.grey,
    },
    tagContainer: {
        flexDirection: 'row',
        width: SeaScale.Layout(100),
    },
    tagImage: {
        width: SeaScale.Layout(56),
        height: SeaScale.Layout(28),
        marginRight: SeaScale.Layout(6),
    },
    tagText: {
        width: SeaScale.Layout(128),
        height: SeaScale.Layout(40),
        borderRadius: 3,
        borderColor: '#FCFCD2',
        backgroundColor: '#FCFCD2',
        borderWidth: 0.5,
        fontSize: SeaTheme.font_size_sm,
        color: '#E5B83D',
        textAlign: 'center',
        marginRight: 5,
    },
});
