/**
 * @author xukj
 * @date 2018/9/3
 * @description 资源搜索容器 - 自带搜索导航栏 content和other为扩展组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { ResourceSearchHistoryPage } from '../../resource';
import { SeaStyle } from '../../../asserts';
import SearchTitleWithBack from './SearchTitleWithBack';

export default class SearchWithBackTemplate extends React.PureComponent {
    static propTypes = {
        // 内容部分
        content: PropTypes.node,
        other: PropTypes.node,
        // 搜索分类
        category: PropTypes.string,
        // 搜索分类
        placeholder: PropTypes.string,
    };

    static defaultProps = {
        placeholder : "输入搜索内容",
    };

    constructor(props) {
        super(props);
        this.state = { search: false };
    }

    render() {
        const doSearch = _.curry(this._doSearch)(this.props.category);
        return (
            <View style={SeaStyle.page}>
                <SearchTitleWithBack
                    mode="touch"
                    onCancelPress={Actions.pop}
                    onSearchPress={this._showSearchHistory}
                    placeholder={this.props.placeholder}
                />
                <ResourceSearchHistoryPage
                    show={this.state.search}
                    onSearch={doSearch}
                    onCancel={this._hideSearchHistory}
                    placeholder={this.props.placeholder}
                />
                {this.props.content}
                {this.props.other}
            </View>
        );
    }

    /*
     * @private
     * @description 展示搜索历史
     */
    _showSearchHistory = () => {
        this.setState({ search: true });
    };

    /*
     * @private
     * @description 关闭搜索历史
     */
    _hideSearchHistory = () => {
        this.setState({ search: false });
    };

    /*
     * @private
     * @description 执行搜索
     */
    _doSearch = (category, keyword) => {
        this.setState({ search: false });
        const text = _.trim(keyword);
        if (text.length > 0) {
            Actions.show('searchResourceList', { keyword: text, category: category });
        }
    };
}
