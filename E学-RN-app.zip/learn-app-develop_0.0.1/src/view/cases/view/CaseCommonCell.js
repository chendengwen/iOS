/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-10-16 18:07:14
 */
/**
 * @author xukj
 * @date 2019/08/15
 * @description 搜索的专题结果cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { SeaListCell, SeaFlagText } from '../../../components';
import CasesCellView from './CasesCellView';
import Source from '../data/Source';
import { SeaImageUtil } from '../../../util';
import { ResourceService } from '../../../servie';
import { FSLToast } from 'react-native-kpframework';
import { SeaConstant } from '../../../asserts';
import { DeviceEventEmitter } from 'react-native';

export default class CaseCommonCell extends React.PureComponent {
    // 提供给外部的属性
    static propTypes = {
        item: PropTypes.instanceOf(Source).isRequired,
        onPress: PropTypes.func,
        keyword: PropTypes.string,
    };

    // 需要设置默认值的属性
    static defaultProps = {
        onPress: () => { },
    };
    constructor(props) {
        super(props);
        this._getFavoriteInfo()
        this.state = {
            favorite: false,
            favoriteCount: 0,
        }
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_CASE,
            this._getFavoriteInfo
        );
    }

    componentWillUnmount() {
        this.listener.remove();
    }

    _getFavoriteInfo = () => {
        ResourceService.getFavoriteStatus({ businessId: this.props.item.id, businessType: SeaConstant.ResourceType.CASE })
            .then((responseJson) => {
                if (responseJson.code === '000000') {
                    this.setState({
                        favorite: responseJson.data.favorite,
                        favoriteCount: responseJson.data.favoriteCount
                    })
                } else {
                    FSLToast.show(responseJson.msg);
                }
            })
            .catch((error) => {
                FSLToast.show(error.message);
            });
    };

    render() {
        const { item, onPress, keyword, ...restProps } = this.props;
        convertToTableData(item);
        const img = item.imageId || item.coverImageUrl ? SeaImageUtil.getImageSource(item.imageId, item.coverImageUrl)
            : require('../../../asserts/images/list_default_img.jpg');
        return (
            <SeaListCell
                backgroundColor="white"
                showArrow={false}
                showSeparator
                onPress={onPress}
                {...restProps}
            >
                <CasesCellView
                    tags={item.tags ? item.tags : '11111'}
                    id={item.id ? item.id : 'id'}
                    name={item.name ? item.name : 'xxxx'}
                    summary={item.summary ? item.summary : '111'}
                    likes={item.likes ? item.likes : 0}
                    comment={item.comment ? item.comment : 0}
                    isLike={item.isLike ? item.isLike : 0}
                    pageViews={item.pageViews ? item.pageViews : 0}
                    caseId={item.id ? item.id : '1112'}
                    // source={item.coverSource()}
                    coverChildren={<SeaFlagText>案例</SeaFlagText>}
                    keyword={keyword}
                    source={img}
                    // favorite={item.favorites ? item.favorites == 1 : false}
                    // favoriteCount={item.favoritesCount ? item.favoritesCount : 0}
                    favorite={this.state.favorite}
                    favoriteCount={this.state.favoriteCount}
                />
            </SeaListCell>
        );
    }
}

const convertToTableData = (item) => {
    // item.tags = item.tags && item.tags.length > 0 ? (item.tags + '').split(",") : [];
    if (item.tags && item.tags.length) {
        item.tags = (item.tags + '').replace(/[\uff0c]/g, ",");
        item.tags = item.tags.split(',');
    }
    if (item.tags) {
        trimSpace(item.tags);
    }

    return item;
};

function trimSpace(array) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == "" || array[i] == null || typeof (array[i]) == "undefined") {
            array.splice(i, 1);
            i = i - 1;

        }
    }
    return array;
}
