import React from 'react';
import PropTypes from 'prop-types';
import { ScrollView, View, StyleSheet, Text ,Image} from 'react-native';
import Source from '../data/Source';
import { SeaConstant, SeaTheme,SeaScale } from '../../../asserts';

export default class CaseDetail extends React.Component {
    static propTypes = {
        item: PropTypes.instanceOf(Source).isRequired,
    };

    static defaultProps = {
    };
    constructor(props) {
        super(props);
        // alert(JSON.stringify(props.item.tags))
    }

    render() {
        const { item, ...restProps } = this.props;
        return (
            <ScrollView backgroundColor='white'>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>案例名称</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.name} </Text>
                    </View>
                </View>

                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>案例所属范畴</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.categoryName} </Text>
                    </View>
                </View>

                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>案例分类</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.type} </Text>
                    </View>
                </View>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>设置标签</Text>
                    <View style={styles.rightContex} >
                        {(item.tags && item.tags.indexOf('必选课程') >= 0) && (
                           <Text style = {styles.tagText} >必选课程</Text>
                        )}
                        {(item.tags && item.tags.indexOf('冲刺课程') >= 0) && (
                          <Text style = {styles.tagText} >冲刺课程</Text>
                        )}
                    </View>
                </View>

                <View style={styles.summary}>
                    <Text style={styles.caseText}>案例概要</Text>
                    <View style={styles.summaryContext} >
                        <Text style={styles.summaryScribe} >    {item.summary} </Text>
                    </View>
                </View>

                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>提交人姓名</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.author} </Text>
                    </View>
                </View>

                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>提交人账号</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.createUser} </Text>
                    </View>
                </View>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>邮箱</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.email} </Text>
                    </View>
                </View>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>岗位名称</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.postName} </Text>
                    </View>
                </View>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>电话</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.phone} </Text>
                    </View>
                </View>
                <View style={styles.caseItem}>
                    <Text style={styles.caseText}>所属部门</Text>
                    <View style={styles.rightContex} >
                        <Text style={styles.caseScribe} numberOfLines={1}>{item.deptName} </Text>
                    </View>
                </View>
                <View style={{ height: 150 }}>

                </View>
            </ScrollView>
        )
    }
}

const styles = StyleSheet.create({
    parent: {
        flex: 1,
        backgroundColor: 'white',
    },
    caseItem: {
        flex: 1,
        flexDirection: 'row',
        marginVertical: 10,
    },
    caseText: {
        flex: 1,
        color: '#333',
        fontSize: SeaTheme.font_size_xxxl,
        marginLeft: 20

    },
    rightContex: {
        flex: 1,
        color: '#999',
        fontSize: SeaTheme.font_size_xl,
        position: 'absolute',
        right: 20,
        left: 150,
        flexDirection: 'row-reverse'
    },
    caseScribe: {
        color: '#999',
        fontSize: SeaTheme.font_size_xl,
        alignItems: 'flex-start'
    },
    summary: {
        flex: 1,
        flexDirection: 'column',
        marginVertical: 10,
    },
    summaryContext: {
        height: 120,
        marginLeft: 20,
        marginRight: 20,
        marginVertical: 10,
        backgroundColor: '#f5f5f5',
        borderRadius: 10,
        justifyContent: 'center'
    },
    summaryScribe: {
        color: '#999',
        fontSize: SeaTheme.font_size_xl,
        alignItems: 'flex-start'
    },
    tagText: {
        width: SeaScale.Layout(120),
        height: SeaScale.Layout(40),
        borderRadius:3,
        borderColor:'#1a5ff7',
        borderWidth:0.5,
        fontSize: SeaTheme.font_size_sm,
        color: '#1a5ff7',
        textAlign:'center', 
    },
})