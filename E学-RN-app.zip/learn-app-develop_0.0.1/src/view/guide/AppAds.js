/**
 * @author xukj
 * @date 2019/12/27
 * @class
 * @description 界面展示组件AppAds
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Image } from 'react-native';
import { SeaScale, SeaTheme, SeaStyle } from '../../asserts';
import { StatusBar } from 'react-native';
import { SeaCoverImage, SeaTextButton, SeaButton } from '../../components';

export default class AppAds extends React.PureComponent {
    static propTypes = {
        counting: PropTypes.number,
        source: PropTypes.any,
        onSkip: PropTypes.func,
        onPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { source, counting, onSkip, onPress } = this.props;
        return (
            <SeaButton style={SeaStyle.page} onPress={onPress}>
                <StatusBar hidden />
                <Image style={StyleSheet.absoluteFill} source={source} resizeMode="contain" />
                <SeaTextButton style={styles.skip} title={`跳过 ${counting}`} onPress={onSkip} />
            </SeaButton>
        );
    }
}

const styles = StyleSheet.create({
    skip: {
        position: 'absolute',
        top: SeaScale.Layout(100),
        right: SeaTheme.h_spacing_md,
        paddingHorizontal: SeaTheme.h_spacing_sm,
        height: SeaScale.Layout(50),
        borderRadius: SeaScale.Layout(25),
    },
});
