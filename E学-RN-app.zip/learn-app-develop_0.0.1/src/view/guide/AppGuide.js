/**
 * @author xukj
 * @date 2018/8/6
 * @description app导航页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, ScrollView, Image, StatusBar, Platform } from 'react-native';
import { SeaScale, SeaStyle } from '../../asserts';
import { SeaButton } from '../../components';

export default class AppGuide extends React.PureComponent {
    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { images, onClose } = this.props;
        const pages = images.map((image, index, arr) => {
            // 防止无法关闭引导页，在最后一页添加触摸关闭功能
            return this._renderGuide(image, index, index >= arr.length - 1 ? onClose : undefined);
        });
        const onScroll = this._onScroll(onClose, images.length);
        return (
            <View style={SeaStyle.page}>
                <StatusBar hidden={true} />
                <ScrollView
                    style={styles.page}
                    horizontal={true}
                    pagingEnabled={true}
                    keyboardDismissMode="on-drag"
                    showsHorizontalScrollIndicator={false}
                    onScrollEndDrag={onScroll}
                >
                    {pages}
                </ScrollView>
            </View>
        );
    }

    /*
     * @private
     * @description 展示引导页
     */
    _renderGuide(image, index, onClose) {
        return (
            <View key={index}>
                <Image style={styles.guide} source={image} resizeMode="contain" />
                {onClose ? (
                    <SeaButton style={styles.close} onPress={onClose}>
                        <View style={styles.close} />
                    </SeaButton>
                ) : null}
            </View>
        );
    }

    /*
     * @private
     * @description 监听滚动
     */
    _onScroll(onClose, count) {
        return event => {
            const offsetX = event.nativeEvent.contentOffset.x;
            if (Platform.OS === 'ios') {
                if (offsetX > SeaScale.screenWidth * (count - 0.8 > 0 ? count - 0.8 : 0)) {
                    onClose();
                }
            } else {
                // android无弹性，因此直接判断页数
                // 因为android部分机型适配问题，需要微调offset
                if (offsetX + 10 >= SeaScale.screenWidth * (count - 1 > 0 ? count - 1 : 0)) {
                    onClose();
                }
            }
        };
    }
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: 'white',
    },
    guide: {
        width: SeaScale.screenWidth,
        height: SeaScale.screenHeight,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
    },
    info: {},
    close: {
        width: SeaScale.screenWidth - 80,
        height: SeaScale.screenHeight / 3 - 40,
        position: 'absolute',
        bottom: 40,
        left: 40,
        backgroundColor: 'transparent',
    },
});

// 提供给外部的属性
AppGuide.propTypes = {
    images: PropTypes.array,
    onClose: PropTypes.func,
};

// 需要设置默认值的属性
AppGuide.defaultProps = {
    images: [],
    onClose: () => {},
};
