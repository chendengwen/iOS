/**
 * @author xukj
 * @date 2019/12/27
 * @class
 * @description 广告页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Platform } from 'react-native';
import AppAds from './AppAds';
import { LinkingActions } from '../resource';
import { SeaConstant } from '../../asserts';

export default class AppAdsPage extends React.PureComponent {
    static propTypes = {
        ads: PropTypes.array,
    };

    static defaultProps = {
        ads: [],
        onClose: () => {},
    };

    constructor(props) {
        super(props);
        this.timer;
        this.state = { counting: SeaConstant.AdsCounting };
    }

    componentDidMount() {
        this._startTimer();
    }

    componentWillUnmount() {
        this._stopTimer();
    }

    render() {
        const imageUri = _.last(this.props.ads, {}).imagePath;
        const { counting } = this.state;
        return (
            <AppAds
                source={{ uri: Platform.OS == 'android' ? `file://${imageUri}` : imageUri }}
                counting={counting}
                onSkip={this._skipAds}
                onPress={this._showAds}
            />
        );
    }

    _skipAds = () => {
        this.props.onClose && this.props.onClose();
        this._stopTimer();
    };

    _showAds = () => {
        const latestAds = _.last(this.props.ads, {});
        LinkingActions.browser(latestAds.url);
    };

    _startTimer = () => {
        this.timer = setInterval(() => {
            if (this.state.counting <= 0) {
                // 倒计时结束
                this._skipAds();
            } else {
                // 更新倒计时
                this.setState(prevState => ({ counting: prevState.counting - 1 }));
            }
        }, 1000);
    };

    _stopTimer = () => {
        this.timer && clearInterval(this.timer);
    };
}
