/**
 * Created by xukj on 2018/8/6.
 *
 */
import React from 'react';
import PropTypes from 'prop-types';
import AppGuide from './AppGuide';
import GuideStorageLoader from './GuideStorageLoader';

/**
 * @author xukj
 * @date 2018/8/6
 * @description 交互界面 AppGuidePage 引导页
 * 条件：1.安装后首次打开；2.更新后首次打开；
 */
export default class AppGuidePage extends React.PureComponent {
    constructor(props) {
        super(props);
    }

    componentDidMount() {

    }

    render() {
        const onGuideClose = this._onGuideClose(this.props.onClose);
        const images = [
            require('../../asserts/images/guide/guide01.jpg'),
            require('../../asserts/images/guide/guide02.jpg'),
            require('../../asserts/images/guide/guide03.jpg'),
        ];
        return (
            <AppGuide images={images} onClose={onGuideClose} />
        );
    }

    /*
     * @private
     * @description 引导页关闭，保存状态
     */
    _onGuideClose(onClose) {
        return () => {
            // 保存状态
            GuideStorageLoader.saveCurrentVersionForGuideShown();
            // 外部回调
            onClose();
        };
    }
}

// 提供给外部的属性
AppGuidePage.propTypes = {
    onClose: PropTypes.func,
};

// 需要设置默认值的属性
AppGuidePage.defaultProps = {
    onClose: () => {},
};