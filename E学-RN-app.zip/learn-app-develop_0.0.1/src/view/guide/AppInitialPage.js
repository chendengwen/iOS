/**
 * Created by xukj on 2018/8/16.
 *
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, InteractionManager } from 'react-native';
import { SeaLoading } from '../../components';
import SplashScreen from 'react-native-splash-screen';
import GuideStorageLoader from './GuideStorageLoader';
import { SessionStorageService } from '../../servie';
import { Actions, ActionConst } from 'react-native-router-flux';
import { UserSessionManager } from '../login';
import { SeaStyle } from '../../asserts';
import { SeaAds } from '../../util';

/**
 * @author xukj
 * @date 2018/8/16
 * @description 交互界面 AppInitialPage
 * App初始化的等待界面
 */
export default class AppInitialPage extends React.PureComponent {
    // 获取广告页数据
    // Promise.resolve(array)
    _adsLoader = SeaAds.getAds();

    // 获取引导页数据
    // Promise.resolve(boolean)
    _guideLoader = new Promise(resolve => {
        GuideStorageLoader.isCurrentVersionForGuideShown(result => {
            resolve(result);
        });
    });

    // 获取登录用户数据
    // Promise.resolve(object)
    _userLoader = new Promise(resolve => {
        SessionStorageService.loadLatestLoginSession()
            .then(user => {
                resolve(user);
            })
            .catch(() => {
                resolve(null);
            });
    });

    constructor(props) {
        super(props);
        this._showInitialPage = this._showInitialPage.bind(this);
    }

    componentDidMount() {
        InteractionManager.runAfterInteractions(() => {
            this._showInitialPage();
        });
    }

    render() {
        return (
            <View style={SeaStyle.page}>
                <SeaLoading />
            </View>
        );
    }

    /*
     * @private
     * @description 显示第一个界面。逻辑如下
     * 1.如果为首次打开或更新后的首次打开，展示引导页
     * 2.如果不满足1，判断是否登录，如果登录展示tab
     * 3.如果1、2都不满足，展示登录页
     * 通过设置state来控制第一个展示的页面
     */
    _showInitialPage(skipGuide = false, skipAds = false) {
        // const guideLoader = new Promise(resolve => {
        //     GuideStorageLoader.isCurrentVersionForGuideShown(result => {
        //         resolve(result);
        //     });
        // });

        // const userLoader = new Promise(resolve => {
        //     SessionStorageService.loadLatestLoginSession()
        //         .then(user => {
        //             resolve(user);
        //         })
        //         .catch(() => {
        //             resolve(null);
        //         });
        // });

        // // 获取广告页数据
        // const adLoader = SeaAds.getAds();

        Promise.all([this._guideLoader, this._userLoader, this._adsLoader]).then(results => {
            const shown = results[0];
            const user = results[1];
            const ads = results[2];
            // console.log('init', { shown, user, ads });
            if (!skipAds && !_.isEmpty(ads)) {
                // 1. 如果有广告页，首先显示广告页
                Actions.show('appAdsPage', {
                    ads,
                    onClose: () => this._showInitialPage(false, true),
                });
            }
            // 需要手动跳转, Router不允许重复注册，因此多次render是无效的
            else if (!shown && !skipGuide) {
                // 2. 如果未显示过引导页，则显示引导页
                Actions.show('appGuidePage', { onClose: () => this._showInitialPage(true, true) });
            } else if (user) {
                // 3. 如果有用户信息，则自动登录
                UserSessionManager.signIn(user);
            } else {
                // 4. 进入登录页
                Actions.show('account');
            }

            SplashScreen.hide();
        });
    }
}
