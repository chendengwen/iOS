/**
 * @author xukj
 * @date 2019/08/05
 * @description 阅读计划列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, View, Image, StyleSheet } from 'react-native';
import { ListDeleteCell, SeaCoverImage } from '../../../components';
import { SeaImageUtil } from '../../../util';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';

export default class BookToLearnCell extends React.PureComponent {
    static propTypes = {
        // data
        data: PropTypes.object,
        index: PropTypes.number,
        // cell点击
        onPress: PropTypes.func, // 点击事件
        onDeletePress: PropTypes.func, // 删除按钮点击
        onRowOpen: PropTypes.func,
        onRowClose: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => { },
        onDeletePress: () => { },
    };

    closeRow = () => {
        if (this._comp) this._comp.closeRow();
    };

    constructor(props) {
        super(props);
        this._comp;
    }

    // render() {
    //     return this._renderSwipeCommonItem(this.props);
    // }

    // 默认展示的组件
    // _renderSwipeCommonItem = props => 
    render() {
        const { data, style, onRowOpen, onRowClose, onPress, onDeletePress, ...restProps } = this.props;
        return (
            <ListDeleteCell
                ref={_comp => (this._comp = _comp)}
                style={[style, styles.cell]}
                onRowOpen={this._onRowOpen(onRowOpen)}
                onRowClose={this._onRowClose(onRowClose)}
                onPress={this._onPress(onPress)}
                onDeletePress={this._onDeletePress(onDeletePress)}
                {...restProps}
            >
                <View style={styles.courseContainer}>
                    <SeaCoverImage
                        style={styles.courseCoverImage}
                        source={SeaImageUtil.getImageSource(data.coverImageId, data.coverImageUrl)}
                    >
                        <this._renderUnderCarriage item={data} />
                    </SeaCoverImage>
                    <View style={styles.courseMiddlePanel}>
                        <Text style={styles.courseTitleText} numberOfLines={3}>
                            {data.resourceName}
                        </Text>
                        <this._renderValidDateFlag item={data} />
                        <View style={styles.tagContainer}>
                            {Number(data.required) === 1 && (
                                <Image
                                    style={styles.tagImage}
                                    source={require('../../../asserts/images/tolearn/force.png')}
                                />
                            )}
                            {Number(data.required) === 2 && (
                                <Image
                                    style={styles.tagImage}
                                    source={require('../../../asserts/images/tolearn/choose.png')}
                                />
                            )}
                            {Number(data.required) === 3 && (
                                <Image
                                    style={styles.tagImage}
                                    source={require('../../../asserts/images/tolearn/self.png')}
                                />
                            )}
                        </View>
                    </View>
                </View>
            </ListDeleteCell>
        );
    };

    // 长期有效展示
    _renderValidDateFlag = props => {
        const { item } = props;
        const time = item.endTime !== null ? item.endTime : '长期有效';
        const showDate = time !== '长期有效' ? '到期时间：' + time : '长期有效';
        return <Text style={styles.courseDetailText}>{showDate}</Text>;
    };

    // 下架展示
    _renderUnderCarriage = props => {
        const { item } = props;
        const status = item.status == 2;
        if (status) {
            return (
                <View style={styles.maskView}>
                    <View style={styles.unavailableView}>
                        <Text style={styles.maskTag}>已下架</Text>
                    </View>
                </View>
            );
        } else {
            return null;
        }
    };

    _onRowOpen = onRowOpen => () => {
        if (onRowOpen) onRowOpen(this._comp);
    };

    _onRowClose = onRowClose => () => {
        if (onRowClose) onRowClose(this._comp);
    };

    _onPress = onPress => () => {
        if (onPress) onPress(this._comp);
    };

    _onDeletePress = onDeletePress => () => {
        if (onDeletePress) onDeletePress(this._comp);
    };
}

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(300),
    },
    courseContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        flex: 1,
    },
    courseCoverImage: {
        width: SeaScale.Layout(200),
        height: SeaScale.Layout(266),
        backgroundColor: SeaColor.img_background,
        marginLeft: SeaTheme.h_spacing_md,
    },
    courseMiddlePanel: {
        height: SeaScale.Layout(266),
        flex: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        paddingVertical: SeaScale.Layout(8),
    },
    courseTitleText: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    courseDetailText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.tag_text,
    },
    tagContainer: {
        flexDirection: 'row',
        width: SeaScale.Layout(100),
    },
    maskView: {
        ...StyleSheet.absoluteFill,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    unavailableView: {
        borderWidth: 2,
        borderColor: SeaColor.red,
        width: SeaScale.Layout(140),
        height: SeaScale.Layout(50),
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderRadius: SeaTheme.raduis_sm,
    },
    maskTag: {
        color: SeaColor.red,
        fontSize: SeaTheme.font_size_sm,
        fontWeight: 'bold',
    },
    tagImage: {
        width: SeaScale.Layout(56),
        height: SeaScale.Layout(28),
        marginRight: SeaScale.Layout(6),
    },
});
