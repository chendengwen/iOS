/**
 * @author xukj
 * @date 2019/08/05
 * @class
 * @description 阅读计划列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { FSLToast, FSLPrompt } from 'react-native-kpframework';
import BookToLearn from './BookToLearn';
import { ToLearnService } from '../../../servie';
import { SeaConstant } from '../../../asserts';
import { Actions } from 'react-native-router-flux';

export default class BookToLearnPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey;
        this._list;
    }

    componentDidMount() {}

    render() {
        return (
            <BookToLearn
                ref={comp => (this._list = comp)}
                onFetch={this._loader}
                onCellPress={this._onCellPress}
                onDeletePress={this._onDeletePress}
            />
        );
    }

    // 分页的加载逻辑
    _loader = (pageTo, pageSize) => {
        return ToLearnService.getToLearnResourceList(
            pageTo,
            pageSize,
            SeaConstant.ResourceType.READER
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data,
                    totalPage:
                        responseJson.total === 0 ? 0 : Math.ceil(responseJson.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = (item, index) => {
        Actions.show('bookDetail', { bookId: item.resourceId }, true);
    };

    _onDeletePress = async (item, index) => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍后');
            await ToLearnService.deleteToLearn(item.id);
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show('删除成功');
            this._list.reload(); // 刷新列表
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    _onRowOpen = () => {};
}
