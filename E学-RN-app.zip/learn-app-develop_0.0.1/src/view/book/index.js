/**
 * @author xukj
 * @date 2019/08/16
 * @description 阅读模块
 */
// 阅读数据模型
export { default as BookData } from './data/BookData';
// 阅读通用cell
export { default as BookCommonCell } from './view/BookCommonCell';

export { default as BooksListPage } from './list/BooksListPage';
export { default as BookDetailPage } from './detail/BookDetailPage';
export { default as BookToLearnPage } from './tolearn/BookToLearnPage';
// 阅读审批
export { default as BookApprovePage } from './approve/BookApprovePage';
