/**
 * @author xukj
 * @date 2018/7/30
 * @description 展示界面组件 BooksList 阅读列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';
import SeaList from '../../../components/list/SeaList';
import BooksListCell from './BooksListCell';
import BookData from '../data/BookData';
import { SeaStyle } from '../../../asserts';

export default class BooksList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaList
                style={SeaStyle.list}
                onFetch={onFetch}
                data={defaultData}
                renderItem={this._renderItem}
            />
        );
    }

    /*
     * @private
     * @description 列表项
     */
    _renderItem = ({ item, index }) => {
        return (
            <BooksListCell
                item={BookData.channel(item)}
                onPress={() => this.props.onCellPress(item, index)}
            />
        );
    };
}
