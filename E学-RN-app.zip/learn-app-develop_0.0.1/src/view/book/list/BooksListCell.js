/**
 * @author xukj
 * @date 2018/7/20
 * @description 阅读列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet } from 'react-native';
import { SeaListCell, SeaFlagText, SeaCoverImage } from '../../../components';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import BookData from '../data/BookData';
import Moment from 'moment'

export default class BooksListCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(BookData).isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress } = this.props;
        return (
            <SeaListCell
                backgroundColor="white"
                style={styles.cell}
                showArrow={false}
                showSeparator={true}
                onPress={onPress}
            >
                <View style={styles.content}>
                    <SeaCoverImage style={styles.cover} source={item.coverSource()}>
                        {item.finishStudy == 1 && <SeaFlagText theme="red">已学</SeaFlagText>}
                    </SeaCoverImage>
                    <View style={styles.rightContent}>
                        <Text style={styles.title} numberOfLines={3}>
                            {item.name}
                        </Text>
                        <Text style={styles.tag} numberOfLines={2}>
                            发布者：
                            <Text style={styles.tagContent}>{item.publisher}</Text>
                        </Text>
                        <Text style={styles.time}>发布时间：{Moment(item.publishTime).format('YYYY-MM-DD HH:mm')}</Text>
                    </View>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(300),
    },
    content: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        padding: SeaTheme.h_spacing_sm,
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    rightContent: {
        flex: 1,
        height: SeaScale.Layout(266),
        flexDirection: 'column',
        alignItems: 'flex-start',
        marginLeft: SeaScale.Layout(40),
    },
    cover: {
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        backgroundColor: SeaColor.img_background,
        borderRadius: SeaTheme.raduis_sm,
        width: SeaScale.Layout(200),
        height: SeaScale.Layout(266),
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
        marginTop: SeaTheme.v_spacing_sm,
    },
    tag: {
        marginTop: SeaScale.Layout(40),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
    tagContent: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.main,
    },
    time: {
        marginTop: SeaScale.Layout(40),
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
});
