/**
 * @author xukj
 * @date 2018/7/30
 * @description 交互界面 BooksListPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import BooksList from './BooksList';
import { CategoryService, BookService } from '../../../servie';
import { Actions } from 'react-native-router-flux';
import { FSLToast } from 'react-native-kpframework';
import { SeaConstant } from '../../../asserts';

export default class BooksListPage extends React.PureComponent {
    // 提供给外部的属性
    static propTypes = {
        category: PropTypes.string, // 分类
    };

    // 需要设置默认值的属性
    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const loader = this.props.category ? this._categoryLoader : this._allLoader;
        return <BooksList onFetch={loader} onCellPress={this._onCellPress} />;
    }

    /*
     * @private
     * @description 点击事件，查看详情
     */
    _onCellPress = item => {
        Actions.show('bookDetail', { bookId: item.id });
    };

    /*
     * @private
     * @description 获取阅读列表
     */
    _allLoader = (pageTo, pageSize) => {
        return BookService.getAllBookList('all', pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message ? error.message : '出错啦');
                return Promise.reject(error);
            });
    };

    /**
     * @private
     * @description 阅读分类api
     */
    _categoryLoader = (pageTo, pageSize) => {
        return CategoryService.getResourceList(
            this.props.category,
            SeaConstant.ResourceType.READER,
            this.props.isLoadAll,
            pageTo,
            pageSize
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}
