/**
 * @author xukj
 * @date 2019/08/16
 * @description 阅读通用cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell, SeaFlagText, SeaCoverImage } from '../../../components/index';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts/index';
import BookData from '../data/BookData';

export default class BookCommonCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(BookData).isRequired,
        onPress: PropTypes.func,
        keyword: PropTypes.string,
    };

    static defaultProps = {
        onPress: () => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    _keywordTitle = (keyword, strins) => {
        let data = strins          //   获取文本
        let newData = data.split(keyword)       //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.title} numberOfLines={2}>
                {
                    newData.map((item, index) => {
                        return <Text key={index}>
                            {item}
                            {(index < newData.length - 1) && (<Text style={{ color: 'red' }}>{keyword}</Text>)}
                        </Text>
                    })
                }
            </Text>
        )
    }

    _keywordTags = (keyword, strins) => {
        let data = strins          //   获取文本
        let newData = data.split(keyword)       //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.tag} numberOfLines={1}>
                {
                    newData.map((item, index) => {
                        return <Text key={index}>
                            {item}
                            {(index < newData.length - 1) && (<Text style={{ color: 'red' }}>{keyword}</Text>)}
                        </Text>
                    })
                }
            </Text>
        )
    }

    render() {
        const { item, onPress, keyword, ...restProps } = this.props;
        return (
            <SeaListCell
                backgroundColor="white"
                style={styles.cell}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.content}>
                    <SeaCoverImage style={styles.cover} source={item.coverSource()}>
                        <SeaFlagText>阅读</SeaFlagText>
                    </SeaCoverImage>
                    <View style={styles.rightContent}>
                        <View >
                            {
                                item.name && item.name.includes(keyword) ?
                                    this._keywordTitle(keyword, item.name) :
                                    <Text style={styles.title} numberOfLines={2}>
                                        {item.name}
                                    </Text>
                            }
                        </View>
                        <View >
                            {
                                item.tagsName && item.tagsName.includes(keyword) ?
                                    this._keywordTags(keyword, item.tagsName) :
                                    <Text style={styles.tag} numberOfLines={1}>
                                        {item.tagsName}
                                    </Text>
                            }
                        </View>
                        <Text style={styles.time} numberOfLines={1} adjustsFontSizeToFit>
                            发布时间：{item.publishTime}
                        </Text>
                    </View>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(250),
    },
    content: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    rightContent: {
        flex: 1,
        height: SeaScale.Layout(188),
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    cover: {
        width: SeaScale.Layout(250),
        height: SeaScale.Layout(188),
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        backgroundColor: SeaColor.img_background,
        borderRadius: SeaTheme.raduis_sm,
        marginLeft: SeaTheme.h_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    keyword: {
        fontSize: SeaTheme.font_size_md,
        color: 'red',
    },
    tag: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
    },
    time: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
});
