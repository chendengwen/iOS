/**
 * @author xukj
 * @date 2019/08/15
 * @description BookData 阅读数据模型
 */
import { SeaImageUtil } from '../../../util';
import moment from 'moment';

export default class BookData {
    constructor() {
        this.id;
        this.name;
        this.coverImageId;
        this.coverImageUrl;
        this.tagsName;
        this.finishStudy;
        this.publisher;
        this.publishTime;
        this._sourceData;
    }

    /**
     * 创建阅读数据对象,数据来源:频道
     * @param {object} value
     * @return {BookData}
     */
    static channel(value) {
        const book = new BookData();
        book._sourceData = value;

        book.id = value.id;
        book.name = value.name;
        book.coverImageId = value.coverImageId;
        book.coverImageUrl = value.coverImageUrl;
        book.tagsName = value.tagsName;
        book.publisher = value.publisher;
        book.publishTime = value.publishTime;
        book.finishStudy = value.finishStudy;
        return book;
    }

    /**
     * 创建阅读数据对象,数据来源:搜索
     * @param {object} value
     * @return {BookData}
     */
    static search(value) {
        const book = new BookData();
        book._sourceData = value;

        book.id = value.id;
        book.name = value.name;
        book.coverImageId = value.coverImageId;
        book.coverImageUrl = value.coverImageUrl;
        book.tagsName = value.tags;
        book.publisher = value.publisher;
        book.publishTime = value.publishTime;
        return book;
    }

    /**
     * 创建阅读数据对象,数据来源:专题
     * @param {object} value
     * @return {BookData}
     */
    static subject(value) {
        const book = new BookData();
        book._sourceData = value;

        book.id = value.id;
        book.name = value.name;
        book.coverImageId = value.coverImageId;
        book.coverImageUrl = value.coverImageUrl;
        book.tagsName = value.tagsName;
        book.publisher = value.publisher;
        book.publishTime = moment(value.publishTime).format('YYYY-MM-DD HH:mm');
        return book;
    }

    /**
     * 封面source
     */
    coverSource(size = 's') {
        return SeaImageUtil.getImageSource(this.coverImageId, this.coverImageUrl, size);
    }
}
