/**
 * @author xukj
 * @date 2019/09/18
 * @class
 * @description 阅读审批
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView, Text } from 'react-native';
import { SeaTextButton, SeaListCell, SeaCoverImage } from '../../../components';
import { SeaColor, SeaScale, SeaTheme, SeaConstant, SeaStyle } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';
import { SeaImageUtil } from '../../../util';

/**
 * 分组头部标题组件
 */
const HeadRowComp = props => {
    const { title } = props;
    return (
        <View style={styles.infoHeadContainer}>
            <View style={styles.infoHeadFlag} />
            <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{title}</Text>
        </View>
    );
};

/**
 * 头部组件
 */
const HeadComp = props => {
    const { style, data } = props;
    const name = _.get(data, 'name', '阅读');
    const publisher = _.get(data, 'publisher', '佚名');
    const category = _.get(data, 'categoryName', '暂无');

    return (
        <View style={style}>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textLg, { color: SeaColor.h1_text }]}>{name}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textSm, { color: SeaColor.h2_text }]}>发布人：{publisher}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text style={[styles.textSm, { color: SeaColor.content_text }]}>分类：{category}</Text>
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );
};

/**
 * 基本信息组件
 */
const InfoComp = props => {
    const { style, data } = props;
    const summary = _.get(data, 'summary', '暂无');
    // 积分
    const giveCredits = _.get(data, 'giveCredits', 1);
    const score = giveCredits == 0 ? _.get(data, 'credits', 0) : 0;

    const InfoRow = props => {
        const { title, content } = props;
        return (
            <View style={{ flexDirection: 'row' }}>
                <Text style={styles.infoTitleText}>{title}</Text>
                <Text style={[styles.infoContentText, { flex: 1 }]}>{content}</Text>
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="阅读信息" />
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <View style={[SeaStyle.row, { justifyContent: 'center' }]}>
                    <SeaCoverImage
                        style={styles.cover}
                        source={SeaImageUtil.getImageSource(data.coverImageId, null, 'l')}
                    />
                </View>
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="可获积分：" content={score} />
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={[styles.infoTitleText, { color: SeaColor.h1_text }]}>阅读说明</Text>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={styles.infoContentText}>{summary}</Text>
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
        </View>
    );
};

/**
 * 可见性
 */
const VisibilityComp = props => {
    const { style, data, onPress } = props;
    return (
        <View style={style}>
            <SeaListCell
                showArrow
                showSeparator
                arrowSize={SeaTheme.icon_size_md}
                onPress={Number(data.visibility)=== 1 ? null: onPress}
                style={styles.visibility}
            >
                <Text style={[styles.textMd, { color: SeaColor.h1_text, flex: 1 }]}>
                    可见性：{SeaConstant.getVisibilityTypeString(_.get(data, 'visibility'))}
                </Text>
            </SeaListCell>
            <FSLWhiteSpace size={vSpaceSize} />
            <Text
                style={[
                    styles.textMd,
                    { color: SeaColor.h2_text, marginLeft: SeaTheme.h_spacing_md },
                ]}
            >
                {data.preStaffHidden ? '岗前人员不可见' : '岗前人员可见'}
            </Text>
        </View>
    );
};

const TopicViewComp = props => {
    const { style, onPress } = props;
    return (
        <View style={[style, SeaStyle.center, { height: SeaScale.Layout(300) }]}>
            <SeaTextButton
                round
                style={{ height: SeaScale.Layout(80), width: SeaScale.Layout(300) }}
                theme="main"
                title="查看阅读内容"
                titleStyle={styles.textMd}
                onPress={onPress}
            />
        </View>
    );
};

export default class BookApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.func,
        onPassPress: PropTypes.func,
        onRefusePress: PropTypes.func,
        onVisibilityPress: PropTypes.func,
        onPreviewPress: PropTypes.func,
        review: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            data,
            review,
            onVisibilityPress,
            onPassPress,
            onRefusePress,
            onPreviewPress,
        } = this.props;
        return (
            <View style={SeaStyle.page}>
                <ScrollView style={{ flex: 1 }}>
                    <View style={{ width: SeaScale.screenWidth }}>
                        <HeadComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <InfoComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <VisibilityComp
                            style={{ backgroundColor: 'white' }}
                            data={data}
                            onPress={onVisibilityPress}
                        />
                        <TopicViewComp style={styles.section} onPress={onPreviewPress} />
                    </View>
                </ScrollView>
                {!review && (
                    <View style={[styles.footer, styles.borderTop]}>
                        <SeaTextButton
                            style={{ flex: 1 }}
                            theme="main"
                            titleStyle={SeaTheme.font_size_lg}
                            title="审批通过"
                            onPress={onPassPress}
                        />
                        <SeaTextButton
                            style={{ flex: 1, backgroundColor: SeaColor.defaultBackgroudColor_3 }}
                            theme="disable"
                            titleStyle={[SeaTheme.font_size_lg, { color: SeaColor.h2_text }]}
                            title="退回修改"
                            onPress={onRefusePress}
                        />
                    </View>
                )}
            </View>
        );
    }
}

const vSpaceSize = SeaScale.Layout(24);

const styles = StyleSheet.create({
    // 字体
    // ---
    textLg: {
        fontSize: SeaTheme.font_size_lg,
    },
    textMd: {
        fontSize: SeaTheme.font_size_md,
    },
    textSm: {
        fontSize: SeaTheme.font_size_sm,
    },

    // 分割线
    // ---
    sp: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    spTable: {
        backgroundColor: SeaColor.parting_line,
    },

    // 分割线
    // ---
    borderTop: {
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },

    // 其他
    // ---
    section: {
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    headRightContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-around',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
    },
    cover: {
        width: SeaScale.Layout(276),
        height: SeaScale.Layout(370),
        backgroundColor: SeaColor.img_background,
        borderRadius: SeaTheme.raduis_sm,
    },
    infoHeadContainer: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
    },
    infoHeadFlag: {
        height: SeaScale.Layout(26),
        width: SeaScale.Layout(4),
        backgroundColor: SeaColor.main,
        marginRight: SeaTheme.h_spacing_md,
    },
    infoTitleText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        minWidth: SeaScale.Layout(150),
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
    },
    infoContentText: {
        fontSize: SeaTheme.font_size_md,
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
        color: SeaColor.h2_text,
    },
    tableCell: {
        height: SeaScale.Layout(70),
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    visibility: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
        paddingLeft: SeaTheme.h_spacing_md,
    },
    footer: {
        flexDirection: 'row',
        height: SeaScale.Layout(100),
    },
});
