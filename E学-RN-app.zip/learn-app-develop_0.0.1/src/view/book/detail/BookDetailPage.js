/**
 * @author xukj
 * @date 2018/7/20
 * @description 交互界面 BookDetailPage，展示阅读资源的详情
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Alert, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaPdfGalleryControl } from '../../common';
import BookDetail from './BookDetail';
import { SeaNavigator, SeaNavigationItems as Items, SeaSharePanel } from '../../../components';
import { ToLearnService, BookService } from '../../../servie';
import { AC_ADD_TO_PLAY, AC_InitCourse } from '../../../redux/actions/course';
import { AC_SetResourceStatus, AC_ClearResourceStatus } from '../../../redux/actions/resource';
import { SeaConstant, SeaStyle } from '../../../asserts';
import { AC_ResetResourceComment } from '../../../redux/actions/resourceScore';

@connect(undefined, mapDispatchToProps)
export default class BookDetailPage extends React.PureComponent {
    static propTypes = {
        bookId: PropTypes.string, // 阅读书籍id
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { bookInfo: null, assigned: false };
        this._loadingKey; // 等待框
        this.galleryControl; // 图片管理
    }

    componentDidMount() {
        this._loadData(this.props.bookId);
    }
    componentWillUnmount() {
        this.props.clearProjectStatus && this.props.clearProjectStatus();
        this.props.resetScore && this.props.resetScore();
    }
    render() {
        const { bookId, bookInfo, assigned } = this.state;
        const renderRightButton = () => {
            if (bookInfo && bookInfo.status === '1') {
                return Items.renderSeaIconButton(this._onSharePress, 'share', '#0C5FDD');
            } else {
                return null;
            }
        };

        return (
            <View style={SeaStyle.page}>
                <SeaNavigator
                    title="阅读详情"
                    onBackPress={this._onBackPress}
                    renderRightButton={renderRightButton}
                />
                <BookDetail
                    tabLabel="详情介绍"
                    data={bookInfo}
                    assigned={assigned}
                    onShowPress={this._onReadPress}
                    onAddPress={this._onAddPress}
                    onScorePress={this._onScorePress}
                />
            </View>
        );
    }

    /*
     * private
     * @method 加入计划/阅读书籍
     */
    _onReadPress = bookInfo => {
        if (bookInfo.status !== '1') {
            Alert.alert('提示', '未发布的项目不支持此操作', [{ text: '确定' }], {
                cancelable: false,
            });
        } else if (bookInfo.fileType && bookInfo.fileType.toLowerCase() === 'pdf') {
            if (!bookInfo.isAssign) {
                this._preView(bookInfo.id);
            }
            this._showPdpReader(bookInfo);
        } else {
            Alert.alert(
                '提示',
                '目前仅支持pdf阅读!其他文件格式还在加紧开发中...',
                [{ text: '确定' }],
                { cancelable: false }
            );
        }
    };

    _onAddPress = bookInfo => {
        if (bookInfo.status !== '1') {
            Alert.alert('提示', '未发布的项目不支持此操作', [{ text: '确定' }], {
                cancelable: false,
            });
        } else {
            this._addToLearn(bookInfo.id);
        }
    };

    _onScorePress = bookInfo => {
        Actions.show('addScore', { resourceId: bookInfo.id });
    };

    /*
     * private
     * @method 获取书籍详情
     */
    _loadData = async resourceId => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            const responseJson = await BookService.getBookDetail(resourceId);
            FSLPrompt.hide(this._loadingKey);
            if (responseJson) {
                this.setState({ bookInfo: responseJson, assigned: responseJson.isAssign });
                this.props.setProjectStatus(this.state.bookInfo.status);
                this._prepareReader(responseJson);
            } else {
                FSLToast.show('找不到该资源', 2, Actions.pop);
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message, 2, Actions.pop);
        }
    };

    /*
     * private
     * @method 加入待学
     */
    _addToLearn = async resourceId => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            await ToLearnService.addToLearn(resourceId, undefined, false);
            FSLPrompt.hide(this._loadingKey);
            this.setState({ assigned: true });
            FSLToast.show('加入我的计划成功');
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /*
     * private
     * @method 加入试读
     */
    _preView = async id => {
        try {
            await ToLearnService.addToLearn(id, undefined, true);
        } catch (error) {}
    };

    /*
     * private
     * @method 阅读详细界面
     */
    _showPdpReader = item => {
        const payload = { ...item, resourceId: item.id, type: SeaConstant.ResourceType.READER };
        if (!this.galleryControl) {
            this.galleryControl = new SeaPdfGalleryControl(payload, true);
        } else {
            this.galleryControl.reset(payload, true);
        }
        this.galleryControl.start();
    };

    /*
     * private
     * @method 初始化阅读数据
     */
    _prepareReader = item => {
        // 上报学习进度
        // 这里因为历史代码的原因，需要使用redux，来初始化pdf模板和上报学习进度
        this.props.initCourse(); //初始化
        this.props.addToPlay({
            //阅读特殊处理，没有课件
            resourceId: item.id,
            contentId: item.id,
            snapshotId: item.id,
            played: item.played,
            fileId: item.fileId,
            fileSize: item.fileSize,
            isCrosswise: item.isCrosswise,
            type: '4', //阅读类型
        });
    };

    _onSharePress = () => {
        const bookInfo = _.get(this.state, 'bookInfo', {});
        SeaSharePanel.show({
            wxSession: true,
            wxTL: true,
            recommend: true,
            resourceId: bookInfo.id,
            title: bookInfo.name,
            imageUrl: SeaSharePanel.detailImageUrl(bookInfo.coverImageId, bookInfo.coverImage),
            url: SeaSharePanel.detailUrl(SeaConstant.ResourceType.READER, bookInfo.id),
        });
    };

    _onBackPress = () => {
        DeviceEventEmitter.emit(SeaConstant.SeaGlobalEventType.REPORT);
        Actions.pop();
    };
}

function mapDispatchToProps(dispatch) {
    return {
        addToPlay: resource => dispatch(AC_ADD_TO_PLAY(resource)),
        initCourse: () => dispatch(AC_InitCourse()),
        setProjectStatus: status => dispatch(AC_SetResourceStatus(status)),
        clearProjectStatus: () => dispatch(AC_ClearResourceStatus()),
        resetScore: () => dispatch(AC_ResetResourceComment()),
    };
}
