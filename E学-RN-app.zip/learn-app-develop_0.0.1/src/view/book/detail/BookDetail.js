/**
 * @author xukj
 * @date 2018/7/20
 * @description 展示界面组件 BookDetail
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
    View,
    ScrollView,
    Text,
    Image,
    StyleSheet,
    SafeAreaView,
    findNodeHandle,
} from 'react-native';
import { BlurView } from '@react-native-community/blur';
import { FSLWhiteSpace } from 'react-native-kpframework';
import ScrollableTabView from 'react-native-scrollable-tab-view';
import { Icon, Rating } from 'react-native-elements';
import {
    SeaLikeButton,
    SeaTextButton,
    SeaFlagText,
    CustomTopTabBar,
    SeaButton,
    SeaScoreButton,
    SeaCoverImage,
} from '../../../components';
import { SeaColor, SeaScale, SeaStyle, SeaTheme } from '../../../asserts';
import { SeaImageUtil, SeaDevice, SeaString } from '../../../util';
import { Comment } from '../../resource';

export default class BookDetail extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        assigned: PropTypes.bool,
        onAddPress: PropTypes.func,
        onShowPress: PropTypes.func,
    };

    static defaultProps = {
        assigned: false,
        onAddPress: data => { },
        onShowPress: data => { },
    };

    constructor(props) {
        super(props);
        this.state = { localCover: null, viewRef: null };
        this.tab;
    }

    componentDidMount() { }

    render() {
        const { data } = this.props;
        const { localCover } = this.state;
        if (!data) {
            return null;
        }

        return (
            <View style={SeaStyle.page}>
                <ScrollableTabView
                    ref={_comp => (this.tab = _comp)}
                    renderTabBar={() => <CustomTopTabBar underline />}
                >
                    <this._renderContent data={data} backCover={localCover} tabLabel="详情介绍" />
                    <this._renderComment data={data} tabLabel="培训评价" />
                </ScrollableTabView>
                <this._renderToolBar {...this.props} />
            </View>
        );
    }

    /*
     * private
     * @method 界面展示
     */
    _renderPage = props => {
        if (!props.data) {
            // 展示占位控件
            return null;
        } else {
            // 展示数据
            return (
                <View style={{ flex: 1 }}>
                    {this._renderContent(props)}
                    {this._renderToolBar(props)}
                </View>
            );
        }
    };

    /*
     * private
     * @method 内容部分
     */
    _renderContent = props => {
        const { data, backCover } = props;
        return (
            <ScrollView style={{ flex: 1 }}>
                <Image
                    ref={_comp => (this._imgBlur = _comp)}
                    style={[styles.head, { backgroundColor: SeaColor.parting_line }]}
                    resizeMode="cover"
                    source={backCover}
                />
                <BlurView
                    style={[styles.head, { position: 'absolute' }]}
                    blurType="light"
                    blurAmount={3}
                    viewRef={this.state.viewRef}
                />
                <View style={styles.content}>
                    <Text style={styles.title}>{data.name}</Text>
                    <FSLWhiteSpace size={SeaScale.Layout(30)} />
                    {data.avgRate > 0 && [
                        <View style={[styles.group, SeaStyle.row]} key="rategroup">
                            <Rating
                                readonly
                                type="custom"
                                ratingCount={5}
                                startingValue={Number(data.avgRate)}
                                imageSize={SeaScale.Layout(30)}
                                ratingColor={SeaColor.orange}
                                ratingBackgroundColor={SeaColor.parting_line}
                                tintColor="white"
                                starStyle={{ margin: SeaScale.Layout(3) }}
                            />
                            <Text style={styles.score}>{data.avgRate} 分</Text>
                            <SeaButton
                                style={[SeaStyle.row, { marginLeft: SeaTheme.h_spacing_md }]}
                                onPress={this._onScore}
                            >
                                <Text style={styles.score_count}>{data.ratePerson} 评价</Text>
                                <Icon
                                    name="keyboard-arrow-right"
                                    color={SeaColor.h2_text}
                                    size={SeaScale.Layout(40)}
                                />
                            </SeaButton>
                        </View>,

                        <FSLWhiteSpace size={SeaScale.Layout(100)} key="ratespace" />,
                    ]}

                    <this._renderInfo time={data.publishTime} fileSize={data.fileSize} />
                    <FSLWhiteSpace size={SeaScale.Layout(40)} />
                    <View style={styles.group}>
                        <Text style={styles.publish_title}>发布人</Text>
                        <Text style={styles.publish_name}>{data.publisher}</Text>
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(40)} />
                    <View style={styles.group}>
                        <Text style={styles.points_text}>可获积分：{data.credits}分</Text>
                        <Icon
                            name="database"
                            type="material-community"
                            size={SeaScale.Layout(32)}
                            color={SeaColor.orange}
                        />
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(40)} />
                    <this._renderStudyTime min={data.minTimes} max={data.maxTimes} />
                    <FSLWhiteSpace size={SeaScale.Layout(40)} />
                    <this._renderTagList tagsName={data.tagsName} />
                    <View style={{ height: 30 }} />
                </View>
                <View style={styles.cover}>
                    <SeaCoverImage
                        style={StyleSheet.absoluteFill}
                        resizeMode="contain"
                        source={SeaImageUtil.getImageSource(
                            data.coverImageId,
                            data.coverImage,
                            'l'
                        )}
                        onImageLoadEnd={this._onImageLoadEnd}
                    />
                </View>
            </ScrollView>
        );
    };

    _renderInfo(props) {
        const { time, fileSize } = props;
        const publishTime = time ? time.substr(0, 10) : '未知';
        return (
            <View style={styles.group}>
                <Icon
                    name="clock-outline"
                    type="material-community"
                    size={SeaScale.Layout(24)}
                    color={SeaColor.h3_text}
                />
                <Text style={styles.info_time}>{publishTime}</Text>
                <Text style={styles.info_size}>大小：{SeaString.readableSize(fileSize)}</Text>
            </View>
        );
    };

    _renderStudyTime(props) {
        const { min, max } = props;
        if (min && max) {
            return (
                <View style={styles.group}>
                    <Text style={styles.studyTime_text}>
                        建议学习时长{min}分钟~{max}分钟
                    </Text>
                </View>
            );
        } else {
            return null;
        }
    };

    /*
     * private
     * @method 标签list
     */
    _renderTagList(props) {
        const { tagsName } = props;
        const tagViews = _.isEmpty(tagsName)
            ? null
            : _.chain(tagsName)
                .split(',')
                .map((tag, index) => {
                    return (
                        <SeaFlagText style={styles.tags_text} key={index}>
                            {tag}
                        </SeaFlagText>
                    );
                })
                .value();
        return <View style={[styles.group, { flexWrap: 'wrap' }]}>{tagViews}</View>;
    };

    _renderComment = props => {
        const { data } = props;
        return (
            <View
                style={{
                    flex: 1,
                    backgroundColor: SeaColor.defaultBackgroudColor_3,
                    width: SeaScale.screenWidth,
                    flexDirection: 'column',
                }}
            >
                <Comment resourceId={data.id} />
            </View>
        );
    };

    /*
     * private
     * @method 底部功能栏
     */
    _renderToolBar = props => {
        const { loading, data, assigned, onShowPress, onAddPress } = props;

        const onPress = (onPress, loading, data) => () => {
            if (!loading && onPress) {
                onPress(data);
            }
        };

        const isComment = _.get(data, 'isCommented', false);

        return (
            <SafeAreaView style={{ backgroundColor: 'white' }}>
                <View style={styles.toolBar}>
                    <SeaLikeButton id={data.id} enabled={data.status === '1'} />
                    <SeaScoreButton resourceId={data.id} initCommented={isComment} />
                    <SeaTextButton
                        theme="default"
                        style={styles.btnShow}
                        titleStyle={styles.showTitle}
                        title="开始阅读"
                        onPress={onPress(onShowPress, loading, data)}
                    />
                    {// 如果已经加入阅读，则不显示添加按钮
                        !assigned && (
                            <SeaTextButton
                                theme="main"
                                style={styles.btnAdd}
                                titleStyle={styles.addTitle}
                                title="加入计划"
                                onPress={onPress(onAddPress, loading, data)}
                            />
                        )}
                </View>
            </SafeAreaView>
        );
    };

    _onImageLoadEnd = path => {
        if (_.isEmpty(path)) return;
        this.setState({
            localCover: { uri: `file://${path}` },
            viewRef: findNodeHandle(this._imgBlur),
        });
    };

    _onScore = () => {
        this.tab && this.tab.goToPage(1);
    };
}

const styles = StyleSheet.create({
    head: {
        height: SeaScale.Layout(402),
        width: SeaScale.screenWidth,
        alignItems: 'flex-start',
    },
    content: {
        flex: 1,
        width: SeaScale.screenWidth,
        backgroundColor: 'white',
        paddingLeft: SeaScale.Layout(30),
        paddingRight: SeaScale.Layout(30),
        alignItems: 'center',
    },
    cover: {
        position: 'absolute',
        top: SeaScale.Layout(60),
        left: (SeaScale.screenWidth - SeaScale.Layout(309)) / 2,
        width: SeaScale.Layout(309),
        height: SeaScale.Layout(412),
        borderRadius: SeaTheme.raduis_sm,
        justifyContent: 'center',
        backgroundColor: 'white',
        shadowColor: 'black',
        shadowOffset: { width: 1, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.6,
    },
    title: {
        fontSize: SeaScale.Font(40),
        marginTop: SeaScale.Layout(128),
        color: SeaColor.h1_text,
        textAlign: 'center',
    },
    score: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.orange,
        marginLeft: SeaScale.Layout(16),
    },
    score_count: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    group: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
    },
    info_time: {
        color: SeaColor.h3_text,
        fontSize: SeaTheme.font_size_md,
        marginLeft: 4,
    },
    info_size: {
        color: SeaColor.h3_text,
        fontSize: SeaTheme.font_size_md,
        marginLeft: SeaScale.Layout(60),
    },
    publish_title: {
        color: SeaColor.content_text,
        fontSize: SeaTheme.font_size_md,
    },
    publish_name: {
        color: SeaColor.main,
        fontSize: SeaTheme.font_size_md,
        marginLeft: SeaScale.Layout(20),
    },
    studyTime_text: {
        color: SeaColor.content_text,
        fontSize: SeaTheme.font_size_md,
    },
    points_text: {
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_xl,
        marginRight: 4,
    },
    tags_text: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
        borderWidth: SeaTheme.line_width_xs,
        borderColor: SeaColor.parting_line,
        borderRadius: SeaTheme.raduis_sm,
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_sm,
        paddingRight: SeaTheme.h_spacing_sm,
        paddingTop: SeaScale.Layout(10),
        paddingBottom: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(12),
        marginBottom: SeaTheme.v_spacing_sm,
    },
    toolBar: {
        backgroundColor: 'white',
        width: SeaScale.screenWidth,
        flexDirection: 'row',
        height: SeaScale.Layout(88),
        justifyContent: 'center',
        borderColor: SeaColor.parting_line,
        borderTopWidth: SeaTheme.line_width_xs,
        borderBottomWidth: SeaTheme.line_width_xs,
        overflow: 'hidden',
    },
    btnAdd: {
        height: SeaScale.Layout(88),
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: SeaColor.main,
        borderRadius: 0,
    },
    btnShow: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
        borderWidth: 0,
        borderLeftWidth: SeaTheme.line_width_xs,
    },
    addTitle: {
        fontSize: SeaTheme.font_size_xl,
        color: 'white',
    },
    showTitle: {
        fontSize: SeaTheme.font_size_xl,
        color: SeaColor.main,
    },
    scoreBtn: {
        width: SeaScale.Layout(130),
        alignItems: 'center',
        justifyContent: 'center',
    },
    scoreIcon: {
        width: SeaScale.Layout(40),
        height: SeaScale.Layout(40),
        overflow: 'hidden',
    },
});
