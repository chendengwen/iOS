/**
 * @author xukj
 * @date 2019/08/15
 * @description ECourse e课数据模型
 */
import { SeaConstant } from '../../../asserts';
import { SeaImageUtil } from '../../../util';
import moment from 'moment';

export default class ECourseData {
    constructor() {
        this.id;
        this.coverImageId;
        this.coverImageUrl;
        this.finishStudy;
        this.name;
        this.frequency;
        this.coursewareTypes;
        this.publishTime;
        this.tags;
        this.tagsName;

        this.resourceName;
        this.imageId;
        this._sourceData; // 原始数据
    }

    /**
     * 创建e课数据对象,数据来源:搜索
     * @param {object} value
     * @return {ECourseData}
     */
    static search(value) {
        const course = new ECourseData();
        course._sourceData = value;

        course.id = value.id;
        course.coverImageId = value.coverImageId;
        course.name = value.name;
        course.frequency = value.frequency;
        course.publishTime = value.publishTime;
        course.tagsName = value.tags;

        course.resourceName=value.resourceName;
        course.imageId=value.imageId;
        return course;
    }

    /**
     * 创建e课数据对象,数据来源:频道
     * @param {object} value
     * @return {ECourseData}
     */
    static channel(value) {
        const course = new ECourseData();
        course._sourceData = value;

        course.id = value.id;
        course.coverImageId = value.coverImageId;
        course.coverImageUrl = value.coverImageUrl;
        course.finishStudy = value.finishStudy;
        course.name = value.name;
        course.frequency = value.frequency;
        course.coursewareTypes = value.coursewareTypes;

        course.resourceName=value.resourceName;
        course.imageId=value.imageId;
        return course;
    }

    /**
     * 创建e课数据对象,数据来源:专题
     * @param {object} value
     * @return {ECourseData}
     */
    static subject(value) {
        const course = new ECourseData();
        course._sourceData = value;

        course.id = value.id;
        course.coverImageId = value.coverImageId;
        course.name = value.name;
        course.frequency = value.frequency;
        course.publishTime = moment(value.publishTime).format('YYYY-MM-DD HH:mm');
        course.tagsName = value.tagsName;

        course.resourceName=value.resourceName;
        course.imageId=value.imageId;
        return course;
    }

    /**
     * 资源是否包含文本，根据资源类型判断
     * @returns {boolean}
     */
    hasDoc() {
        const types = this.coursewareTypes ? this.coursewareTypes : [];
        const doc = types.find(n => {
            return (
                n == SeaConstant.CoursewareType.AUDIOANDRICHSNIPPET ||
                n == SeaConstant.CoursewareType.PICANDTXT ||
                n == SeaConstant.CoursewareType.RICHSNIPPET
            );
        });
        return !!doc;
    }

    /**
     * 资源是否包含音频，根据资源类型判断
     * @returns {boolean}
     */
    hasAudio() {
        const types = this.coursewareTypes ? this.coursewareTypes : [];
        const audio = types.find(n => {
            return (
                n == SeaConstant.CoursewareType.AUDIO ||
                n == SeaConstant.CoursewareType.AUDIOANDRICHSNIPPET
            );
        });
        return !!audio;
    }

    /**
     * 资源是否包含视频，根据资源类型判断
     * @returns {boolean}
     */
    hasVideo() {
        const types = this.coursewareTypes ? this.coursewareTypes : [];
        const video = types.find(n => {
            return n == SeaConstant.CoursewareType.VEDIO;
        });
        return !!video;
    }

    /**
     * 封面source
     */
    coverSource() {
        return SeaImageUtil.getImageSource(this.coverImageId, this.coverImageUrl);
    }

    subjectCoverSource() {
        return SeaImageUtil.getImageSource(this.imageId, this.coverImageUrl);
    }
}
