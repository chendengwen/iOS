/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-11 10:25:06
 */
/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description E课审批详情页
 */
import React from 'react';
import PropTypes from 'prop-types';
import EClassApprove from './EClassApprove';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { ApproveService } from '../../../servie';
import { PersonalService } from '../../../servie';

export default class EClassApprovePage extends React.PureComponent {
    static propTypes = {
        detailInfo: PropTypes.object.isRequired,
        review: PropTypes.bool,
        publish: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = {
            data: null,
            flowData: null
        };
        this._loadingKey;
    }

    componentDidMount() {
        this._load();
        this._getFlowDetail();
    }

    render() {
        const { data, flowData } = this.state;
        const { review, detailInfo, publish } = this.props;
        return <EClassApprove data={data} review={review} flowData={flowData} detailInfo={detailInfo} publish={publish}/>;
    }

    /**
     * @private
     * @description 获取待审批面授详情
     */
    _load = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('加载中');
            const result = await ApproveService.getApproveEClassDetail(this.props.detailInfo.bussSerialNo);
            this.setState({ data: result.data });
            FSLPrompt.hide(this._loadingKey);
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /**
     * 获取流程进度信息
     */
    _getFlowDetail = () => {
        return PersonalService.getFlowDetailList(this.props.detailInfo.bussSerialNo, this.props.detailInfo.flowSerialNo)
            .then(responseJson => {
                return Promise.resolve(
                    this.setState({
                        flowData: responseJson.data
                    })
                );
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}

function testApi(resourceId) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve({});
        }, 2000);
    });
}
