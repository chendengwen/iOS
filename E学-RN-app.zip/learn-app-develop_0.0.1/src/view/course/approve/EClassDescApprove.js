/**
 * @author xukj
 * @date 2019/09/05
 * @class
 * @description 面授审批基本信息预览UI
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, ScrollView, View, Text, Image, TextInput } from 'react-native';
import { SeaButton, SeaTextButton, SeaListCell, SeaCoverImage } from '../../../components';
import { SeaTheme, SeaColor, SeaScale, SeaStyle, SeaConstant } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';
import moment from 'moment';
import { SeaImageUtil } from '../../../util';

/**
 * 分组头部标题组件
 */
const HeadRowComp = props => {
    const { title } = props;
    return (
        <View style={styles.infoHeadContainer}>
            <View style={styles.infoHeadFlag} />
            <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{title}</Text>
        </View>
    );
};

/**
 * 头部组件
 */
const HeadComp = props => {
    const { style, data } = props;
    const name = _.get(data, 'name', '培训课程');
    const category = _.get(data, 'categoriesDesc', '暂无');

    return (
        <View style={style}>
            <FSLWhiteSpace size={vSpaceSize} />
            <View style={[SeaStyle.row, { alignItems: 'flex-start' }]}>
                <SeaCoverImage
                    style={styles.cover}
                    source={SeaImageUtil.getImageSource(data.coverImage)}
                />
                <View style={styles.headRightContainer}>
                    <Text style={[styles.textLg, { color: SeaColor.h1_text }]}>{name}</Text>
                    <FSLWhiteSpace size={vSpaceSize} />
                    <Text style={[styles.textSm, { color: SeaColor.content_text }]}>
                        分类：{category}
                    </Text>
                </View>
            </View>
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );
};

/**
 * 基本信息组件
 */
const InfoComp = props => {
    const { style, data } = props;
    const summary = _.get(data, 'summary', '暂无');
    const publisher = _.get(data, 'publisher', '佚名');
    const teacher = _.get(data, 'teacher');
    // 积分
    const giveScore = _.get(data, 'giveScore', 0);
    const score = _.get(data, 'score', 0);

    _renderText = (title, content) => (
        <View style={{ flexDirection: 'row' }}>
            <Text style={styles.infoTitleText}>{title}</Text>
            <Text style={[styles.infoContentText, { flex: 1 }]}>{content}</Text>
        </View>
    );

    return (
        <View style={style}>
            <HeadRowComp title="课程详情" />
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <View style={{ flexDirection: 'row' }}>
                    <Text style={styles.infoTitleText}>发布人：</Text>
                    <Text style={[styles.infoContentText, { flex: 1 }]}>{publisher}</Text>
                </View>
                {!_.isEmpty(teacher) && [
                    <FSLWhiteSpace size={vSpaceSize} />,
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={styles.infoTitleText}>讲&emsp;师：</Text>
                        <Text style={[styles.infoContentText, { flex: 1 }]}>{teacher}</Text>
                    </View>,
                ]}
                {giveScore > 0 && [
                    <FSLWhiteSpace size={vSpaceSize} />,
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={styles.infoTitleText}>积&emsp;分：</Text>
                        <Text style={[styles.infoContentText, { flex: 1 }]}>{score}</Text>
                    </View>,
                ]}
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={[styles.infoTitleText, { color: SeaColor.h1_text }]}>课程介绍</Text>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={styles.infoContentText}>{summary}</Text>
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
        </View>
    );
};

/**
 * 课程表组件
 */
const TimetableComp = props => {
    const { style, data } = props;

    _renderRow = (name, teacher, starttime, endtime) => (
        <View style={styles.borderTop}>
            <FSLWhiteSpace size={vSpaceSize} />
            <View style={{ flexDirection: 'row' }}>
                <Image
                    style={styles.iconMd}
                    source={require('../../../asserts/images/icon-approve-time.png')}
                />
                <View style={{ flex: 1, marginLeft: SeaTheme.h_spacing_md }}>
                    <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{name}</Text>
                    <FSLWhiteSpace size={vSpaceSize} />
                    {teacher && [
                        <Text style={[styles.textMd, { color: SeaColor.h2_text }]}>
                            讲师：{teacher}
                        </Text>,
                        <FSLWhiteSpace size={vSpaceSize} />,
                    ]}
                    <Text style={[styles.textMd, { color: SeaColor.h2_text }]}>
                        {starttime} 至 {endtime}
                    </Text>
                </View>
            </View>
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );

    return (
        <View style={style}>
            <HeadRowComp title="课程表" />
            {_.map(data.classSchedules, value => {
                return _renderRow(
                    value.name,
                    value.teacherName,
                    moment(value.startTime).format('YYYY-MM-DD HH:mm'),
                    moment(value.endTime).format('YYYY-MM-DD HH:mm')
                );
            })}
        </View>
    );
};

/**
 * 可见性
 */
const VisibilityComp = props => {
    const { style, data, onPress } = props;
    return (
        <View style={style}>
            <SeaListCell
                showArrow
                showSeparator={false}
                arrowSize={SeaTheme.icon_size_md}
                onPress={Number(data.visibility)=== 1 ? null: onPress}
                style={styles.visibility}
            >
                <Text style={[styles.textMd, { color: SeaColor.h1_text, flex: 1 }]}>
                    可见性：{SeaConstant.getVisibilityTypeString(data.visibility)}
                </Text>
            </SeaListCell>
            {/* <FSLWhiteSpace size={vSpaceSize} />
            <Text
                style={[
                    styles.textMd,
                    { color: SeaColor.h2_text, marginLeft: SeaTheme.h_spacing_md },
                ]}
            >
                 {data.preStaffHidden ? '岗前人员不可见' : '岗前人员可见'} 
            </Text> */}
        </View>
    );
};

/**
 * 我的评语
 */
const CommentComp = props => {
    const { style, onChangeCommentTxt } = props;
    return (
        <View style={style}>
            <HeadRowComp title="我的评语" />
            <TextInput
                maxLength={200}
                style={styles.comment}
                multiline={true}
                placeholder="请输入您的评语"
                placeholderTextColor={SeaColor.content_text}
                autoFocus={false}
                autoCapitalize="none"
                autoCompleteType="off"
                autoCorrect={false}
                returnKeyType="done"
                underlineColorAndroid="transparent"
                onChangeText={onChangeCommentTxt}
            />
        </View>
    );
};

/**
 * 进度说明
 */
const FlowComp = props => {
    const { style, flowData } = props;

    _renderStep = (item, index) => (
        <View style={styles.leftContainer}>
            <Image style={styles.stepIcon} source={require('../../../asserts/images/approval/ic_process_dot.png')} />
            {index != (flowData.length - 1) &&
                <Text style={styles.line}></Text>}
        </View>
    );
    _renderContent = (item) => (
        <View style={styles.rightContainer}>
            <Text style={styles.title}>
                【{item.stateName}】{item.handledByName}({item.handledByDeptName})
                </Text>
            {!_.isEmpty(item.comment) && <Text style={styles.flowDesc}>{item.comment}</Text>}
            {!_.isEmpty(item.handledAt) && <Text style={[styles.flowDesc, { marginBottom: SeaScale.Layout(45) }]}>{item.handledAt}</Text>}
        </View>
    );
    _renderItem = (item, index) => (
        <View style={styles.itemContainer} key={index}>
            {_renderStep(item, index)}
            {_renderContent(item)}
        </View>
    );

    return (
        <View style={style}>
            <HeadRowComp title="进度说明" />
            {flowData != null && flowData.length > 0 && flowData.map((item, index) => _renderItem(item, index))}
        </View>
    );
};

export default class EClassDescApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired,
        flowData: PropTypes.array.isRequired,
        detailInfo: PropTypes.object.isRequired,
        onVisibilityPress: PropTypes.func,
        onPassPress: PropTypes.func,
        onRefusePress: PropTypes.func,
        onChangeCommentTxt: PropTypes.func,
        review: PropTypes.bool,
        onPublishPress: PropTypes.func,
        publish: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { data, flowData, detailInfo, review, publish, onPassPress, onRefusePress, onVisibilityPress, onChangeCommentTxt, onPublishPress } = this.props;
        return (
            <View style={SeaStyle.page}>
                <ScrollView style={{ flex: 1 }}>
                    <View style={{ width: SeaScale.screenWidth }}>
                        <HeadComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <InfoComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        {!_.isEmpty(data.classSchedules) && [
                            <TimetableComp style={styles.section} data={data} />,
                            <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />,
                        ]}
                        <VisibilityComp
                            style={{ backgroundColor: 'white' }}
                            data={data}
                            onPress={onVisibilityPress}
                        />

                        {!review && <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />}
                        {!review && <CommentComp style={styles.section} data={data} onChangeCommentTxt={onChangeCommentTxt} />}
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <FlowComp style={styles.processContent} flowData={flowData} />
                    </View>
                </ScrollView>
                {!review && (
                    <View style={[styles.footer, styles.borderTop]}>
                        <SeaTextButton
                            style={{ flex: 1 }}
                            theme="main"
                            titleStyle={styles.textLg}
                            title="审批通过"
                            onPress={onPassPress}
                        />
                        <SeaTextButton
                            style={{ flex: 1, backgroundColor: SeaColor.defaultBackgroudColor_3 }}
                            theme="disable"
                            titleStyle={[styles.textLg, { color: SeaColor.h2_text }]}
                            title="退回修改"
                            onPress={onRefusePress}
                        />
                    </View>
                )}
                {publish && (
                    <View style={[styles.footer, styles.borderTop]}>
                        <SeaTextButton
                            style={{ flex: 1 }}
                            theme="main"
                            titleStyle={styles.textLg}
                            title="申请发布"
                            onPress={onPublishPress}
                        />
                    </View>
                )}
            </View>
        );
    }
}

const vSpaceSize = SeaScale.Layout(24);

const styles = StyleSheet.create({
    // 字体
    // ---
    textLg: {
        fontSize: SeaTheme.font_size_lg,
    },
    textMd: {
        fontSize: SeaTheme.font_size_md,
    },
    textSm: {
        fontSize: SeaTheme.font_size_sm,
    },

    // 分割线
    // ---
    sp: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },

    // 图片
    // ---
    iconMd: {
        width: SeaScale.Layout(30),
        height: SeaScale.Layout(30),
    },
    cover: {
        width: SeaScale.Layout(266),
        height: SeaScale.Layout(200),
        backgroundColor: SeaColor.defaultBackgroudColor,
        borderRadius: SeaTheme.raduis_sm,
    },

    // 分割线
    borderTop: {
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },

    // 其他
    // ---
    section: {
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    headRightContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-around',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
    },
    addrRow: {
        ...SeaStyle.row,
        flex: 1,
    },
    infoHeadContainer: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
    },
    infoHeadFlag: {
        height: SeaScale.Layout(26),
        width: SeaScale.Layout(4),
        backgroundColor: SeaColor.main,
        marginRight: SeaTheme.h_spacing_md,
    },
    infoTitleText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        minWidth: SeaScale.Layout(100),
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
    },
    infoContentText: {
        fontSize: SeaTheme.font_size_md,
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
        color: SeaColor.h2_text,
    },
    timetableRow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
    },
    visibility: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
        paddingLeft: SeaTheme.h_spacing_md,
    },
    footer: {
        flexDirection: 'row',
        height: SeaScale.Layout(100),
    },
    comment: {
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: '#F5F5F5',
        marginTop: SeaScale.Layout(10),
        marginBottom: SeaScale.Layout(30),
        padding: SeaScale.Layout(30),
        fontSize: SeaScale.Font(26),
        color: SeaColor.text3,
        borderRadius: SeaScale.Layout(10),
        minHeight: SeaScale.Layout(200),
        textAlignVertical: 'top',
    },
    processContent: {
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    itemContainer: {
        width: SeaScale.screenWidth - SeaScale.Layout(50),
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        flexDirection: 'row',
        paddingRight: SeaScale.Layout(30),
    },
    leftContainer: {
        flexDirection: 'column',
        marginLeft: SeaScale.Layout(10),
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    rightContainer: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: SeaScale.Layout(20),
    },
    flowDesc: {
        fontSize: SeaScale.Font(24),
        color: SeaColor.text3,
        marginTop: SeaScale.Layout(10),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(150),
    },
    stepIcon: {
        width: SeaScale.Layout(24),
        height: SeaScale.Layout(24),
    },
    line: {
        flex: 1,
        flexDirection: 'column',
        height: 'auto',
        width: SeaScale.Layout(2),
        backgroundColor: '#CCCCCC',
    },
    title: {
        fontSize: SeaScale.Font(28),
        color: SeaColor.text1,
        marginRight: SeaScale.Layout(20),
        lineHeight: SeaScale.Layout(30),
    },
});
