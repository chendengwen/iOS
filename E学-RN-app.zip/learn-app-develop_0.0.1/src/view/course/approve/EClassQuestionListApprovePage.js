/**
 * @author xukj
 * @date 2019/09/25
 * @class
 * @description e课问卷列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import EClassQuestionListApprove from './EClassQuestionListApprove';
import { Actions } from 'react-native-router-flux';

export default class EClassQuestionListApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 面授审批信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const questions = _.get(this.props, 'data.questionnaires', []);
        return <EClassQuestionListApprove data={questions} onCellPress={this._onCellPress} />;
    }

    _onCellPress = (item, index) => {
        Actions.show('QPaperApprove', { data: item, title: item.name });
    };
}
