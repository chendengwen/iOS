/**
 * @author xukj
 * @date 2019/09/25
 * @class
 * @description e课课程列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import EClassCourseListApprove from './EClassCourseListApprove';
import { Actions } from 'react-native-router-flux';

export default class EClassCourseListApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 课程审批信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const courses = _.get(this.props, 'data.curricula', []);
        return <EClassCourseListApprove data={courses} onCellPress={this._onCellPress} />;
    }

    _onCellPress = (item, index) => {
        Actions.show('coursePlay', {
            resourceId: this.props.data.id,
            snapshotId: item.id,
            resourceData: this.props.data,
            courseData: item,
            review: true,
        });
    };
}
