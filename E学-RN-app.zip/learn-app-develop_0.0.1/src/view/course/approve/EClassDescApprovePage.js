/**
 * @author xukj
 * @date 2019/09/05
 * @class
 * @description E课审批基本信息预览页
 */
import React from 'react';
import { View, Alert, DeviceEventEmitter } from 'react-native';
import PropTypes from 'prop-types';
import EClassDescApprove from './EClassDescApprove';
import { Actions } from 'react-native-router-flux';
import { ApproveService } from '../../../servie';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaConstant, SeaStyle } from '../../../asserts';
import { PersonalService } from '../../../servie';
import ChooseBackApproverDialog from '../../personal/submitandapprove/ChooseBackApproverDialog';

export default class EClassDescApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        detailInfo: PropTypes.object,
        flowData: PropTypes.array,
        review: PropTypes.bool,
        publish: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey;
        this.commentTxt = '';

        this.state = {
            dialogVisable: false,
            rejectOptionsList: [], //驳回选项列表
        };
    }

    componentDidMount() {
        this._getRejectOptions();
    }

    render() {
        const { data, flowData, detailInfo, review, publish } = this.props;
        return data ? (
            <View style={SeaStyle.page}>
                <EClassDescApprove
                    data={data}
                    flowData={flowData}
                    detailInfo={detailInfo}
                    review={review}
                    publish={publish}
                    onVisibilityPress={this._onVisibilityPress}
                    onPassPress={this._onApproveBtnPress}
                    onRefusePress={this._onNotApproveBtnPress}
                    onChangeCommentTxt={this._onChangeText}
                    onPublishPress={this._onPublishPress}
                />
                <ChooseBackApproverDialog
                    visible={this.state.dialogVisable}
                    rejectOptionsList={this.state.rejectOptionsList}
                    onCloseDialogPress={this._onCloseDialogPress}
                    onRejectTo={this._onRejectTo}
                />
            </View>
        ) : (
            <View style={SeaStyle.page} />
        );
    }

    _onCloseDialogPress = () => {
        this.setState({ dialogVisable: false });
    };

    _onRejectTo = (id) => {
        this._updateAutit(2, id);
    };

    _disApprove = () => {
        if (this.state.rejectOptionsList != null && this.state.rejectOptionsList.length == 1) {
            this._updateAutit(2, this.state.rejectOptionsList[0].id);
        } else if (
            this.state.rejectOptionsList != null &&
            this.state.rejectOptionsList.length > 1
        ) {
            this.setState({ dialogVisable: true });
        } else {
            FSLToast.show('获取的驳回选项为空！');
        }
    };

    _onChangeText = (text) => {
        this.commentTxt = text;
    };

    _onVisibilityPress = () => {
        Actions.show('visibilityList', { resourceId: this.props.data.id });
    };

    /**
     * 审批通过
     */
    _onApproveBtnPress = () => {
        if (!this.commentTxt) {
            Alert.alert('审批评语不能为空!');
            return;
        }
        Alert.alert(
            '提示',
            '是否同意该审批',
            [
                { text: '取消', style: 'cancel' },
                { text: '确定', onPress: () => this._updateAutit(1, '') },
            ],
            { cancelable: false }
        );
    };

    /**
     * 退回修改
     */
    _onNotApproveBtnPress = () => {
        if (!this.commentTxt) {
            Alert.alert('审批评语不能为空!');
            return;
        }
        Alert.alert(
            '提示',
            '是否驳回该审批',
            [
                { text: '取消', style: 'cancel' },
                { text: '确定', onPress: this._disApprove },
            ],
            { cancelable: false }
        );
    };

    /**
     * 提交审批
     * @param {string} approveOpinion 审批意见1:同意,2:不同意
     * @param {string} rejOptId 驳回选项编码
     */
    _updateAutit = async (approveOpinion, rejOptId) => {
        try {
            let param = {
                definitionCode: this.props.detailInfo.definitionCode, //审批链编码，从获取我的审批获取
                bussSerialNo: this.props.detailInfo.bussSerialNo, //业务流水号（关联业务资源）
                flowSerialNo: this.props.detailInfo.flowSerialNo, //工作流申请号（审批流程唯一编码）
                approveOpinion: approveOpinion, //审批意见 1:同意,2:不同意,3:发起会签;4:发起或签
                approveComment: this.commentTxt, //审批评语
                rejOptId: rejOptId, //驳回选项编码
                extraHandledBy: null, //会签者或者或签者用户ID，审批意见取值3,4时,此字段需要传入至少一个元素
            };
            this._loadingKey = FSLPrompt.loading('正在提交审批结果');
            const responseJson = await PersonalService.submitApproval(param);
            FSLPrompt.hide(this._loadingKey);
            if (responseJson.code != '000000') {
                FSLToast.show(responseJson.msg);
            } else {
                FSLToast.show('提交成功');
                // 通知其他界面审批完成
                DeviceEventEmitter.emit(SeaConstant.Notification.FINISHED_APPROVAL_PROCESS);
                Actions.pop();
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /**
     * 发布E课
     */
    _onPublishPress = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('正在发布');
            const responseJson = await ApproveService.publishEClass(
                this.props.detailInfo.bussSerialNo
            );
            FSLPrompt.hide(this._loadingKey);
            if (responseJson.code === '000000') {
                FSLToast.show('提交申请成功');
                // 通知其他界面审批完成
                DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_RECORDS_LIST);
                Actions.pop();
            } else {
                FSLToast.show(responseJson.msg);
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /**
     * 获取驳回选项列表
     */
    _getRejectOptions = () => {
        return PersonalService.getRejectOptionsList(this.props.detailInfo.flowSerialNo)
            .then((responseJson) => {
                return Promise.resolve(
                    this.setState({
                        rejectOptionsList: responseJson.data,
                    })
                );
            })
            .catch((error) => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}
