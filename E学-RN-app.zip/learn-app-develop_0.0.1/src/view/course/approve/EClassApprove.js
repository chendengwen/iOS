/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description E课审批UI
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';
import { CustomTopTabBar } from '../../../components';
import EClassDescApprovePage from './EClassDescApprovePage';
import EClassCourseListApprovePage from './EClassCourseListApprovePage';
import EClassTestListApprovePage from './EClassTestListApprovePage';
import EClassQuestionListApprovePage from './EClassQuestionListApprovePage';
import { SeaStyle } from '../../../asserts';

const TabText = ['详细介绍', '在线学习', '考试', '问卷'];

export default class EClassApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        detailInfo: PropTypes.object,
        flowData: PropTypes.array,
        review: PropTypes.bool,
        publish: PropTypes.bool,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { data, flowData, detailInfo, review, publish } = this.props;

        if (!data) {
            return <View style={SeaStyle.page} />;
        }

        const isCourseEmpty = _.chain(data)
            .get('curricula', [])
            .isEmpty()
            .value();
        const isQuestionEmpty = _.chain(data)
            .get('questionnaires', [])
            .isEmpty()
            .value();
        const isTestEmpty = _.chain(data)
            .get('testPaperBasicInfo', [])
            .isEmpty()
            .value();

        let TableComponent = ScrollableTabView;
        if (isCourseEmpty && isQuestionEmpty && isTestEmpty) {
            TableComponent = View;
        }

        return (
            <View style={SeaStyle.page}>
                <TableComponent
                    style={{ flex: 1 }}
                    renderTabBar={() => <CustomTopTabBar underline />}
                >
                    <EClassDescApprovePage data={data} flowData={flowData} detailInfo={detailInfo} review={review} publish={publish} tabLabel={TabText[0]} />
                    {!isCourseEmpty && (
                        <EClassCourseListApprovePage
                            review={review}
                            data={data}
                            tabLabel={TabText[1]}
                        />
                    )}
                    {!isTestEmpty && (
                        <EClassTestListApprovePage
                            review={review}
                            data={data}
                            tabLabel={TabText[2]}
                        />
                    )}
                    {!isQuestionEmpty && (
                        <EClassQuestionListApprovePage
                            review={review}
                            data={data}
                            tabLabel={TabText[3]}
                        />
                    )}
                </TableComponent>
            </View>
        );
    }
}
