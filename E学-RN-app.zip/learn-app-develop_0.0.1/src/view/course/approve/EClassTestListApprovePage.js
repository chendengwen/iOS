/**
 * @author xukj
 * @date 2019/09/25
 * @class
 * @description e课考试列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import EClassTestListApprove from './EClassTestListApprove';
import { Actions } from 'react-native-router-flux';

export default class EClassTestListApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 面授审批信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const papers = _.get(this.props, 'data.testPaperBasicInfo', []);
        return <EClassTestListApprove data={papers} onCellPress={this._onCellPress} />;
    }

    _onCellPress = (item, index) => {
        Actions.show('testPaperApprove', { data: item, title: item.name });
    };
}
