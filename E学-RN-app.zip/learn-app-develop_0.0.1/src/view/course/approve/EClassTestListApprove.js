/**
 * @author xukj
 * @date 2019/09/25
 * @class
 * @description e课考试列表
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaList, SeaListCell } from '../../../components';
import { SeaStyle, SeaScale, SeaTheme, SeaColor } from '../../../asserts';

export default class EClassTestListApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array.isRequired,
        onCellPress: PropTypes.func,
    };

    static defaultProps = {
        data: [],
        onCellPress: (item, index) => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        return <SeaList data={data} style={SeaStyle.list} renderItem={this._renderItem} />;
    }

    _renderItem = ({ item, index }) => {
        return (
            <SeaListCell
                backgroundColor="white"
                onPress={() => this.props.onCellPress(item, index)}
            >
                <View style={styles.cell}>
                    <Text style={styles.title}>{item.name}</Text>
                </View>
            </SeaListCell>
        );
    };
}

const styles = StyleSheet.create({
    cell: {
        flexDirection: 'row',
        height: SeaTheme.row_height_md,
        paddingLeft: SeaTheme.h_spacing_md,
        alignItems: 'center',
    },
    title: {
        flex: 1,
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h1_text,
    },
});
