/**
 * @author xukj
 * @date 2019/08/09
 * @description e课内容部分样式
 */
import React from 'react';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';
import { StyleSheet } from 'react-native';

const width = SeaScale.screenWidth;

export default StyleSheet.create({
    flex: {
        flex: 1,
    },

    tabBarUnderline: {
        backgroundColor: SeaColor.main,
        width: SeaScale.Layout(126),
        height: SeaScale.Layout(2),
    },
    tabBarTextStyle: {
        fontSize: SeaTheme.font_size_md,
        marginTop: SeaScale.Layout(16),
    },
    tab: {
        backgroundColor: SeaColor.back,
        height: SeaScale.Layout(70),
        // borderColor: SeaColor.parting_line,
        // borderWidth: 0,
        alignItems: 'center',
    },
    toLearnButton: {
        height: SeaScale.Layout(88),
        backgroundColor: SeaColor.main,
        width,
        position: 'absolute',
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    },
    toLearnText: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.back,
    },
});
