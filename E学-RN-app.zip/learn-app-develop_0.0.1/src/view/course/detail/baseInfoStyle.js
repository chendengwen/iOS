/**
 * @author xukj
 * @date 2019/08/09
 * @description e课基本信息样式
 */
import React from 'react';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';
import { StyleSheet } from 'react-native';

const width = SeaScale.screenWidth;
export default StyleSheet.create({
    container: {
        flex: 1,
    },

    scroll: {
        flex: 1,
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },

    titleContainer: {
        marginTop: SeaTheme.v_spacing_md,
        alignItems: 'flex-start',
    },

    title: {
        fontSize: SeaTheme.font_size_xxxl,
        color: SeaTheme.color_txt_h1,
        lineHeight: SeaScale.Layout(54),
    },

    itemText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaTheme.color_txt_h1,
    },

    itemContentText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaTheme.color_txt_h2,
    },

    like: {
        flexDirection: 'row',
        // justifyContent: 'center',
        alignItems: 'center',
    },

    tagView: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },

    tagContainer: {
        flexDirection: 'row',
        width: width - SeaScale.Layout(100),
    },

    score: {
        marginLeft: SeaScale.Layout(16),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.orange,
    },

    sp: {
        borderBottomColor: SeaColor.parting_line,
        borderBottomWidth: SeaTheme.line_width_xs,
    },

    tagGroup: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(180),
    },

    tagText0: {
        fontSize: SeaTheme.font_size_xxs,
        color: '#E5B83D',
        backgroundColor: '#FCFCD2',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(20),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(200),
    },
    tagText1: {
        fontSize: SeaTheme.font_size_xxs,
        color: '#D8946C',
        backgroundColor: '#FCEDE4',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(20),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(200),
    },
    tagText2: {
        fontSize: SeaTheme.font_size_xxs,
        color: '#51B3FA',
        backgroundColor: '#DEF0FD',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(20),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(200),
    },
    tagText3: {
        fontSize: SeaTheme.font_size_xxs,
        color: '#883DE7',
        backgroundColor: '#E8D9FB',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: SeaScale.Layout(20),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(200),
    },
    tagText4: {
        fontSize: SeaTheme.font_size_xxs,
        color: '#F44048',
        backgroundColor: '#FCE4E5',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: SeaScale.Layout(10),
        marginRight: SeaScale.Layout(20),
        maxWidth: SeaScale.screenWidth - SeaScale.Layout(350),
    },
});