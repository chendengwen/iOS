/**
 * @author xukj
 * @date 2019/04/08
 * @description CouresProject e课详情
 * modify by xukj - 1.28.0
 * 调整错误提示
 */
import React, { Component } from 'react';
import { View, Alert, StatusBar, BackHandler, DeviceEventEmitter } from 'react-native';
import { connect } from 'react-redux';
import { SeaLoading } from '../../../components';
import {
    AC_AsyFetchCourseDetailData,
    AC_InitCourse,
    AC_FetchFinishStatus,
} from '../../../redux/actions/course';
import { AC_AsyFetchLikeData, AC_initLikeData } from '../../../redux/actions/resourceLike';
import { AC_initFavoriteData, AC_AsyFetchFavoriteData } from '../../../redux/actions/resourceFavorite';
import { AC_SetResourceStatus, AC_ClearResourceStatus } from '../../../redux/actions/resource';
import { Actions } from 'react-native-router-flux';
import { PlayerView } from '../../resource';
import CourseProjectContent from './CourseProjectContent';
import { FSLLoadingView, FSLToast } from 'react-native-kpframework';
import { SeaStyle, SeaConstant } from '../../../asserts';
import { AC_ResetResourceComment } from '../../../redux/actions/resourceScore';

@connect(mapStateToProps, mapDispatchToProps)
export default class ECourseDetailPage extends Component {
    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.detailError && nextProps.detailError !== this.props.detailError) {
            console.log('ECourseDetailPage ' + JSON.stringify(nextProps.detailError));
            Alert.alert(
                '提示',
                nextProps.detailError,
                [{ text: '确定', onPress: Actions.pop }],
                { cancelable: false }
            );
        } else if (nextProps.addError && nextProps.addError !== this.props.addError) {
            // 加入计划失败
            FSLToast.show(nextProps.addError.message);
        } else if (nextProps.addMessage && nextProps.addMessage !== this.props.addMessage) {
            // 加入计划提示
            FSLToast.show(nextProps.addMessage);
        }

        if (nextProps.data && nextProps.data.status != this.props.projectStatus) {
            this.props.setProjectStatus(nextProps.data.status);
        }
    }
    constructor(props) {
        super(props);
        this.backHandler;
    }

    componentDidMount() {
        this.props.init();
        this.props.initLike();
        this.props.fetchData(this.props.Id);
        this.props.fetchLike(this.props.Id);
        //this.props.initFavorite();
        this.props.fetchFavorite(this.props.Id);
        this.props.loadFinishState(this.props.Id);
        // fix cannot listen android back key
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', this._onBackPress);
        this.closs_class = DeviceEventEmitter.addListener(SeaConstant.Notification.CLOSE_CLASS,
            this._onCloseClass);
    }

    componentWillUnmount() {
        this.props.init && this.props.init();
        this.props.clearProjectStatus && this.props.clearProjectStatus();
        this.props.resetScore && this.props.resetScore();
        this.backHandler && this.backHandler.remove();
        this.closs_class && this.closs_class.remove();
    }

    render() {
        if (!this.props.data) {
            return <SeaLoading />;
        } else {
            return (
                <View style={SeaStyle.page}>
                    <StatusBar barStyle={'light-content'} />
                    <View>
                        <PlayerView
                            cover={this.props.data.coverImageUrl}
                            name={this.props.data.name}
                            snapshotId={this.props.data.curricula.id}
                            onBackPress={this._onBackPress}
                        />
                    </View>
                    <View style={{ flex: 1 }}>
                        <CourseProjectContent businessType={'1'} />
                    </View>
                    {this.props.addSending && <FSLLoadingView content="处理中" />}
                </View>
            );
        }
    }

    _onCloseClass = ()=>{
        this.props.init();
        this.props.fetchData(this.props.Id);
        // report
        DeviceEventEmitter.emit(SeaConstant.SeaGlobalEventType.REPORT); 
    }

    /**
     * @private
     * @description 返回键逻辑
     */
    _onBackPress = () => {
        this.props.init();
        this.props.fetchData(this.props.Id);
        // report
        DeviceEventEmitter.emit(SeaConstant.SeaGlobalEventType.REPORT);

        // 未报名的，不验证未完成
        const isAssign = _.get(this.props.data, 'isAssign', 0) == 1 || this.props.toLearn;
        if (!isAssign) {
            Actions.pop();
            return true;
        }

        const isFinishQ = _.get(this.props, 'finishState.finishQuestionnaire', true);
        const isFinishT = _.get(this.props, 'finishState.finishPaper', true);
        let unfinish = [];
        if (!isFinishQ) unfinish.push('问卷');
        if (!isFinishT) unfinish.push('考试');

        if (unfinish.length <= 0) {
            Actions.pop();
            return true;
        }

        Alert.alert(
            '提示',
            `您还有${unfinish.join('和')}未完成，是否离开？`,
            [
                { text: '取消', style: 'cancel' },
                { text: '退出', style: 'destructive', onPress: Actions.pop },
            ],
            { cancelable: false }
        );

        return true;
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        data: store.courseStore.data,
        projectStatus: store.resourceStore.status,
        detailError: store.courseStore.detailError,
        addError: store.courseStore.addError,
        addMessage: store.courseStore.addMessage,
        addSending: store.courseStore.addSending,
        // add by xukj - 1.40.0
        // 加入计划
        toLearn: store.courseStore.toLearn,
        // 完成情况
        finishState: store.courseStore.finishState,
    };
}

//store到action的action映射
function mapDispatchToProps(dispatch) {
    return {
        fetchData: courseId => dispatch(AC_AsyFetchCourseDetailData(courseId)),
        init: () => dispatch(AC_InitCourse()),
        fetchLike: courseId => dispatch(AC_AsyFetchLikeData(courseId)),
        initLike: () => dispatch(AC_initLikeData()),
        //initFavorite: () => dispatch(AC_initFavoriteData()),
        fetchFavorite: (id) => dispatch(AC_AsyFetchFavoriteData(id, SeaConstant.ResourceType.ONLINE_COURSE)),
        setProjectStatus: status => dispatch(AC_SetResourceStatus(status)),
        clearProjectStatus: () => dispatch(AC_ClearResourceStatus()),
        resetScore: () => dispatch(AC_ResetResourceComment()),
        // add by xukj - 1.40.0
        // 获取e课状态
        loadFinishState: resourceId => dispatch(AC_FetchFinishStatus(resourceId)),
    };
}
