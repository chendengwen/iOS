/**
 * 在线项目的底部操作栏
 * Created by zk on 2017/9/19.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet, SafeAreaView, Alert, Image, ImageBackground } from 'react-native';
import { SeaScale, SeaColor, SeaTheme, SeaConstant } from '../../../asserts';
import { connect } from 'react-redux';
import {
    AC_AsyFetchLikeData,
    AC_AsyToggleLike,
    AC_initLikeData,
} from '../../../redux/actions/resourceLike';
import {
    AC_AsyFetchFavoriteData,
    AC_AsyToggleFavorite,
    AC_initFavoriteData,
} from '../../../redux/actions/resourceFavorite';
import {
    AC_START_QA,
    AC_ClearExamFinishState,
    AC_ClearQuestionFinishState,
} from '../../../redux/actions/course';
import { Actions } from 'react-native-router-flux';
import { ResourceProxy } from '../../resource';
import { SeaButton } from '../../../components';
import { SeaDevice } from '../../../util';
import { FSLBadge } from 'react-native-kpframework';
import { PersonalService } from '../../../servie';
import { DeviceEventEmitter } from 'react-native';

@connect(mapStateToProps, mapDispatchToProps)
export default class LearnedBottomBar extends React.PureComponent {
    static propTypes = {
        businessType: PropTypes.string,
    };

    static defaultProps = {
        businessType: '1',
    };

    constructor(props) {
        super(props);
        this.state = {
            like: false,
            count: 0,
            isComment: false,
        };
    }
    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_STATE,
            () => {
                this._getState();
            }
        );
        this._getState();
    }
    componentWillUnmount() {
        this.listener.remove();
    }

    render() {
        const like = _.get(this.props, 'likeData.like', false);
        const count = _.get(this.props, 'likeData.likeCount', 0);
        const {  isComment } = this.state; //like,count,
        // const isComment = this._isCommented(this.props.data, this.props.scoreData);
        const isQFinish = _.get(this.props, 'finishState.finishQuestionnaire', true);
        const isEFinish = _.get(this.props, 'finishState.finishPaper', true);

        const favorite = _.get(this.props, 'favoriteData.favorite', false);

        return (
            <SafeAreaView>
                <View style={SeaTheme.footerToolBar.boxAutoFix}>
                    <SeaButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        onPress={this._onQuestionPress}
                    >
                        <ImageBackground
                            style={styles.bottomIcon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-qn.png')}
                        >
                            <FSLBadge.Dot show={!isQFinish} size={SeaTheme.raduis_lg} />
                        </ImageBackground>
                        <Text style={SeaTheme.footerToolBar.buttonAssideText}>问卷</Text>
                    </SeaButton>
                    <SeaButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        onPress={isComment ? null : this._onScorePress}
                    // onPress={this._onScorePress}
                    >
                        <Image
                            style={[styles.bottomIcon, isComment && { tintColor: SeaColor.main }]}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-score.png')}
                        />
                        <Text style={[SeaTheme.footerToolBar.buttonAssideText, isComment && { color: SeaColor.main }]}>
                            {isComment ? '已评价' : '评分'}
                        </Text>
                    </SeaButton>
                    <SeaButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        onPress={this._onTestPress}
                    >
                        <ImageBackground
                            style={styles.bottomIcon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-test.png')}
                        >
                            <FSLBadge.Dot show={!isEFinish} size={SeaTheme.raduis_lg} />
                        </ImageBackground>
                        <Text style={SeaTheme.footerToolBar.buttonAssideText}>答题</Text>
                    </SeaButton>
                    <SeaButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        onPress={this._onLikePress}
                    >
                        <Image
                            style={[styles.bottomIcon, like && { tintColor: SeaColor.main }]}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-like.png')}
                        />
                        <Text style={[SeaTheme.footerToolBar.buttonAssideText, like && { color: SeaColor.main }]}>
                            {like ? `已点赞` : '点赞'}
                        </Text>
                    </SeaButton>
                    <SeaButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        onPress={this._onFavoritePress}
                    >
                        <Image
                            style={[styles.bottomIcon, favorite && { tintColor: SeaColor.main }]}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic_favorite.png')}
                        />
                        <Text
                            style={[
                                SeaTheme.footerToolBar.buttonAssideText,
                                favorite && { color: SeaColor.main },
                            ]}
                        >
                            {favorite ? `已收藏` : '收藏'}
                        </Text>
                    </SeaButton>
                </View>
            </SafeAreaView>
        );
    }
    _getState() {
        const resourceId = _.get(this.props.data, 'id', '');
        PersonalService.queryResourceById(resourceId)
            .then((responseJson) => {
                this.setState({
                    like: responseJson.data.like,
                    count: responseJson.data.likeCount,
                    isComment: responseJson.data.evaluateParentCount > 0,
                });
                return Promise.resolve({});
            })
            .catch(() => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    }

    //点击答题按钮
    _onTestPress = () => {
        // 重置考试完成情况
        this.props.clearEFinishState(this.props.data.id);
        // 进入考试
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (this.props.testPapers.length < 1) {
                Alert.alert('提示', '该项目还没有考试哦~', [{ text: '确定' }], {
                    cancelable: false,
                });
            } else {
                this.props.startQA();
                Actions.show('testResourcePaperList', { id: this.props.data.id, showResult: true });
            }
        });
    };

    //点击问卷按按钮
    _onQuestionPress = () => {
        // 重置问卷完成情况
        this.props.clearQFinishState(this.props.data.id);
        // 进入问卷
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (this.props.questionData.length < 1) {
                Alert.alert('提示', '该项目还没有问卷哦~', [{ text: '确定' }], {
                    cancelable: false,
                });
            } else {
                this.props.startQA();
                Actions.show('questionnaireList', {
                    data: this.props.questionData,
                    resourceId: this.props.data.id,
                });
            }
        });
    };

    //点赞
    _onLikePress = () => {
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (!this.props.liking) {
                this.props.toggleLike(this.props.data.id);
                this._getState();
            }
        });
    };

    //收藏
    _onFavoritePress = () => {
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (!this.props.favoriting) {
                this.props.toggleFavorite(this.props.data.id);
                //this._getState();
            }
        });
    };

    _onScorePress = () => {
        Actions.show('addScore', {
            resourceId: this.props.data.id,
            businessType: this.props.businessType,
        });
    };

    _isCommented = (initData = {}, scoreData = {}) => {
        if (initData.id != scoreData.resourceId) {
            return initData.isCommented;
        }

        return initData.isCommented || scoreData.isCommented;
    };
}
//样式表
const styles = StyleSheet.create({
    bottomBar: {
        height: SeaScale.Layout(88) + SeaDevice.bottomHeight(),
        width: SeaScale.screenWidth,
        borderTopWidth: SeaTheme.line_width_xs,
        borderTopColor: SeaColor.parting_line,
        flexDirection: 'row',
        justifyContent: 'space-around',
        backgroundColor: '#F00',
    },
    bottomButton: {
        width: SeaScale.screenWidth / 5,
        height: SeaScale.Layout(88),
        alignItems: 'center',
        justifyContent: 'center',
    },
    bottomIcon: {
        width: SeaScale.Layout(38),
        height: SeaScale.Layout(38),
        alignItems: 'center',
    },
    bottomText: {
        color: SeaColor.content_text,
        marginTop: SeaScale.Layout(6),
        fontSize: SeaTheme.font_size_xxs,
    },
    bottomTextLiked: {
        color: SeaColor.main,
        marginTop: SeaScale.Layout(6),
        fontSize: SeaTheme.font_size_xxs,
    },
});

//store到action的state映射
function mapStateToProps(store) {
    return {
        data: store.courseStore.data,
        questionData: store.courseStore.questionnaires,
        testPapers: store.courseStore.testPapers,
        toLearn: store.courseStore.toLearn,
        likeData: store.likeStore.data,
        likeStatus: store.likeStore.exception,
        likingFail: store.likeStore.likingFail,
        liking: store.likeStore.liking,
        //收藏
        favoriteData: store.favoriteStore.data,
        favoriteStatus: store.favoriteStore.exception,
        favoritingFail: store.favoriteStore.favoritingFail,
        favoriting: store.favoriteStore.favoriting,
        scoreData: store.scoreStore,
        // add by xukj - 1.40.0
        // 完成情况
        finishState: store.courseStore.finishState,
    };
}
//store到action的action映射
function mapDispatchToProps(dispatch) {
    return {
        fetchLikeData: (id) => dispatch(AC_AsyFetchLikeData(id)),
        toggleLike: (id) => dispatch(AC_AsyToggleLike(id)),
        initLike: () => dispatch(AC_initLikeData()),
        fetchFavoriteData: (id, type) => dispatch(AC_AsyFetchFavoriteData(id, type)),
        toggleFavorite: (id) =>
            dispatch(AC_AsyToggleFavorite(id, SeaConstant.ResourceType.ONLINE_COURSE)),
        initFavorite: () => dispatch(AC_initFavoriteData()),
        startQA: () => dispatch(AC_START_QA()),
        // add by xukj - 1.40.0
        clearQFinishState: (resourceId) => dispatch(AC_ClearQuestionFinishState(resourceId)),
        clearEFinishState: (resourceId) => dispatch(AC_ClearExamFinishState(resourceId)),
    };
}
