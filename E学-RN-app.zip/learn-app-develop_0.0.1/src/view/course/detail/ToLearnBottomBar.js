/**
 * 在线项目加入计划的按钮
 * Created by zk on 2017/9/19.
 */
import React, { Component } from 'react';
import { StyleSheet, View, Image, SafeAreaView, Alert, Text, DeviceEventEmitter } from 'react-native';
import { connect } from 'react-redux';
import { Actions } from 'react-native-router-flux';
import { AC_ADD_TO_LEARN, AC_START_QA } from '../../../redux/actions/course';
import { SeaScale, SeaTheme, SeaColor, SeaConstant } from '../../../asserts';
import { SeaLikeButton, SeaTextButton, SeaScoreButton, SeaButton, SeaFavoriteButton } from '../../../components';
import { ResourceProxy } from '../../resource';
import { PersonalService } from '../../../servie';
import PropTypes from 'prop-types';

@connect(mapStateToProps, mapDispatchToProps)
export default class ToLearnBottomBar extends Component {
    static propTypes = { businessType: PropTypes.string };

    static defaultProps = {
        // businessType: '1',
    };

    constructor(props) {
        super(props);
        this.state = {
            like: false,
            count: 0,
            isComment: false,
        }
    }
    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_STATE,
            () => { this._getState() }
        );
        this._getState();
    }
    componentWillUnmount() {
        this.listener.remove();
    };

    render() {
        const { like, count, isComment } = this.state;
        return (
            <SafeAreaView>
                <View style={SeaTheme.footerToolBar.box}>
                    <SeaLikeButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        imageStyle={SeaTheme.footerToolBar.icon}
                        titleStyle={SeaTheme.footerToolBar.buttonAssideText}
                        id={this.props.data.id}
                        enabled={this.props.data.status === '1'}
                    />
                    <SeaFavoriteButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        imageStyle={SeaTheme.footerToolBar.icon}
                        titleStyle={SeaTheme.footerToolBar.buttonAssideText}
                        id={this.props.data.id}
                        type={SeaConstant.ResourceType.ONLINE_COURSE}
                        enabled={this.props.data.status === '1'}
                    />
                    <SeaButton style={SeaTheme.footerToolBar.buttonAsside} onPress={this._onTestPress}>
                        <Image
                            style={SeaTheme.footerToolBar.icon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-test.png')}
                        />
                    </SeaButton>
                    <SeaButton style={SeaTheme.footerToolBar.buttonAsside} onPress={this._onQuestionPress}>
                        <Image
                            style={SeaTheme.footerToolBar.icon}
                            resizeMode="contain"
                            source={require('../../../asserts/images/ic-bottom-qn.png')}
                        />
                    </SeaButton>
                    <SeaScoreButton
                        style={SeaTheme.footerToolBar.buttonAsside}
                        imageStyle={SeaTheme.footerToolBar.icon}
                        resourceId={this.props.data.id}
                        initCommented={isComment}
                        businessType={this.props.businessType}
                    />
                    <SeaTextButton
                        theme="main"
                        style={SeaTheme.footerToolBar.buttonMain}
                        titleStyle={SeaTheme.footerToolBar.buttonMainText}
                        onPress={this._addToLearn}
                        title="加入计划"
                    />
                </View>
            </SafeAreaView>
        );
    }

    _getState() {
        const resourceId = _.get(this.props.data, 'id', '');
        PersonalService.queryResourceById(resourceId).then(responseJson => {
            this.setState({
                like: responseJson.data.like,
                count: responseJson.data.likeCount,
                isComment: responseJson.data.evaluateParentCount > 0,
            })
            return Promise.resolve({

            })
        }).catch(() => {
            FSLToast.show(error.message);
            return Promise.reject(error);
        })

    }

    // 点击加入计划
    _addToLearn = () => {
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            this.props.addToLearn(this.props.data.id);
        });
    };

    // 点击评分
    _onScorePress = () => {
        Actions.show('addScore', { resourceId: this.props.data.id, businessType: this.props.businessType });
    };

    //点击答题按钮
    _onTestPress = () => {
        // 进入考试
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (this.props.testPapers.length < 1) {
                Alert.alert('提示', '该项目还没有考试哦~', [{ text: '确定' }], {
                    cancelable: false,
                });
            } else {
                this.props.startQA();
                Actions.show('testResourcePaperList', { id: this.props.data.id, showResult: true });
            }
        });
    };

    //点击问卷按按钮
    _onQuestionPress = () => {
        // 进入问卷
        ResourceProxy.publishedProxy(this.props.data.status, () => {
            if (this.props.questionData.length < 1) {
                Alert.alert('提示', '该项目还没有问卷哦~', [{ text: '确定' }], {
                    cancelable: false,
                });
            } else {
                this.props.startQA();
                Actions.show('questionnaireList', {
                    data: this.props.questionData,
                    resourceId: this.props.data.id,
                });
            }
        });
    };
}

const BAR_HEIGHT = SeaScale.Layout(88);
const IMAGE_BTN_WIDTH = SeaScale.Layout(100);
const ICON_SIZE = SeaScale.Layout(38);

const styles = StyleSheet.create({
    // container: {
    //     flexDirection: 'row',
    //     width: SeaScale.screenWidth,
    //     borderColor: SeaColor.parting_line,
    //     borderTopWidth: SeaTheme.line_width_xs,
    //     borderBottomWidth: SeaTheme.line_width_xs,
    //     backgroundColor: SeaTheme.footer_bg,
    //     padding: SeaTheme.footer_padding,
    // },
    // toLearnButton: {
    //     height: SeaTheme.footer_elem_height,
    //     flex: 1,
    // },
    // toLearnText: {
    //     fontSize: SeaTheme.font_size_lg,
    // },
    // bar_icon: {
    //     // width: SeaTheme.footer_elem_height,
    //     height: SeaTheme.footer_icon_size,
    //     backgroundColor: "red",
    // },
    // bar_button: {
    //     width: IMAGE_BTN_WIDTH,
    //     height: SeaTheme.footer_elem_height,
    //     alignItems: 'center',
    //     justifyContent: 'center',
    //     backgroundColor: "#f0f",
    // },
    bar_txt: {
        color: SeaColor.content_text,
        marginTop: SeaScale.Layout(6),
        fontSize: SeaTheme.font_size_xxs,
    },
});

//store到action的state映射
function mapStateToProps(store) {
    return {
        data: store.courseStore.data,
        toLearn: store.courseStore.toLearn,
        like: store.likeStore.data,
        // add by xukj - 1.41.0
        questionData: store.courseStore.questionnaires,
        testPapers: store.courseStore.testPapers,
    };
}
//store到action的action映射
function mapDispatchToProps(dispatch) {
    return {
        addToLearn: resourceId => dispatch(AC_ADD_TO_LEARN(resourceId)),
        // add by xukj - 1.41.0
        startQA: () => dispatch(AC_START_QA()),
    };
}
