/*
 * @Author: your name
 * @Date: 2020-08-05 17:37:47
 * @LastEditTime: 2020-08-14 15:03:16
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \learn\src\view\course\detail\CourseProjectContent.js
 */
/**
 * 资源播放主页面
 */

import React from 'react';
import { View } from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';
import { connect } from 'react-redux';
import styles from './contentStyle';
import { CurriculaCatalogView, Comment } from '../../resource';
import CourseProjectBaseInfo from './CourseProjectBaseInfo';
import ToLearnBottomBar from './ToLearnBottomBar';
import LearnedBottomBar from './LearnedBottomBar';
import { CustomTopTabBar } from '../../../components';
import { FSLToast } from 'react-native-kpframework';
import { CaseEvaluateDetailPage } from '../../evaluate';
import PropTypes from 'prop-types';

@connect(mapStateToProps)
export default class CourseProjectContent extends React.PureComponent {
    static propTypes = {
        businessType: PropTypes.string,
    };
    constructor(props) {
        super(props);
        this.tab;
    }

    render() {
        const { data, toLearn } = this.props;

        const chapters = _.get(data, 'curricula.chapters', null);
        const snapshotId = _.get(data, 'curricula.id', '');
        const resourceId = _.get(data, 'id', '');
        const fileType = _.get(data, 'curricula.chapters.[0].contents[0].fileType', '');
        // alert(JSON.stringify(data.curricula.chapters[0].contents[0].fileType))
        //判断在线项目是否已报名
        const isAssign = _.get(data, 'isAssign', 0) == 1 || toLearn;

        return (
            <View style={styles.flex}>
                <ScrollableTabView
                    ref={_comp => (this.tab = _comp)}
                    renderTabBar={() => <CustomTopTabBar underline />}
                >
                    <View tabLabel="课程介绍" style={styles.flex}>
                        <CourseProjectBaseInfo onShowCommentPress={this._onShowCommentPress} />
                    </View>
                    <View tabLabel="目录" style={styles.flex}>
                        <CurriculaCatalogView
                            chapters={chapters}
                            snapshotId={snapshotId}
                            resourceId={resourceId}
                            type={1}
                        />
                    </View>
                    <View tabLabel="评价" style={styles.flex}>
                        {/* <Comment from="eclass" resourceId={this.props.data.id} /> */}
                        <CaseEvaluateDetailPage title='111'
                            businessType={this.props.businessType}
                            businessId={resourceId} ></CaseEvaluateDetailPage>
                    </View>
                </ScrollableTabView>
                {isAssign ? <LearnedBottomBar businessType={this.props.businessType} /> :
                    <ToLearnBottomBar businessType={this.props.businessType} />}
            </View>
        );
    }

    _onShowCommentPress = () => {
        this.tab && this.tab.goToPage(2);
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        data: store.courseStore.data,
        toLearn: store.courseStore.toLearn,
    };
}
