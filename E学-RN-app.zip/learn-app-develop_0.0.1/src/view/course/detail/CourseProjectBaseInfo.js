/**
 * @author xukj
 * @date 2019/08/09
 * @description e课基本信息UI
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, View, ScrollView, DeviceEventEmitter } from 'react-native';
import { connect } from 'react-redux';
import styles from './baseInfoStyle';
import { SeaTheme, SeaScale, SeaColor, SeaConstant } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';
import { Rating } from 'react-native-ratings';
import { Icon, AirbnbRating } from 'react-native-elements';
import { SeaFlagText } from '../../../components';
import { PersonalService } from '../../../servie';

@connect(mapStateToProps)
export default class CourseProjectBaseInfo extends React.PureComponent {
    static propTypes = {
        onShowCommentPress: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            evaluateCount: 0,
            avgScore: 0,
        };
    }
    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_STATE,
            () => {
                this._getEvaluateCount();
            }
        );
        this._getEvaluateCount();
    }
    componentWillUnmount() {
        this.listener.remove();
    }

    render() {
        return (
            <ScrollView style={{ flex: 1 }}>
                <View style={{ paddingHorizontal: SeaTheme.h_spacing_md }}>
                    <FSLWhiteSpace size={SeaScale.Layout(50)} />
                    <Text style={styles.title}>课程名字：{this.props.data.name}</Text>
                    <View
                        style={{
                            marginTop: SeaScale.Layout(30),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                    >
                        <View style={{ width: SeaScale.Layout(250) }}>
                            <AirbnbRating
                                showRating={false}
                                defaultRating={this.state.avgScore}
                                count={5}
                                size={SeaScale.Layout(35)}
                                selectedColor={SeaColor.orange}
                                isDisabled={true}
                            />
                        </View>
                        <Text style={{ marginLeft: SeaScale.Layout(10) }}>
                            {this.state.avgScore} 分
                        </Text>
                    </View>
                    <FSLWhiteSpace style={styles.sp} size={SeaScale.Layout(30)} />
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <Text style={styles.itemText}>
                        发布人：
                        <Text style={styles.itemContentText}>{this.props.data.publisher}</Text>
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <Text style={styles.itemText}>
                        讲&emsp;师：
                        <Text style={styles.itemContentText}>{this.props.data.teacher}</Text>
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <Text style={styles.itemText}>
                        有效期：
                        <Text style={styles.itemContentText}>{this._getValidDate()}</Text>
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <Text style={styles.itemText}>
                        积&emsp;分：
                        <Text style={styles.itemContentText}>{this.props.data.score}分</Text>
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <View style={styles.tagView}>
                        <Text style={styles.itemText}>
                            标&emsp;签：
                            {/* <Text style={styles.itemContentText}>
                                {_.chain(this.props.data)
                                    .get('tags', [])
                                    .map(tag => tag.name)
                                    .join('/')
                                    .value()}
                            </Text> */}
                        </Text>
                        <this._renderTagList tagsName={this.props.data} />
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(28)} />
                    <Text style={styles.itemText}>
                        介&emsp;绍：
                        <Text style={styles.itemContentText}>{this.props.data.summary}</Text>
                    </Text>
                    <FSLWhiteSpace size={SeaScale.Layout(50)} />
                </View>
            </ScrollView>
        );
    }

    _getValidDate() {
        if (this.props.data.validStart != null && this.props.data.validEnd != null) {
            return this.props.data.validStart + ' 至 ' + this.props.data.validEnd;
        } else {
            return '长期有效';
        }
    }
    _getEvaluateCount() {
        const resourceId = _.get(this.props.data, 'id', '');
        PersonalService.queryResourceById(resourceId)
            .then((responseJson) => {
                this.setState({ evaluateCount: responseJson.data.evaluateCount });
                this.setState({ avgScore: parseInt(responseJson.data.avgScore) });
                return Promise.resolve({});
            })
            .catch(() => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    }

    _renderTagList = (props) => {
        const { tagsName } = props;
        const tagViews = _.isEmpty(tagsName)
            ? null
            : _.chain(tagsName)
                  .get('tags', [])
                  .map((tag, index) => {
                      return (
                          <SeaFlagText
                              style={tagTxtStyles[index%5]}
                              ellipsizeMode="tail"
                              numberOfLines={1}
                          >
                              {tag.name}
                          </SeaFlagText>
                      );
                  })
                  .value();
        return <View style={styles.tagGroup}>{tagViews}</View>;
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        data: store.courseStore.data,
        toLearn: store.courseStore.toLearn,
        like: store.likeStore.data,
    };
}

const tagTxtStyles = [
    styles.tagText0,
    styles.tagText1,
    styles.tagText2,
    styles.tagText3,
    styles.tagText4,
];
