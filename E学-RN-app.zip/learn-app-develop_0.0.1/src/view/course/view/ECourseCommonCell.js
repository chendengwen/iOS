/**
 * @author xukj
 * @date 2019/08/15
 * @description 通用e课cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell, SeaFlagText, SeaCoverImage } from '../../../components/index';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts/index';
import ECourseData from '../data/ECourseData';

export default class ECourseCommonCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(ECourseData).isRequired,
        onPress: PropTypes.func,
        keyword: PropTypes.string,
    };

    static defaultProps = {
        onPress: () => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {
    }

    _keywordTitle = (keyword, strins) => {
        let data = strins          //   获取文本
        let newData = data.split(keyword)       //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.title} numberOfLines={2}>
                {
                    newData.map((item, index) => {
                        return <Text key={index}>
                            {item}
                            {(index < newData.length - 1) && (<Text style={{ color: 'red' }}>{keyword}</Text>)}
                        </Text>
                    })
                }
            </Text>
        )
    }

    _keywordTags = (keyword, strins) => {
        let data = strins          //   获取文本
        let newData = data.split(keyword)       //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.tag} numberOfLines={1}>
                {
                    newData.map((item, index) => {
                        return <Text key={index}>
                            {item}
                            {(index < newData.length - 1) && (<Text style={{ color: 'red' }}>{keyword}</Text>)}
                        </Text>
                    })
                }
            </Text>
        )
    }

    render() {
        const { item, onPress, keyword, ...restProps } = this.props;
        convertToTableData(item)
        return (
            <SeaListCell
                backgroundColor="white"
                style={styles.cell}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.content}>
                    <SeaCoverImage style={styles.cover} source={item.coverSource()}>
                        <SeaFlagText>在线学习</SeaFlagText>
                    </SeaCoverImage>
                    <View style={styles.rightContent}>
                        <View >
                            {
                                item.name && item.name.includes(keyword) ?
                                    this._keywordTitle(keyword, item.name) :
                                    <Text style={styles.title} numberOfLines={2}>
                                        {item.name}
                                    </Text>
                            }
                        </View>
                        <View style={styles.tagContainer}>
                            {/* {
                                item.tagsName && item.tagsName.includes(keyword) ?
                                    this._keywordTags(keyword, item.tagsName) :
                                    <Text style={styles.tag} numberOfLines={1}>
                                        {item.tagsName}
                                    </Text>
                            } */}

                            {(item.tagsName && item.tagsName.length >= 1) && (
                                <View >
                                    {
                                        item.tagsName[0].includes(keyword) ?
                                            this._keywordTags(keyword, item.tagsName[0]) :
                                            <Text style={styles.tag} numberOfLines={1}>{item.tagsName[0]} </Text>
                                    }
                                </View>
                            )}
                            {(item.tagsName && item.tagsName.length >= 2) && (
                                <View >
                                    {
                                        item.tagsName[1].includes(keyword) ?
                                            this._keywordTags(keyword, item.tagsName[1]) :
                                            <Text style={styles.tag} numberOfLines={1}>{item.tagsName[1]} </Text>
                                    }
                                </View>
                            )}
                            {(item.tagsName && item.tagsName.length >= 3) && (
                                <View >
                                    {
                                        item.tagsName[2].includes(keyword) ?
                                            this._keywordTags(keyword, item.tagsName[2]) :
                                            <Text style={styles.tag} numberOfLines={1}>{item.tagsName[2]} </Text>
                                    }
                                </View>
                            )}
                        </View>
                        <Text style={styles.time} numberOfLines={1} adjustsFontSizeToFit>
                            发布时间：{item.publishTime}
                        </Text>
                    </View>
                </View>
            </SeaListCell>
        );
    }

}
const convertToTableData = (item) => {
    item.tagsName = item.tagsName && item.tagsName.length > 0 ? (item.tagsName + '').split(",") : [];
    item.name = item.name && item.name.length > 0 ? item.name : item.resourceName;
    return item;
};

const styles = StyleSheet.create({
    cell: {
        height: SeaScale.Layout(250),
    },
    content: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    rightContent: {
        flex: 1,
        height: SeaScale.Layout(180),
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    cover: {
        width: SeaScale.Layout(250),
        height: SeaScale.Layout(188),
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        backgroundColor: SeaColor.img_background,
        borderRadius: SeaTheme.raduis_sm,
        marginLeft: SeaTheme.h_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    tag: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
        borderRadius: 3,
        borderColor: '#FCFCD2',
        backgroundColor: '#FCFCD2',
        borderWidth: 0.5,
        marginRight: 5,
        width: SeaScale.Layout(128),
        textAlign: 'center',
    },
    time: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
    tagContainer: {
        flexDirection: 'row',
        width: SeaScale.Layout(100),
    },
});
