/**
 * @author xukj
 * @date 2019/08/08
 * @description e课模块
 */
// e课数据模型
export { default as ECourseData } from './data/ECourseData';
// e课cell
export { default as ECourseCommonCell } from './view/ECourseCommonCell';

// e课列表页
export { default as ECourseListPage } from './list/ECourseListPage';
// e课计划列表页
export { default as ECourseToLearnPage } from './tolearn/ECourseToLearnPage';
// e课详情页
export { default as ECourseDetailPage } from './detail/ECourseDetailPage';

export {default as EClassApprove}   from  './approve/EClassApprovePage';
