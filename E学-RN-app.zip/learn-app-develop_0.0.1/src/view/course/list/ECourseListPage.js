
/**
 * @author xukj
 * @date 2019/08/08
 * @description ECourseListPage e课列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { CategoryService, CourseService } from '../../../servie';
import { Actions } from 'react-native-router-flux';
import { FSLToast, FSLWhiteSpace } from 'react-native-kpframework';
import ECourseList from './ECourseList';
import { SeaConstant, SeaScale } from '../../../asserts';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default class ECourseListPage extends React.PureComponent {
    // 提供给外部的属性
    static propTypes = {
        category: PropTypes.string, // 分类
    };

    // 需要设置默认值的属性
    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const loader = this.props.category ? this._categoryLoader : this._AllLoader;
        const { from } = this.props;
        return (
            <View style={from != 'category' ? styles.parent : styles.category}>
                {from != 'category' &&
                    <View style={styles.caseArt} >
                        <Text style={{ height: 80, marginLeft: 20, marginTop: 12, fontSize: 16, color: '#000000' }}>在线学习</Text>

                        <TouchableOpacity
                            style={{
                                position: 'absolute', bottom: 2, height: 40, justifyContent: 'center',
                                width: SeaScale.screenWidth / 2, left: 20
                            }}
                            onPress={this._toCategory}
                        >
                            <Text style={{ fontSize: 14, color: '#000000' }}>全部分类</Text>
                        </TouchableOpacity>

                    </View>}
                {from != 'category' && <FSLWhiteSpace size={SeaScale.Layout(24)} ></FSLWhiteSpace>}
                <ECourseList onFetch={loader} onCellPress={this._onCellPress} />
            </View>
        );
    }

    _toCategory = () => {
        Actions.show('categoryChoose', { index: 0, from: 'eclass' });
    }

    /*
     * @private
     * @description 点击事件，查看详情
     */
    _onCellPress = item => {
        Actions.show('courseDetail', { Id: item.id });
    };

    /*
     * @private
     * @description 获取阅读列表
     */
    _AllLoader = (pageTo, pageSize) => {
        return CourseService.getAllCourseResource(pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data == null ? null : responseJson.data.data,
                    totalPage:
                        responseJson.data == null ? 0 : (responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize)),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    /**
     * @private
     * @description E课分类api
     */
    _categoryLoader = (pageTo, pageSize) => {
        return CategoryService.getResourceList(
            this.props.category,
            SeaConstant.ResourceType.ONLINE_COURSE,
            this.props.isLoadAll,
            pageTo,
            pageSize
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
}
const styles = StyleSheet.create({
    parent: {
        flex: 1,
        position: 'relative',
        flexDirection: 'column',
        paddingTop: 80,
        backgroundColor: '#eeeeee'
    },
    category: {
        flex: 1,
        position: 'relative',
        flexDirection: 'column',
        backgroundColor: '#eeeeee'
    },
    caseArt: {
        position: 'absolute',
        flexDirection: 'column',
        top: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        zIndex: 1
    },
})