/**
 * @author xukj
 * @date 2019/08/08
 * @description ECourseListCell e课列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, View, Image, StyleSheet } from 'react-native';
import { SeaListCell, SeaFlagText, SeaCoverImage } from '../../../components';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import ECourseData from '../data/ECourseData';

export default class ECourseListCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(ECourseData).isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    render() {
        const { item, onPress, ...restProps } = this.props;
        return (
            <SeaListCell
                backgroundColor="white"
                showArrow={false}
                showSeparator
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.content}>
                    <SeaCoverImage style={styles.cover} source={item.coverSource()}>
                        {item.finishStudy == 1 && <SeaFlagText theme="red">已学</SeaFlagText>}
                    </SeaCoverImage>
                    <View style={styles.rightContent}>
                        <Text style={styles.title} numberOfLines={2}>
                            {item.name}
                        </Text>
                        <Text style={styles.desc}>
                            {item.frequency > 9999 ? `${item.frequency / 10000}万` : item.frequency}
                            次学习
                        </Text>
                        <View>
                            <View style={styles.flagContainer}>
                                {this._renderDocFlag(item)}
                                {this._renderAudioFlag(item)}
                                {this._renderVideoFlag(item)}
                            </View>
                        </View>
                    </View>
                </View>
            </SeaListCell>
        );
    }

    _renderDocFlag = item => {
        if (item.hasDoc()) {
            return (
                <Image
                    style={styles.typeFlag}
                    source={require('../../../asserts/images/resource/icon_tag_doc.png')}
                />
            );
        }
    };

    _renderVideoFlag = item => {
        if (item.hasVideo()) {
            return (
                <Image
                    style={styles.typeFlag}
                    source={require('../../../asserts/images/resource/icon_tag_vedio.png')}
                />
            );
        }
    };

    _renderAudioFlag = item => {
        if (item.hasAudio()) {
            return (
                <Image
                    style={styles.typeFlag}
                    source={require('../../../asserts/images/resource/icon_tag_audio.png')}
                />
            );
        }
    };
}

const styles = StyleSheet.create({
    content: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        height: SeaScale.Layout(250),
    },
    rightContent: {
        flex: 1,
        height: SeaScale.Layout(180),
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
    },
    cover: {
        width: SeaScale.Layout(250),
        height: SeaScale.Layout(188),
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        backgroundColor: SeaColor.img_background,
        borderRadius: SeaTheme.raduis_sm,
        marginLeft: SeaTheme.v_spacing_md,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    desc: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    flagContainer: {
        flexDirection: 'row',
        width: SeaScale.Layout(100),
    },
    typeFlag: {
        width: SeaScale.Layout(60),
        height: SeaScale.Layout(30),
        marginRight: SeaScale.Layout(6),
    },
});
