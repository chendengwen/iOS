/**
 * @author xukj
 * @date 2019/08/08
 * @class
 * @description e课计划列表UI
 */
import React from 'react';
import PropTypes from 'prop-types';
import { SeaList } from '../../../components';
import ECourseToLearnCell from './ECourseToLearnCell';
import { SeaStyle } from '../../../asserts';

export default class ECourseToLearn extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onFetch: PropTypes.func.isRequired,
        onCellPress: PropTypes.func,
        onDeletePress: PropTypes.func,
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => {},
        onDeletePress: (item, index) => {},
    };

    reload = () => {
        this.refs.list.reload();
    };

    constructor(props) {
        super(props);
        this.openCell;
    }

    componentDidMount() {}

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaList
                style={SeaStyle.list}
                ref="list"
                onFetch={onFetch}
                data={defaultData}
                renderItem={this._renderItem}
            />
        );
    }

    /*
     * private
     * @method 列表项
     */
    _renderItem = ({ item, index }) => {
        return (
            <ECourseToLearnCell
                data={item}
                index={index}
                onPress={comp => this._onPress(item, index, comp)}
                onDeletePress={comp => this._onDeletePress(item, index, comp)}
                onRowOpen={comp => this._onRowOpen(item, index, comp)}
                onRowClose={comp => this._onRowClose(item, index, comp)}
            />
        );
    };

    _onPress = (data, index, comp) => {
        this.openCell && this.openCell.closeRow();
        this.openCell = null;
        if (this.props.onCellPress) this.props.onCellPress(data, index);
    };

    _onDeletePress = (data, index, comp) => {
        this.openCell && this.openCell.closeRow();
        this.openCell = null;
        if (this.props.onDeletePress) this.props.onDeletePress(data, index);
    };

    _onRowOpen = (data, index, comp) => {
        if (this.openCell && this.openCell.props.index != index) {
            this.openCell.closeRow();
        }
        this.openCell = comp;
    };

    _onRowClose = (data, index, comp) => {};
}
