/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-07 16:41:42
 */

/**
 * @author xukj
 * @date 2019/08/08
 * @class
 * @description e课计划列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLToast, FSLPrompt } from 'react-native-kpframework';
import { ToLearnService } from '../../../servie';
import { SeaConstant } from '../../../asserts';
import { Actions } from 'react-native-router-flux';
import ECourseToLearn from './ECourseToLearn';

export default class ECourseToLearnPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey;
        this._list;
    }

    componentDidMount() {

    }

    render() {
        return (
            <ECourseToLearn
                ref={comp => (this._list = comp)}
                onFetch={this._loader}
                onCellPress={this._onCellPress}
                onDeletePress={this._onDeletePress}
            />
        );
    }

    // 分页的加载逻辑
    _loader = (pageTo, pageSize) => {
        return ToLearnService.getToLearnResourceList(
            pageTo,
            pageSize,
            SeaConstant.ResourceType.ONLINE_COURSE
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = (item, index) => {
        Actions.show('courseDetail', { Id: item.resourceId, businessType: 1 }, true);
    };

    _onDeletePress = async (item, index) => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍后');
            await ToLearnService.deleteToLearn(item.id);
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show('删除成功');
            this._list && this._list.reload(); // 刷新列表
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };
}
