/**
 * @author xukj
 * @date 2019/08/08
 * @description e课计划列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Text, View, Image, StyleSheet } from 'react-native';
import { ListDeleteCell, SeaCoverImage } from '../../../components';
import { SeaImageUtil } from '../../../util';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';

export default class ECourseToLearnCell extends React.PureComponent {
    static propTypes = {
        // data
        data: PropTypes.object,
        index: PropTypes.number,
        // cell点击
        onPress: PropTypes.func, // 点击事件
        onDeletePress: PropTypes.func, // 删除按钮点击
        onRowOpen: PropTypes.func,
        onRowClose: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => { },
        onDeletePress: () => { },
        onRowOpen: () => { },
        onRowClose: () => { },
    };

    /**
     * 关闭删除按钮
     */
    closeRow = () => {
        this._comp && this._comp.closeRow();
    };

    constructor(props) {
        super(props);
        this._comp;
    }

    render() {
        return this._renderSwipeCommonItem(this.props);
    }

    // 默认展示的组件
    _renderSwipeCommonItem = props => {
        const { data, onPress, onDeletePress, onRowOpen, onRowClose, ...restProps } = props;
        return (
            <ListDeleteCell
                ref={_comp => (this._comp = _comp)}
                onPress={this._onPress(onPress)}
                onDeletePress={this._onDeletePress(onDeletePress)}
                onRowOpen={this._onRowOpen(onRowOpen)}
                onRowClose={this._onRowClose(onRowClose)}
                {...restProps}
            >
                <View style={learnStyles.courseContainer}>
                    <SeaCoverImage
                        style={learnStyles.courseCoverImage}
                        source={SeaImageUtil.getImageSource(data.coverImageId, data.coverImageUrl)}
                    >
                        {this._renderUnderCarriage(data)()}
                    </SeaCoverImage>
                    <View style={learnStyles.courseMiddlePanel}>
                        <Text style={learnStyles.courseTitleText} numberOfLines={2}>
                            {data.resourceName}
                        </Text>
                        {/* {this._renderValidDateFlag(data)()} */}
                        <View style={learnStyles.tagContainer}>
                            {/* {Number(data.required) === 1 && (
                                <Image
                                    style={learnStyles.tagImage}
                                    source={require('../../../asserts/images/tolearn/force.png')}
                                    resizeMode="contain"
                                />
                            )}
                            {Number(data.required) === 2 && (
                                <Image
                                    style={learnStyles.tagImage}
                                    source={require('../../../asserts/images/tolearn/choose.png')}
                                    resizeMode="contain"
                                />
                            )}
                            {Number(data.required) === 3 && (
                                <Image
                                    style={learnStyles.tagImage}
                                    source={require('../../../asserts/images/tolearn/self.png')}
                                    resizeMode="contain"
                                />
                            )} */}
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Image
                                    style={learnStyles.tagImage}
                                    source={require('../../../asserts/images/myView/integral.png')}
                                    resizeMode="contain"
                                />
                                <Text style={learnStyles.courseDetailText} numberOfLines={1}>
                                    {data.score}分
                                </Text>
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center',marginLeft:SeaScale.Layout(70) }}>
                                <Image
                                    style={learnStyles.tagImage}
                                    source={require('../../../asserts/images/case/preview.png')}
                                    resizeMode="contain"
                                />
                                <Text style={learnStyles.courseDetailText} numberOfLines={1}>
                                    {data.frequency}人
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </ListDeleteCell>
        );
    };

    // 长期有效展示
    _renderValidDateFlag = item => {
        const time = item.endTime !== null ? item.endTime : '长期有效';
        return () => {
            const showDate = time !== '长期有效' ? '到期时间：' + time : '长期有效';
            return <Text style={learnStyles.courseDetailText}>{showDate}</Text>;
        };
    };

    // 下架展示
    _renderUnderCarriage = item => {
        const status = item.status === 2;
        return () => {
            return (
                <View style={status ? learnStyles.maskView : learnStyles.hidden}>
                    <View style={learnStyles.unavailableView}>
                        <Text style={learnStyles.maskTag}>已下架</Text>
                    </View>
                </View>
            );
        };
    };

    _onRowOpen = onRowOpen => () => {
        if (onRowOpen) onRowOpen(this._comp);
    };

    _onRowClose = onRowClose => () => {
        if (onRowClose) onRowClose(this._comp);
    };

    _onPress = onPress => () => {
        if (onPress) onPress(this._comp);
    };

    _onDeletePress = onDeletePress => () => {
        if (onDeletePress) onDeletePress(this._comp);
    };
}

const learnStyles = StyleSheet.create({
    courseContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        height: SeaScale.Layout(250),
    },
    courseCoverImage: {
        marginLeft: SeaTheme.h_spacing_md,
        width: SeaScale.Layout(250),
        height: SeaScale.Layout(188),
        backgroundColor: SeaColor.img_background,
    },
    courseMiddlePanel: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginLeft: SeaTheme.h_spacing_sm,
        marginRight: SeaTheme.h_spacing_md,
        height: SeaScale.Layout(180),
    },
    tagContainer: {
        flexDirection: 'row',
        marginTop: SeaScale.Layout(16),
    },
    courseTitleText: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        lineHeight: SeaScale.Layout(42),
    },
    courseDetailText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.tag_text,
    },
    maskView: {
        position: 'absolute',
        width: SeaScale.Layout(250),
        height: SeaScale.Layout(188),
        zIndex: 99999,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    unavailableView: {
        borderWidth: 2,
        borderColor: SeaColor.red,
        width: SeaScale.Layout(140),
        height: SeaScale.Layout(50),
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderRadius: SeaTheme.raduis_sm,
    },
    maskTag: {
        color: SeaColor.red,
        fontSize: SeaTheme.font_size_md,
        fontWeight: 'bold',
    },
    tagImage: {
        width: SeaScale.Layout(60),
        height: SeaScale.Layout(30),
        marginRight: SeaScale.Layout(6),
    },
    hidden: {
        position: 'absolute',
        left: -999,
    },
});
