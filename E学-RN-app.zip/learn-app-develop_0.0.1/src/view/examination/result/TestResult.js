/**
 * @author xukj
 * @date 2019/03/01
 * @class
 * @description TestResult
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, Image } from 'react-native';
import { SeaTextButton } from '../../../components';
import { SeaColor, SeaStyle } from '../../../asserts';
import styles from './styleTestResult';

export default class TestResult extends React.PureComponent {
    static propTypes = {
        pass: PropTypes.bool.isRequired, // 是否通过
        score: PropTypes.number.isRequired, // 得分
        restTimes: PropTypes.number, // 剩余考试次数
        onBackPress: PropTypes.func,
    };

    static defaultProps = {
        onBackPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { onBackPress } = this.props;
        const values = this._resultValues();

        return (
            <View style={SeaStyle.page}>
                <View style={styles.contentView}>
                    <View style={styles.contentTop}>
                        <Text style={[styles.title, { color: values.titleColor }]}>
                            {values.title}
                        </Text>
                        <Text style={styles.subTitle}>{values.subTitle}</Text>
                        <Image style={styles.icon} source={values.icon} />
                        {values.descNode}
                    </View>
                    <View style={styles.contentBottom}>
                        <SeaTextButton
                            theme="blue"
                            style={styles.button}
                            title="返回"
                            onPress={onBackPress}
                        />
                    </View>
                </View>
            </View>
        );
    }

    /**
     * @private
     * @description 结果
     */
    _resultValues = () => {
        const { pass, score, restTimes,subjectiveFlag} = this.props;
        // console.log(this.props,'props');
        let resData;
        if(subjectiveFlag==='1'){
            resData={
                title: '',
                titleColor: SeaColor.red_text,
                subTitle: '考试成绩待主观题阅卷完成后可查看',
                icon: require('../../../asserts/images/icon_result_score.png'),
                descNode:
                    restTimes > 0 ? (
                        <Text style={styles.description}>
                            您还有<Text style={{ color: SeaColor.red_text }}> {restTimes} </Text>
                            次考试机会，最终成绩取最高分
                        </Text>
                    ) : (
                        <Text style={styles.description}>
                            对不起，您的考试次数已耗尽，最终成绩取最高分
                        </Text>
                    ),
            };
        } else if(pass){
            resData ={
                title: `${score}分`,
                titleColor: SeaColor.green,
                subTitle: '恭喜您~考试通过！',
                icon: require('../../../asserts/images/icon_result_pass.png'),
                descNode: <Text style={styles.description}>不问收获，但问耕耘！天道酬勤~</Text>,
            }
        } else {
            resData={
                title: '很遗憾 没通过',
                titleColor: SeaColor.red_text,
                subTitle: '再接再厉 加油哦',
                icon: require('../../../asserts/images/icon_result_notpass.png'),
                descNode:
                    restTimes > 0 ? (
                        <Text style={styles.description}>
                            您还有<Text style={{ color: SeaColor.red_text }}> {restTimes} </Text>
                            次考试机会，最终成绩取最高分
                        </Text>
                    ) : (
                        <Text style={styles.description}>
                            对不起，您的考试次数已耗尽，最终成绩取最高分
                        </Text>
                    ),
            };
        }
        return resData
    };
}
