/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-11 17:18:56
 */
/**
 * @author xukj
 * @date 2019/02/28
 * @class
 * @description 考试结果页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Actions } from 'react-native-router-flux';
import TestResult from './TestResult';

export default class TestResultPage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 结果对象
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        // 得分
        const userScore = _.get(this.props, 'data.userScore', 0);
        const passScore = _.get(this.props, 'data.passScore', 100);
        const subjectiveFlag = _.get(this.props, 'data.subjectiveFlag', '0');
        const restTimes =
            _.get(this.props, 'data.testFrequency', 99) - _.get(this.props, 'data.examTimes', 0);

        return (
            <TestResult
                subjectiveFlag={subjectiveFlag}
                pass={userScore >= passScore}
                score={userScore}
                restTimes={restTimes >= 0 ? restTimes : 0}
                onBackPress={Actions.pop}
            />
        );
    }
}
