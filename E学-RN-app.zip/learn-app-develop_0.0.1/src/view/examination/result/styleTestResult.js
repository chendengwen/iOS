/**
 * @author xukj
 * @date 2019/07/04
 * @description 考试结果页样式
 */
import { StyleSheet } from 'react-native';
import { SeaColor, SeaScale } from '../../../asserts';

// 兼容5s
const space = SeaScale.screenHeight > 568 ? 50 : 20;

export default {
    page: {
        flex: 1,
        backgroundColor: '#e0f5fe',
    },
    contentView: {
        margin: 10,
        flex: 1,
        backgroundColor: 'white',
        borderRadius: 4,
    },
    contentTop: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 8,
        paddingRight: 8,
    },
    contentBottom: {
        height: 105,
        marginLeft: 10,
        marginRight: 10,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: SeaColor.parting_line,
        flexDirection: 'row',
        alignItems: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: '600',
        color: SeaColor.red_text,
    },
    subTitle: {
        fontSize: 16,
        color: SeaColor.h2_text,
        marginTop: 12,
    },
    icon: {
        width: 222,
        height: 190,
        marginTop: space,
    },
    description: {
        fontSize: 16,
        color: SeaColor.h1_text,
        marginTop: space,
        textAlign: 'center',
        lineHeight: 24,
    },
    button: {
        flex: 1,
        marginLeft: 8,
        marginRight: 8,
        borderRadius: 23,
        height: 46,
        fontSize: 16,
    },
};
