/**
 * @author xukj
 * @date 2019/06/26
 * @description 考试信息页样式表
 */
import { StyleSheet } from 'react-native';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';

// 通用
const flex1 = {
    flex: 1,
};

const container = {
    width: SeaScale.screenWidth,
    paddingLeft: SeaTheme.h_spacing_md,
    paddingRight: SeaTheme.h_spacing_md,
    backgroundColor: 'white',
};

const rowContainer = {
    paddingTop: SeaScale.Layout(40),
    paddingBottom: SeaScale.Layout(40),
    flexDirection: 'row',
    alignItems: 'center',
};

// 考试信息页，头部提示banner
const bannerContainer = {
    minHeight: SeaScale.Layout(60),
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingLeft: SeaTheme.h_spacing_md,
    paddingRight: SeaTheme.h_spacing_md,
    paddingTop: SeaTheme.v_spacing_sm,
    paddingBottom: SeaTheme.v_spacing_sm,
    backgroundColor: '#FFF8D6',
};

const bannerTitle = {
    fontSize: SeaTheme.font_size_md,
    color: '#eb6100',
    lineHeight: SeaScale.Layout(40),
    flex: 1,
    marginLeft: SeaScale.Layout(12),
};

// 考试信息页，结果组件
const resultCell = {
    justifyContent: 'space-between',
    flex: 1,
};

const resultValue = {
    marginTop: SeaScale.Layout(24),
    fontSize: SeaScale.Font(48),
    color: SeaColor.h2_text,
};

// 分割线
const line = {
    height: SeaScale.Layout(20),
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: SeaColor.parting_line,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    backgroundColor: SeaColor.defaultBackgroudColor_3,
};

// 考试信息页，表格组件
const header = {
    height: SeaScale.Layout(100),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
};

// 通用
const title = {
    fontSize: SeaTheme.font_size_lg,
    color: SeaColor.h1_text,
};

const content = {
    fontSize: SeaTheme.font_size_md,
    color: SeaColor.h2_text,
};

const cell = {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
};

const sp_bottom = {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
};

// 描述

const desc_container = {
    width: SeaScale.screenWidth,
    backgroundColor: 'white',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    marginBottom: SeaTheme.v_spacing_sm,
};

const desc_head = {
    height: SeaTheme.row_height_md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
};

const desc_favorite = {
    marginRight: SeaScale.Layout(50),
    height: SeaScale.Layout(68),
};

const desc_flag = {
    height: SeaScale.Layout(24),
    width: SeaScale.Layout(4),
    backgroundColor: SeaColor.main,
    marginLeft: SeaScale.Layout(12),
    marginRight: SeaScale.Layout(12),
};

const desc_content = {
    padding: SeaTheme.h_spacing_md,
    lineHeight: SeaScale.Layout(40),
    color: SeaColor.h2_text,
    fontSize: SeaTheme.font_size_md,
};

// 试卷信息
const info_container = {
    width: SeaScale.screenWidth,
    height: SeaScale.Layout(404),
    flexDirection: 'row',
    backgroundColor: 'white',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: SeaColor.parting_line,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    marginBottom: SeaTheme.v_spacing_sm,
};

const info_leftrow = {
    flex: 7,
    borderRightWidth: StyleSheet.hairlineWidth,
    borderRightColor: SeaColor.parting_line,
    alignItems: 'center',
    justifyContent: 'center',
};

const info_icon = {
    width: SeaScale.Layout(60),
    height: SeaScale.Layout(70),
    marginTop: SeaScale.Layout(32),
};

const info_score = {
    fontSize: SeaScale.Font(40),
    color: SeaColor.red_text,
    marginTop: SeaScale.Layout(32),
};

const info_button = {
    height: SeaScale.Layout(68),
    width: SeaScale.Layout(200),
    borderRadius: SeaScale.Layout(34),
    marginTop: SeaScale.Layout(32),
};

const info_rightrow = {
    flex: 10,
};

// 结果
const result_container = {
    paddingLeft: SeaTheme.h_spacing_sm,
    paddingRight: SeaTheme.h_spacing_sm,
    marginBottom: SeaTheme.v_spacing_sm,
    height: SeaScale.Layout(190),
    flexDirection: 'row',
};

const result_times = {
    fontSize: SeaScale.Layout(40),
    color: SeaColor.h1_text,
};

// 历史
const list_container = {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: SeaColor.parting_line,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    backgroundColor: 'white',
    marginBottom: SeaScale.Layout(160),
};

const list_header = {
    height: SeaScale.Layout(120),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: SeaTheme.h_spacing_md,
    paddingRight: SeaTheme.h_spacing_md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: SeaColor.parting_line,
    backgroundColor: 'white',
};

const list_cell = {
    height: SeaScale.Layout(90),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: SeaTheme.h_spacing_md,
    paddingRight: SeaTheme.h_spacing_md,
};

const list_celltime = {
    ...content,
    flex: 1,
    textAlign: 'left',
};

const list_cellscore = {
    ...content,
    flex: 1,
    textAlign: 'center',
    color: SeaColor.red_text,
};

const list_cellreview = {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    flexDirection: 'row',
    paddingRight: SeaScale.Layout(36),
};

export default {
    flex1,
    container,
    rowContainer,
    bannerContainer,
    bannerTitle,
    resultCell,
    resultValue,
    line,
    header,

    title,
    content,
    cell,
    sp_bottom,
    desc_container,
    desc_head,
    desc_favorite,
    desc_flag,
    desc_content,
    info_container,
    info_leftrow,
    info_icon,
    info_score,
    info_button,
    info_rightrow,
    result_container,
    result_times,
    list_container,
    list_header,
    list_cell,
    list_celltime,
    list_cellscore,
    list_cellreview,
};
