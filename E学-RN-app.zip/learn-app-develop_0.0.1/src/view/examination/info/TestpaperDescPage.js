/**
 * @author xukj
 * @date 2017/7/19
 * @class
 * @description 考试信息简介页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Alert, View, BackHandler, Platform, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';
import { FSLLoadingView } from 'react-native-kpframework';
import { TestPaperService } from '../../../servie';
import { TestUtil } from '../../../util';
import { SeaNormalCard } from '../../../components';
import ExamAnswerManager from '../detail/ExamAnswerManager';
import TestPaperDesc from './TestPaperDesc';
import { SeaStyle, SeaConstant } from '../../../asserts';

@connect(mapStateToProps)
export default class TestpaperDescPage extends React.PureComponent {
    static propTypes = {
        basicData: PropTypes.any, // 试卷基础信息
        resourceId: PropTypes.string, // 试卷项目id
        id: PropTypes.string, // 试卷id
        assignment: PropTypes.bool, //是否已加入待考
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.answerManager = ExamAnswerManager.sharedInstance();
        this.state = {
            data: props.basicData, // 试卷基本信息
            resourceId: props.resourceId, // 试卷项目id
            id: props.id, // 试卷id 
            loading: false, // 等待框
            assignment: props.assignment,
        };
        this._backlistener;
        this._cardKey;
    }

    componentDidMount() {
        this._loadTestPaperDesc();
        if (Platform.OS == 'android') {
            this._backlistener = BackHandler.addEventListener('hardwareBackPress', () => {
                if (this._cardKey) {
                    SeaNormalCard.hide(this._cardKey);
                    this._cardKey = null;
                    return true;
                } else {
                    return false;
                }
            });
        }
    }

    componentWillUnmount() {
        if (this._backlistener) {
            this._backlistener.remove();
        }
    }

    render() {
        // 因为涉及到后台刷新，这里不能使用全局的等待框
        const { data, loading, assignment } = this.state;
        return (
            <View style={SeaStyle.page}>
                {data && (
                    <TestPaperDesc
                        data={data}
                        assignment={assignment}
                        onExamPress={this._onExamPress}
                        onReviewPress={this._onReviewPress}
                        onAddtoPlanPress={this._onAddtoPlan}
                    />
                )}
                {loading && <FSLLoadingView content="请稍等" mask={true} />}
            </View>
        );
    }
    /**
     * @description: 加入待考
     * @param {type} 
     * @return {type} 
     */
    _onAddtoPlan = async () => {
        try {
            const { resourceId } = this.state;
            const result = await TestPaperService.addtoPlan(resourceId);

            if (result.code != '000000') {
                this._showAlert(result.msg)
            } else {
                this.setState({ assignment: true })
                DeviceEventEmitter.emit(SeaConstant.Notification.REFRESH_EXAM_LIST)
            }
        } catch (error) {
            this._showAlert(error.message);
        }
    }
    /**
     * @private
     * @description 获取考试试卷信息
     */
    _loadTestPaperDesc = async () => {
        try {
            const { id } = this.props;
            if (!id) {
                this._showAlert('找不到该试卷', Actions.pop);
                return;
            }

            this.setState({ loading: true });
            const result = await TestPaperService.getPaperBaseInfo(id);
            if (result.code == '000000') {
                this.setState({
                    data: result,
                    id: result.data.id,
                    resourceId: result.data.resourceId,
                    loading: false,
                });
            } else {
                this.setState({ loading: false });
                this._showAlert(result.msg);
            }

        } catch (error) {
            this.setState({ loading: false });
            this._showAlert(error.message);
        }
    };

    _onExamPress = statusObject => {
        // 弹出提示框
        this._cardKey = SeaNormalCard.show({
            title: '温馨提示',
            content:
                '1.进入即开始倒计时\n2.若中途异常退出，会继续计时，在倒计时结束前可进入继续答题',
            submitTitle: '准备好了',
            cancelTitle: '稍后再考',
            onSubmitPress: () => this._startExam(statusObject),
            onClose: () => (this._cardKey = null),
        });
    };
    /**
     * @private
     * @description 继续考试 / 开始考试
     */
    _startExam = async statusObject => {
        try {
            // 通过检查执行下面的操作
            this.setState({ loading: true });
            const { userId } = this.props;
            const { data, id, resourceId } = this.state;
            // 检查是否可以考试，如果失败会throw error
            await TestUtil.checkTestable(data.data);
            // 1. 获取试卷信息
            const response = await TestPaperService.startPaperTestPromise(id, resourceId);
            if (response.code == '000000') {
                // 2. 恢复试卷信息, 如果是再考一次，则不恢复已答数据
                const recoveryPaperData = await this.answerManager.recoveryExamDataFromLocal(
                    id,
                    userId,
                    response.data.stems,
                    statusObject.status != TestUtil.UserTestStatus.NO_FIRST
                );
                this.setState({ loading: false });
                // 3. 进入答题界面
                Actions.show('testpaper', {
                    data: recoveryPaperData,
                    resourceId: resourceId,
                    id: id,
                    userId: userId,
                    remainingTime: response.data.remainingTime,
                    userTestResultId: response.data.userTestResultId,
                    onRefresh: this._loadTestPaperDesc, // 刷新方法
                });
            } else {
                this._showAlert(response.msg);
                this.setState({ loading: false });
            }

        } catch (error) {
            this.setState({ loading: false });
            this._showAlert(error.message);
        }
    };

    /**
     * @private
     * @description 回顾答案
     */
    _onReviewPress = async value => {
        try {
            const { data, id } = this.state;
            // 验证是否可以回顾答案
            TestUtil.checkReviewable(data, value);
            this.setState({ loading: true });
            // 获取回顾信息
            const result = await TestPaperService.reviewTestResult(value.userTestResultId);
            this.setState({ loading: false });
            // 进入回顾界面
            Actions.show('testPaperReview', { data: result.data.stems });
        } catch (error) {
            this.setState({ loading: false });
            this._showAlert(error.message);
        }
    };

    /**
     * @private
     * @description 提示
     */
    _showAlert = (content, onPress = () => { }) => {
        Alert.alert('提示', content, [{ text: '确定', style: 'cancel', onPress: onPress }], {
            cancelable: false,
        });
    };
}

//store到action的state映射
function mapStateToProps(store) {
    return {
        userId: store.identifyStore.userInfo.id,
    };
}
