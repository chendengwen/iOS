/**
 * @author xukj
 * @date 2019/07/05
 * @class
 * @description 考试描述组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import descStyle from './testDescStyle';
import { SeaFavoriteButton } from '../../../components';
import { SeaColor, SeaTheme, SeaScale, SeaConstant } from '../../../asserts';

export default class TestDescComponent extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷数据
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        let content;
        if (data.startTime && data.endTime) {
            content =
                data.summary +
                `\n考试有效时间为 ${data.startTime} 到 ${data.endTime}, 请在此期间完成考试。`;
        } else if (!data.startTime && data.endTime) {
            content = data.summary + `\n考试截止时间为 ${data.endTime}, 请在此之前完成考试。`;
        } else if (data.startTime && !data.endTime) {
            content = data.summary + `\n考试开始时间为 ${data.startTime}, 请在此之后完成考试。`;
        }

        return (
            <View style={descStyle.desc_container}>
                <View style={descStyle.desc_head}>
                    <View style={{ flexDirection: 'row',alignItems: 'center' }}>
                        <View style={descStyle.desc_flag} />
                        <Text style={descStyle.title}>试卷说明</Text>
                    </View>
                    <SeaFavoriteButton
                        style={descStyle.desc_favorite}
                        imageStyle={SeaTheme.footerToolBar.icon}
                        titleStyle={SeaTheme.footerToolBar.buttonAssideText}
                        id={data.resourceId}
                        type={SeaConstant.ResourceType.EXAM}
                        enabled={data.status === '1'}
                    />
                </View>
                <Text style={descStyle.desc_content}>{content}</Text>
            </View>
        );
    }
}
