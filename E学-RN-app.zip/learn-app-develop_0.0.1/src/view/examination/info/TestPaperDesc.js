/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-10 13:51:50
 */
/**
 * @author xukj
 * @date 2019/06/21
 * @class
 * @description 试卷简介
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, Text, TouchableOpacity } from 'react-native';
import { TestUtil } from '../../../util';
import descStyle from './testDescStyle';
import TestDescComponent from './TestDescComponent';
import TestInformationComponent from './TestInformationComponent';
import TestHistoryComponent from './TestHistoryComponent';
import TestResultComponent from './TestResultComponent';
import TestBannerComponent from './TestBannerComponent';
import { SeaStyle, SeaScale, SeaColor, SeaTheme } from '../../../asserts';

/**
 * 考试简介组件
 */
export default class TestPaperDesc extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object, // 试卷信息
        onExamPress: PropTypes.func,
        onReviewPress: PropTypes.func,
        onAddtoPlanPress: PropTypes.func,
        assignment: PropTypes.bool,
    };

    static defaultProps = {
        onExamPress: statusObject => { },
        onReviewPress: item => { },
        onAddtoPlanPress: () => { },
        assignment: true
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { onExamPress, onReviewPress, data, onAddtoPlanPress, assignment } = this.props;
        // 当前用户考试状态
        const statusObject = TestUtil.currentUserTestStatus(data);
        // 考试记录
        const hasHistory = _.get(data, 'userExamDTOs', []).length > 0;

        return (
            <View style={SeaStyle.list}>
                {statusObject.status == TestUtil.UserTestStatus.TESTING && (
                    <TestBannerComponent data={data.data} />
                )}
                <ScrollView style={descStyle.flex1}>
                    <TestDescComponent data={data.data} />
                    <TestInformationComponent
                        data={data.data}
                        statusObject={statusObject}
                        onPress={() => onExamPress(statusObject)}
                    />
                    <TestResultComponent data={data.data} />
                    {hasHistory && <TestHistoryComponent data={data} onCellPress={onReviewPress} />}


                    {!assignment && <TouchableOpacity
                        style={{
                            height: SeaScale.Layout(68),
                            width: SeaScale.Layout(260),
                            borderRadius: SeaScale.Layout(16),
                            marginTop: SeaScale.Layout(200),
                            backgroundColor: SeaColor.main,
                            justifyContent: 'center',
                            alignItems: 'center',
                            alignSelf: 'center',
                        }}
                        onPress={onAddtoPlanPress}
                    >
                        <Text style={{
                            textAlign: 'center',
                            fontSize: SeaTheme.font_size_lg,
                            color: 'white',
                        }}>加入考试</Text>
                    </TouchableOpacity>}
                </ScrollView>
            </View>
        );
    }
}
