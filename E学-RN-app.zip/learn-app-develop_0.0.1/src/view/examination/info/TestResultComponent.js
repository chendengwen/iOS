/**
 * @author xukj
 * @date 2019/07/05
 * @class
 * @description 考试结果组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import descStyle from './testDescStyle';
import { SeaTheme, SeaScale } from '../../../asserts';

// 显示组件
const TestResultCell = props => {
    // 样式、标题、次数
    const { style, title, number } = props;
    return (
        <View style={[descStyle.cell, style && style]}>
            <Text style={descStyle.result_times}>
                {number}&nbsp;
                <Text style={[descStyle.title, { fontSize: SeaTheme.font_size_md }]}>次</Text>
            </Text>
            <Text style={[descStyle.content, { marginTop: SeaScale.Layout(32) }]}>{title}</Text>
        </View>
    );
};

export default class TestResultComponent extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        // 总次数
        const maxTimes = data.testFrequency;
        // 已考次数
        const examTimes = data.userExamDTO.examTimes ? data.userExamDTO.examTimes : 0;
        // 剩余次数
        const restTimes = data.testFrequency >= examTimes ? data.testFrequency - examTimes : 0;

        return (
            <View style={descStyle.result_container}>
                <TestResultCell number={maxTimes} title="允许考试次数" />
                <TestResultCell
                    number={examTimes}
                    title="已考"
                    style={{ marginLeft: SeaScale.Layout(12) }}
                />
                <TestResultCell
                    number={restTimes}
                    title="剩余考试次数"
                    style={{ marginLeft: SeaScale.Layout(12) }}
                />
            </View>
        );
    }
}
