/**
 * @author xukj
 * @date 2019/07/05
 * @class
 * @description 考试头部提示
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { TestUtil } from '../../../util';
import descStyle from './testDescStyle';
import moment from 'moment';
import { SeaScale } from '../../../asserts';

export default class TestBannerComponent extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        const timeStr = moment(TestUtil.getNeedSubmitTime(data)).format('HH:mm');
        return (
            <View style={descStyle.bannerContainer}>
                <Icon name="error-outline" color="#eb6100" size={SeaScale.Layout(36)} />
                <Text style={descStyle.bannerTitle}>
                    系统检测到您上次异常退出，请在 {timeStr} 之前重新进入并完成考试
                </Text>
            </View>
        );
    }
}
