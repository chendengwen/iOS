/**
 * @author xukj
 * @date 2019/07/05
 * @class
 * @description 界面展示组件TestInformationComponent
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, Image } from 'react-native';
import { TestUtil } from '../../../util';
import { SeaTextButton } from '../../../components';
import { SeaColor, SeaTheme } from '../../../asserts';
import descStyle from './testDescStyle';

export default class TestInformationComponent extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷信息
        statusObject: PropTypes.object.isRequired, // 状态信息
        onPress: PropTypes.func, // 考试按钮点击
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data, statusObject, onPress } = this.props;
        // 总分
        const score = data.scores ? data.scores : 0;
        // 及格分
        const passScore = data.passScore ? data.passScore : 0;
        // 得分
        const userScore = data.userExamDTO.userScores;

        let scoreNodes = null;
        if (!this._isValidateScore(data)) {
            scoreNodes = this._renderScoreDefaultNodes();
        } else if (this._isPass(data)) {
            scoreNodes = this._renderScorePassNodes(userScore);
        } else {
            scoreNodes = this._renderScoreFailNodes(userScore);
        }
        const button = this._renderTestButton(statusObject, onPress);

        return (
            <View style={descStyle.info_container}>
                <View style={descStyle.info_leftrow}>
                    <Text style={descStyle.title}>有效成绩</Text>
                    {scoreNodes}
                    {button}
                </View>
                <View style={descStyle.info_rightrow}>
                    <View style={[descStyle.cell, descStyle.sp_bottom]}>
                        <Text style={[descStyle.title, { fontSize: SeaTheme.font_size_md }]}>
                            {score} （{passScore}分及格）
                        </Text>
                        <Text style={[descStyle.content, { marginTop: SeaTheme.v_spacing_sm }]}>
                            总分
                        </Text>
                    </View>
                    <View style={descStyle.cell}>
                        <Text style={[descStyle.title, { fontSize: SeaTheme.font_size_md }]}>
                            {Math.floor(data.duration / 60)}小时{Math.floor(data.duration % 60)}分钟
                        </Text>
                        <Text style={[descStyle.content, { marginTop: SeaTheme.v_spacing_sm }]}>
                            考试时间
                        </Text>
                    </View>
                </View>
            </View>
        );
    }

    /**
     * @private
     * @description 是否有效成绩
     */
    _isValidateScore = paper => {
        const times = paper.userExamDTO.examTimes;
        const isTesting = TestUtil.isUserTesting(paper.userExamDTO);
        const isTimeout = TestUtil.isUserTimeout(paper, paper.userExamDTO);
        // 正在第一次考试中
        const isFirstTesting = times == 1 && isTesting && !isTimeout;
        // 有效成绩 = 未考试 && ！第一次考试中
        return times > 0 && !isFirstTesting;
    };

    /**
     * @private
     * @description 是否通过
     */
    _isPass = paper => {
        return paper.userExamDTO.userScores >= paper.passScore;
    };

    /**
     * @private
     * @description 无有效成绩时
     */
    _renderScoreDefaultNodes = () => {
        return [
            <Image
            key="nodes-default"

                style={descStyle.info_icon}
                source={require('../../../asserts/images/exam-before.png')}
            />,
            <Text key='txt-default' style={[descStyle.info_score, { color: SeaColor.h2_text }]}>-</Text>,
        ];
    };

    /**
     * @private
     * @description 未通过
     */
    _renderScoreFailNodes = score => {
        return [
            <Image
                key="nodes-fail"
                style={descStyle.info_icon}
                source={require('../../../asserts/images/exam-fail.png')}
            />,
            <Text key="txt-fail" style={[descStyle.info_score, { color: SeaColor.red_text }]}>
                {score}
            </Text>,
        ];
    };

    /**
     * @private
     * @description 已通过
     */
    _renderScorePassNodes = score => {
        return [
            <Image
                key="nodes-pass"
                style={descStyle.info_icon}
                source={require('../../../asserts/images/exam-success.png')}
            />,
            <Text key="txt-pass" style={[descStyle.info_score, { color: SeaColor.green }]}>
                {score}
            </Text>,
        ];
    };

    /**
     * @private
     * @description 按钮
     */
    _renderTestButton = (statusObject, onPress) => {
        const disabled = statusObject == TestUtil.UserTestStatus.USED_UP;
        return (
            <SeaTextButton
                disabled={disabled}
                theme={disabled ? 'disable' : 'main'}
                style={descStyle.info_button}
                titleStyle={[descStyle.title, { color: 'white' }]}
                title={statusObject.title}
                onPress={onPress}
            />
        );
    };
}
