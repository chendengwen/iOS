/**
 * @author xukj
 * @date 2019/07/05
 * @class
 * @description 考试历史
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { SeaConstant, SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import { SeaTextButton } from '../../../components';
import descStyle from './testDescStyle';
import moment from 'moment';

/**
 * 得分样式
 */
function getScoreColor(paper, userExamDTO) {
    // 及格分
    const passScore = paper.passScore ? paper.passScore : 0;
    // 得分
    const userScore = userExamDTO.userScores;
    // 是否过关
    return userScore >= passScore ? SeaColor.green : SeaColor.red_text;
}

/**
 * 考试历史头部组件
 */
const TestHistoryHead = props => {
    return (
        <View style={descStyle.list_header}>
            <View style={[descStyle.cell, { flexDirection: 'row', justifyContent: 'flex-start' }]}>
                <Text style={descStyle.title}>提交时间</Text>
                <Icon color={SeaColor.h2_text} name="arrow-drop-down" size={SeaScale.Layout(28)} />
            </View>
            <View style={[descStyle.cell, { flexDirection: 'row' }]}>
                <Text style={descStyle.title}>考试成绩</Text>
                <Icon color={SeaColor.h2_text} name="arrow-drop-down" size={SeaScale.Layout(28)} />
            </View>
            <View style={[descStyle.cell, { flexDirection: 'row', justifyContent: 'flex-end' }]}>
                <Text style={descStyle.title}>答案回顾</Text>
                <Icon color={SeaColor.h2_text} name="arrow-drop-down" size={SeaScale.Layout(28)} />
            </View>
        </View>
    );
};

/**
 * 考试历史cell组件
 */
const TestHistoryCell = props => {
    // 点击、单次考试信息、试卷信息、及格分、index
    const { onPress, userExamDTO, paper, index } = props;

    let reviewable = false;
    let title = '考试异常';
    let score = '-';
    let scoreColor = SeaColor.h2_text;
    if (userExamDTO.userTestStatus == SeaConstant.UserExamType.NONE) {
        title = moment(userExamDTO.submitTestTime).format('YYYY-MM-DD');
        reviewable = paper.review && true;
        score = userExamDTO.userScores;
        scoreColor = getScoreColor(paper, userExamDTO);
    } else if (userExamDTO.userTestStatus == SeaConstant.UserExamType.TESTING) {
        title = '考试中';
        reviewable = false;
        score = '-';
    } else if (userExamDTO.userTestStatus == SeaConstant.UserExamType.EXCEPTION) {
        title = '考试异常';
        reviewable = paper.review && true;
        score = userExamDTO.userScores;
        scoreColor = getScoreColor(paper, userExamDTO);
    }

    return (
        <View
            style={[
                descStyle.list_cell,
                { backgroundColor: index % 2 == 0 ? SeaColor.defaultBackgroudColor_3 : 'white' },
            ]}
        >
            <Text style={descStyle.list_celltime}>{title}</Text>
            <Text style={[descStyle.list_cellscore, { color: scoreColor }]}>{score}</Text>
            <View style={descStyle.list_cellreview}>
                {reviewable ? (
                    <SeaTextButton
                        theme="custom"
                        title="答案回顾"
                        titleStyle={{ fontSize: SeaTheme.font_size_md, color: SeaColor.main }}
                        onPress={onPress}
                    />
                ) : (
                    <Text style={descStyle.content}>不可回顾</Text>
                )}
            </View>
        </View>
    );
};

export default class TestHistoryComponent extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷信息
        onCellPress: PropTypes.func, // 点击
    };

    static defaultProps = {
        onCellPress: item => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { onCellPress, data } = this.props;
        return (
            <View style={descStyle.list_container}>
                <TestHistoryHead />
                {data.userExamDTOs.map((value, index) => {
                    return (
                        <TestHistoryCell
                            key={index}
                            userExamDTO={value}
                            index={index}
                            paper={data}
                            onPress={() => onCellPress(value)}
                        />
                    );
                })}
            </View>
        );
    }
}
