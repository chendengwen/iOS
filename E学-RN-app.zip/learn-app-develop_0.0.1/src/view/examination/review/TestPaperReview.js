/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件TestPaperDetail 考试框架组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import Swiper from 'react-native-swiper';
import { Icon } from 'react-native-elements';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import SingleChoiceQuestion from '../detail/SingleChoiceQuestion';
import MultipleChoiceQuestion from '../detail/MultipleChoiceQuestion';
import JudgementQuestion from '../detail/JudgementQuestion';
import UnsupportQuestion from '../detail/UnsupportQuestion';
import SubjectiveQuestion from '../detail/SubjectiveQuestion';

export default class TestPaperReview extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array, // 题目数据
        onImageZoomer: PropTypes.func,
        preview: PropTypes.bool, // 预览还是回顾
    };

    static defaultProps = {
        data: [],
        preview: false,
    };

    constructor(props) {
        super(props);
        this.mode = props.preview ? 'preview' : 'review';
    }

    componentDidMount() {}

    render() {
        const { data, onImageZoomer } = this.props;

        return (
            <Swiper
                scrollEnabled={true}
                loop={false}
                showsButtons={true}
                loadMinimal={true}
                loadMinimalSize={5}
                showsPagination={false}
                buttonWrapperStyle={styles.buttonWrapper}
                prevButton={this._renderPrevButton()}
                nextButton={this._renderNextButton()}
            >
                {this._renderQuestions(data, onImageZoomer)}
            </Swiper>
        );
    }

    _renderPrevButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-start', paddingLeft: SeaTheme.h_spacing_md },
                ]}
            >
                <Icon
                    type="ionicon"
                    name="ios-arrow-back"
                    size={SeaTheme.icon_size_md}
                    color="white"
                />
                <Text style={[styles.buttonText, { marginLeft: 8 }]}>上一题</Text>
            </View>
        );
    };

    _renderNextButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-end', paddingRight: SeaTheme.h_spacing_md },
                ]}
            >
                <Text style={[styles.buttonText, { marginRight: 8 }]}>下一题</Text>
                <Icon
                    type="ionicon"
                    name="ios-arrow-forward"
                    size={SeaTheme.icon_size_md}
                    color="white"
                />
            </View>
        );
    };

    _renderQuestions = (data, onImageZoomer) => {
        return data.map((value, index, array) => {
            switch (value.type) {
                case '1':
                    return (
                        <SingleChoiceQuestion
                            mode={this.mode}
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '2':
                    return (
                        <MultipleChoiceQuestion
                            mode={this.mode}
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '3':
                    return (
                        <JudgementQuestion
                            mode={this.mode}
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '4':
                    return (
                        <SubjectiveQuestion
                            mode={this.mode}
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                default:
                    return (
                        <UnsupportQuestion
                            mode={this.mode}
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                        />
                    );
            }
        });
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    buttonWrapper: {
        backgroundColor: SeaColor.main,
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        top: 'auto',
        bottom: 0,
    },
    buttonContainer: {
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonText: {
        backgroundColor: SeaColor.main,
        fontSize: SeaTheme.font_size_lg,
        color: 'white',
    },
});
