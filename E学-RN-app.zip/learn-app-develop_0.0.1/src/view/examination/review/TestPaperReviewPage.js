/**
 * @author xukj
 * @date 2019/03/05
 * @description 考试回顾
 * 因为回顾界面极有可能不会与考试界面一致，因此重新制作
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Modal } from 'react-native';
import TestPaperReview from './TestPaperReview';
import { SeaImageZoomer } from '../../../components';
import { SeaScale, SeaStyle } from '../../../asserts';

export default class TestPaperReviewPage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.any, // 题目信息
        preview: PropTypes.bool, // 预览还是回顾
    };

    static defaultProps = {
        preview: false,
    };

    constructor(props) {
        super(props);
        this.state = {
            data: _.get(props, 'data', []),
            zoom: false,
            zoomPath: null,
            preview: props.preview,
        };
    }

    componentDidMount() {}

    componentWillUnmount() {}

    render() {
        const { data, zoom, zoomPath, preview } = this.state;
        return (
            <View style={SeaStyle.page}>
                <TestPaperReview data={data} preview={preview} onImageZoomer={this._onImageZoom} />
                <Modal
                    animationType="fade"
                    transparent={false}
                    visible={zoom}
                    supportedOrientations={['portrait', 'landscape-left', 'landscape-right']}
                    onRequestClose={this._hideZoomer}
                >
                    <SeaImageZoomer
                        url={zoomPath}
                        width={SeaScale.screenWidth}
                        height={SeaScale.screenHeight}
                        onClose={this._hideZoomer}
                    />
                </Modal>
            </View>
        );
    }

    /**
     * @private
     * @description 图片题缩放
     */
    _onImageZoom = (index, selectedIndex, path) => {
        if (path) this.setState({ zoom: true, zoomPath: path });
    };

    /**
     * @private
     * @description 隐藏图片浏览器
     */
    _hideZoomer = () => {
        this.setState({ zoom: false });
    };
}
