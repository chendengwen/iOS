/**
 * @author xukj
 * @date 2019/08/07
 * @description 考试模块
 */
// 考试项目数据模型
export { default as TestResourceData } from './data/TestResourceData';
// 试卷数据模型
export { default as TestPaperData } from './data/TestPaperData';
// 考试项目通用cell
export { default as TestCommonCell } from './view/TestCommonCell';
// 试卷通用cell
export { default as TestPaperCommonCell } from './view/TestPaperCommonCell';
// 考试项试卷列表
export { default as TestResourcePaperListPage } from './TestResourcePaperListPage';
// 考试信息页
export { default as TestPaperDescPage } from './info/TestpaperDescPage';
// 试卷考试
export { default as TestPaperTestPage } from './detail/TestPaperDetailPage';
// 考试结果
export { default as TestResultPage } from './result/TestResultPage';
// 考试回顾
export { default as TestPaperReviewPage } from './review/TestPaperReviewPage';
// 通用试卷列表
export { default as TestPaperListPage } from './list/TestPaperListPage';
// 计划试卷列表
export { default as TestPaperToLearnPage } from './list/TestPaperToLearnPage';
// 考试审批
export { default as TestApprovePage } from './approve/TestApprovePage';
// 考试试卷审批
export { default as TestPaperApprovePage } from './approve/TestPaperApprovePage';
