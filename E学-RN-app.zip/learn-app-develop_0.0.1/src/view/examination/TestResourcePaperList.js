/**
 * @author xukj
 * @date 2018/7/19
 * @description 考试项目列表组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, FlatList } from 'react-native';
import { ExceptionView } from '../../components';
import TestResourcePaperCell from './TestResourcePaperCell';
import { SeaConstant, SeaScale, SeaColor, SeaStyle } from '../../asserts';

export default class TestResourcePaperList extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array,
        onCellPress: PropTypes.func,
        showStatus: PropTypes.bool,
    };

    static defaultProps = {
        onCellPress: () => {},
        showStatus: false,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data, showStatus } = this.props;

        const renderItem = _.curry(this._renderItem)(this._onPress)(showStatus);
        const renderList = _.curry(this._renderList)(this._renderHeader)(renderItem)(
            this._renderException()
        );

        return <View style={styles.page}>{renderList(data)}</View>;
    }

    /*
     * private
     * @method list
     */
    _renderList = (renderHeader, renderItem, renderException, data) => {
        if (!data) {
            return null;
        } else if (data.length > 0) {
            return (
                <FlatList
                    ListHeaderComponent={renderHeader}
                    style={SeaStyle.list}
                    data={data}
                    renderItem={renderItem}
                    keyExtractor={(item, index) => index.toString()}
                />
            );
        } else {
            return renderException;
        }
    };

    // 头部样式
    _renderHeader = () => {
        const height = 20 * SeaScale.scaleHorizontal;
        return <View style={{ height: height }} />;
    };

    /*
     * private
     * @method item
     */
    _renderItem = (onPress, showStatus, { item }) => {
        const { name, validEnd, resultScores, passScore, maxScore, examTimes } = item;
        const time = !validEnd ? '长期有效' : validEnd;
        // 列表默认不展示是否考试，只展示是否通过
        // 如果maxScore没值，则使用resultScores
        const status = SeaConstant.getExamResult(
            examTimes,
            maxScore ? maxScore : resultScores,
            passScore
        );
        return (
            <TestResourcePaperCell
                name={name}
                desc={`截止日期：${time}`}
                status={status}
                showArrow={true}
                showStatus={showStatus}
                onPress={onPress(item)}
            />
        );
    };

    /*
     * private
     * @method exception
     */
    _renderException = message => {
        return <ExceptionView message={message} />;
    };

    /*
     * private
     * @method 点击试卷做判断
     */
    _onPress = item => {
        return () => this.props.onCellPress(item);
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    list: {
        flex: 1,
    },
});
