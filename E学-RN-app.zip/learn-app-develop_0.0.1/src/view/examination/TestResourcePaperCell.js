/**
 * @author xukj
 * @date 2018/6/28
 * @class
 * @description 考试试卷列表样式，标注通过、未通过
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet, Image } from 'react-native';
import { SeaListCell } from '../../components';
import { SeaConstant, SeaColor, SeaScale, SeaTheme } from '../../asserts';

export default class TestResourcePaperCell extends React.PureComponent {
    static propTypes = {
        name: PropTypes.string,
        desc: PropTypes.string,
        status: PropTypes.number, // 考试结果
        showStatus: PropTypes.bool, // 是否展示考试结果
        onPress: PropTypes.func,
    };

    static defaultProps = {
        name: '',
        desc: '',
        status: SeaConstant.ExamResultType.NONE,
        showStatus: false,
        onPress: () => {},
    };

    render() {
        const { name, desc, status, showStatus, onPress } = this.props;
        return (
            <View style={styles.container}>
                <SeaListCell
                    showArrow={false}
                    showSeparator={false}
                    style={styles.content}
                    onPress={onPress}
                >
                    <View style={styles.leftContent}>
                        <Text style={styles.title} numberOfLines={1}>
                            {name}
                        </Text>
                        <Text style={styles.subTitle} numberOfLines={1}>
                            {desc}
                        </Text>
                    </View>
                    <View
                        style={[
                            styles.rightContent,
                            showStatus ? { width: SeaScale.Layout(160) } : { width: 0 },
                        ]}
                    >
                        {this._renderFlag(status, showStatus)}
                    </View>
                </SeaListCell>
            </View>
        );
    }

    _renderFlag = (flag, show) => {
        if (!show) {
            return null;
        }

        switch (flag) {
            case SeaConstant.ExamResultType.NONE:
                return <Text style={styles.statusText}>未考试</Text>;
            case SeaConstant.ExamResultType.FAIL:
                return <Text style={styles.statusText}>未通过</Text>;
            case SeaConstant.ExamResultType.PASS:
                return (
                    <Image
                        style={styles.statusImage}
                        source={require('../../asserts/images/icon_pass.png')}
                    />
                );
            default:
                return null;
        }
    };
}

const styles = StyleSheet.create({
    container: {
        paddingBottom: SeaScale.Layout(10),
        paddingLeft: SeaTheme.h_spacing_sm,
        paddingRight: SeaTheme.h_spacing_sm,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    content: {
        height: SeaScale.Layout(174),
        padding: SeaTheme.h_spacing_md,
        flex: 1,
        flexDirection: 'row',
        backgroundColor: 'white',
    },
    leftContent: {
        flex: 1,
        height: SeaScale.Layout(114),
    },
    rightContent: {
        width: SeaScale.Layout(160),
        height: SeaScale.Layout(114),
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
    },
    subTitle: {
        marginTop: SeaScale.Layout(40),
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    statusText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.red_text,
    },
    statusImage: {
        width: SeaScale.Layout(144),
        height: SeaScale.Layout(120),
        position: 'absolute',
        bottom: 0 - SeaScale.Layout(30),
        right: 0 - SeaScale.Layout(30),
    },
});
