/**
 * @author xukj
 * @date 2019/08/15
 * @description TestPaperData 试卷数据模型
 */
export default class TestPaperData {
    constructor() {
        this.id;
        this.name;
        this.totalScore;
        this.passScore;
        this.publishTime;
        this._sourceData;
    }

    /**
     * 创建试卷数据对象,数据来源:搜索
     * @param {object} value
     * @return {TestPaperData}
     */
    static search(value) {
        const paper = new TestPaperData();
        paper._sourceData = value;

        paper.id = value.id;
        paper.name = value.name;
        paper.totalScore = value.totalScore;
        paper.passScore = value.passScore;
        paper.publishTime = value.publishTime;
        return paper;
    }
}
