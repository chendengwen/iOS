import moment from 'moment';

/**
 * @author xukj
 * @date 2019/08/15
 * @description TestResourceData 考试项目数据模型
 */
export default class TestResourceData {
    constructor() {
        this.id;
        this.name;
        this.publisher;
        this.publishTime;
        this._sourceData;
    }

    /**
     * 创建试卷数据对象,数据来源:专题
     * @param {object} value
     * @return {TestResourceData}
     */
    static subject(value) {
        const test = new TestResourceData();
        test._sourceData = value;

        test.id = value.id;
        test.name = value.name;
        test.publisher = value.publisherName;
        test.publishTime = moment(value.publishTime).format('YYYY-MM-DD HH:mm:ss');
        return test;
    }
}
