/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-09 16:45:22
 */
/**
 * @author xukj
 * @date 2018/7/19
 * @description 考试项目试卷列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import TestResourcePaperList from './TestResourcePaperList';
import { TestPaperService } from '../../servie';
import { Actions } from 'react-native-router-flux';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';

export default class TestResourcePaperListPage extends React.PureComponent {
    static propTypes = {
        id: PropTypes.string,
        showResult: PropTypes.bool,
        defaultData: PropTypes.array,
    };

    static defaultProps = {
        showResult: false,
    };

    constructor(props) {
        super(props);
        this.state = { data: props.defaultData };
        this._loadingKey; // 等待框
    }

    componentDidMount() {
        // 未设置默认数据的话，需要去服务器请求
        if (!this.props.defaultData) this._loadList(this.props.id);
    }

    render() {
        const { data } = this.state;

        return (
            <TestResourcePaperList
                data={data}
                onCellPress={this._onCellPress}
                showStatus={this.props.showResult}
            />
        );
    }

    _onCellPress = item => {
        Actions.show('testpaperDesc', { id: item.id });
    };

    /*
     * private
     * @method 试卷列表加载器
     */
    _loadList = async testId => {
        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            const responseJson = await TestPaperService.getPapersByResourceId(testId);
            FSLPrompt.hide(this._loadingKey);
            this.setState({ data: responseJson.data });
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message, 2, Actions.pop);
        }
    };
}
