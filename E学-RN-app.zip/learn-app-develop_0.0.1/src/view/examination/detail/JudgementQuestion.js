/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件JudgementQuestion 判断题
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView } from 'react-native';
import { RadioButtons } from 'react-native-radio-buttons';
import Stem from './Stem';
import ResultContent from './ResultContent';
import { SeaScale } from '../../../asserts';
import { SeaCheckBox } from '../../../components';
import { SeaImageUtil, TestUtil } from '../../../util';

export default class JudgementQuestion extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        index: PropTypes.number,
        maxCount: PropTypes.number,
        onSelection: PropTypes.func,
        onImageZoomer: PropTypes.func,
        // 做题模式、回顾模式、预览模式
        mode: PropTypes.oneOf('default', 'review', 'preview'),
    };

    static defaultProps = {
        data: {},
        onSelection: (index, selectedIndex) => {},
        onImageZoomer: (index, selectedIndex, path) => {},
        mode: 'default',
    };

    constructor(props) {
        super(props);
        this.showResult = props.mode != 'default';
    }

    componentDidMount() {}

    render() {
        const { data, index, maxCount, onSelection, mode } = this.props;
        const { options } = data;
        return (
            <ScrollView style={styles.container} key={index}>
                <Stem
                    index={index}
                    maxCount={maxCount}
                    type="判断题"
                    content={data.description}
                    score={data.scores}
                    picture={data.stemPicture}
                />
                <RadioButtons
                    options={options}
                    renderOption={this._renderOption}
                    renderContainer={this._renderContainer}
                    selectedIndex={options.findIndex(value => {
                        return value.checked == true;
                    })}
                    onSelection={(_, selectedIndex) => onSelection(index, selectedIndex)}
                />
                {this.showResult && <ResultContent topic={data} mode={mode} />}
            </ScrollView>
        );
    }

    _renderOption = (option, selected, onSelectPress, i) => {
        const { index, onImageZoomer } = this.props;
        return (
            <SeaCheckBox
                reviewMode={TestUtil.optionReviewMode(option, this.showResult)}
                isMult={false}
                key={i}
                title={TestUtil.optionDisplay(option)}
                checked={selected}
                source={SeaImageUtil.getImageSource(option.optionPicture)}
                onPress={onSelectPress}
                onImagePress={path => onImageZoomer(index, i, path)}
            />
        );
    };

    _renderContainer = optionNodes => {
        return <View>{optionNodes}</View>;
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginBottom: SeaScale.Layout(88),
        width: SeaScale.screenWidth,
        backgroundColor: 'white',
    },
});
