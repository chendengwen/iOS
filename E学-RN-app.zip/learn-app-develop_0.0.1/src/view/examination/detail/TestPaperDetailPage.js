/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面交互组件TestPaperDetailPage 考试页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Alert, StyleSheet, BackHandler, Modal, InteractionManager } from 'react-native';
import { Actions, ActionConst } from 'react-native-router-flux';
import { FSLPrompt } from 'react-native-kpframework';
import { SeaNavigator, SeaImageZoomer } from '../../../components';
import { SeaScale, SeaStyle } from '../../../asserts';
import { TestPaperService } from '../../../servie';
import TestPagerDetail from './TestPaperDetail';
import ExamAnswerManager from './ExamAnswerManager';

export default class TestPaperDetailPage extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string.isRequired, // 考试项id
        userTestResultId: PropTypes.string.isRequired, // 考试结果id
        id: PropTypes.string, // 试卷id
        data: PropTypes.array.isRequired, // 题目信息
        answer: PropTypes.any, // 答题记录
        userId: PropTypes.string.isRequired, // 用户id
        remainingTime: PropTypes.number, // 续考剩余时间/分钟
        onRefresh: PropTypes.func, // 需要刷新
    };

    static defaultProps = {
        onRefresh: () => {},
        data: [],
    };

    constructor(props) {
        super(props);
        this.state = {
            time: _.get(props, 'remainingTime', 0) * 60, // 倒计时, 秒
            data: _.get(props, 'data', []),
            zoom: false,
            zoomPath: null,
        };
        this.answerManager = ExamAnswerManager.sharedInstance();
        this.saveCounting = 0; // 保存答题记录, 10秒记录一次
        this._loadingKey; // 等待框
        this.autoSubmiting = false; // 后台自动提交中
        this.manualSubmiting = false; // 手动提交
    }

    componentDidMount() {
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', this._onCancelPress);
        this._startTimer();
    }

    componentWillUnmount() {
        this._stopTimer();
        this.backHandler && this.backHandler.remove();
    }

    render() {
        const { time, data, zoom, zoomPath } = this.state;
        const title = time <= 0 ? '倒计时 00:00:00' : `倒计时 ${fsl.timeString(time)}`;
        return (
            <View style={SeaStyle.page}>
                <SeaNavigator
                    title={title}
                    onBackPress={this._onCancelPress}
                    rightText="提交"
                    onRightPress={this._onSubmitPress}
                />
                <TestPagerDetail
                    data={data}
                    onSingleSelection={this._updateDataBySingleSelected}
                    onMultipleSelection={this._updateDataByMultipleSelected}
                    onJudgementSelection={this._updateDataByJudgementSelected}
                    onSubjectiveChanged={this._updateSubjectiveChanged}
                    onImageZoomer={this._onImageZoom}
                />
                <Modal
                    animationType="fade"
                    transparent={false}
                    visible={zoom}
                    supportedOrientations={['portrait', 'landscape-left', 'landscape-right']}
                    onRequestClose={this._hideZoomer}
                >
                    <SeaImageZoomer
                        url={zoomPath}
                        width={SeaScale.screenWidth}
                        height={SeaScale.screenHeight}
                        onClose={this._hideZoomer}
                    />
                </Modal>
            </View>
        );
    }

    /**
     * @private
     * @description 提交试卷
     */
    _onSubmitPress = () => {
        Alert.alert(
            '提醒',
            '是否现在提交试卷？',
            [
                { text: '继续做题', style: 'cancel' },
                { text: '提交', onPress: this._submitAndShowResult },
            ],
            { cancelable: false }
        );
    };

    /**
     * @private
     * @description 退出考试
     */
    _onCancelPress = () => {
        Alert.alert(
            '提醒',
            '就快完成考试了，确认要退出考试？',
            [
                { text: '继续做题', style: 'cancel' },
                { text: '我要退出', style: 'destructive', onPress: this._exitTest },
            ],
            { cancelable: false }
        );
        return true;
    };

    /**
     * @private
     * @description 已到交卷时间
     */
    _onTimeout = () => {
        Alert.alert('提醒', '考试时间已结束，试卷已自动提交', [{ text: '确定' }], {
            cancelable: false,
        });
        this._submitAndShowResult();
    };

    /**
     * @private
     * @description 图片题缩放
     */
    _onImageZoom = (index, selectedIndex, path) => {
        if (path) this.setState({ zoom: true, zoomPath: path });
    };

    /**
     * @private
     * @description 隐藏图片浏览器
     */
    _hideZoomer = () => {
        this.setState({ zoom: false });
    };

    /**
     * @private
     * @description 开始计时
     */
    _startTimer = () => {
        this.timer = setInterval(() => {
            const nextTime = this.state.time - 1;
            this.setState({ time: nextTime });
            this.saveCounting += 1;
            if (nextTime <= 0) {
                // 计时结束，首先保存答题数据
                this.answerManager
                    .saveExamDataInLocal(this.props.id, this.props.userId, this.state.data)
                    .then();
                this._stopTimer();
                this._onTimeout();
                return;
            }

            // 如果未到结束时间，每10秒保存一次
            if (this.saveCounting % 10 === 0) {
                this.answerManager
                    .saveExamDataInLocal(this.props.id, this.props.userId, this.state.data)
                    .then();
            }

            // 每2分钟后台提交一次答卷
            if (this.saveCounting % 120 === 0) {
                this._submitInBackground(
                    this.props.resourceId,
                    this.props.userTestResultId,
                    this.state.data
                );
            }
        }, 1000);
    };

    /**
     * @private
     * @description 结束计时
     */
    _stopTimer = () => {
        this.timer && clearInterval(this.timer);
    };

    /**
     * @private
     * @description 提交试卷到服务器
     */
    _submitAndShowResult = async () => {
        try {
            this.manualSubmiting = true;
            this._loadingKey = FSLPrompt.loading('正在提交');
            // 组装答题数据
            const answer = this.answerManager.getAnswersFromPaperData(this.state.data);
            const { resourceId, id, userId, userTestResultId, onRefresh } = this.props;
            // 提交答题记录
            const result = await TestPaperService.submitPaperTestManual(
                resourceId,
                userTestResultId,
                _.values(answer)
            );

            await this.answerManager.removeExamDataInLocal(id, userId);
            FSLPrompt.hide(this._loadingKey);
            // 刷新前一界面
            onRefresh();
            // 跳转到结果页
            Actions.show('testResult', { data: result.data, type: ActionConst.REPLACE });
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            Alert.alert(
                '提醒',
                error.message,
                [
                    { text: '继续做题', style: 'cancel' },
                    { text: '重新提交', onPress: this._submitAndShowResult },
                ],
                { cancelable: false }
            );
        }
    };

    /**
     * @private
     * @description 后台自动提交自动提交
     */
    _submitInBackground = async (resourceId, resultId, data) => {
        try {
            if (this.autoSubmiting || this.manualSubmiting) return;
            this.autoSubmiting = true;
            // 组装答题数据
            const answer = this.answerManager.getAnswersFromPaperData(data);
            // 提交答题记录
            const result = await TestPaperService.submitPaperTestAuto(
                resourceId,
                resultId,
                _.values(answer)
            );
            // console.log('答题结果', result);
            this.autoSubmiting = false;
        } catch (error) {
            // do nothing
            this.autoSubmiting = false;
        }
    };

    /**
     * 退出考试
     * modify by xukj - 1.32.0
     * 不再提交退出申请到服务器
     */
    _exitTest = () => {
        // 关闭计时
        this._stopTimer();
        Actions.pop();
    };

    /**
     * @private
     * @description 单选后更新数据
     */
    _updateDataBySingleSelected = (index, selectedIndex) => {
        (async () => {
            const result = await this.answerManager.updateDataBySingleSelection(
                this.state.data,
                index,
                selectedIndex
            );
            this.setState({ data: result });
        })();
    };

    /**
     * @private
     * @description 多选后更新数据
     */
    _updateDataByMultipleSelected = (index, selectedIndex) => {
        (async () => {
            const result = await this.answerManager.updateDataByMultipleSelection(
                this.state.data,
                index,
                selectedIndex
            );
            this.setState({ data: result });
        })();
    };

    /**
     * @private
     * @description 判断后更新数据
     */
    _updateDataByJudgementSelected = (index, selectedIndex) => {
        (async () => {
            const result = await this.answerManager.updateDataByJudgementSelection(
                this.state.data,
                index,
                selectedIndex
            );
            this.setState({ data: result });
        })();
    };
    /**
     * @private
     * @description 主观题更新数据
     */
    _updateSubjectiveChanged= (index, text) => {
        (async () => {
            const result = await this.answerManager.updateDataBySubjectiveChange(
                this.state.data,
                index,
                text
            );
            this.setState({ data: result });
        })();
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
    },
});
