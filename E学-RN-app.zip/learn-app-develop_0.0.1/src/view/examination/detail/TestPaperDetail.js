/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件TestPaperDetail 考试框架组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import Swiper from 'react-native-swiper';
import { Icon } from 'react-native-elements';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import SingleChoiceQuestion from './SingleChoiceQuestion';
import MultipleChoiceQuestion from './MultipleChoiceQuestion';
import JudgementQuestion from './JudgementQuestion';
import SubjectiveQuestion from './SubjectiveQuestion';
import UnsupportQuestion from './UnsupportQuestion';

export default class TestPaperDetail extends React.PureComponent {
    static propTypes = {
        data: PropTypes.array, // 题目数据
        onSingleSelection: PropTypes.func,
        onMultipleSelection: PropTypes.func,
        onJudgementSelection: PropTypes.func,
        onImageZoomer: PropTypes.func,
    };

    static defaultProps = {
        data: [],
        onSingleSelection: (index, selectedIndex) => {},
        onMultipleSelection: (index, selectedIndex) => {},
        onJudgementSelection: (index, selectedIndex) => {},
        onImageZoomer: (index, selectedIndex, path) => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            data,
            onSingleSelection,
            onMultipleSelection,
            onJudgementSelection,
            onSubjectiveChanged,
            onImageZoomer,
        } = this.props;

        return (
            <Swiper
                scrollEnabled={true}
                loop={false}
                showsButtons={true}
                loadMinimal={true}
                loadMinimalSize={5}
                showsPagination={false}
                buttonWrapperStyle={styles.buttonWrapper}
                prevButton={this._renderPrevButton()}
                nextButton={this._renderNextButton()}
            >
                {this._renderQuestions(
                    data,
                    onSingleSelection,
                    onMultipleSelection,
                    onJudgementSelection,
                    onSubjectiveChanged,
                    onImageZoomer
                )}
            </Swiper>
        );
    }

    _renderPrevButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-start', paddingLeft: SeaTheme.h_spacing_md },
                ]}
            >
                <Icon
                    type="ionicon"
                    name="ios-arrow-back"
                    size={SeaTheme.icon_size_md}
                    color="white"
                />
                <Text style={[styles.buttonText, { marginLeft: 8 }]}>上一题</Text>
            </View>
        );
    };

    _renderNextButton = () => {
        return (
            <View
                style={[
                    styles.buttonContainer,
                    { justifyContent: 'flex-end', paddingRight: SeaTheme.h_spacing_md },
                ]}
            >
                <Text style={[styles.buttonText, { marginRight: 8 }]}>下一题</Text>
                <Icon
                    type="ionicon"
                    name="ios-arrow-forward"
                    size={SeaTheme.icon_size_md}
                    color="white"
                />
            </View>
        );
    };

    _renderQuestions = (
        data,
        onSingleSelection,
        onMultipleSelection,
        onJudgementSelection,
        onSubjectiveChanged,
        onImageZoomer
    ) => {
        return data.map((value, index, array) => {
            switch (value.type) {
                case '1':
                    return (
                        <SingleChoiceQuestion
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onSelection={onSingleSelection}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '2':
                    return (
                        <MultipleChoiceQuestion
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onSelection={onMultipleSelection}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '3':
                    return (
                        <JudgementQuestion
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onSelection={onJudgementSelection}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                case '4':
                    return (
                        <SubjectiveQuestion
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onTextChanged={onSubjectiveChanged}
                            onImageZoomer={onImageZoomer}
                        />
                    );
                default:
                    return (
                        <UnsupportQuestion
                            key={index}
                            data={value}
                            index={index}
                            maxCount={array.length}
                            onSelection={onJudgementSelection}
                        />
                    );
            }
        });
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    buttonWrapper: {
        backgroundColor: SeaColor.main,
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        top: 'auto',
        bottom: 0,
    },
    buttonContainer: {
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonText: {
        backgroundColor: SeaColor.main,
        fontSize: SeaTheme.font_size_lg,
        color: 'white',
    },
});
