/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件Stem 题干
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import SeaReloadImage from '../../../components/image/SeaReloadImage';
import SeaImageUtil from '../../../util/SeaImageUtil';
import { SeaImageGalleryControl } from '../../common';

export default class Stem extends React.PureComponent {
    static propTypes = {
        type: PropTypes.string,
        content: PropTypes.string,
        score: PropTypes.number,
        index: PropTypes.number,
        maxCount: PropTypes.number,
        picture: PropTypes.string,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    _onOptionImagePress = (qIndex, oIndex, source) => {
        // qIndex - 问题index
        // oIndex - 选项index
        // path - 图片地址
        // console.log({ qIndex, oIndex, source });
        if (!this._galleryControl) {
            this._galleryControl = new SeaImageGalleryControl();
        }
        this._galleryControl.start([{ source }]);
    };

    render() {
        const { type, content, score, index, maxCount, picture } = this.props;
        const imgWidth = SeaScale.screenWidth - SeaTheme.h_spacing_md * 2;
        const imgHeight = parseInt((imgWidth * 480) / 642);
        const source = SeaImageUtil.getImageSource(picture, null, 'l');
        return (
            <View>
                <View style={styles.typeContainer}>
                    <Text style={styles.type}>{type}</Text>
                </View>
                <Text style={styles.topicText}>&emsp;&emsp;&emsp;&emsp;{content} </Text>
                {!_.isEmpty(picture) && (
                    <SeaReloadImage
                        width={imgWidth}
                        height={imgHeight}
                        containerStyle={styles.topicImg}
                        source={source}
                        resizeMode="contain"
                        onPress={() => this._onOptionImagePress(null, null, source)}
                    />
                )}
                <View style={styles.subTitleContainer}>
                    <Text style={styles.subTitle}>分值: {score} 分</Text>
                    <Text style={styles.progress}>
                        进度 {index + 1}/{maxCount}
                    </Text>
                </View>
                <View style={styles.line} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    typeContainer: {
        position: 'absolute',
        top: SeaScale.Layout(34),
        width: SeaScale.Layout(110),
        height: SeaScale.Layout(40),
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: SeaColor.main,
        borderWidth: 1,
        left: SeaScale.Layout(30),
    },
    type: {
        color: SeaColor.main,
        fontSize: SeaTheme.font_size_xs,
    },
    topicText: {
        marginTop: SeaScale.Layout(32),
        color: SeaColor.h1_text,
        fontSize: SeaTheme.font_size_lg,
        marginLeft: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
        lineHeight: SeaScale.Layout(48),
    },
    topicImg: {
        marginLeft: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_sm,
    },
    subTitleContainer: {
        justifyContent: 'space-between',
        flexDirection: 'row',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
        marginTop: SeaTheme.v_spacing_md,
    },
    subTitle: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    progress: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    line: {
        marginTop: SeaTheme.v_spacing_md,
        width: SeaScale.screenWidth,
        height: 1,
        borderBottomWidth: SeaTheme.line_width_xs,
        borderBottomColor: SeaColor.parting_line,
    },
});
