/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件MultipleChoiceQuestion 多选题
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, ScrollView } from 'react-native';
import Stem from './Stem';
import ResultContent from './ResultContent';
import { SeaScale } from '../../../asserts';
import { SeaCheckBox } from '../../../components';
import { SeaImageUtil, TestUtil } from '../../../util';

export default class MultipleChoiceQuestion extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        index: PropTypes.number,
        maxCount: PropTypes.number,
        onSelection: PropTypes.func,
        onImageZoomer: PropTypes.func,
        // 做题模式、回顾模式、预览模式
        mode: PropTypes.oneOf('default', 'review', 'preview'),
    };

    static defaultProps = {
        data: {},
        onSelection: (index, selectedIndex) => {},
        onImageZoomer: (index, selectedIndex, path) => {},
        mode: 'default',
    };

    constructor(props) {
        super(props);
        this.showResult = props.mode != 'default';
    }

    componentDidMount() {}

    render() {
        const { data, index, maxCount, onSelection, onImageZoomer, mode } = this.props;
        const { options } = data;
        return (
            <ScrollView style={styles.container} key={index}>
                <Stem
                    index={index}
                    maxCount={maxCount}
                    type="多选题"
                    content={data.description}
                    score={data.scores}
                    picture={data.stemPicture}
                />
                {this._renderOptions(options, index, onSelection, onImageZoomer)}
                {this.showResult && <ResultContent topic={data} mode={mode} />}
            </ScrollView>
        );
    }

    _renderOptions = (options, index, onSelection, onImageZoomer) => {
        return options.map((value, i) => {
            return (
                <SeaCheckBox
                    reviewMode={TestUtil.optionReviewMode(value, this.showResult)}
                    isMult={true}
                    checked={value.checked}
                    key={i}
                    title={TestUtil.optionDisplay(value)}
                    source={SeaImageUtil.getImageSource(value.optionPicture)}
                    onPress={() => onSelection(index, i)}
                    onImagePress={path => onImageZoomer(index, i, path)}
                />
            );
        });
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginBottom: SeaScale.Layout(88),
        width: SeaScale.screenWidth,
        backgroundColor: 'white',
    },
});
