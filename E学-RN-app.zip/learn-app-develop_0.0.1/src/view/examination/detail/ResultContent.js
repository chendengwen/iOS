/**
 * @author xukj
 * @date 2019/03/05
 * @class
 * @description 试卷解析, 结果信息
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { TestUtil } from '../../../util';
import { SeaTheme, SeaScale } from '../../../asserts';

export default class ResultContent extends React.PureComponent {
    static propTypes = {
        topic: PropTypes.object, // 题目信息
        // 做题模式、回顾模式、预览模式
        mode: PropTypes.oneOf('default', 'review', 'preview'),
    };

    static defaultProps = {
        mode: 'default',
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { topic, mode } = this.props;
        let AnswerComponent = () => null;
        if (mode == 'review') AnswerComponent = this._renderReview;
        if (mode == 'preview') AnswerComponent = this._renderPreview;

        return (
            <View style={styles.container}>
                <AnswerComponent topic={topic} />
                <View style={styles.knowledgeRow}>
                    <Text style={styles.knowledgePoint}>
                        试题解析：{topic.knowledgePoint ? topic.knowledgePoint : '无'}
                    </Text>
                </View>
            </View>
        );
    }

    _renderReview = props => {
        const { topic } = props;
        const isEssayQuestion = TestUtil.isEssayQuestion(topic);
        const answer = _.join(TestUtil.correctOptions(topic), '、');
        return (
            <View style={styles.resultRow}>
                {!isEssayQuestion && [
                    <Text
                        style={[styles.userResult, topic.correct && { color: 'black' }]}
                        numberOfLines={1}
                    >
                        {topic.correct ? '回答正确' : '回答错误'}
                    </Text>,
                    <Text style={styles.successResult} numberOfLines={2}>
                        标准答案：{answer ? answer : '无'}
                    </Text>,
                ]}
                <Text style={styles.score} numberOfLines={1}>
                    得分：{TestUtil.userScore(topic)}
                </Text>
            </View>
        );
    };

    _renderPreview = props => {
        const { topic } = props;
        const answer = _.join(TestUtil.correctOptions(topic), '、');
        return (
            <View style={styles.resultRow}>
                <Text style={styles.successResult} numberOfLines={2}>
                    标准答案：{answer ? answer : '无'}
                </Text>
            </View>
        );
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    resultRow: {
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
        height: SeaTheme.row_height_md,
        flexDirection: 'row',
        alignItems: 'center',
    },
    userResult: {
        flex: 1,
        fontSize: SeaTheme.font_size_md,
        textAlign: 'left',
        color: '#FF6666',
    },
    successResult: {
        flex: 2,
        fontSize: SeaTheme.font_size_md,
        color: 'green',
    },
    score: {
        flex: 1,
        fontSize: SeaTheme.font_size_md,
        textAlign: 'right',
    },
    knowledgeRow: {
        flexDirection: 'row',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
        paddingBottom: SeaTheme.v_spacing_md,
    },
    knowledgePoint: {
        flex: 1,
        fontSize: SeaTheme.font_size_md,
        lineHeight: SeaScale.Layout(40),
    },
});
