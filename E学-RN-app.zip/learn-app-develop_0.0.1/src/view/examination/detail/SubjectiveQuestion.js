/**
 * @author xukj
 * @date 2018/11/28
 * @class
 * @description 界面展示组件SubjectiveQuestion 主观题
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView, TextInput } from 'react-native';
import { RadioButtons } from 'react-native-radio-buttons';
import Stem from './Stem';
import ResultContent from './ResultContent';
import { SeaScale, SeaTheme } from '../../../asserts';
import { SeaColor } from '../../../asserts';
import { SeaCheckBox } from '../../../components';
import { SeaImageUtil, TestUtil } from '../../../util';

export default class SubjectiveQuestion extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        index: PropTypes.number,
        maxCount: PropTypes.number,
        onTextChanged: PropTypes.func,
        onImageZoomer: PropTypes.func,
        // 做题模式、回顾模式、预览模式
        mode: PropTypes.oneOf('default', 'review', 'preview'),
    };

    static defaultProps = {
        data: {},
        onSelection: (index, selectedIndex) => {},
        onImageZoomer: (index, selectedIndex, path) => {},
        mode: 'default',
    };

    constructor(props) {
        super(props);
        this.showResult = props.mode != 'default';
        // 因为输入框是受控组件，直接个defaultValue赋值
        this.defaultContent = _.get(props, 'data.options[0].answerContent', '');
    }

    render() {
        const { data, index, maxCount, onTextChanged, mode } = this.props;
        return (
            <ScrollView style={styles.container} key={index}>
                <Stem
                    index={index}
                    maxCount={maxCount}
                    type="主观题"
                    content={data.description}
                    score={data.scores}
                    picture={data.stemPicture}
                />
                <View style={styles.header}>
                    <TextInput
                        maxLength={200}
                        style={[styles.contentText, { textAlignVertical: 'top' }]}
                        ref="textInput"
                        placeholder="请在此填写答案"
                        placeholderTextColor={SeaColor.tag_text}
                        multiline={true}
                        underlineColorAndroid="transparent"
                        returnKeyType="done"
                        defaultValue={this.defaultContent}
                        blurOnSubmit={true}
                        editable={!this.showResult}
                        onChangeText={text => onTextChanged(index, text)}
                    />
                </View>
                {this.showResult && <ResultContent topic={data} mode={mode} />}
            </ScrollView>
        );
    }
    _renderContainer = optionNodes => {
        return <View>{optionNodes}</View>;
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginBottom: SeaScale.Layout(88),
        width: SeaScale.screenWidth,
        backgroundColor: 'white',
    },
    contentText: {
        borderColor: SeaColor.grey5,
        height: SeaScale.Layout(300),
        width: SeaScale.screenWidth - SeaTheme.h_spacing_md * 2,
        borderWidth: StyleSheet.hairlineWidth,
        padding: 5,
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.black,
    },
    header: {
        flexDirection: 'column',
        width: SeaScale.screenWidth,
        justifyContent: 'center',
        marginTop: SeaScale.Layout(10),
        alignItems: 'center',
        height: SeaScale.Layout(350),
    },
});
