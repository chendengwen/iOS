import { ExamStorageService } from '../../../servie';

/**
 * @author xukj
 * @date 2019/02/28
 * @description ExamAnswerManager 考试答案管理
 */

export default class ExamAnswerManager {
    constructor() {
        this.instance = null;
    }

    // 单例方法
    static sharedInstance() {
        if (!this.instance) {
            this.instance = new ExamAnswerManager();
        }
        return this.instance;
    }

    /**
     * 恢复答题记录
     * @param {array} paperData 试题信息
     * @param {any} answer 答题记录
     */
    recoveryExamData = (paperData, answer) => {
        return new Promise(resolve => {
            const tempData = paperData.map(topic => {
                let newTopic = { ...topic };
                newTopic.options = topic.options.map(option => {
                    let newOption = { ...option};
                    newOption.checked = answer[option.id] != null;
                    if(answer[option.id]&&answer[option.id].answerContent){
                        newOption.answerContent=answer[option.id].answerContent;
                    }
                    return newOption;
                });
                return newTopic;
            });
            resolve(tempData);
        });
    };

    /**
     * 从本地恢复答题记录
     * @param {string} paperId,
     * @param {string} userId,
     * @param {array} paperData 试题信息
     * @param {bool} isRecovery 是否恢复答卷
     * 如果没找到不会抛出错误
     */
    recoveryExamDataFromLocal = (paperId, userId, paperData, isRecovery = true) => {
        return ExamStorageService.loadExamData(paperId, userId)
            .then(data => {
                // console.log('记录的考试记录', data);
                return this.recoveryExamData(paperData, isRecovery ? data : {});
            })
            .catch(error => this.recoveryExamData(paperData, {}));
    };

    /**
     * 更新单选后的数据(异步)
     * @param {array} paperData 试题信息
     * @param {number} index 题目index
     * @param {number} selectedIndex 选项index
     * @return {Promise}
     */
    updateDataBySingleSelection = (paperData, index, selectedIndex) => {
        return new Promise(resolve => {
            let [...tempData] = paperData;
            tempData[index] = { ...tempData[index] };
            for (let tmpValue of tempData[index].options) {
                tmpValue.checked = false;
            }
            tempData[index].options[selectedIndex].checked = true;
            resolve(tempData);
        });
    };

    /**
     * 更新单选后的数据(异步)
     * @param {array} paperData 试题信息
     * @param {number} index 题目index
     * @param {number} selectedIndex 选项index
     */
    updateDataByMultipleSelection = (paperData, index, selectedIndex) => {
        return new Promise(resolve => {
            let [...tempData] = paperData;
            tempData[index] = { ...tempData[index] };
            tempData[index].options[selectedIndex].checked = !tempData[index].options[selectedIndex]
                .checked;
            resolve(tempData);
        });
    };

    /**
     * 更新单选后的数据(异步)
     * @param {array} paperData 试题信息
     * @param {number} index 题目index
     * @param {number} selectedIndex 选项index
     */
    updateDataByJudgementSelection = (paperData, index, selectedIndex) => {
        return new Promise(resolve => {
            let [...tempData] = paperData;
            tempData[index] = { ...tempData[index] };
            for (let tmpValue of tempData[index].options) {
                tmpValue.checked = false;
            }
            tempData[index].options[selectedIndex].checked = true;
            resolve(tempData);
        });
    };

    /**
     * 更新主观题的数据(异步)
     * @param {array} paperData 试题信息
     * @param {number} index 题目index
     * @param {string} text 主观题答案text
     */
    updateDataBySubjectiveChange = (paperData, index, text) => {
        return new Promise(resolve => {
            let [...tempData] = paperData;
            tempData[index] = { ...tempData[index] };
            for (let tmpValue of tempData[index].options) {
                tmpValue.checked = false;
            }
            tempData[index].options[0].checked = true;
            tempData[index].options[0].answerContent=text;
            resolve(tempData);
        });
    };

    /**
     * 保存答案到本地
     * @param {string} paperId,
     * @param {string} userId,
     * @param {array} paperData 试题信息
     */
    saveExamDataInLocal = (paperId, userId, paperData) => {
        return new Promise(resolve => {
            resolve(this.getAnswersFromPaperData(paperData));
        }).then(answer => {
            // console.log('保存考试记录', answer);
            ExamStorageService.saveExamData(paperId, userId, answer);
        });
    };

    /**
     * 从现有的数据中获取答案
     * 答案格式
     * { id: '选项id' }
     * @param {array} paperData 试题信息
     */
    getAnswersFromPaperData = paperData => {
        let answer = {};
        paperData.forEach(topic => {
            topic.options.forEach(option => {
                if (option.checked) {
                    answer[option.id] = { id: option.id,answerContent: option.answerContent?option.answerContent:null};
                }
            });
        });
        return answer;
    };

    /**
     * 获取本地的答题记录
     * @param {string} paperId,
     * @param {string} userId,
     */
    loadExamDataInLocal = (paperId, userId) => {
        return ExamStorageService.loadExamData(paperId, userId);
    };

    /**
     * 移除本地的答题记录
     * @param {string} paperId,
     * @param {string} userId,
     */
    removeExamDataInLocal = (paperId, userId) => {
        return ExamStorageService.removeExamData(paperId, userId);
    };
}
