/**
 * @author xukj
 * @date 2019/09/11
 * @class
 * @description 考试试卷审批前预览页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Actions } from 'react-native-router-flux';
import TestPaperApprove from './TestPaperApprove';

export default class TestPaperApprovePage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object.isRequired, // 试卷审批预览信息
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data } = this.props;
        return <TestPaperApprove data={data} onPreviewPress={this._onPreviewPress} />;
    }

    _onPreviewPress = () => {
        const stems = _.get(this.props, 'data.stems', []);
        const title = _.get(this.props, 'title', '试题浏览');
        // 进入预览界面
        Actions.show('testPaperReview', { data: stems, title, preview: true });
    };
}
