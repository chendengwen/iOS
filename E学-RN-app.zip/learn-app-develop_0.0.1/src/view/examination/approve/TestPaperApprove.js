/**
 * @author xukj
 * @date 2019/09/11
 * @class
 * @description 考试试卷审批预览
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ScrollView, Text } from 'react-native';
import { SeaTextButton } from '../../../components';
import { SeaColor, SeaScale, SeaTheme, SeaConstant, SeaStyle } from '../../../asserts';
import { FSLWhiteSpace } from 'react-native-kpframework';

/**
 * 分组头部标题组件
 */
const HeadRowComp = props => {
    const { title } = props;
    return (
        <View style={styles.infoHeadContainer}>
            <View style={styles.infoHeadFlag} />
            <Text style={[styles.textMd, { color: SeaColor.h1_text }]}>{title}</Text>
        </View>
    );
};

/**
 * 基本信息组件
 */
const InfoComp = props => {
    const { style, data } = props;
    const duration = _.get(data, 'duration', 0);
    const scores = _.get(data, 'scores', 0);
    const passScore = _.get(data, 'passScore', 0);
    const testFrequency = _.get(data, 'testFrequency', 0);
    const review = _.get(data, 'review', 0);
    const summary = _.get(data, 'summary', '暂无');

    // 答题时间
    let time = '无限制';
    const starttime = _.get(data, 'validStart', '');
    const endtime = _.get(data, 'validEnd', '');
    if (starttime && endtime) time = `${starttime} 至 ${endtime}`;
    else if (starttime) time = `${starttime}开始`;
    else time = `${endtime}截止`;

    const InfoRow = props => {
        const { title, content } = props;
        return (
            <View style={{ flexDirection: 'row' }}>
                <Text style={styles.infoTitleText}>{title}</Text>
                <Text style={[styles.infoContentText, { flex: 1 }]}>{content}</Text>
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="试卷信息" />
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="试卷时长：" content={`${duration}分钟`} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="卷面总分：" content={`${scores}分`} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="及格分数：" content={`${passScore}分`} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow
                    title="允许考试次数："
                    content={testFrequency > 0 ? `${testFrequency}次` : '不限'}
                />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="是否允许回顾答案：" content={review ? '是' : '否'} />
                <FSLWhiteSpace size={vSpaceSize} />
                <InfoRow title="答题时间：" content={time} />
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
            <View style={styles.borderTop}>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={[styles.infoTitleText, { color: SeaColor.h1_text }]}>内容介绍</Text>
                <FSLWhiteSpace size={vSpaceSize} />
                <Text style={styles.infoContentText}>{summary}</Text>
                <FSLWhiteSpace size={vSpaceSize} />
            </View>
        </View>
    );
};

/**
 * 题型分布
 */
const TopicsComp = props => {
    const { style, data } = props;

    // 单选题统计
    const singleChoiceArray = _.chain(data)
        .get('stems', [])
        .filter(value => value.type == SeaConstant.TestTopicType.SINGLE)
        .value();
    const singleChoiceCount = singleChoiceArray.length;
    const signleChoiceScore = _.sumBy(singleChoiceArray, value => value.scores);
    // 多选题统计
    const multipleChoiceArray = _.chain(data)
        .get('stems', [])
        .filter(value => value.type == SeaConstant.TestTopicType.MULTIPLE)
        .value();
    const multipleChoiceCount = multipleChoiceArray.length;
    const multipleChoiceScore = _.sumBy(multipleChoiceArray, value => value.scores);
    // 判断题统计
    const judgementChoiceArray = _.chain(data)
        .get('stems', [])
        .filter(value => value.type == SeaConstant.TestTopicType.JUDGEMENT)
        .value();
    const judgementChoiceCount = judgementChoiceArray.length;
    const judgementChoiceScore = _.sumBy(judgementChoiceArray, value => value.scores);
    // 主观题统计
    const shortChoiceArray = _.chain(data)
        .get('stems', [])
        .filter(value => value.type == SeaConstant.TestTopicType.SHORTANSWER)
        .value();
    const shortChoiceCount = shortChoiceArray.length;
    const shortChoiceScore = _.sumBy(shortChoiceArray, value => value.scores);

    // 分割线
    const VerticalSp = () => (
        <View style={[styles.spTable, { height: SeaScale.Layout(70), width: tableLineSize }]} />
    );

    // 头部
    const TopicRow = props => {
        const { title, number, score, head } = props;
        const cellStyle = { backgroundColor: head ? SeaColor.defaultBackgroudColor_3 : 'white' };
        const textStyle = [styles.textMd, { color: SeaColor.h1_text }];
        return (
            <View style={SeaStyle.row}>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{title}</Text>
                </View>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{number}</Text>
                </View>
                <VerticalSp />
                <View style={[styles.tableCell, cellStyle]}>
                    <Text style={textStyle}>{score}</Text>
                </View>
                <VerticalSp />
            </View>
        );
    };

    return (
        <View style={style}>
            <HeadRowComp title="题型分布" />
            <FSLWhiteSpace style={styles.borderTop} size={vSpaceSize} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="题型" number="数量" score="分值" head />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="单选题" number={singleChoiceCount} score={signleChoiceScore} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="多选题" number={multipleChoiceCount} score={multipleChoiceScore} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="判断题" number={judgementChoiceCount} score={judgementChoiceScore} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <TopicRow title="主观题" number={shortChoiceCount} score={shortChoiceScore} />
            <FSLWhiteSpace size={tableLineSize} style={styles.spTable} />
            <FSLWhiteSpace size={vSpaceSize} />
        </View>
    );
};

const TopicViewComp = props => {
    const { style, onPress } = props;
    return (
        <View style={[style, SeaStyle.center, { height: SeaScale.Layout(300) }]}>
            <SeaTextButton
                round
                style={{ height: SeaScale.Layout(80), width: SeaScale.Layout(300) }}
                theme="main"
                title="查看考试习题"
                titleStyle={styles.textMd}
                onPress={onPress}
            />
        </View>
    );
};

export default class TestPaperApprove extends React.PureComponent {
    static propTypes = {
        data: PropTypes.func,
        onPreviewPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { data, onPreviewPress } = this.props;
        return (
            <View style={SeaStyle.page}>
                <ScrollView style={{ flex: 1 }}>
                    <View style={{ width: SeaScale.screenWidth }}>
                        <InfoComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <TopicsComp style={styles.section} data={data} />
                        <FSLWhiteSpace style={styles.sp} size={SeaTheme.v_spacing_sm} />
                        <TopicViewComp style={styles.section} onPress={onPreviewPress} />
                    </View>
                </ScrollView>
            </View>
        );
    }
}

const vSpaceSize = SeaScale.Layout(24);
const tableLineSize = SeaScale.spWidth;

const styles = StyleSheet.create({
    // 字体
    // ---
    textLg: {
        fontSize: SeaTheme.font_size_lg,
    },
    textMd: {
        fontSize: SeaTheme.font_size_md,
    },
    textSm: {
        fontSize: SeaTheme.font_size_sm,
    },

    // 分割线
    // ---
    sp: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    spTable: {
        backgroundColor: SeaColor.parting_line,
    },

    // 分割线
    // ---
    borderTop: {
        borderTopColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
    },

    // 其他
    // ---
    section: {
        backgroundColor: 'white',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    infoHeadContainer: {
        ...SeaStyle.row,
        height: SeaScale.Layout(100),
    },
    infoHeadFlag: {
        height: SeaScale.Layout(26),
        width: SeaScale.Layout(4),
        backgroundColor: SeaColor.main,
        marginRight: SeaTheme.h_spacing_md,
    },
    infoTitleText: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        minWidth: SeaScale.Layout(150),
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
    },
    infoContentText: {
        fontSize: SeaTheme.font_size_md,
        lineHeight: Math.round(SeaTheme.font_size_md) + 4,
        color: SeaColor.h2_text,
    },
    tableCell: {
        height: SeaScale.Layout(70),
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
});
