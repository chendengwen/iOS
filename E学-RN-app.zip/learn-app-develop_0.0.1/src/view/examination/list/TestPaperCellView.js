/**
 * @author xukj
 * @date 2019/08/01
 * @description 考试列表cell组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, StyleSheet } from 'react-native';
import { SeaListCell } from '../../../components';
import { SeaColor, SeaIcon, SeaTheme, SeaScale } from '../../../asserts';

export default class TestPaperCellView extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object, // 源数据
        name: PropTypes.string, // 标题
        score: PropTypes.number, // 总分
        passScore: PropTypes.number, // 及格分
        startTime: PropTypes.string, // 开始时间
        endTime: PropTypes.string, // 结束时间
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    render() {
        const { onPress, name, score, passScore, startTime, endTime } = this.props;

        return (
            <View style={styles.container}>
                <SeaListCell
                    showArrow={false}
                    showSeparator={false}
                    backgroundColor="white"
                    style={styles.cell}
                    onPress={onPress}
                >
                    <View style={styles.headerContainer}>
                        <Text style={styles.content} numberOfLines={2}>
                            {name}
                        </Text>
                        <SeaIcon
                            style={styles.arrow}
                            name={'arrow-goto'}
                            size={SeaScale.Layout(32)}
                            color={SeaColor.grey}
                        />
                    </View>
                    <View style={styles.contentContainer}>
                        <View style={styles.subContentContainer}>
                            <Text style={styles.score}>
                                总分：
                                <Text style={{ color: SeaColor.red_text }}>{score}分</Text>
                            </Text>
                            <View style={styles.sp} />
                            <Text style={styles.passScore}>
                                及格分：
                                <Text style={{ color: SeaColor.red_text }}>{passScore}分</Text>
                            </Text>
                        </View>
                        <Text style={styles.time}>
                            有效期：
                            <Text style={{ color: SeaColor.content_text }}>
                                {!endTime ? '长期有效' : `${startTime} 至 ${endTime}`}
                            </Text>
                        </Text>
                    </View>
                </SeaListCell>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        paddingBottom: SeaTheme.v_spacing_sm,
    },
    cell: {
        height: SeaScale.Layout(272),
        borderColor: SeaColor.parting_line,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
    },
    headerContainer: {
        height: SeaTheme.row_height_md,
        borderColor: SeaColor.parting_line,
        borderBottomWidth: StyleSheet.hairlineWidth,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: SeaTheme.h_spacing_md,
        paddingRight: SeaTheme.h_spacing_md,
    },
    contentContainer: {
        flex: 1,
        justifyContent: 'space-between',
        padding: SeaTheme.h_spacing_md,
    },
    subContentContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    content: {
        flex: 1,
        fontSize: SeaTheme.font_size_lg,
        color: SeaColor.h1_text,
        marginRight: SeaTheme.h_spacing_md,
    },
    arrow: {
        width: SeaScale.Layout(32),
        height: SeaScale.Layout(32),
    },
    score: {
        width: SeaScale.Layout(172),
        fontSize: SeaTheme.font_size_md,
    },
    passScore: {
        width: SeaScale.Layout(190),
        fontSize: SeaTheme.font_size_md,
    },
    sp: {
        width: SeaScale.Layout(30),
        borderLeftWidth: 1,
        borderColor: SeaColor.parting_line,
        height: SeaScale.Layout(32),
    },
    time: {
        marginTop: SeaTheme.v_spacing_md,
        flex: 1,
        fontSize: SeaTheme.font_size_md,
    },
});
