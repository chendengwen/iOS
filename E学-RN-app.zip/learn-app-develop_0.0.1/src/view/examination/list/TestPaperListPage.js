/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-27 11:08:27
 */
/**
 * @author xukj
 * @date 2019/08/01
 * @class
 * @description 试卷列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import TestPaperList from './TestPaperList';
import { TestPaperService } from '../../../servie';
import { FSLToast, FSLWhiteSpace } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { DeviceEventEmitter, View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { SeaConstant, SeaScale } from '../../../asserts';

export default class TestPaperListPage extends React.PureComponent {
    static propTypes = {
        category: PropTypes.string, // 分类
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(SeaConstant.Notification.REFRESH_EXAM_LIST,
            this._reload
        )
    }

    _reload = () => {
        this.refs.TestPaperList && this.refs.TestPaperList.reload();
    }

    render() {
        // return <TestPaperList
        //     ref='TestPaperList'
        //     onFetch={this._loader}
        //     onCellPress={this._onCellPress} />;
        const { from } = this.props;
        return (
            <View style={from != 'category' ? styles.parent : styles.category}>
                {from != 'category' &&
                    <View style={styles.caseArt} >
                        <Text style={{ height: 80, marginLeft: 20, marginTop: 12, fontSize: 16, color: '#000000' }}>考试</Text>

                        <TouchableOpacity
                            style={{
                                position: 'absolute', bottom: 2, height: 40, justifyContent: 'center',
                                width: SeaScale.screenWidth / 2, left: 20
                            }}
                            onPress={this._toCategory}
                        >
                            <Text style={{ fontSize: 14, color: '#000000' }}>全部分类</Text>
                        </TouchableOpacity>
                    </View>}

                { from != 'category' && <FSLWhiteSpace size={SeaScale.Layout(22)} ></FSLWhiteSpace>}

                <TestPaperList
                    ref='TestPaperList'
                    onFetch={this._loader}
                    onCellPress={this._onCellPress} />
            </View>
        );
    }

    _toCategory = () => {
        Actions.show('categoryChoose', { index: 2, from: 'testpaper' });
    }

    /*
     * @private
     * @description 加载器
     */
    _loader = (pageTo, pageSize) => {
        return TestPaperService.getTestPaperList(this.props.category, pageTo, pageSize)
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = (item, index) => {
        Actions.show('testpaperDesc', { id: item.id, title: item.name, assignment: item.assignment });
    };
}
const styles = StyleSheet.create({
    parent: {
        flex: 1,
        position: 'relative',
        flexDirection: 'column',
        paddingTop: 80,
        backgroundColor: '#eeeeee'
    },
    category: {
        flex: 1,
        position: 'relative',
        flexDirection: 'column',
        backgroundColor: '#eeeeee'
    },
    caseArt: {
        position: 'absolute',
        flexDirection: 'column',
        top: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        zIndex: 1
    },
})