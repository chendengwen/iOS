/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: 
 * @LastEditTime: 2020-09-07 16:42:27
 */
/**
 * @author xukj
 * @date 2019/08/05
 * @class
 * @description 考试计划列表页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { ToLearnService } from '../../../servie';
import { SeaConstant } from '../../../asserts';
import TestPaperToLearn from './TestPaperToLearn';

export default class TestPaperToLearnPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        return <TestPaperToLearn onFetch={this._loader} onCellPress={this._onCellPress} />;
    }

    /*
     * @private
     * @description 加载器
     */
    _loader = (pageTo, pageSize) => {
        return ToLearnService.getToLearnResourceList(
            pageTo,
            pageSize,
            SeaConstant.ResourceType.EXAM
        )
            .then(responseJson => {
                return Promise.resolve({
                    data: responseJson.data.data,
                    totalPage:
                        responseJson.data.total === 0 ? 0 : Math.ceil(responseJson.data.total / pageSize),
                });
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };

    _onCellPress = (item, index) => {
        Actions.show('testpaperDesc', { id: item.id, title: item.name });
    };
}
