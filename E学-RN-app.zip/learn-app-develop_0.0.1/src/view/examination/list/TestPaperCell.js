/**
 * @author xukj
 * @date 2019/08/01
 * @description 考试列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import TestPaperCellView from './TestPaperCellView';

export default class TestPaperCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object.isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        item: {},
        onPress: () => {},
    };

    render() {
        const { onPress, item } = this.props;

        return (
            <TestPaperCellView
                name={_.get(item, 'name', '')}
                score={_.get(item, 'scores', 0)}
                passScore={_.get(item, 'passScore', 0)}
                startTime={_.get(item, 'validStart')}
                endTime={_.get(item, 'validEnd')}
                onPress={onPress}
            />
        );
    }
}
