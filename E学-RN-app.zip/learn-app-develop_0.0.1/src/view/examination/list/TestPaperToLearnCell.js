/**
 * @author xukj
 * @date 2019/08/01
 * @description 考试计划列表cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import TestPaperCellView from './TestPaperCellView';

export default class TestPaperToLearnCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.object.isRequired,
        onPress: PropTypes.func,
    };

    static defaultProps = {
        item: {},
        onPress: () => {},
    };

    render() {
        const { onPress, item } = this.props;

        return (
            <TestPaperCellView
                name={_.get(item, 'name', '')}
                score={_.get(item, 'score', 0)}
                passScore={_.get(item, 'passScore', 0)}
                startTime={_.get(item, 'startTime')}
                endTime={_.get(item, 'endTime')}
                onPress={onPress}
            />
        );
    }
}
