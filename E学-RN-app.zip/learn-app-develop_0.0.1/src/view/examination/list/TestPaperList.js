/*
 * @Descripition: 
 * @Author: 
 * @Date: 2020-08-27 13:25:19
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-10 15:00:54
 */
/**
 * @author xukj
 * @date 2019/08/01
 * @class
 * @description 界面展示组件TestPaperList
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { SeaList } from '../../../components';
import TestPaperCell from './TestPaperCell';
import { SeaStyle } from '../../../asserts';

export default class TestPaperList extends React.PureComponent {
    static propTypes = {
        defaultData: PropTypes.array, //组件加载成功后展示的默认值
        onCellPress: PropTypes.func.isRequired,
        onFetch: PropTypes.func.isRequired, // 分页方法
    };

    static defaultProps = {
        defaultData: [],
        onCellPress: (item, index) => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { defaultData, onFetch } = this.props;
        return (
            <SeaList
                ref='testpapers'
                style={SeaStyle.list}
                onFetch={onFetch}
                data={defaultData}
                renderItem={this._renderItem}
            />
        );
    }

    reload = () => {
        this.refs.testpapers && this.refs.testpapers.reload();
    }
    /*
     * private
     * @method 列表项
     */
    _renderItem = ({ item, index }) => {
        return <TestPaperCell item={item} onPress={() => this.props.onCellPress(item, index)} />;
    };
}
