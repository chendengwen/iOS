/**
 * @author xukj
 * @date 2018/7/20
 * @description 试卷通用cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell, SeaFlagText } from '../../../components';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import TestPaperData from '../data/TestPaperData';

export default class TestPaperCommonCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(TestPaperData),
        onPress: PropTypes.func,
        keyword: PropTypes.string,
    };

    static defaultProps = {
        onPress: () => { },
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    _keywordTitle = (keyword, strins) => {
        let data = strins          //   获取文本
        let newData = data.split(keyword)       //  通过关键字的位置开始截取，结果为一个数组
        return (
            <Text style={styles.title} numberOfLines={2}>
                &emsp;&emsp;&emsp;
                {
                    newData.map((item, index) => {
                        return <Text key={index}>
                            {item}
                            {(index < newData.length - 1) && (<Text style={{ color: 'red' }}>{keyword}</Text>)}
                        </Text>
                    })
                }
            </Text>
        )
    }

    render() {
        const { item, onPress, keyword, ...restProps } = this.props;
        return (
            <SeaListCell
                backgroundColor="white"
                style={styles.cell}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.contentContainer}>
                    <SeaFlagText style={styles.flag}>考试</SeaFlagText>
                    <View >
                        {
                            item.name && item.name.includes(keyword) ?
                                this._keywordTitle(keyword, item.name) :
                                <Text style={styles.title} numberOfLines={2}>
                                    &emsp;&emsp;&emsp;{item.name}
                                </Text>
                        }
                    </View>
                    <View>
                        <Text style={styles.content}>
                            总分：{item.totalScore}分&emsp;&emsp; 及格分：
                            {item.passScore}分
                        </Text>
                    </View>
                    <Text style={styles.time}>发布时间：{item.publishTime}</Text>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        minHeight: SeaScale.Layout(240),
    },
    contentContainer: {
        flex: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        margin: SeaTheme.h_spacing_md,
    },
    flag: {
        position: 'absolute',
        top: 0,
        left: 0,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(42),
        color: SeaColor.h1_text,
    },
    keyword: {
        fontSize: SeaTheme.font_size_md,
        color: 'red',
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    time: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
});
