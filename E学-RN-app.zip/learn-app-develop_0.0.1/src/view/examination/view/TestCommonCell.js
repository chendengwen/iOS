/**
 * @author xukj
 * @date 2018/7/20
 * @description 考试项目通用cell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text } from 'react-native';
import { SeaListCell, SeaFlagText } from '../../../components';
import { SeaColor, SeaScale, SeaTheme } from '../../../asserts';
import TestResourceData from '../data/TestResourceData';

export default class TestCommonCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.instanceOf(TestResourceData),
        onPress: PropTypes.func,
    };

    static defaultProps = {
        onPress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item, onPress, ...restProps } = this.props;
        return (
            <SeaListCell
                backgroundColor="white"
                style={styles.cell}
                showArrow={false}
                onPress={onPress}
                {...restProps}
            >
                <View style={styles.contentContainer}>
                    <SeaFlagText style={styles.flag}>考试</SeaFlagText>
                    <Text style={styles.title} numberOfLines={2}>
                        &emsp;&emsp;&emsp;{item.name}
                    </Text>
                    <Text style={styles.content}>发布人：{item.publisher}</Text>
                    <Text style={styles.time}>发布时间：{item.publishTime}</Text>
                </View>
            </SeaListCell>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        minHeight: SeaScale.Layout(240),
    },
    contentContainer: {
        flex: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        margin: SeaTheme.h_spacing_md,
        marginRight: SeaTheme.h_spacing_md,
    },
    flag: {
        position: 'absolute',
        top: 0,
        left: 0,
    },
    title: {
        fontSize: SeaTheme.font_size_lg,
        lineHeight: SeaScale.Layout(42),
        color: SeaColor.h1_text,
    },
    keyword: {
        fontSize: SeaTheme.font_size_md,
        color: 'red',
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
    },
    time: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.content_text,
    },
});
