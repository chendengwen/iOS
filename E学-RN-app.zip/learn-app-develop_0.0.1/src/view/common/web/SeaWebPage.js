/**
 * @author xukj
 * @date 2018/12/24
 * @class
 * @description 界面交互组件SeaWebPage web页面
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Platform, Alert } from 'react-native';
import { SeaNavigator, SeaNavigationItems as Items, ExceptionView } from '../../../components';
import SeaSharePanel from './SeaSharePanel';
import JSMessageHandler from './JSMessageHandler';
import { injectForH5HeadRead } from './JSInjectUtil';
import { SeaStyle } from '../../../asserts';
import { WebView } from 'react-native-webview';

export default class SeaWebPage extends React.PureComponent {
    static propTypes = {
        url: PropTypes.string,
        title: PropTypes.string,
        sharable: PropTypes.bool,
        shareUrl: PropTypes.string, // 如果没指定则使用url
    };

    static defaultProps = {
        sharable: false,
    };

    constructor(props) {
        super(props);
        this.state = {
            title: props.title,
            head: null,
        };
        this._jsHander = new JSMessageHandler();
        this._jsHander.setHandler('share', this._onSharePress);
        this._jsHander.setHandler('injectH5Head', this._onLoadH5Head);
    }

    componentDidMount() {}

    componentDidUpdate() {}

    render() {
        const { url } = this.props;
        const { title } = this.state;
        return (
            <View style={SeaStyle.page}>
                <SeaNavigator
                    title={title}
                    backMode
                    renderRightButton={() =>
                        Items.renderSeaIconButton(() => this._onSharePress(), 'share', '#0C5FDD')
                    }
                />
                <WebView
                    ref="web"
                    styles={styles.page}
                    automaticallyAdjustContentInsets
                    scalesPageToFit
                    startInLoadingState
                    androidjavaScriptEnable
                    source={{ uri: url }}
                    onMessage={this._jsHander.handler}
                    injectedJavaScript={injectForH5HeadRead}
                    renderError={() => <ExceptionView message="出错啦，请稍后再试" />}
                />
                <SeaSharePanel
                    ref="sharePanel"
                    onResult={(_, message) =>
                        Alert.alert('提示', message, [{ text: '确定' }], { cancelable: false })
                    }
                />
            </View>
        );
    }

    _onSharePress = values => {
        let title, url, description, imageUrl;
        const { head } = this.state;
        url = this.props.shareUrl ? this.props.shareUrl : this.props.url;
        if (head) {
            title = head.title;
            description = head.description;
            // android不能取html的图标
            imageUrl = Platform.OS == 'android' ? '' : head.imageUrl;
        }

        if (values) {
            title = !!values.title ? values.title : title;
            url = !!values.url ? values.url : url;
            description = !!values.description ? values.description : description;
            imageUrl = !!values.imageUrl ? values.imageUrl : imageUrl;
        }

        if (!!title && !!description && !!url) {
            this.refs.sharePanel.show({ title, description, imageUrl, url });
        }
    };

    _onLoadH5Head = json => {
        const title = !!json.title ? json.title : this.state.title;
        this.setState({ head: json, title: title });
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
    },
});
