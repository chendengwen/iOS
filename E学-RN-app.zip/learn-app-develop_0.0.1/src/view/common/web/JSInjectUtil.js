/**
 * @author xukj
 * @date 2019/01/10
 * @description JSInjectUtil 定义了一批javascript脚本供注入webview
 */

/**
 * injectJavaScript 获取h5页面的head
 * 标题 <title><title>
 * 描述 <meta name='description' content='${这里是描述的内容}' />
 * icon <link rel='shortcut icon' href='${图标地址}' />
 */
const readH5HeadFunction = function () {
    // 因为rn与h5交互有延迟，需要设置100毫秒的延迟处理
    setTimeout(function(){
        var heads = document.getElementsByTagName('head');
        if (heads.length <= 0) return;
        var head = heads[0];
        // 标题
        var title = document.title;
        // 描述
        var metas = head.getElementsByTagName('meta');
        var description = title;
    
        for (var i = 0; i < metas.length; i++) {
            var meta = metas[i];
            var key = meta.getAttribute('name');
            if (key && key.toLowerCase() == 'description') {
                description = meta.getAttribute('content');
                break;
            }
        }
    
        // 图标
        var links = head.getElementsByTagName('link');
        var imageUrl;
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            var key = link.getAttribute('rel');
            if (key && key.toLowerCase() == 'icon') {
                imageUrl = link.getAttribute('href');
                imageUrl = window.location.protocol + '//' + window.location.host + imageUrl;
                break;
            }
        }
    
        window.postMessage(JSON.stringify({
            type: 'injectH5Head',
            title,
            description,
            imageUrl,
        }));
    }, 100);
};

/**
 * 某些页面会覆盖使用的onMessage方法，为了防止崩溃需要做一个代理
 */
const patchPostMessageFunction = function () {
    var originalPostMessage = window.postMessage;
    var patchedPostMessage = function (message, targetOrigin, transfer) {
        originalPostMessage(message, targetOrigin, transfer);
    };
    patchedPostMessage.toString = function () {
        return String(Object.hasOwnProperty).replace('hasOwnProperty', 'postMessage');
    };
    window.postMessage = patchedPostMessage;
};

export const injectForH5HeadRead = '(' + String(patchPostMessageFunction) + ')();'
    + '\n' + '(' + String(readH5HeadFunction) + ')();';