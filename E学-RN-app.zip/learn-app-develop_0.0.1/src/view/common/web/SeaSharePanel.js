/**
 * @author xukj
 * @date 2018/12/24
 * @class
 * @description 界面展示组件SeaSharePanel
 * 这是一个可控的组件, 提供show 和 hide方法来控制控件的展示隐藏
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
    StyleSheet,
    View,
    Text,
    Image,
    TouchableOpacity,
    Modal,
    TouchableWithoutFeedback,
    AppState,
} from 'react-native';
import { SeaShareUtil, SeaSharePlatform, SeaShareCode } from '../../../util';
import { SeaScale, SeaColor } from '../../../asserts';
import { FSLLoadingView } from 'react-native-kpframework';
import { Separator } from '../../../components';

const ShareConfigs = {
    unsupport: {
        name: '暂不支持',
        source: undefined,
        type: -1,
    },
    qq: {
        name: 'QQ分享',
        source: undefined,
        type: SeaSharePlatform.QQ,
    },
    wxSession: {
        name: '微信分享',
        source: require('../../../asserts/images/wechat_session.png'),
        type: SeaSharePlatform.WechatSessoin,
    },
    wxTL: {
        name: '朋友圈分享',
        source: require('../../../asserts/images/wechat_tl.png'),
        type: SeaSharePlatform.WeChatTimeLine,
    },
};

const ShareButton = props => {
    const { style, type, onPress } = props;
    const configs = ShareConfigs[type] ? ShareConfigs[type] : ShareConfigs['unsupport'];
    let Component = View;
    if (onPress) Component = TouchableOpacity;

    return (
        <Component style={[styles.icon, style && style]} onPress={() => onPress(configs.type)}>
            <Image style={styles.icon} source={configs.source} />
        </Component>
    );
};

ShareButton.propTypes = {
    // weixin - 微信; qq - QQ;
    type: PropTypes.string.isRequired,
    onPress: PropTypes.func,
};

ShareButton.defaultProps = {
    type: 'unsupport',
};

/**
 * 这是一个可控的组件, 提供show 和 hide方法来控制控件的展示隐藏
 */
export default class SeaSharePanel extends React.PureComponent {
    static propTypes = {
        // 默认是否展示，仅影响初始化的状态
        defaultVisiable: PropTypes.bool,
        // 分享的title
        title: PropTypes.string,
        // 分享的链接
        url: PropTypes.string,
        // 分享的内容
        description: PropTypes.string,
        // 分享的图片logo地址
        imageUrl: PropTypes.string,
        // 取消分享callback
        onCancel: PropTypes.func,
        // 分享结果callback
        onResult: PropTypes.func,
        // 展示的图片
        source: PropTypes.any,
    };

    static defaultProps = {
        defaultVisiable: false,
    };

    constructor(props) {
        super(props);
        this.state = {
            show: props.defaultVisiable,
            source: props.source,
            title: props.title,
            description: props.description,
            imageUrl: props.imageUrl,
            url: props.url,
            waiting: false,
        };
        this.show = this.show.bind(this);
        this.hide = this.hide.bind(this);
    }

    componentDidMount() {
        AppState.addEventListener('change', this._appStateChangeHandler);
    }

    componentWillUnmount() {
        AppState.removeEventListener('change', this._appStateChangeHandler);
    }

    /**
     * 显示本Panel
     * @param {object} shareData 分享需要的数据 title/content/url/imageUrl/source
     */
    show(shareData = {}) {
        this.setState({
            show: true,
            ...shareData,
            title: '我的年度学习报告',
        });
    }

    /**
     * 隐藏本Panel
     */
    hide() {
        this.setState({ show: false });
    }

    render() {
        const { show, waiting } = this.state;

        return (
            <Modal
                animationType="fade"
                transparent={true}
                visible={show}
                supportedOrientations={['portrait']}
                onRequestClose={this._onCancel}
            >
                <TouchableWithoutFeedback
                    style={{ width: SeaScale.screenWidth, height: SeaScale.screenHeight }}
                    onPress={this._onCancel}
                >
                    <View style={styles.panel}>
                        <View style={styles.contentView}>
                            <View style={styles.imageContainer}>
                                <Image
                                    style={styles.image}
                                    resizeMode="contain"
                                    source={require('../../../asserts/images/report_modal.png')}
                                />
                            </View>
                            <View style={styles.infoContainer}>
                                <Separator style={[styles.sp, { marginRight: 15 }]} />
                                <Text style={styles.info}>分享到</Text>
                                <Separator style={[styles.sp, { marginLeft: 15 }]} />
                            </View>
                            <View style={styles.iconContainer}>
                                <ShareButton type="wxSession" onPress={this._onSharePress} />
                                <ShareButton
                                    style={{ marginLeft: 20 }}
                                    type="wxTL"
                                    onPress={this._onSharePress}
                                />
                            </View>
                        </View>
                        {waiting && <FSLLoadingView content="请稍等" />}
                    </View>
                </TouchableWithoutFeedback>
            </Modal>
        );
    }

    _onCancel = () => {
        const { onCancel } = this.props;
        this.hide();
        if (onCancel) onCancel();
    };

    _onSharePress = type => {
        this.setState({ waiting: true });
        const { onResult } = this.props;
        const { description, title, url, imageUrl } = this.state;

        SeaShareUtil.share(description, imageUrl, url, title, type, (code, message) => {
            this.setState({ waiting: false });
            if (code == SeaShareCode.SUCCESS) {
                // success
                if (onResult) onResult(code, '分享成功');
            } else {
                // fail
                if (onResult) onResult(code, message);
            }
        });
    };

    _appStateChangeHandler = appState => {
        switch (appState) {
            case 'background':
                this.setState({ waiting: false });
                break;
            default:
                break;
        }
    };
}

const styles = StyleSheet.create({
    panel: {
        width: SeaScale.screenWidth,
        height: SeaScale.screenHeight,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    contentView: {
        width: 280,
        height: 365,
        backgroundColor: 'white',
        borderRadius: 5,
        alignItems: 'center',
        padding: 10,
    },
    imageContainer: {
        width: 260,
        height: 265,
        backgroundColor: '#e52a27',
        alignItems: 'center',
        justifyContent: 'center',
    },
    image: {
        width: 245,
        height: 250,
    },
    infoContainer: {
        height: 16,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        marginTop: 10,
    },
    sp: {
        height: StyleSheet.hairlineWidth,
        flex: 1,
        backgroundColor: '#c9c9c9',
    },
    info: {
        fontSize: 16,
        color: SeaColor.h2_text,
    },
    iconContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 6,
    },
    icon: {
        width: 40,
        height: 40,
    },
});
