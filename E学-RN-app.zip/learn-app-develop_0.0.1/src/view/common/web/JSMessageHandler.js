/**
 * @author xukj
 * @date 2019/01/07
 * @description MessageHandler 接收从h5传递过来的message并转义为json，通过策略模式分发给handler
 * @class
 * 使用方式:
 * 1. 接收js的数据交互
 * <WebView onMessage={(new JSMessageHandler()).handler} />
 * 2. 如果需要替换或添加新的逻辑, 例如type为'share'的js调用
 * const handler = new JSMessageHandler();
 * handler.setHandler('share', (json) => {...});
 * 详细的JS定义，请查看 【h5与原生交互定义.md】 文档
 */
export default class JSMessageHandler {

    constructor() {
        this.handlers = {
            // 分享策略
            share: this._shareHandler,
            // inject开头表示这个type是由app自己注入的，不在通用定义中
            // 错误策略
            injectError: this._errorHandler,
            // h5头
            injectH5Head: this._headHandler,
        };
    }

    /**
     * 设置自定义的handler, 来替换默认的策略
     * @param {string} action 策略key
     * @param {func} func 策略执行的func
     */
    setHandler = (action, handler) => {
        this.handlers[action] = handler;
    }

    /**
     * 移除指定的handler
     * @param {string} action 策略key
     */
    removeHandler = (action) => {
        delete this.handlers[action];
    }

    handler = (e) => {
        try {
            console.log('inject', e.nativeEvent.data);
            const json = JSON.parse(e.nativeEvent.data);
            this.handlers[json.type](json);
        } catch (error) {
            this.handlers['injectError'](error);
        }
    }

    // 以下是默认的JS策略

    // 分享
    _shareHandler = (json) => {
        console.log('share', json);
    };

    // 报错
    _errorHandler = (error) => {
        console.log('injectError', error);
    };

    // 头部信息
    _headHandler = (json) => {
        console.log('injectH5Head', json);
    };
}