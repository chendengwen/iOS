
/**
 * @author xukj
 * @date 2019/06/21
 * @description 图片播放控制器
 * 使用方式:
 * // 初始化
 * const galleryControl = new SeaImageGallerControl();
 * // 打开
 * // images - { source: 与Image组件的source一致 }
 * // index - 显示第几张
 * galleryControl.start(images, index);
 */
import KPGallery from 'react-native-kpframework-gallery';

export default class SeaImageGallerControl {
    constructor() {
        this.images = [];
        this.index = 0;
    }

    /**
     * 开启图片播放器
     */
    start = (images, index) => {
        this.images = images;
        this.index = index;

        if (_.isEmpty(this.images) || index >= this.images.length) {
            return;
        }

        KPGallery.showGallery(
            {
                images: this.images,
                mode: 'crop',
                debug: false,
                orientation: 'portrait',
                index,
            },
            this._onIndexChange,
            this._onClose
        );
    };

    _onIndexChange = index => {};

    _onClose = () => {};
}
