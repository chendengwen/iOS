/**
 * @author xukj
 * @date 2019/07/16
 * @class
 * @description SeaPdfGalleryPage 仅android有效
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Platform } from 'react-native';
import { KPAndroidGalleryView } from 'react-native-kpframework-gallery';
import { Actions } from 'react-native-router-flux';

export default class SeaPdfGalleryPage extends React.PureComponent {
    static propTypes = {
        options: PropTypes.object,
        onPageChanged: PropTypes.func,
        onClose: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    componentWillUnmount() {
        if (this.props.onClose) this.props.onClose();
    }

    render() {
        const { options, onPageChanged } = this.props;

        return (
            <KPAndroidGalleryView
                style={{ flex: 1 }}
                options={options}
                onPageChanged={onPageChanged}
                onClosePress={Actions.pop}
            />
        );
    }
}
