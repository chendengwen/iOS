/**
 * @author xukj
 * @date 2019/06/20
 * @class
 * @description pdf播放控制器
 * 使用方法:
 * // 初始化
 * const control = new SeaPdfGalleryControl(payload, true);
 * // 开始pdf播放
 * control.start();
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Alert, DeviceEventEmitter, Platform } from 'react-native';
import { FSLPrompt } from 'react-native-kpframework';
import KPGallery from 'react-native-kpframework-gallery';
import Orientation from 'react-native-orientation-locker';
import { CommonService } from '../../../servie';
import { SeaImageUtil, SeaStudyTimeUtil, SeaPlayProgressUtil } from '../../../util';
import { SeaConstant } from '../../../asserts';
import { CourseExtension } from '../../../redux';
import { Actions } from 'react-native-router-flux';

export default class SeaPdfGalleryControl {
    constructor(payload, learn) {
        this.payload = payload; // pdf学习数据
        this.learn = learn; // 是否学习
        this.images = [];
        this._loadingKey;
        this.landscape = false;
        this.fileId = null;
    }

    // 是否正在浏览
    isOpen = false;

    /**
     * 重置数据
     */
    reset(payload, learn) {
        this.payload = payload;
        this.learn = learn;
        this.images = [];
        this._loadingKey;
        this.landscape = false;
        this.fileId = null;
    }

    /**
     * 开始阅读
     */
    start = async () => {
        // 正在浏览，直接跳过
        if (this.isOpen) return;

        this.isOpen = true;

        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            // 初始化
            this._configInit();
            // 加载图片
            this.images = await this._loadImages();
            if (_.isEmpty(this.images)) {
                throw new Error('没有找到PDF课件');
            }
            // 开始学习
            this._startLearning();

            FSLPrompt.hide(this._loadingKey);
            this.landscape = _.get(this, 'payload.isCrosswise') == '1';

            if (Platform.OS == 'android') {
                this._androidStart();
            } else if (Platform.OS == 'ios') {
                this._iosStart();
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            Alert.alert('提示', error.message, [{ text: '确定' }], { cancelable: false });
            this.isOpen = false;
        }
    };


    /**
     * (案例管理)开始阅读pdf
     */
    startPdf = async () => {
        // 正在浏览，直接跳过
        if (this.isOpen) return;

        this.isOpen = true;

        try {
            this._loadingKey = FSLPrompt.loading('请稍等');
            // 初始化
            this._configInit();
            // 加载图片
            this.images = await this._loadPdfImages();
            if (_.isEmpty(this.images)) {
                throw new Error('没有找到PDF');
            }

            FSLPrompt.hide(this._loadingKey);
            this.landscape = _.get(this, 'payload.isCrosswise') == '1';

            if (Platform.OS == 'android') {
                this._androidStart();
            } else if (Platform.OS == 'ios') {
                this._iosStart();
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            Alert.alert('提示', error.message, [{ text: '确定' }], { cancelable: false });
            this.isOpen = false;
        }
    };

    //获取已读页数
    _getIndex = () => {
        if (!this.learn) return 0;
        if (this.payload.type && this.payload.type == SeaConstant.ResourceType.READER) {
            return this.payload.playedSeconds ? this.payload.playedSeconds - 1 : 0;
        } else return this.payload.playedSeconds ? this.payload.playedSeconds - 1 : 0;
    };

    // android 需要界面跳转
    _androidStart = () => {
        // 横竖屏切换
        if (this.landscape) Orientation.lockToLandscape();

        const options = {
            images: this.images,
            debug: false,
            mode: 'crop',
            orientation: this.landscape ? 'landscape' : 'portrait',
            seek: true,
            index: this._getIndex(),
        };
        Actions.show('pdfGallery', {
            options,
            onPageChanged: this._onIndexChanged,
            onClose: () => {
                DeviceEventEmitter.emit(SeaConstant.Notification.CLOSE_CLASS);
                this._stopLearning();
                // 防止crash
                setTimeout(Orientation.lockToPortrait, 1);
                // 重置状态
                this.isOpen = false;
            },
        });
    };

    // ios 不需要界面跳转
    _iosStart = () => {
        KPGallery.showGallery(
            {
                images: this.images,
                debug: false,
                mode: 'crop',
                orientation: this.landscape ? 'landscape' : 'portrait',
                seek: true,
                index: this._getIndex(),
            },
            this._onIndexChanged,
            () => {
                DeviceEventEmitter.emit(SeaConstant.Notification.CLOSE_CLASS);
                this._stopLearning();
                // 防止crash
                setTimeout(Orientation.lockToPortrait, 1);
                // 重置状态
                this.isOpen = false;
            }
        );
    };

    _onIndexChanged = index => {
        if (index >= this.images.length - 1) this._reportFinish();
        console.log('change', index);
        this._reportProgress(index);
    };

    /**
     * @private
     * @description 初始化需要的数据 fileId
     */
    _configInit = () => {
        // 1.pdf文件id
        this.fileId = _.get(this, 'payload.fileId');
    };

    /**
     * @private
     * @description 获取pdf图片
     */
    _loadImages = () => {
        return CommonService.getImageIds(this.fileId).then(responseJson => {
            // 转换为可以识别的结构
            // modify by xukj 1.28.0
            // 增加水印标识
            const imageIds = responseJson.data.ids;
            const mark = responseJson.data.hasWatermark;
            const images = (imageIds ? imageIds : []).map(value => {
                const uri = SeaImageUtil.getPdfImageUri(value, mark);
                return { source: { uri } };
            });
            return Promise.resolve(images);
        });
    };

    /**
 * @private
 * @description (案例管理)获取pdf图片
 */
    _loadPdfImages = () => {
        return CommonService.getPdfImageIds(this.fileId).then(responseJson => {
            // 转换为可以识别的结构
            // modify by xukj 1.28.0
            // 增加水印标识
            const imageIds = responseJson.data;
            const mark = responseJson.data.hasWatermark;
            const images = (imageIds ? imageIds : []).map(value => {
                const uri = SeaImageUtil.getPdfImageUri(value, mark);
                return { source: { uri } };
            });
            return Promise.resolve(images);
        });
    };

    /**
     * @private
     * @description 开始学习
     */
    _startLearning = () => {
        // 没有数据
        if (_.isEmpty(this.images)) {
            Alert.alert('提示', '没有找到pdf文件', [{ text: '确定' }], { cancelable: false });
            return;
        }

        // 开始记录学时
        if (this.learn) SeaStudyTimeUtil.startTimer(this.payload);
        // 如果只有一张图，则上报完成
        if (this.images.length == 1) this._reportFinish();
    };

    /**
     * @private
     * @description 结束学习
     */
    _stopLearning = () => {
        SeaStudyTimeUtil.stopTimer();
    };

    /**
     * @private
     * @description 上报学习完成
     */
    _reportFinish = () => {
        if (!this.learn || this.payload.played) return;
        if (this.payload.type && this.payload.type == SeaConstant.ResourceType.READER) {
            CourseExtension.updateFinishState({
                id: this.payload.resourceId,
                type: this.payload.type,
            });
        } else {
            CourseExtension.updateFinishState({ id: this.payload.curriculaContentSnapshotId });
        }
    };
    /**
     * @private
     * @description 上报学习进度
     */
    _reportProgress = index => {
        if (!this.learn) return;
        if (this.payload.type && this.payload.type == SeaConstant.ResourceType.READER) {
            console.log('阅读进度统计');
            const payload = SeaPlayProgressUtil.payload(
                index + 1,
                this.images.length,
                this.payload.contentId,
                this.payload.snapshotId
            );
            SeaPlayProgressUtil.collect(payload);
        } else {
            const payload = SeaPlayProgressUtil.payload(
                index + 1,
                this.images.length,
                this.payload.contentId,
                this.payload.snapshotId
            );
            SeaPlayProgressUtil.collect(payload);
        }
    };
}
