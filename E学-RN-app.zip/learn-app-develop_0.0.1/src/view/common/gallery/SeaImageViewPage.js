/**
 * @author xukj
 * @date 2019/05/10
 * @class
 * @description 图片浏览器
 * @deprecated 1.32.0 替换为 @class SeaImageGalleryControl
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';
import { SeaImageGallery, SeaNavigator } from '../../../components';

export default class SeaImageViewPage extends React.PureComponent {
    static propTypes = {
        images: PropTypes.array.isRequired,
    };

    static defaultProps = {
        images: [],
    };

    constructor(props) {
        super(props);
        this.state = { index: 0 };
    }

    componentDidMount() {}

    render() {
        const { images } = this.props;
        const { index } = this.state;
        return (
            <View style={{ flex: 1 }}>
                <SeaImageGallery
                    imageUrls={images}
                    onIndexChanged={this._onIndexChanged}
                />
                <SeaNavigator
                    style={styles.navigator}
                    closeMode
                    title={`${index + 1}/${images.length}`}
                />
            </View>
        );
    }

    _onIndexChanged = index => {
        this.setState({ index });
    };
}

const styles = StyleSheet.create({
    navigator: {
        backgroundColor: 'transparent',
        position: 'absolute',
        top: 0,
        left: 0,
        borderBottomWidth: 0,
    },
    navButtonStyle: {
        backgroundColor: 'rgba(1, 1, 1, 0.5)',
        borderRadius: 17,
        width: 34,
        height: 34,
        overflow: 'hidden',
        marginLeft: 5,
        marginRight: 5,
    },
});
