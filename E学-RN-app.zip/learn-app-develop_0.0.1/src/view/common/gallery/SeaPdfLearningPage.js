/**
 * @author xukj
 * @date 2018/11/14
 * @class
 * @description 界面交互组件SeaImageGalleryPage
 * @deprecated 1.32.0 替换为 @class SeaPdfGalleryControl
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Alert } from 'react-native';
import {
    SeaImageGallery,
    SeaNavigator,
    SeaLoading,
    SeaNavigationItems as Items,
} from '../../../components';
import Orientation from 'react-native-orientation-locker';
import { SeaDevice, SeaImageUtil } from '../../../util';
import { SeaScale, SeaConstant } from '../../../asserts';
import { Actions } from 'react-native-router-flux';
import { CommonService } from '../../../servie';
import { AC_UpdateFinishStatus } from '../../../redux/actions/course';
import { SeaStudyTimeUtil } from '../../../util';
import { connect } from 'react-redux';

@connect(
    null,
    mapDispatchToProps
)
export default class SeaPdfLearningPage extends React.PureComponent {
    static propTypes = {
        // { isCrosswise: 横竖屏, fileId: pdf文件, played: 是否已完成学习, type: 资源类型, resourceId: 资源id, curriculaContentSnapshotId: 课件id, ...其他参考统计学习时长}
        payload: PropTypes.any, // 供统计学时用，数据结构参见以前的界面
        learn: PropTypes.bool, // 是否学习，如果true则需要统计学时和上报完成
    };

    static defaultProps = {
        learn: true,
    };

    constructor(props) {
        super(props);
        this.state = {
            index: 0,
            images: [],
            loading: false,
        };
        this._configInit(props);
    }

    componentDidMount() {
        this._configOrientation();
        this._loadImages();
    }

    componentWillUnmount() {
        this._stopLearning();
    }

    render() {
        const { index, images, loading } = this.state;
        if (loading) {
            const renderLeftButton = () =>
                Items.renderSeaIconButton(this._close, 'back', 'white', 26, styles.navButtonStyle);
            return (
                <View style={{ flex: 1 }}>
                    <SeaLoading />
                    <SeaNavigator
                        style={styles.navigator}
                        landscape={this.landscape}
                        renderBackButton={renderLeftButton}
                    />
                </View>
            );
        } else {
            return (
                <View style={{ flex: 1 }}>
                    <SeaImageGallery
                        {...this.size}
                        imageUrls={images}
                        onIndexChanged={this._onIndexChanged}
                    />
                    <SeaNavigator
                        style={[styles.navigator]}
                        landscape={this.landscape}
                        backMode={true}
                        onBackPress={this._close}
                        title={`${index + 1}/${images.length}`}
                    />
                </View>
            );
        }
    }

    /**
     * @private
     * @description 初始化需要的数据 landscape fileId
     */
    _configInit = props => {
        // 1.是否横竖屏
        this.landscape = _.get(props, 'payload.isCrosswise') == '1';
        // 2.pdf文件id
        this.fileId = _.get(props, 'payload.fileId');
        // 3.优先计算屏幕，降低渲染时的运算
        const statusBarHeight = SeaDevice.androidStatusBarHeight();
        this.size = this.landscape
            ? { width: SeaScale.longSide, height: SeaScale.shortSide - statusBarHeight }
            : { width: SeaScale.shortSide, height: SeaScale.longSide - statusBarHeight };
    };

    _configOrientation = () => {
        if (this.landscape) Orientation.lockToLandscape();
    };

    _recoveryOrientation = () => {
        Orientation.lockToPortrait();
    };

    _onIndexChanged = index => {
        const { images } = this.state;
        if (index >= images.length - 1) this._reportFinish();
        this.setState({ index });
    };

    /**
     * @private
     * @description 开始学习
     */
    _startLearning = images => {
        // 没有数据
        if (!images || images.length <= 0) {
            Alert.alert('提示', '没有找到pdf文件', [{ text: '确定', onPress: this._close }], {
                cancelable: false,
            });
            return;
        }
        const { payload, learn } = this.props;
        // 开始记录学时
        if (learn) SeaStudyTimeUtil.startTimer(payload);
        // 如果只有一张图，则上报完成
        if (images && images.length == 1) this._reportFinish();
        this.setState({
            images: images,
            loading: false,
        });
    };

    /**
     * @private
     * @description 结束学习
     */
    _stopLearning = () => {
        this._recoveryOrientation();
        SeaStudyTimeUtil.stopTimer();
    };

    /**
     * @private
     * @description 关闭当前页
     */
    _close = () => Actions.pop();

    /**
     * @private
     * @description 获取pdf图片
     */
    _loadImages = () => {
        this.setState({ loading: true });
        CommonService.getImageIds(this.fileId)
            .then(responseJson => {
                // 转换为可以识别的结构
                // modify by xukj 1.28.0
                // 增加水印标识
                const imageIds = responseJson.ids;
                const mark = responseJson.hasWatermark;
                const images = (imageIds ? imageIds : []).map(value => ({
                    url: SeaImageUtil.getPdfImageUri(value, mark),
                }));
                this._startLearning(images);
            })
            .catch(error => {
                Alert.alert('提示', error.message, [{ text: '确定', onPress: this._close }], {
                    cancelable: false,
                });
            });
    };

    /**
     * @private
     * @description 上报学习完成
     */
    _reportFinish = () => {
        const { payload, updateFinish, learn } = this.props;
        if (!learn || payload.played) return;

        if (payload.type && payload.type == SeaConstant.ResourceType.READER) {
            updateFinish({
                id: payload.resourceId,
                type: payload.type,
            });
        } else {
            updateFinish({
                id: payload.curriculaContentSnapshotId,
            });
        }
    };

    _testLoader = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(testImages);
        }, 3000);
    });
}

const styles = StyleSheet.create({
    navigator: {
        backgroundColor: 'transparent',
        position: 'absolute',
        top: 0,
        left: 0,
        borderBottomWidth: 0,
    },
    navButtonStyle: {
        backgroundColor: 'rgba(1, 1, 1, 0.5)',
        borderRadius: 17,
        width: 34,
        height: 34,
        overflow: 'hidden',
        marginLeft: 5,
        marginRight: 5,
    },
    loading: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
});

function mapDispatchToProps(dispatch) {
    return {
        updateFinish: payload => dispatch(AC_UpdateFinishStatus(payload)),
    };
}

const testImages = [
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f48ef7f.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f568ffd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f664d07.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f767d21.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f875a55.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4f97cf86.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4fb033e9.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4fc0d5b7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4fd1717b.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f4fe20fc1.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d57073db2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d5719e2f7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d572ac4bd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d573bc645.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d574c42d1.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d575c7b30.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d576e339c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3d577a1119.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b71302618efd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b71302796441.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b713028ada6f.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b713029a1bdd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b71302aa51fd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b71302d770e5.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-13/5b71302fd389d.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1ab14685.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1adf3564.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1b0857dc.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1b3cdc05.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1b7569c7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1bbc930d.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1c0ee376.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1c548747.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1ca9e439.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-08/5be3f1e767a8e.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be12993cd4d2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be129948ac37.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be129952f736.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be12995dacaa.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be1299689267.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be129979dc9b.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be1299880e2a.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be1299951504.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be1299a03202.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-06/5be1299aadc09.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631672ee7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/57996317b3a92.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/579963194649c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631a9509c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631c093cd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631d86b34.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631eb5f04.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799631fd48cd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799632161168.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/57996322d1968.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/579963247d66c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/57996327867ca.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/57996328d3eca.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799632a562e6.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799632be95ce.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2/5799632d1de47.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b86452ed87e1.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b86452fe8ff9.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b864530932a7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b8645313fd74.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b864531ea20c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b86453298652.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b864533509d7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b86453403db4.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b864534aea13.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b86453560fd8.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-08-29/5b8645360e3a1.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea194f7a.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea2c441e.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea3deaf2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea4c2fc2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea5d7b9e.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea6dfd48.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-02/5bb2eea814bfd.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c412ad20d.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c41586076.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c418670e3.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c41c15f3f.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c4202404c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c422e366f.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c4285148c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c42a1fbff.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-22/5b03c42c4c057.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c45603c29.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c45b403c3.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c46136676.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c46638172.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c46a194b6.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-12-25/5a40c46eaa167.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d00ae29d.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d049ec27.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d0718a7f.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d09b135d.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d0b443cc.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d0c89c8c.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d0ec3637.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2017-11-21/5a140d11484a6.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a4fb12d5.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a520fbf9.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a540aa29.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a56122a4.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a58411a2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a5adc5fe.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a5cc5a79.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a5f05b6a.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-05-17/5afd4a6134898.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be013137ad38.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be01314413ee.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be01314ec038.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be01315ac420.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be0131667634.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be0131725f51.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be013186aee3.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-11-05/5be013192d5a5.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd963491e664.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd96349b52d7.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd9634a71089.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd9634b237d2.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd9634bd38bc.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd9634c8c07a.jpg' },
    { url: 'http://pic1.win4000.com/wallpaper/2018-10-31/5bd9634d3f135.jpg' },
];
