/**
 * @author xukj
 * @date 2019/09/04
 * @class
 * @description 可见性列表
 */
import React from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaExpandableList, SeaExpandNode } from '../../../components/index.js';
import { ApproveService } from '../../../servie/index.js';
import { SeaStyle } from '../../../asserts/index.js';

export default class SeaVisibilityListPage extends React.PureComponent {
    static propTypes = {
        resourceId: PropTypes.string,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = { list: [] };
        this._loadingKey;
    }

    componentDidMount() {
        this._loadList();
    }

    render() {
        return _.isEmpty(this.state.list) ? (
            <View style={SeaStyle.page} />
        ) : (
            <SeaExpandableList defaultData={this.state.list} />
        );
    }

    _loadList = async () => {
        try {
            this._loadingKey = FSLPrompt.loading('加载中');
            // 获取列表数据
            const source = await ApproveService.getResourceVisibleList(this.props.resourceId);
            FSLPrompt.hide(this._loadingKey);
            if (source.code === '000000') {
                // 组装数据
                const result = await this._prepareData(source.data);
                this.setState({ list: result });
            } else {
                FSLToast.show(source.msg);
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };

    /**
     * @private
     * @description 准备数据
     */
    _prepareData = (source) => {
        return new Promise((resolve, reject) => {
            const list = _.map(source, (value) => {
                return this._createNode(value, null, 0);
            });
            resolve(list);
        });
    };

    /**
     * @private
     * @description 生成节点数据
     * @return {SeaExpandNode}
     */
    _createNode = (nodeValue, parentId, level) => {
        const currentNodeId = nodeValue.id;
        const subNodes = _.chain(nodeValue)
            .get('children', [])
            .map((subValue) => this._createNode(subValue, nodeValue.id, level + 1))
            .value();
        return new SeaExpandNode(
            currentNodeId,
            parentId,
            subNodes,
            level,
            nodeValue,
            nodeValue.name
        );
    };
}
