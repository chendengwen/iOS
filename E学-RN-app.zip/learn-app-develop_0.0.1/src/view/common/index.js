/**
 * @author xukj
 * @date 2018/11/14
 * @description index 通用界面
 */
export { default as QRCodeScanPage } from './scan/QRCodeScanPage';
export { default as QRCodeInputPage } from './scan/QRCodeInputPage';
export { default as SeaWebPage } from './web/SeaWebPage';

// modify by xukj - 1.32.0
// 替换图片浏览组件
export { default as SeaImageGalleryControl } from './gallery/SeaImageGalleryControl';
export { default as SeaPdfGalleryControl } from './gallery/SeaPdfGalleryControl';
export { default as SeaPdfGalleryPage } from './gallery/SeaPdfGalleryPage';

// add by xukj - 1.36.0
export { default as SeaVisibilityListPage } from './visibility-list/SeaVisibilityListPage';
// add by xukj - 1.39.0
export { default as SeaVideoPlayer } from './media/SeaVideoPlayer';
export { default as SeaAudioPlayer } from './media/SeaAudioPlayer';
export { default as SeaMediaTestPage } from './media/SeaMediaTestPage';
