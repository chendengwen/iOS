/**
 * @author xukj
 * @date 2018/10/17
 * @class
 * @description QRScanReadPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Text, Alert, StyleSheet } from 'react-native';
import QRCodeScanner from './QRCodeScanner';
import { SeaNavigator, SeaButton } from '../../../components';
import { Actions, ActionConst } from 'react-native-router-flux';
import { SeaQRCode, ResourceActions } from '../../resource';
import { SeaIcon, SeaScale, SeaTheme } from '../../../asserts';
import ImagePicker from 'react-native-image-crop-picker';
import { getQRCodeFromFile } from 'react-native-smart-barcode';
import moment from 'moment';
import { IdentifyExtension } from '../../../redux';
import { TrainingService } from '../../../servie';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';

export default class QRScanReadPage extends React.PureComponent {
    static propTypes = {
        title: PropTypes.string,
        custom: PropTypes.any, // 自定义扩展
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() { }

    render() {
        const { title } = this.props;
        return (
            <View style={styles.page}>
                <SeaNavigator
                    style={styles.navigator}
                    title={title}
                    rightText="相册"
                    onRightPress={this._chooseQRImage}
                />
                <QRCodeScanner
                    ref={comp => (this._scanner = comp)}
                    style={{ flex: 1 }}
                    onQRCodeRead={this._onQRCodeRead}
                />
                <View style={styles.panel}>
                    <SeaButton style={styles.item} onPress={this._onInputPress}>
                        <View style={styles.itemIconContainer}>
                            <SeaIcon name="qaInput" color="white" size={40} />
                        </View>
                        <Text style={styles.itemTitle}>输入编号完成扫描</Text>
                    </SeaButton>
                </View>
            </View>
        );
    }

    _chooseQRImage = () => {
        this._scanner.stopScan();
        ImagePicker.openPicker({ width: 400, height: 400, cropping: false }).then(image => {
            getQRCodeFromFile(
                image.path,
                error => {
                    Alert.alert(
                        '提示',
                        error.message,
                        [{ text: '确定', onPress: this._scanner.startScan }],
                        { cancelable: false }
                    );
                },
                result => {
                    this._onQRCodeRead(result, code => {
                        if (code && code.isSignQR())
                            throw new Error('对不起，请通过扫描二维码完成签到');
                    });
                }
            );
        });
    };

    // 扫描结果
    _onQRCodeRead = (result, onParsed) => {
        console.log('_onQRCodeRead result=' + (result));
        let jsonstring = decodeURI(result);
        console.log('jsonstring result= ' + jsonstring);
        try {
            this._scanner.stopScan();
            // 解析扫描数据
            var seaQRCode = new SeaQRCode();
            const code = JSON.parse(jsonstring);
            console.log('result= code' + JSON.stringify(code));
            // 签到修改为弹窗，其他照旧
            if (code && code.code && code.code == 'sign') {
                this._loadInfo(code.data.resourceId, code.data.code)
            } else {
                console.log('result= code' + 222);
                // 解析扫描数据
                const resultValue = seaQRCode.parse(result);
                // 处理特殊逻辑
                if (onParsed) onParsed(resultValue);
                // 添加扩展信息
                if (this.props.custom) resultValue.append({ custom: this.props.custom });
                // 执行跳转逻辑
                ResourceActions.qr(resultValue);
            }

        } catch (e) {
            Alert.alert('提示', e.message, [{ text: '确定', onPress: this._scanner.startScan }], {
                cancelable: false,
            });
        }
    };

    _loadInfo = async (resourceId, signCode) => {
        this._loadingKey = FSLPrompt.loading('loading...');
        try {
            let userinfo = IdentifyExtension.getLoginUserInfo();
            this.userId = userinfo.id;
            this.userName = userinfo.userName;
            this.departmentName = userinfo.departmentName;
            this.phone = userinfo.phone;
            const resultInfo = await TrainingService.getTraclassDetail(resourceId);
            FSLPrompt.hide(this._loadingKey);
            if (resultInfo.code == '000000') {
                Alert.alert(
                    '培训信息：',
                    '培训名称：' + resultInfo.data.trainingDetail.resourceName + '\n' +
                    '开班开始时间：' + moment(resultInfo.data.trainingDetail.startTime).format('YYYY-MM-DD HH:mm') + '\n' +
                    '开班结束时间：' + moment(resultInfo.data.trainingDetail.endTime).format('YYYY-MM-DD HH:mm') + '\n' +
                    '内容介绍：' + resultInfo.data.trainingDetail.summary + '\n' +
                    (resultInfo.data.trainingDetail.address ? '开班地址:' + (resultInfo.data.trainingDetail.address) + '\n\n' : '' + '\n') +

                    '报名人基本信息：' + '\n' +
                    '姓名：' + this.userName + '\n' +
                    '所属部门：' + this.departmentName + '\n' +
                    '手机号：' + this.phone,
                    [{ text: '签到', onPress: () => { this._toSign(signCode) } }],    // Actions.pop
                    { cancelable: false }
                )
            } else {
                FSLToast.show(resultInfo.msg)
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
        }



    }
    _toSign = (signCode) => {
        TrainingService.assignResourceWithCode(signCode)
            .then(this._success)
            .catch(this._fail);

    }
    _success = response => {
        if (response.code == '000000') {
            Alert.alert(
                '提示',
                '签到成功',
                [{ text: '确定', onPress: Actions.pop }],
                { cancelable: false }
            );
        } else {
            FSLToast.show(response.msg);
            Actions.pop();
        }

    };
    _fail = error => {
        let message = error.message ? error.message : '系统异常,请稍后尝试';
        Alert.alert('提示', message, [{ text: '确定', onPress: Actions.pop }], {
            cancelable: false,
        });
    };
    // 输入数字
    _onInputPress = () => {
        this._scanner.stopScan();
        Actions.show('qrCodeInput', { type: ActionConst.REPLACE, custom: this.props.custom });
    };
}

const styles = StyleSheet.create({
    page: {
        width: SeaScale.screenWidth,
        flex: 1,
        backgroundColor: 'black',
        justifyContent: 'space-between',
    },
    navigator: {
        backgroundColor: 'black',
        borderBottomWidth: 0,
    },
    panel: {
        marginBottom: 0,
        height: SeaScale.Layout(240),
        backgroundColor: 'black',
        justifyContent: 'center',
        alignItems: 'center',
    },
    item: {
        width: SeaScale.Layout(240),
        height: SeaScale.Layout(140),
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    itemIconContainer: {
        width: SeaScale.Layout(100),
        height: SeaScale.Layout(100),
        justifyContent: 'center',
        alignItems: 'center',
    },
    itemTitle: {
        fontSize: SeaTheme.font_size_md,
        color: 'white',
    },
});
