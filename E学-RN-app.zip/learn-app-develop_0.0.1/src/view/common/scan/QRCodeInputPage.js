/**
 * @author
 * @date
 * @class
 * @description 交互界面 QRCodeInputPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Keyboard } from 'react-native';
import QRCodeInput from './QRCodeInput';
import { SeaQRCode, ResourceActions } from '../../resource';
import { SeaStyle } from '../../../asserts';

export default class QRCodeInputPage extends React.PureComponent {
    static propTypes = {
        custom: PropTypes.any, // 自定义扩展
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <View style={SeaStyle.page}>
                <QRCodeInput style={styles.input} onSubmitPress={this._onSubmitPress} />
            </View>
        );
    }

    _onSubmitPress = codes => {
        Keyboard.dismiss();
        const qrcode = new SeaQRCode().signByCode(codes);
        // 添加扩展信息
        if (this.props.custom) qrcode.append({ custom: this.props.custom });
        ResourceActions.qr(qrcode);
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
    },
    navigator: {
        backgroundColor: 'black',
    },
    input: {
        flex: 1,
    },
});
