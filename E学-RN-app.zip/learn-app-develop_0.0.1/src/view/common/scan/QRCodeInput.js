/**
 * @author xukj
 * @date 2018/10/17
 * @class
 * @description QRCodeInput
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet, Text, Platform } from 'react-native';
import { FSLNumberInput } from 'react-native-kpframework';
import { SeaScale, SeaColor } from '../../../asserts';
import { SeaTextButton } from '../../../components';

export default class QRCodeInput extends React.PureComponent {
    static propTypes = {
        onSubmitPress: PropTypes.func,
    };

    static defaultProps = {
        onSubmitPress: codes => {},
    };

    constructor(props) {
        super(props);
        this.state = {
            codes: '',
        };
        // 定义的编号位数
        this.codeNumber = 6;
    }

    componentDidMount() {}

    render() {
        const { onSubmitPress } = this.props;
        const isValide = this.state.codes.length >= this.codeNumber;
        return (
            <View style={styles.page}>
                <Text style={styles.title}>请输入6位编码</Text>
                <FSLNumberInput
                    style={styles.input}
                    number={this.codeNumber}
                    cellHeight={50}
                    space={15}
                    cellWidth={40}
                    onChangeText={this._onChangeText}
                    onSubmitEditing={this._onSubmitEditing}
                    normalCellStyle={styles.inputNormalCellStyle}
                    highlightCellStyle={styles.inputHighlightCellStyle}
                    keyboardType={Platform.OS == 'ios' ? 'numbers-and-punctuation' : 'numeric'}
                />
                <SeaTextButton
                    round
                    style={styles.submit}
                    titleStyle={{ fontSize: 16 }}
                    title="提交"
                    disabled={!isValide}
                    theme={isValide ? 'main' : 'disable'}
                    onPress={() => onSubmitPress(this.state.codes)}
                />
            </View>
        );
    }

    _onChangeText = text => {
        this.setState({
            codes: text,
        });
    };

    _onSubmitEditing = event => {};

    _buttonProps = codes => {
        if (codes.length >= this.codeNumber) {
            return {
                disabled: false,
                theme: 'main',
                title: '提交',
            };
        } else {
            return {
                disabled: true,
            };
        }
    };
}

const styles = StyleSheet.create({
    page: {
        flex: 1,
        alignItems: 'center',
    },
    title: {
        marginTop: 70,
        fontSize: 15,
    },
    input: {
        marginTop: 50,
    },
    inputTitleStyle: {},
    inputNormalCellStyle: {
        borderRadius: 2,
        borderWidth: 1,
        borderColor: SeaColor.parting_line,
    },
    inputHighlightCellStyle: {
        borderRadius: 2,
        borderWidth: 1,
        borderColor: SeaColor.main,
    },
    submit: {
        width: SeaScale.screenWidth - 70 * 2,
        height: 44,
        marginTop: 50,
    },
});
