/**
 * @author xukj
 * @date 2018/10/17
 * @class
 * @description QRCodeScanner 二维码扫描组件
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Alert } from 'react-native';
import BarcodeView from 'react-native-smart-barcode';
import { Actions } from 'react-native-router-flux';
import TimerEnhance from 'react-native-smart-timer-enhance';

class QRCodeScanner extends React.PureComponent {

    static propTypes = {
        onQRCodeRead: PropTypes.func,
    };

    static defaultProps = {
        onQRCodeRead: (result) => { },
    };

    /**
     * @description 开启扫描
     */
    startScan = () => {
        this._barCode.startScan();
    };

    /**
     * @description 关闭扫描
     */
    stopScan = () => {
        this._barCode.stopScan();
    };

    //构造方法
    constructor(props) {
        super(props);
        this.state = {
            viewAppear: false,
        };
    }

    componentDidMount() {
        //启动定时器
        this.timer = setTimeout(
            () => this.setState({ viewAppear: true }),
            250
        );
    }

    //组件销毁生命周期
    componentWillUnmount() {
        //清楚定时器
        this.timer && clearTimeout(this.timer);
    }

    render() {
        if (this.state.viewAppear) {
            return (
                <BarcodeView
                    style={{ flex: 1 }}
                    ref={component => this._barCode = component}
                    onBarCodeRead={this._onBarCodeRead(this.props.onQRCodeRead)}
                    onAuthorized={this._onAuthorized}
                    scannerLineInterval={2000}
                />
            );
        }
        else {
            return null;
        }
    }

    _onBarCodeRead = (onQRCodeRead) => (e) => {
        console.log(`e.nativeEvent.data.type = ${e.nativeEvent.data.type}, e.nativeEvent.data.code = ${e.nativeEvent.data.code}`);
        onQRCodeRead(e.nativeEvent.data.code);
    };

    _onAuthorized = (result) => {
        if (!result) {
            Alert.alert('提示', '没有相机权限~', [{ text: '确定', onPress: () => Actions.pop() }], { cancelable: false });
        }
    };
}

export default TimerEnhance(QRCodeScanner);