/**
 * @author xukj
 * @date 2019/11/13
 * @class
 * @description 视频全屏播放器
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, ActivityIndicator, TouchableOpacity, Animated } from 'react-native';
import Video from 'react-native-video';
import _ from 'lodash';
import MediaControls from './MediaControls';
import Orientation from 'react-native-orientation-locker';

export default class VideoPlayerFull extends React.PureComponent {
    static propTypes = {
        source: PropTypes.any,
        defaultTime: PropTypes.number, // 默认播放时间
        defaultPlay: PropTypes.bool, // 是否播放
        onFullscreenDismissPress: PropTypes.func, // 关闭全屏
        onLoadStart: PropTypes.func,
        onLoad: PropTypes.func,
        onProgress: PropTypes.func,
        onEnd: PropTypes.func,
        onSeek: PropTypes.func,
        onError: PropTypes.func,
    };

    static defaultProps = {};

    // public
    // ---
    play = () => this._play();

    pause = () => this._pause();

    seek = seconds => this._seek(seconds);

    // private
    // --
    constructor(props) {
        super(props);
        this.state = {
            playing: false, // 视频是否正在播放
            currentTime: 0, // 视频当前播放的时间
            duration: 0, // 视频的总时长
            loading: true,
            buffering: false,
            showControls: true, // 显示控制器
            fadeAnim: new Animated.Value(1),
        };
        this.videoPlayer = null;
        // 因为这里有bug过于频繁的seek会导致内存暴涨，需要限流
        this.seekThrottle = _.throttle(
            seconds => this.videoPlayer && this.videoPlayer.seek(seconds),
            200,
            { trailing: true }
        );
        // 控制器timer
        this.controlTimer = null;
        this.controlAnimate = null;
        // 缓冲判断, 因为android缓冲时不会调用onBuffer, 需要通过当前播放时间变动频率来判断
        this.sameProgressCount = 0; // 相同的进度出现次数
        this.latestProgress = 0; // 上一次的进度
    }

    componentDidMount() {
        Orientation.unlockAllOrientations();
    }

    componentWillUnmount() {
        this.seekThrottle && this.seekThrottle.cancel();
        this.controlTimer && clearTimeout(this.controlTimer);
        this.controlAnimate && this.controlAnimate.stop();
        Orientation.lockToPortrait();
    }

    render() {
        const { children, source } = this.props;
        const { playing, loading, buffering, currentTime, duration, fadeAnim } = this.state;
        return (
            <View style={StyleSheet.absoluteFill} onLayout={this._onLayout}>
                <Video
                    // repeat
                    source={source}
                    // controls
                    ref={_comp => (this.videoPlayer = _comp)}
                    style={[StyleSheet.absoluteFill, { backgroundColor: 'black' }]}
                    paused={!playing}
                    onLoad={this._onLoad}
                    onLoadStart={this._onLoadStart}
                    onProgress={this._onProgress}
                    onSeek={this._onSeek}
                    onEnd={this._onEnd}
                    onError={this._onError}
                    onBuffer={this._onBuffer}
                    progressUpdateInterval={500}
                    resizeMode="contain"
                />
                {(loading || buffering) && <this._loadingView />}
                <TouchableOpacity
                    style={StyleSheet.absoluteFill}
                    activeOpacity={1}
                    onPress={this._onPlayerTouch}
                >
                    <MediaControls
                        translucent
                        fullscreen
                        style={{ opacity: fadeAnim }}
                        playing={playing}
                        currentTime={currentTime}
                        duration={duration}
                        loading={loading}
                        onPlayOrPausePress={this._onPlayOrPausePress}
                        onFullscreenPress={this._onFullScreenPress}
                        onSeek={this._onSliderValueChanged}
                    />
                </TouchableOpacity>
                {children}
            </View>
        );
    }

    // component
    // ---
    _loadingView = props => {
        return (
            <View
                style={[
                    StyleSheet.absoluteFill,
                    { alignItems: 'center', justifyContent: 'center' },
                ]}
            >
                <ActivityIndicator animating size="large" color="white" />
            </View>
        );
    };

    // video event
    // ---
    _onLoadStart = payload => {
        // console.log('onLoadStart', payload);
        this.setState({ loading: true });
        this.props.onLoadStart && this.props.onLoadStart(payload);
    };

    _onLoad = payload => {
        // console.log('onLoad', payload);
        this.setState({ loading: false, duration: payload.duration });
        let seekTime = this.props.defaultTime;
        if (seekTime > 0 && seekTime < payload.duration) {
            this._seek(seekTime, true);
        }

        this.setState({ playing: true });
        this.props.onLoad && this.props.onLoad(payload);
    };

    _onError = error => {
        // console.log('onError', error);
        this.setState({ error, loading: false, buffering: false });
        this.props.onError && this.props.onError(error);
    };

    _onProgress = payload => {
        // console.log('onProgress', payload);
        this.setState({ currentTime: payload.currentTime, loading: false });
        this._showBufferingOrNot(payload.currentTime);
        this.props.onProgress && this.props.onProgress(payload);
    };

    _onBuffer = payload => {
        // console.log('onBuffer', payload);
        this.setState({ buffering: true });
        this.props.onBuffer && this.props.onBuffer(payload);
    };

    _onEnd = payload => {
        // console.log('onEnd', payload);
        this._stop();
        // 关闭全屏页
        this._onFullScreenPress();
        this.props.onEnd && this.props.onEnd(payload);
    };

    _onSeek = payload => {
        // console.log('onSeek', payload);
        this.props.onSeek && this.props.onSeek(payload);
    };

    _onLayout = e => {
        // console.log('layout', e.nativeEvent);
    };

    // controls event
    // ---
    _onSliderValueChanged = currentTime => {
        this._seek(currentTime);
    };

    _onFullScreenPress = () => {
        const payload = _.clone(this.state);
        this.props.onFullscreenDismissPress && this.props.onFullscreenDismissPress(payload);
    };

    _onPlayOrPausePress = () => {
        if (this.state.playing) {
            this._pause();
        } else {
            this._play();
        }
    };

    _onPlayerTouch = () => {
        const { showControls, playing } = this.state;
        this._stopAutoHideControls();
        if (showControls) {
            this._hideControls(true);
            return;
        }

        this._showControls(true);
        if (playing) {
            this._startAutoHideControls();
        }
    };

    // util
    // ---
    _showBufferingOrNot = progress => {
        if (this.latestProgress != progress) {
            // 正常播放
            this.setState({ buffering: false });
            this.latestProgress = progress;
            this.sameProgressCount = 0;
            return;
        }

        this.sameProgressCount++;

        // 如果多次没有更新进度，则标注在缓冲中
        if (this.sameProgressCount >= 2) {
            this.setState({ buffering: true });
        }
    };

    // other func
    // ---
    _play = () => {
        this.setState({ playing: true });
        this._stopAutoHideControls();
        this._startAutoHideControls();
    };

    _pause = () => {
        this.setState({ playing: false });
        this._stopAutoHideControls();
        this._showControls(true);
    };

    _stop = () => {
        this.setState({ playing: false });
        this._seek(0, true);
        this._stopAutoHideControls();
        this._showControls(true);
    };

    _seek = (second, immediate) => {
        this.setState({ currentTime: second });
        // 限流防止频繁seek导致崩溃
        if (immediate) {
            this.videoPlayer && this.videoPlayer.seek(second);
        } else {
            this.seekThrottle && this.seekThrottle(second);
        }
    };

    _startAutoHideControls = () => {
        this.controlTimer = setTimeout(() => this._hideControls(true), 10000);
    };

    _stopAutoHideControls = () => {
        this.controlTimer && clearTimeout(this.controlTimer);
    };

    _showControls = anim => {
        if (this.controlAnimate) {
            this.controlAnimate = null;
        }

        if (anim) {
            this.controlAnimate = Animated.timing(this.state.fadeAnim, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
            }).start(() => this.setState({ showControls: true }));
        } else {
            this.setState({ showControls: true });
        }
    };

    _hideControls = anim => {
        if (this.controlAnimate) {
            this.controlAnimate = null;
        }

        if (anim) {
            this.controlAnimate = Animated.timing(this.state.fadeAnim, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
            }).start(() => this.setState({ showControls: false }));
        } else {
            this.setState({ showControls: false });
        }
    };
}
