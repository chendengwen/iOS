/**
 * @author xukj
 * @date 2019/11/14
 * @class
 * @description 界面交互组件SeaMediaTestPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    TouchableWithoutFeedback,
    StyleSheet,
    Dimensions,
    TouchableOpacity,
} from 'react-native';
import { SeaTextButton } from '../../../components';
import { SeaScale } from '../../../asserts';
import SeaVideoPlayer from './SeaVideoPlayer';
import SeaAudioPlayer from './SeaAudioPlayer';

export default class SeaMediaTestPage extends React.PureComponent {
    static propTypes = {};

    static defaultProps = {};

    constructor(props) {
        super(props);
        this.state = {
            // video: require('../../../asserts/media/video.mp4'),
            // video: {
            //     uri:
            //         'https://lec-study-uat.foresealife.com:446/resource/api/resource/file/10c4380d-4965-4d02-8508-6c6435220ea3',
            // },
            video: {
                uri:
                    'https://lec-resource-prod.foresealife.com:443/resource/api/resource/file/b06bed54-e394-4569-b8ac-f5724a7bdb51',
            },
            // audio: require('../../../asserts/media/audio.m4a'),
            // audio: {
            //     uri:
            //         'http://m10.music.126.net/20191202105445/4fae1aa6a8b518f785b2b710442def03/ymusic/0553/0652/005b/29b81b9fcc18b7f2482f710c4399da0c.mp3',
            // },
            // audio: {
            //     uri:
            //         'http://10.60.222.21:8080/resource/api/resource/file/9e980f28-6478-44c0-914f-4ecdc15977f2',
            // },
            // source: require('../../asserts/audio.m4a'),
            // source: {
            //     uri:
            //         'https://lec-resource-prod.foresealife.com:443/resource/api/resource/file/1a82fa49-c13b-4a87-8bc5-4d471070edfa',
            // },
            // videoCover:
            //     'http://124.129.157.208:8889/data/uploads/kecheng/2018/01/18/5a600b2c99836.png@0o_0l_220w.png',
            warning: true,
        };
    }

    componentDidMount() {}

    render() {
        return (
            <View style={{ flex: 1 }}>
                <SeaVideoPlayer
                    ref={_comp => (this.player = _comp)}
                    source={this.state.video}
                    onLoadStart={this._onLoadStart}
                    onLoad={this._onLoad}
                    onProgress={this._onProgress}
                    onEnd={this._onEnd}
                    navigation={this.props.navigation}
                />
                {/* <SeaAudioPlayer
                    // mini
                    ref={_comp => (this.player = _comp)}
                    source={this.state.audio}
                    onLoadStart={this._onLoadStart}
                    onLoad={this._onLoad}
                    onProgress={this._onProgress}
                    onEnd={this._onEnd}
                /> */}
            </View>
        );
    }

    _networkCover = props => {
        const { onOncePress, onAlwaysPress } = props;
        return (
            <View
                style={[
                    StyleSheet.absoluteFill,
                    {
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-around',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    },
                ]}
            >
                <SeaTextButton onPress={onOncePress} theme="custom" title="允许本次" />
                <SeaTextButton onPress={onAlwaysPress} theme="custom" title="始终允许" />
            </View>
        );
    };

    _onOncePress = () => {
        this.setState({ warning: false });
        this.player && this.player.play();
    };

    _onAlwaysPress = () => {
        this.setState({ warning: false });
        this.player && this.player.play();
    };

    _onLoadStart = payload => {};

    _onLoad = payload => {};

    _onProgress = payload => {};

    _onEnd = payload => {};
}
