/**
 * @author xukj
 * @date 2019/11/13
 * @class
 * @description 视频播放器
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
    StyleSheet,
    ViewPropTypes,
    View,
    Text,
    ActivityIndicator,
    TouchableOpacity,
    Animated,
    AppState,
} from 'react-native';
import Video from 'react-native-video';
import _ from 'lodash';
import MediaControls from './MediaControls';
import playerStyles from './playerStyles';

export default class VideoPlayer extends React.PureComponent {
    static propTypes = {
        style: ViewPropTypes.style,
        source: PropTypes.any,
        onLoadStart: PropTypes.func,
        onLoad: PropTypes.func,
        onReadyForDisplay: PropTypes.func,
        onProgress: PropTypes.func,
        onEnd: PropTypes.func,
        onSeek: PropTypes.func,
        onError: PropTypes.func,
        defaultTime: PropTypes.number, // 默认播放时间
        autoPlay: PropTypes.bool, // 加载完后自动播放
    };

    static defaultProps = {};

    // public
    // ---
    play = () => this._play();

    pause = () => this._pause();

    seek = second => this._seek(second);

    // private
    // --
    constructor(props) {
        super(props);
        this.state = {
            playing: false, // 视频是否正在播放
            currentTime: 0, // 视频当前播放的时间
            duration: 0, // 视频的总时长
            loading: true,
            fullscreen: false,
            inactive: false, // app是否未激活
            showControls: true, // 显示控制器
            fadeAnim: new Animated.Value(1),
        };
        this.videoPlayer = null;
        // Bugfix: 因为这里有bug过于频繁的seek会导致内存暴涨，需要限流
        this.seekThrottle = _.throttle(
            seconds => this.videoPlayer && this.videoPlayer.seek(seconds),
            200,
            { trailing: true }
        );
        // 控制器timer
        this.controlTimer = null;
        this.controlAnimate = null;
        // 状态控制
        this.appStateListener;
    }

    componentDidMount() {
        // Bugfix: 退到后台会自动播放, 需要处理
        AppState.addEventListener('change', this._onAppStateChanged);
    }

    componentWillUnmount() {
        this.seekThrottle && this.seekThrottle.cancel();
        this.controlTimer && clearTimeout(this.controlTimer);
        this.controlAnimate && this.controlAnimate.stop();
        AppState.removeEventListener('change', this._onAppStateChanged);
    }

    render() {
        const {
            style,
            children,
            onLoad,
            onLoadStart,
            onProgress,
            onReadyForDisplay,
            onSeek,
            onEnd,
            onError,
            ...restProps
        } = this.props;
        const { playing, loading, currentTime, duration, fadeAnim } = this.state;
        return (
            <View style={[playerStyles.normal, style && style]}>
                <Video
                    // controls
                    repeat
                    ref={_comp => (this.videoPlayer = _comp)}
                    style={[StyleSheet.absoluteFill, { backgroundColor: 'black' }]}
                    paused={!playing}
                    onLoad={this._onLoad}
                    onLoadStart={this._onLoadStart}
                    onReadyForDisplay={this._onReadyForDisplay}
                    onProgress={this._onProgress}
                    onSeek={this._onSeek}
                    onEnd={this._onEnd}
                    onError={this._onError}
                    onBuffer={this._onBuffer}
                    onFullscreenPlayerDidPresent={this._onFullScreenDidPresent}
                    onFullscreenPlayerDidDismiss={this._onFullscreenDidDismiss}
                    progressUpdateInterval={500}
                    resizeMode="contain"
                    {...restProps}
                />
                {loading && <this._loadingView />}
                <TouchableOpacity
                    style={StyleSheet.absoluteFill}
                    activeOpacity={1}
                    onPress={this._onPlayerTouch}
                >
                    <MediaControls
                        translucent
                        style={{ opacity: fadeAnim }}
                        playing={playing}
                        currentTime={currentTime}
                        duration={duration}
                        loading={loading}
                        onPlayOrPausePress={this._onPlayOrPausePress}
                        onFullscreenPress={this._onFullScreenPress}
                        onSeek={this._onSliderValueChanged}
                    />
                </TouchableOpacity>
                {children}
            </View>
        );
    }

    // component
    // ---
    _loadingView = props => {
        return (
            <View
                style={[
                    StyleSheet.absoluteFill,
                    { alignItems: 'center', justifyContent: 'center' },
                ]}
            >
                <ActivityIndicator animating size="large" color="white" />
            </View>
        );
    };

    // 出错或结束的cover界面
    // 带重新播放、错误提示功能
    _finishView = props => {
        return <View />;
    };

    _mediaCoverView = props => {};

    // video event
    // ---
    _onLoadStart = payload => {
        console.log('onLoadStart', payload);
        this.setState({ loading: true });
        this.props.onLoadStart && this.props.onLoadStart(payload);
    };

    _onLoad = payload => {
        // console.log('onLoad', payload);
        this.setState({ loading: false, duration: payload.duration });
        let seekTime = this.props.defaultTime;
        if (seekTime > 0 && seekTime < payload.duration) {
            this._seek(seekTime, true);
        }

        this.props.onLoad && this.props.onLoad(payload);
    };

    _onReadyForDisplay = payload => {
        this.props.autoPlay && this._play();
        this.props.onReadyForDisplay && this.props.onReadyForDisplay(payload);
    };

    _onError = error => {
        // console.log('onError', error);
        this.setState({ loading: false });
        this.props.onError && this.props.onError(error);
    };

    _onProgress = payload => {
        // console.log('onProgress', payload);
        this.setState(prevState => ({
            currentTime: payload.currentTime,
            loading: false,
            playing: prevState.inactive ? false : prevState.playing, // Bugfix: 解决iOS退到后台继续播放
        }));
        // this.setState({ currentTime: payload.currentTime, loading: false });
        this.props.onProgress && this.props.onProgress(payload);
    };

    _onBuffer = payload => {
        // console.log('onBuffer', payload);
        this.setState({ loading: payload.isBuffering });
    };

    _onEnd = payload => {
        this._stop();
        // Bugfix: 组件直接播放下一个会出现 onProgress无法回调，所以暂时只能先关闭全屏模式来修复
        if (this.state.fullscreen) {
            this.videoPlayer && this.videoPlayer.dismissFullscreenPlayer();
        }
        this.props.onEnd && this.props.onEnd(payload);
    };

    _onSeek = payload => {
        this.props.onSeek && this.props.onSeek(payload);
    };

    _onFullScreenDidPresent = () => {
        this.setState({ fullscreen: true });
    };

    _onFullscreenDidDismiss = () => {
        this.setState({ fullscreen: false });
        this._pause();
    };

    // controls event
    // ---
    _onSliderValueChanged = currentTime => {
        this._seek(currentTime);
    };

    _onFullScreenPress = () => {
        if (this.state.loading) return;
        this.videoPlayer && this.videoPlayer.presentFullscreenPlayer();
    };

    _onPlayOrPausePress = () => {
        if (this.state.loading) {
            // do nothing
        } else if (this.state.playing) {
            this._pause();
        } else {
            this._play();
        }
    };

    _onPlayerTouch = () => {
        const { showControls, playing } = this.state;
        this._stopAutoHideControls();
        if (showControls) {
            this._hideControls(true);
            return;
        }

        this._showControls(true);
        if (playing) {
            this._startAutoHideControls();
        }
    };

    // other func
    // ---
    _play = () => {
        this.setState({ playing: true });
        this._stopAutoHideControls();
        this._startAutoHideControls();
    };

    _pause = () => {
        this.setState({ playing: false });
        this._stopAutoHideControls();
        this._showControls(true);
    };

    _stop = () => {
        this.setState({ playing: false });
        this._seek(0, true);
        this._stopAutoHideControls();
        this._showControls(true);
    };

    _seek = (second, immediate) => {
        this.setState({ currentTime: second });
        // 限流防止频繁seek导致崩溃
        if (immediate) {
            this.videoPlayer && this.videoPlayer.seek(second);
        } else {
            this.seekThrottle && this.seekThrottle(second);
        }
    };

    _startAutoHideControls = () => {
        this.controlTimer = setTimeout(() => this._hideControls(true), 10000);
    };

    _stopAutoHideControls = () => {
        this.controlTimer && clearTimeout(this.controlTimer);
    };

    _showControls = anim => {
        if (this.controlAnimate) {
            this.controlAnimate = null;
        }

        if (anim) {
            this.controlAnimate = Animated.timing(this.state.fadeAnim, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
            }).start(() => this.setState({ showControls: true }));
        } else {
            this.setState({ showControls: true });
        }
    };

    _hideControls = anim => {
        if (this.controlAnimate) {
            this.controlAnimate = null;
        }

        if (anim) {
            this.controlAnimate = Animated.timing(this.state.fadeAnim, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
            }).start(() => this.setState({ showControls: false }));
        } else {
            this.setState({ showControls: false });
        }
    };

    _onAppStateChanged = appState => {
        switch (appState) {
            case 'active':
                this.setState({ inactive: false });
                break;
            case 'inactive':
            case 'background':
                this.setState({ inactive: true, playing: false });
                break;
            default:
                // do nothing
                break;
        }
    };
}
