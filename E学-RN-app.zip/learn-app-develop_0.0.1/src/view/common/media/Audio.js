/**
 * @author xukj
 * @date 2019/12/02
 * @class
 * @description 音频播放器
 * @deprecated 移动到 react-native-audio-streamer 中
 */
import React from 'react';
import PropTypes from 'prop-types';
import { DeviceEventEmitter, Platform } from 'react-native';
import AudioStreamer from 'react-native-audio-streamer';
const resolveAssetSource = require('react-native/Libraries/Image/resolveAssetSource');

const PLAY_STATUS = {
    PLAYING: 'PLAYING',
    PAUSED: 'PAUSED',
    STOPPED: 'STOPPED',
    FINISHED: 'FINISHED',
    BUFFERING: 'BUFFERING',
    ERROR: 'ERROR',
};

export { PLAY_STATUS };

export default class Audio extends React.PureComponent {
    static propTypes = {
        source: PropTypes.any, // 仅支持播放url地址的资源
        onLoadStart: PropTypes.func,
        onLoad: PropTypes.func,
        onProgress: PropTypes.func,
        onEnd: PropTypes.func,
        onSeek: PropTypes.func,
        onError: PropTypes.func,
        paused: PropTypes.bool,
    };

    static defaultProps = {};

    seek = second => {
        this._seekTo(second);
    };

    constructor(props) {
        super(props);
        this.listener;
        this.timer; // 0.5秒调用一次
        this.status = PLAY_STATUS.BUFFERING;
        this.current = 0;
        this.duration = 0;
        this.src; // 当前播放的src
    }

    componentDidMount() {
        AudioStreamer.remove();
        this.listener = DeviceEventEmitter.addListener(
            'RNAudioStreamerStatusChanged',
            this._onStatusChanged
        );
        this._ready(this.props.source);
    }

    componentWillUnmount() {
        this.listener && this.listener.remove();
        this._stopTimer();
        AudioStreamer.remove();
    }

    componentDidUpdate(prevProps, prevState) {
        // 1. 空数据, 重置播放器
        if (!this.props.source) {
            this._reset();
            return;
        }

        // 2. 无法解析的数据, 重置播放器
        const destSource = resolveAssetSource(this.props.source);
        if (!destSource || !destSource.uri) {
            this._reset();
            return;
        }

        // 3. 播放新的曲目
        const prevSource = resolveAssetSource(prevProps.source);
        if (!prevSource || !prevSource.uri || destSource.uri != prevSource.uri) {
            this._ready(this.props.source);
            return;
        }

        // 4. 播放/暂停
        if (this.props.paused == prevProps.paused) {
            return;
        }

        this.props.paused ? AudioStreamer.pause() : AudioStreamer.play();
    }

    render() {
        return null;
    }

    _onStatusChanged = status => {
        // console.log('onStatusChanged', status);
        this.status = status;
        switch (status) {
            case PLAY_STATUS.PLAYING:
                this._onPlaying();
                break;
            case PLAY_STATUS.PAUSED:
                this._onPause();
                break;
            case PLAY_STATUS.STOPPED:
                this._onStop();
                break;
            case PLAY_STATUS.FINISHED:
                this._onEnd();
                break;
            case PLAY_STATUS.BUFFERING:
                this._onBuffer();
                break;
            case PLAY_STATUS.ERROR:
                this._onError(new Error('出错啦'));
                break;
            default:
            // do nothing
        }
    };

    // audio
    // ---
    _ready = source => {
        // console.log('ready', source);
        this._stopTimer();
        const assetSource = resolveAssetSource(source);
        if (!assetSource || !assetSource.uri) return;

        const src = assetSource.uri;
        if (src) {
            this.src = src;
            this.status = PLAY_STATUS.BUFFERING;
            this.current = 0;
            this.duration = 0;
            AudioStreamer.setUrl(src);
            this._onLoadStart({ uri: src });
            // 获取当前视频资源
            AudioStreamer.duration((err, duration) => {
                if (
                    Platform.OS == 'ios' &&
                    (err ||
                        this.status == PLAY_STATUS.STOPPED ||
                        this.status == PLAY_STATUS.FINISHED ||
                        this.status == PLAY_STATUS.ERROR)
                ) {
                    // console.log('status', this.status);
                    return;
                }
                this.duration = duration;
                this._onLoad({ duration });
            });
        }
    };

    _reset = url => {
        this._stopTimer();
        AudioStreamer.remove();
        if (url) {
            this.src = url;
            AudioStreamer.setUrl(url);
        }
    };

    _seekTo = second => {
        if (this.duration <= 0) return;
        AudioStreamer.seekToTime(second);
        this._onSeek({ currentTime: second, seekTime: second });
    };

    _onLoadStart = payload => {
        // console.log('onLoadStart', payload);
        this.props.onLoadStart && this.props.onLoadStart({ ...payload });
    };

    _onLoad = payload => {
        // console.log('onLoad', payload);
        this.props.onLoad && this.props.onLoad(payload);
    };

    _onPlaying = payload => {
        // console.log('onPlaying', payload);
        this._startTimer();
    };

    _onPause = payload => {
        // console.log('onPause', payload);
        this._stopTimer();
    };

    _onStop = payload => {
        // console.log('onStop', payload);
        this._stopTimer();
    };

    _onEnd = (payload = {}) => {
        // console.log('onEnd', payload);
        this._stopTimer();
        this._reset(this.src);
        this.props.onEnd && this.props.onEnd({ duration: this.duration, ...payload });
    };

    _onBuffer = (payload = {}) => {
        // console.log('onBuffer', payload);
        this.props.onBuffer && this.props.onBuffer({ isBuffering: true, ...payload });
    };

    _onError = error => {
        // console.log('onError', error);
        this._stopTimer();
        this._reset();
        this.props.onError && this.props.onError(error);
    };

    _onProgress = (payload = {}) => {
        // console.log('onProgress', payload);
        this.props.onProgress && this.props.onProgress(payload);
    };

    _onSeek = (payload = {}) => {
        // console.log('onSeek', payload);
        this.props.onSeek && this.props.onSeek(payload);
    };

    // timer
    // ---
    _startTimer = () => {
        // console.log('_startTimer');
        this._stopTimer();
        this.timer = setInterval(this._getPropgress, 500);
    };

    _stopTimer = () => {
        // console.log('_stopTimer');
        this.timer && clearInterval(this.timer);
    };

    _getPropgress = () => {
        if (this.status == PLAY_STATUS.PLAYING) {
            AudioStreamer.currentTime((err, currentTime) => {
                if (err) return;
                this.current = currentTime;
                this._onProgress({
                    currentTime: this.current,
                    playableDuration: this.current,
                    seekableDuration: this.duration,
                    duration: this.duration,
                });
            });

            AudioStreamer.duration((err, duration) => {
                if (err) return;
                this.duration = duration;
            });
        }
    };
}
