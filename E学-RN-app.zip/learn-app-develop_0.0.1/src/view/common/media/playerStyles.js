/**
 * @author xukj
 * @date 2019/11/15
 * @description 播放器样式
 */
import { StyleSheet } from 'react-native';
import { SeaScale, SeaColor } from '../../../asserts';

// 普通模式
const normalWidth = SeaScale.screenWidth;
const normalHeight = (SeaScale.screenWidth * 9) / 16;
// 迷你模式高度
const miniWidth = SeaScale.screenWidth;
const miniHeight = SeaScale.Layout(60);

const playerStyles = StyleSheet.create({
    normal: {
        width: normalWidth,
        height: normalHeight,
    },
    mini: {
        width: miniWidth,
        height: miniHeight,
    },
});

export default playerStyles;
