/**
 * @author xukj
 * @date 2019/11/20
 * @class
 * @description 音频播放器，支持数据上报等业务逻辑
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Image } from 'react-native';
import { connect } from 'react-redux';
import AudioPlayer from './AudioPlayer';
import { Actions } from 'react-native-router-flux';
import { SeaPlayProgressUtil } from '../../../util';
import { AC_UpdateFinishStatus } from '../../../redux/actions/course';
import SeaMediaErrorView from './SeaMediaErrorView';

@connect(null, mapDispatchToProps)
export default class SeaAudioPlayer extends React.PureComponent {
    static propTypes = {
        source: PropTypes.any,
        mini: PropTypes.bool,
        review: PropTypes.bool, // 浏览模式
        cover: Image.propTypes.source,
        defaultTime: PropTypes.number, // 开始时间
        onProgress: PropTypes.func, // 播放进度
        onEnd: PropTypes.func, // 播放完成
        data: PropTypes.object, // 业务数据 { snapshotId, playCourse, richText, review }
        document: PropTypes.bool, // 是否显示文档icon
    };

    static defaultProps = {};

    static getDerivedStateFromProps(nextProps, prevState) {
        return nextProps.source != prevState.defaultSrc
            ? { defaultSrc: nextProps.source, src: nextProps.source }
            : null;
    }

    constructor(props) {
        super(props);
        this.duration = 0; // 播放的音频总时间
        this.current = 0; // 当前播放的时间
        this.counting = 0; // 记录学习进度的频率
        this.latestReportId = ''; // 上次上报的id
        this.canAutoplay = true; // 是否自动播放flag
        this.state = {
            error: null,
            src: props.source,
            defaultSrc: props.source,
        };
        this.player;
    }

    render() {
        const { source, onLoad, onProgress, document, ...restProps } = this.props;
        const { src, error } = this.state;
        return (
            <AudioPlayer
                autoPlay
                ref={_comp => (this.player = _comp)}
                source={src}
                onLoad={this._onLoad}
                onError={this._onError}
                onProgress={this._onProgress}
                onEnd={this._onEnd}
                onShouldStartPlay={this._onShouldStartPlay}
                document={document}
                onDocumentPress={this._onDocumentPress}
                {...restProps}
            >
                {error && <SeaMediaErrorView onReloadPress={this._reload} />}
            </AudioPlayer>
        );
    }

    // player
    // ---
    _onLoad = payload => {
        this.duration = payload.duration;
    };

    _onProgress = payload => {
        this.current = payload.currentTime;
        if (payload.duration > 0) {
            // Bugfix: iOS端时长获取为异步，需要播放时修正播放时长
            this.duration = payload.duration;
        }
        // 记录学习进度
        this._saveStudyProgress();
        // 上报完成
        this._reportStudyComplete();
    };

    _onError = error => {
        this.setState({ error, src: null });
    };

    _onShouldStartPlay = payload => {
        return this.canAutoplay;
    };

    _onEnd = payload => {
        // 音频无播放下一曲的需求
        // this.props.playNext && this.props.playNext(true);
    };

    // private
    // ---
    // 重置
    _reload = () => {
        this.setState({
            error: null,
            src: this.props.source,
        });
    };

    // 上报学习完成
    _reportStudyComplete = () => {
        const percent = this.duration == 0 ? 0 : this.current / this.duration;
        // console.log('percent', percent);
        // console.log('review', this.props.review);
        // 1. 预览
        if (this.props.review) return;
        // 2. 已上报
        const played = _.get(this.props, 'data.playCourse.played', false);
        const reportId = _.get(this.props, 'data.playCourse.curriculaContentSnapshotId');
        if (played || this.latestReportId == reportId) return;
        // 3. 播放进度未到50%
        if (percent <= 0.5) return;

        console.log('上报学习完成');

        this.latestReportId = reportId;
        this.props.reportFinish({ id: reportId });
    };

    // 记录学习进度
    _saveStudyProgress = () => {
        if (this.props.review) return;
        // 5秒记录一次, onProgress 回调频率 500ms
        this.counting += 1;
        if (this.counting <= 10) return;
        this.counting = 0;

        console.log('记录学习进度');

        const contentId = _.get(this.props, 'data.playCourse.contentId', '');
        const snapshotId = _.get(this.props, 'data.snapshotId', '');
        const payload = SeaPlayProgressUtil.payload(
            parseInt(this.current),
            parseInt(this.duration),
            contentId,
            snapshotId
        );
        SeaPlayProgressUtil.collect(payload);
    };

    _onDocumentPress = () => {
        // 1. 暂停播放
        this.player.pause();
        // 2. 禁止自动播放
        this.canAutoplay = false;
        // 3. 跳转到富文本+音频播放页面
        Actions.show('richText', {
            richSnippet: this.props.data.richText,
            review: this.props.data.review, // 使用业务数据
            audioData: {
                ...this.props,
                review: true, // 富文本页面，以富文本页面的学时情况统计为准
            },
        });
    };
}

function mapDispatchToProps(dispatch) {
    return {
        // 上报完成
        reportFinish: payload => dispatch(AC_UpdateFinishStatus(payload)),
    };
}
