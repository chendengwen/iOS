/**
 * @author xukj
 * @date 2019/11/27
 * @class
 * @description 界面展示组件SeaMediaErrorView
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Platform, View, Text } from 'react-native';
import { SeaTheme, SeaColor, SeaScale } from '../../../asserts';
import { Icon } from 'react-native-elements';
import { SeaButton } from '../../../components';
import { FSLWhiteSpace } from 'react-native-kpframework';

export default class SeaMediaErrorView extends React.PureComponent {
    static propTypes = {
        onReloadPress: PropTypes.func,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { onReloadPress } = this.props;
        return (
            <View style={styles.error_container}>
                <Text style={[styles.error_title, { fontSize: SeaTheme.font_size_lg }]}>警告</Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_md * 2} />
                <Text style={styles.error_title}>无法播放该音视频资源，请重试或联系管理员！</Text>
                <FSLWhiteSpace size={SeaTheme.v_spacing_md * 2} />
                <SeaButton style={styles.error_btn} onPress={onReloadPress}>
                    <Icon
                        size={SeaScale.Layout(30)}
                        name="reload1"
                        type="antdesign"
                        color="white"
                    />
                    <Text style={styles.error_btntext}>重试</Text>
                </SeaButton>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    error_container: {
        ...StyleSheet.absoluteFill,
        padding: SeaTheme.h_spacing_sm,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'black',
    },
    error_title: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.white,
        textAlign: 'center',
        lineHeight: SeaScale.Layout(38),
    },
    error_btn: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: SeaTheme.h_spacing_md,
        paddingVertical: SeaScale.Layout(16),
        borderRadius: SeaTheme.raduis_md,
        backgroundColor: '#505050',
    },
    error_btntext: {
        marginLeft: SeaTheme.h_spacing_sm,
        fontSize: SeaTheme.font_size_sm,
        color: 'white',
    },
});
