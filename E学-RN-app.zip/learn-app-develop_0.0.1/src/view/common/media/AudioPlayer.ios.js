/**
 * @author xukj
 * @date 2019/11/14
 * @class
 * @description 音频播放器
 * 因为iOS端react-native-video会出现获取不掉播放时长的问题，这里暂时使用历史音频包
 * react-native-audio-streamer
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, ViewPropTypes, View, ImageBackground, Image } from 'react-native';
import _ from 'lodash';
import { SeaScale, SeaColor, SeaTheme } from '../../../asserts';
import { FSLCachedImage } from 'react-native-kpframework';
import { SeaButton } from '../../../components';
import MediaControls from './MediaControls';
import playerStyles from './playerStyles';
import Audio from './Audio';

export default class AudioPlayer extends React.PureComponent {
    static propTypes = {
        mini: PropTypes.bool,
        style: ViewPropTypes.style,
        source: PropTypes.any,
        defaultTime: PropTypes.number, // 默认播放时间
        onLoadStart: PropTypes.func,
        onLoad: PropTypes.func,
        onProgress: PropTypes.func,
        onEnd: PropTypes.func,
        onSeek: PropTypes.func,
        onError: PropTypes.func,
        onShouldStartPlay: PropTypes.func, // 是否开始播放
        cover: Image.propTypes.source,
        autoPlay: PropTypes.bool,
        document: PropTypes.bool, // 是否显示文档icon
        onDocumentPress: PropTypes.func, // 点击文档icon
    };

    static defaultProps = {};

    // public
    // ---
    play = () => this._play();

    pause = () => this._pause();

    seek = second => this._seek(second);

    // private
    // --
    constructor(props) {
        super(props);
        this.state = {
            playing: false, // 视频是否正在播放
            currentTime: 0, // 视频当前播放的时间
            duration: 0, // 视频的总时长
            loading: true,
        };
        this.videoPlayer = null;
        // 因为这里有bug过于频繁的seek会导致内存暴涨，需要限流
        this.seekThrottle = _.throttle(
            seconds => this.videoPlayer && this.videoPlayer.seek(seconds),
            200,
            { trailing: true }
        );
    }

    componentDidMount() {}

    componentWillUnmount() {
        this.seekThrottle && this.seekThrottle.cancel();
    }

    render() {
        const {
            style,
            children,
            onLoad,
            onLoadStart,
            onProgress,
            onSeek,
            onEnd,
            onError,
            cover,
            mini,
            document,
            onDocumentPress,
            ...restProps
        } = this.props;
        const { playing, currentTime, duration, loading } = this.state;
        return (
            <View style={[mini ? playerStyles.mini : playerStyles.normal, style && style]}>
                <Audio
                    ref={_comp => (this.videoPlayer = _comp)}
                    style={StyleSheet.absoluteFill}
                    paused={!playing}
                    onLoad={this._onLoad}
                    onLoadStart={this._onLoadStart}
                    onProgress={this._onProgress}
                    onSeek={this._onSeek}
                    onEnd={this._onEnd}
                    onError={this._onError}
                    onBuffer={this._onBuffer}
                    progressUpdateInterval={500}
                    {...restProps}
                />
                {!mini && (
                    <this._audioCoverView
                        playing={playing}
                        cover={cover}
                        document={document}
                        onDocumentPress={onDocumentPress}
                    />
                )}
                <MediaControls
                    audio
                    style={
                        mini ? { ...StyleSheet.absoluteFill } : { backgroundColor: 'transparent' }
                    }
                    playing={playing}
                    currentTime={currentTime}
                    duration={duration}
                    loading={loading}
                    onPlayOrPausePress={this._onPlayOrPausePress}
                    onSeek={this._onSliderValueChanged}
                />
                {children}
            </View>
        );
    }

    // component
    // ---

    // 出错或结束的cover界面
    // 带重新播放、错误提示功能
    _finishView = props => {
        return <View />;
    };

    _audioCoverView = props => {
        const { playing, cover, document, onDocumentPress } = props;
        return (
            <ImageBackground
                style={[
                    StyleSheet.absoluteFill,
                    { alignItems: 'center', justifyContent: 'center', backgroundColor: '#092349' },
                ]}
                source={
                    playing
                        ? require('../../../asserts/images/musicCover0.gif')
                        : require('../../../asserts/images/musicCover1.png')
                }
            >
                <FSLCachedImage style={styles.cover} source={cover} />
                {document && (
                    <SeaButton style={styles.btnDoc} onPress={onDocumentPress}>
                        <Image
                            style={styles.document}
                            source={require('../../../asserts/images/wengao.png')}
                            resizeMode={'contain'}
                        />
                    </SeaButton>
                )}
            </ImageBackground>
        );
    };

    // video event
    // ---
    _onLoadStart = payload => {
        // console.log('onLoadStart', payload);
        this.setState({ loading: true, playing: false, currentTime: 0, duration: 0 });
        this.props.onLoadStart && this.props.onLoadStart(payload);
    };

    _onLoad = payload => {
        // console.log('onLoad', payload);
        this.setState({ loading: false, duration: payload.duration });
        let seekTime = this.props.defaultTime;
        if (seekTime > 0 && seekTime < payload.duration) {
            this._seek(seekTime, true);
        }
        this.props.onLoad && this.props.onLoad(payload);
        // 自动播放
        this.props.autoPlay && this._play();
    };

    _onError = error => {
        // console.log('onError', error);
        this.setState({ error, loading: false, playing: false });
        this.props.onError && this.props.onError(error);
    };

    _onProgress = payload => {
        // console.log('onProgress', payload);
        // 忽略极小数据
        if (payload.currentTime <= 0.01) return;
        this.setState(prevState => ({
            currentTime: payload.currentTime,
            loading: false,
            // 更新播放时长
            duration: payload.duration > prevState.duration ? payload.duration : prevState.duration,
        }));
        this.props.onProgress && this.props.onProgress(payload);
    };

    _onBuffer = payload => {
        // console.log('onBuffer', payload);
        this.setState({ loading: payload.isBuffering });
    };

    _onEnd = payload => {
        // console.log('onEnd', payload);
        this._stop();
        this.props.onEnd && this.props.onEnd(payload);
    };

    _onSeek = payload => {
        // console.log('onSeek', payload);
        this.props.onSeek && this.props.onSeek(payload);
    };

    // controls event
    // ---
    _onSliderValueChanged = currentTime => {
        this._seek(currentTime);
    };

    _onPlayOrPausePress = () => {
        if (this.state.loading) {
            // do nothing
        } else if (this.state.playing) {
            this._pause();
        } else {
            this._play();
        }
    };

    // other func
    // ---
    _play = () => {
        this.setState({ playing: true });
    };

    _pause = () => {
        this.setState({ playing: false });
    };

    _stop = () => {
        this.setState({ playing: false });
        this._seek(0, true);
    };

    _seek = (second, immediate) => {
        this.setState({ currentTime: second });
        // 限流防止频繁seek导致崩溃
        if (immediate) {
            this.videoPlayer && this.videoPlayer.seek(second);
        } else {
            this.seekThrottle && this.seekThrottle(second);
        }
    };
}

const styles = StyleSheet.create({
    control: {
        flexDirection: 'row',
        height: SeaScale.Layout(60),
        alignItems: 'center',
        backgroundColor: 'transparent',
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        paddingHorizontal: SeaScale.Layout(8),
    },
    track: {
        height: SeaScale.Layout(2),
        borderRadius: SeaScale.Layout(1),
    },
    thumb: {
        width: SeaScale.Layout(16),
        height: SeaScale.Layout(16),
        borderRadius: SeaScale.Layout(16) / 2,
        backgroundColor: 'white',
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    time: {
        fontSize: SeaScale.Layout(18),
        width: SeaScale.Layout(100),
        color: '#DEDEDE',
        textAlign: 'center',
    },
    cover: {
        width: SeaScale.Layout(260),
        height: SeaScale.Layout(260),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: SeaScale.Layout(130),
        backgroundColor: SeaColor.circle,
    },
    document: {
        width: SeaScale.Layout(36),
        height: SeaScale.Layout(44),
    },
    btnDoc: {
        position: 'absolute',
        right: SeaTheme.h_spacing_sm,
        bottom: SeaScale.Layout(60),
    },
});
