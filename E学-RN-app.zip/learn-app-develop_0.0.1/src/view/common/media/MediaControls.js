/**
 * @author xukj
 * @date 2019/11/15
 * @class
 * @description 播放控制器
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Animated, View, Text, ActivityIndicator, ViewPropTypes } from 'react-native';
import { Icon, Slider } from 'react-native-elements';
import { SeaScale, SeaColor } from '../../../asserts';
import { FSLTool } from '../../../util';

export default class MediaControls extends React.PureComponent {
    static propTypes = {
        style: ViewPropTypes.style,
        audio: PropTypes.bool, // 是否音频播放器
        playing: PropTypes.bool,
        fullscreen: PropTypes.bool,
        currentTime: PropTypes.number,
        duration: PropTypes.number,
        loading: PropTypes.bool,
        onPlayOrPausePress: PropTypes.func,
        onFullscreenPress: PropTypes.func,
        onSeek: PropTypes.func,
        tintColor: PropTypes.string,
        translucent: PropTypes.bool, // 半透明
    };

    static defaultProps = {
        tintColor: '#DEDEDE',
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const {
            style,
            audio,
            playing,
            fullscreen,
            currentTime,
            duration,
            loading,
            onSeek,
            onPlayOrPausePress,
            onFullscreenPress,
            tintColor,
            translucent,
        } = this.props;
        return (
            <Animated.View
                style={[
                    styles.control,
                    translucent && { backgroundColor: 'rgba(0, 0, 0, 0.6)' },
                    style && style,
                ]}
            >
                <Icon
                    type="material"
                    name={playing ? 'pause' : 'play-arrow'}
                    size={iconSize}
                    color={tintColor}
                    onPress={onPlayOrPausePress}
                    underlayColor="transparent"
                />
                <Text
                    style={[styles.time, { color: tintColor }]}
                    numberOfLines={1}
                    adjustsFontSizeToFit
                >
                    {FSLTool.timeString(currentTime)}
                </Text>
                <Slider
                    style={{ flex: 1 }}
                    thumbStyle={styles.thumb}
                    trackStyle={styles.track}
                    maximumTrackTintColor={'#999999'}
                    minimumTrackTintColor={tintColor}
                    minimumValue={0}
                    maximumValue={duration}
                    // onValueChange={onSeek}
                    value={currentTime}
                    onSlidingComplete={onSeek}
                />
                <Text
                    style={[styles.time, { color: tintColor }]}
                    numberOfLines={1}
                    adjustsFontSizeToFit
                >
                    {FSLTool.timeString(duration)}
                </Text>
                {audio ? (
                    <ActivityIndicator animating={loading} size="small" color={tintColor} />
                ) : (
                    <Icon
                        type="material"
                        name={fullscreen ? 'fullscreen-exit' : 'fullscreen'}
                        size={iconSize}
                        color={tintColor}
                        onPress={onFullscreenPress}
                        underlayColor="transparent"
                    />
                )}
            </Animated.View>
        );
    }
}

const iconSize = SeaScale.Layout(40);
const styles = StyleSheet.create({
    // 控制器样式
    // ---
    control: {
        flexDirection: 'row',
        height: SeaScale.Layout(60),
        alignItems: 'center',
        backgroundColor: '#888888',
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        paddingHorizontal: SeaScale.Layout(8),
    },
    track: {
        height: SeaScale.Layout(2),
        borderRadius: SeaScale.Layout(1),
    },
    thumb: {
        width: SeaScale.Layout(16),
        height: SeaScale.Layout(16),
        borderRadius: SeaScale.Layout(16) / 2,
        backgroundColor: 'white',
        shadowColor: '#888888',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    time: {
        fontSize: SeaScale.Layout(18),
        width: SeaScale.Layout(100),
        textAlign: 'center',
    },
    cover: {
        width: SeaScale.Layout(260),
        height: SeaScale.Layout(260),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: SeaScale.Layout(130),
        backgroundColor: SeaColor.circle,
    },
});
