/**
 * @author xukj
 * @date 2019/11/19
 * @class
 * @description 视频播放器，支持上报等业务逻辑
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { connect } from 'react-redux';
import VideoPlayer from './VideoPlayer';
import { AC_UpdateFinishStatus, AC_PLAY_NEXT } from '../../../redux/actions/course';
import { SeaPlayProgressUtil, SeaStudyTimeUtil } from '../../../util';
import SeaMediaErrorView from './SeaMediaErrorView';

@connect(null, mapDispatchToProps)
export default class SeaVideoPlayer extends React.PureComponent {
    static propTypes = {
        source: PropTypes.any,
        review: PropTypes.bool, // 浏览模式
        onProgress: PropTypes.func, // 播放进度
        onEnd: PropTypes.func, // 播放完成
        defaultTime: PropTypes.number, // 开始时间
        data: PropTypes.object, // 业务数据 { snapshotId, playCourse }
    };

    static defaultProps = {};

    static getDerivedStateFromProps(nextProps, prevState) {
        return nextProps.source != prevState.defaultSrc
            ? { defaultSrc: nextProps.source, src: nextProps.source }
            : null;
    }

    constructor(props) {
        super(props);
        this.state = {
            error: null,
            src: props.source, // `http://127.0.0.1/11.mp4`
            defaultSrc: props.source, // 用来判断当前播放的src是否已经发生改变
        };
        this.duration = 0; // 播放的视频总时间
        this.current = 0; // 当前播放的时间
        this.counting = 0; // 记录学习进度的次数
        this.latestReportId = ''; // 上次上报的id
    }

    componentDidMount() {}

    render() {
        const { source, ...restProps } = this.props;
        const { src, error } = this.state;
        return (
            <VideoPlayer
                ref={_comp => (this.player = _comp)}
                source={src}
                autoPlay
                onLoad={this._onLoad}
                onProgress={this._onProgress}
                onEnd={this._onEnd}
                onError={this._onError}
                {...restProps}
            >
                {error && <SeaMediaErrorView onReloadPress={this._onReloadPress} />}
            </VideoPlayer>
        );
    }

    // play
    // ---
    _onLoad = payload => {
        this.duration = payload.duration;
    };

    _onProgress = payload => {
        this.current = payload.currentTime;
        // 记录学习进度
        this._saveStudyProgress();
        // 上报播放完成
        this._reportStudyComplete();
    };

    _onEnd = () => {
        // 执行播放下一个
        this.props.playNext(true);
    };

    _onError = error => {
        this.setState({ error, src: null });
    };

    // private
    // ---
    // 重置
    _onReloadPress = () => {
        this.setState({
            error: null,
            src: this.props.source,
        });
    };

    // 上报学习完成
    _reportStudyComplete = () => {
        const percent = this.duration == 0 ? 0 : this.current / this.duration;
        // console.log('percent', percent);
        // 1. 预览模式不统计上报学时
        if (this.props.review) return;
        // 2. 已上报的不再统计
        const played = _.get(this.props, 'data.playCourse.played', false);
        const reportId = _.get(this.props, 'data.playCourse.curriculaContentSnapshotId');
        if (played || this.latestReportId == reportId) return;
        // 3. 学习进度未到 50%
        // const percent = this.duration == 0 ? 0 : this.current / this.duration;
        // console.log('percent', percent);
        if (percent <= 0.5) return;

        console.log('上报学习完成');
        this.latestReportId = reportId;
        this.props.reportFinish({ id: reportId });
    };

    // 记录学习进度/学时
    _saveStudyProgress = () => {
        // 1. 预览模式不统计进度
        if (this.props.review) return;
        // 2. 5秒记录一次, onProgress 回调频率 500ms
        this.counting += 1;
        if (this.counting <= 10) return;
        this.counting = 0;

        // 记录进度
        const contentId = _.get(this.props, 'data.playCourse.contentId', '');
        const snapshotId = _.get(this.props, 'data.snapshotId', '');
        const payload = SeaPlayProgressUtil.payload(
            parseInt(this.current),
            parseInt(this.duration),
            contentId,
            snapshotId
        );
        SeaPlayProgressUtil.collect(payload);

        // 记录学时
        SeaStudyTimeUtil.collect(_.get(this.props, 'data.playCourse'));
    };
}

function mapDispatchToProps(dispatch) {
    return {
        // 上报完成
        reportFinish: payload => dispatch(AC_UpdateFinishStatus(payload)),
        // 播放下一曲
        playNext: payload => dispatch(AC_PLAY_NEXT(payload)),
    };
}
