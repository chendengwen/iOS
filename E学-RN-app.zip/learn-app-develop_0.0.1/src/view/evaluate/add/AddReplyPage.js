/**
 * @author ouyfm
 * @date 2020/20/23
 * @class
 * @description AddReplyPage
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, Keyboard, DeviceEventEmitter } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { EvaluateService } from '../../../servie';
import { AddComment } from '../../../components';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { SeaString } from '../../../util';
import { SeaStyle, SeaConstant } from '../../../asserts';

export default class AddReplyPage extends React.PureComponent {
    static propTypes = {
        businessType: PropTypes.string.isRequired,
        businessId: PropTypes.string.isRequired,
        evaluateUserId: PropTypes.string.isRequired,
        evaluateUserName: PropTypes.string.isRequired,
        evaluateParentId: PropTypes.string.isRequired,
        replyId: PropTypes.string,
        replyUserId: PropTypes.string,
        replyUserName: PropTypes.string,
        title: PropTypes.string,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey; //等待框
    }

    componentDidMount() { }

    componentWillMount() {

    }

    render() {
        const { replyId, replyUserName, title } = this.props;
        const placeholder = replyId ? `回复 ${replyUserName}：` : `请输入您的${title}`;
        return (
            <View style={SeaStyle.page}>
                <AddComment
                    title={title}
                    placeholder={placeholder}
                    onClosePress={this._onClosePress}
                    onPublishPress={this._onPublishPress}
                />
            </View>
        );
    }

    _onClosePress = () => {
        Keyboard.dismiss();
        Actions.pop();
    };

    _onPublishPress = (content, anonymous) => {
        Keyboard.dismiss();
        this._publishAnswer(content, anonymous);
    };

    _startLoading = () => {
        this._loadingKey = FSLPrompt.loading('正在提交');
    };

    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };
    _rand = (min, max) => {
        return Math.floor(Math.random() * (max - min)) + min;
    };
    // 提交评价或者回复，需要处理下匿名情况，是匿名传evaluateUserId为-1 evaluateUserName为匿名用户 1字母+4位随机数
    _publishAnswer = async (content, anonymous) => {
        try {
            this._startLoading();
            const value = SeaString.utf16Decoding(content);
            const nextProps = this.props;
            EvaluateService.addCaseEvalate(
                {
                    businessType: nextProps.businessType,
                    businessId: nextProps.businessId,
                    evaluateUserId: nextProps.evaluateUserId,
                    evaluateUserName: anonymous ? '匿名' : nextProps.evaluateUserName,
                    evaluateParentId: nextProps.evaluateParentId,
                    replyId: nextProps.replyId,
                    replyUserId: nextProps.replyUserId,
                    replyUserName: nextProps.replyUserName,
                    evaluateDetails: value,
                    anonymous: anonymous ? 1 : 0,
                }
            ).then(responseJson => {
                this._stopLoading();
                if (responseJson.code == '000000') {
                    // 通知QA详情刷新
                    DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASEREPLY, responseJson);
                    DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_STATE);
                    Actions.pop();
                } else {
                    if (responseJson.code == '100009') {
                        var str = responseJson.tips[0];
                        var start = str.indexOf(':') + 1;
                        var end = str.length;
                        str = str.substring(start, end);
                        FSLToast.show(str);
                    } else {
                        FSLToast.show(responseJson.msg);
                    }
                }
            }).catch(() => {
                this._stopLoading();
                FSLToast.show(error.message);
                return Promise.reject(error);
            });


        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };
}
