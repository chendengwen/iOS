/**
 * @author xukj
 * @date 2020/06/319
 * @description index 共用评价
 */
export { default as CaseEvaluateDetailPage } from './detail/CaseEvaluateDetailPage'; 
export { default as AddReplyPage } from './add/AddReplyPage'; 
export { default as EvaluateReplyDetailPage } from './detail/EvaluateReplyDetailPage';
