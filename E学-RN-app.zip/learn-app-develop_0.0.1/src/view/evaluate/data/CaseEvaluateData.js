/*
 * @Author: ouyfm
 * @Date: 2020-07-01 16:09:53
 * @LastEditors: ouyfm
 * @LastEditTime: 2020-07-03 11:17:30
 * @Descripttion: 案例评价数据模型
 */ 
export default class CaseEvaluateData {
     constructor(){
         this.evaluateList;
         this.evaluateTotal;
         this.evaluatePages;
         this.subEvaluateCount;
         this.replyUserName;
         this.evaluateDetails;
         this.evaluateUserImageId;
         this.evaluateUserName;
         this.isLike;
         this.likeCount;
         this.createTime;
         this.evaluateId;
         this.evaluateUserId;
         this.replyId;
         this.isSelf;
     }
 /**
  * @description: 处理案例中心评价列表数据
  * @param {type}：
  * evaluateList:评价数组
  * evaluateTotal评价总数
  * evaluatePages评价页数
  */    
    static formatEvaluatList(val) {
        let caseEvaluate = new CaseEvaluateData();
        caseEvaluate.evaluateList = val.list || [];
        caseEvaluate.evaluateTotal = val.total || 0;
        caseEvaluate.evaluatePages = val.pages || 0;
        return caseEvaluate;
    }
 /**
  * @description: 处理单条评价数据
  * @param {type} 
  * subEvaluateCount：回复总数
  * replyUserName: 回复的第一个人的名称
  * evaluateDetails:评价信息
  * evaluateUserImageId:头像
  * evaluateUserId：评价人id
  * evaluateUserName:评价人姓名
  * isLike:点赞情况
  * likeCount:点赞总数
  * createTime:评价时间
  * evaluateId:评价id
  * replyId:回复id
  * isSelf是否是本人回复
  */   
    static formatEvaluatItem(val) {
        let caseEvaluate = new CaseEvaluateData();
        let imgPerStr = '/auth/extends/v1/user/photo/stream-public/getImgByEmpId?empId=';
        caseEvaluate.subEvaluateCount = val.subEvaluateCount || 0;
        caseEvaluate.replyUserName = val.replyUserName || '';
        caseEvaluate.evaluateDetails = val.evaluateDetails || '';
        caseEvaluate.evaluateUserImageId = `${imgPerStr}${val.evaluateUserImageId || ''}`;
        caseEvaluate.evaluateUserName = val.evaluateUserName || '';
        caseEvaluate.isLike = val.isLike || '';
        caseEvaluate.likeCount = val.likeCount || 0;
        caseEvaluate.createTime = val.createTime || '';
        caseEvaluate.evaluateId = val.evaluateId || '';
        caseEvaluate.evaluateUserId = val.evaluateUserId || '';
        caseEvaluate.replyId = val.replyId || '';
        caseEvaluate.isSelf = val.isSelf;
        return caseEvaluate;
  
    }
 }
 