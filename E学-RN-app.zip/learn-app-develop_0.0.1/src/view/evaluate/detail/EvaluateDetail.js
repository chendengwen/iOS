/**
 * @author ouyfm
 * @date 2020/06/23
 * @class
 * @description 界面展示组件EvaluateDetail 评价详情
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Alert } from 'react-native';
import { SeaCommentButton, SeaNavigator, SeaList } from '../../../components';
import EvaluateCell from './EvaluateCell';
import NoEvaluateFooter from './NoEvaluateFooter';
import { SeaColor, SeaStyle } from '../../../asserts';
import { SeaDevice } from '../../../util';
import { IdentifyExtension } from '../../../redux';
// import EvaluateDetailHeader from './EvaluateDetailHeader';

export default class EvaluateDetail extends React.PureComponent {
    static propTypes = {
        item: PropTypes.any,
        imgPerStr: PropTypes.string,
        needRenderheader: PropTypes.any,
        onFetch: PropTypes.func,
        onQuestionDeletePress: PropTypes.func,
        onAnswerMorePress: PropTypes.func,
        onAnswerDeletePress: PropTypes.func,
        onAddAnswerPress: PropTypes.func,
        onAddReplyPress: PropTypes.func,
        onCellLikePress: PropTypes.func
    };
    static defaultProps = {
        item: {},
        onQuestionDeletePress: resourceId => { },
        onAnswerMorePress: (item, index) => { },
        onAnswerDeletePress: (item, index) => { },
        onAddAnswerPress: () => { },
        onAddReplyPress: (item, index) => { },
    };
    constructor(props) {
        super(props);
        // 头部绘制
        this.state = { item: props.item ? props.item : {} };
    }
    componentDidMount() { }
    render() {
        const {
            title,
            onFetch,
            onAnswerMorePress,
            onAnswerDeletePress,
            onAddAnswerPress,
            onQuestionDeletePress,
            onAddReplyPress,
            onCellLikePress,
            needRenderheader
        } = this.props;
        const { item } = this.state;
        const renderHeader = _.curry(this._renderHeader)(item);
        const renderItem = _.curry(this._renderItem)(onAnswerMorePress)(onAddReplyPress)(onAnswerDeletePress)(onCellLikePress);
        // 这里需要保留header部分，同时展示emptyComponent，只能通过footer来处理，使用mapDataToProps来达到目的
        return (
            <View style={styles.page}>
                {/* 课程里的评论去掉title */}
                {(title !== '111') && <SeaNavigator title={title} {...this._navProps(onQuestionDeletePress, item)} />}
                <SeaList
                    style={SeaStyle.list}
                    ref="list"
                    onFetch={onFetch}
                    renderItem={renderItem}
                    FSLListEmptyComponent={null}
                    ListHeaderComponent={needRenderheader ? renderHeader : null}
                    mapDataToProps={this._mapDataToProps}
                    mapOtherToProps={this._mapOtherToProps}
                    onLoadStateChanged={this._onLoadStateChanged}
                />
                {(title !== '111') && !this.props.isComment && <View style={styles.footer}>
                    <SeaCommentButton
                        style={{ flex: 1 }}
                        containerStyle={styles.footerContainer}
                        onPress={onAddAnswerPress}
                        text="写评价"
                    />
                </View>}

            </View>
        );
    }
    /**
     * 刷新列表
     */
    reload = () => {
        this.refs.list && this.refs.list.reload();
    };
    _renderHeader = item => () => {
        // todo...
        // return <EvaluateDetailHeader item={item} />;
    };
    _renderItem = (onCellMorePress, onCellReplyPress, onCellDeletePress, onCellLikePress, { item, index }) => {
        const showAlert = this._deleteAlert('警告', '确定要删除这条回答吗？', () =>
            onCellDeletePress(item, index)
        );
        const count = _.get(item, 'subEvaluateCount');
        return (
            <EvaluateCell
                like
                reply
                imgPerStr={this.props.imgPerStr}
                remove={item.evaluateUserId == IdentifyExtension.getLoginUserInfo().id}
                more={count > 0}
                item={item}
                onMorePress={() => onCellMorePress(item, index)}
                onReplyPress={() => onCellReplyPress(item, index)}
                onLikePress={() => onCellLikePress(item, index)}
                onDeletePress={showAlert}
            />
        );
    };
    _navProps = (onQuestionDeletePress, item) => {
        const showAlert = this._deleteAlert('警告', `确定要删除这条问题吗？`, () =>
            onQuestionDeletePress(item)
        );
        return !!item && item.owner
            ? {
                rightIcon: 'delete',
                onRightPress: showAlert,
            }
            : {};
    };
    _onLoadStateChanged = ({ loading, other }) => {
        if (!loading && other) this.setState({ item: other });
    };
    _mapDataToProps = data => {
        if (_.isEmpty(data)) {
            return {
                data: [],
                ListFooterComponent: () => <NoEvaluateFooter />,
            };
        } else {
            return { data };
        }
    };
    _mapOtherToProps = other => {
        let otherProps = {};
        if (other) {
            otherProps = {
                ListHeaderComponent: this._renderHeader(other),
            };
        }
        return {
            ...otherProps,
            other,
        };
    };
    _deleteAlert = (title, content, onPress) => () => {
        Alert.alert(
            title,
            content,
            [
                { text: '取消', style: 'cancel' },
                { text: '删除', style: 'destructive', onPress: onPress },
            ],
            { cancelable: false }
        );
    };
}
const styles = StyleSheet.create({
    page: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },
    list: {
        flex: 1,
    },
    footer: {
        height: SeaDevice.bottomHeight() + 44,
        paddingBottom: SeaDevice.bottomHeight(),
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 15,
        paddingRight: 15,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: SeaColor.parting_line,
        flexDirection: 'row',
    },
    footerContainer: {
        height: 30,
        backgroundColor: 'white',
        borderRadius: 15,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
    },
});
