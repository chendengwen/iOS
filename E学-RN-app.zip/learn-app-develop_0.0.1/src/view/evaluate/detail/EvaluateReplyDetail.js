/**
 * @author ouyfm
 * @date 2020/06/20
 * @class
 * @description 查看回复组件EvaluateReplyDetail
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View } from 'react-native';
import { SeaList, SeaActionSheet, SeaCommentButton } from '../../../components';
import EvaluateCell from './EvaluateCell';
import { SeaStyle, SeaColor } from '../../../asserts';
import EvaluateReplyCell from './EvaluateReplyCell';
import { SeaDevice } from '../../../util';
import { IdentifyExtension } from '../../../redux';

export default class EvaluateReplyDetail extends React.PureComponent {
    static propTypes = {
        answer: PropTypes.object.isRequired,
        replyList: PropTypes.array,
        onReplyToPress: PropTypes.func,
        onReplyPress: PropTypes.func,
        onDeletePress: PropTypes.func,
        needHeader:PropTypes.bool
    };

    static defaultProps = {
        replyList: [],
        onReplyPress: () => {},
        onReplyToPress: (item, index) => {},
        onDeletePress: (item, index) => {},
    };

    constructor(props) {
        super(props);
        this.defaultOptions = [{ name: '评论', value: 0 },{ name: '取消', value: -1 }];
        this.ownerOptions = [
            { name: '评论', value: 0 },
            { name: '删除', value: 1 },
            { name: '取消', value: -1 },
        ];
    }

    componentDidMount() {}

    render() {
        const { replyList, onReplyPress,needHeader} = this.props;
        return (
            <View style={SeaStyle.page}>
                <SeaList
                    style={SeaStyle.list}
                    data={replyList}
                    renderItem={this._renderItem}
                    ListHeaderComponent={needHeader?this._renderHeader:null}
                />
                <View style={styles.footer}>
                    <SeaCommentButton
                        style={{ flex: 1 }}
                        containerStyle={styles.footerContainer}
                        onPress={onReplyPress}
                        text="回复评价"
                    />
                </View>
            </View>
        );
    }

    _renderHeader = () => {
        return <EvaluateCell item={this.props.answer} like/>;
    };

    _renderItem = ({ item, index }) => {
        const { onReplyToPress, onDeletePress } = this.props;
        const owner =   item.evaluateUserId == IdentifyExtension.getLoginUserInfo().id;
        const options = owner ? this.ownerOptions : this.defaultOptions;

        const onSelected = option => {
            if (option.value == 0) {
                onReplyToPress(item, index);
            } else if (option.value == 1) {
                onDeletePress(item, index);
            }
        };
        return (
            <SeaActionSheet
                options={options}
                cancelIndex={options.length - 1}
                selectedIndex={owner ? 1 : -1}
                onSelected={onSelected}
                enable={item.evaluateStatus === '0' ? false: true}
            >
                <EvaluateReplyCell item={item}/>
            </SeaActionSheet>
        );
    };
}

const styles = StyleSheet.create({
    footer: {
        height: SeaDevice.bottomHeight() + 44,
        paddingBottom: SeaDevice.bottomHeight(),
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 15,
        paddingRight: 15,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: SeaColor.parting_line,
        flexDirection: 'row',
    },
    footerContainer: {
        height: 30,
        backgroundColor: 'white',
        borderRadius: 15,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: SeaColor.parting_line,
    },
});
