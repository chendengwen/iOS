/**
 * @author oufm
 * @date 2020/06/23
 * @class
 * @description 界面展示组件EvaluateCell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text, Image } from 'react-native';
import { SeaGenderHeader, SeaButton } from '../../../components';
import { SeaColor, SeaTheme, SeaScale, SeaStyle } from '../../../asserts';
import { SeaString } from '../../../util';
import { FSLWhiteSpace } from 'react-native-kpframework';
import Moment from 'moment';
import { AirbnbRating } from 'react-native-elements';
const ICON_SIZE = SeaScale.Layout(30);

export default class EvaluateCell extends React.PureComponent {
    static propTypes = {
        onLikePress: PropTypes.func,
        onDeletePress: PropTypes.func,
        onReplyPress: PropTypes.func,
        onMorePress: PropTypes.func,
        item: PropTypes.any,
        remove: PropTypes.bool, // 删除按钮
        more: PropTypes.bool, // 更多按钮
        reply: PropTypes.bool, // reply按钮
        like: PropTypes.bool, // 点赞按钮
        getImageSource: PropTypes.func, //获取头像
    };
    static defaultProps = {
        onLikePress: () => {},
        onDeletePress: () => {},
        onReplyPress: () => {},
        onMorePress: () => {},
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {}
    getImageSource = (id) => {
        return `${this.props.imgPerStr}${id}`;
    };
    render() {
        const {
            item,
            remove,
            more,
            reply,
            onMorePress,
            onReplyPress,
            onDeletePress,
            onLikePress,
            like,
            getImageSource,
        } = this.props;
        let moreUser = '';
        let moreCount = 0;
        if (more) {
            moreUser = _.get(item, 'replyUserName', '');
            moreUser = SeaString.subString(moreUser, 6); // 最多6个字符
            moreCount = _.get(item, 'subEvaluateCount');
        }
        const content = SeaString.utf16Encoding(item.evaluateDetails);
        return (
            <View style={styles.cell}>
                <SeaGenderHeader
                    style={styles.header}
                    size={SeaScale.Layout(80)}
                    // sex={item.evaluateUserImageId}
                    source={(item.anonymous == 1)? null:this.getImageSource(item.evaluateUserImageId)}
                />
                <View style={styles.contentView}>
                    <View style={styles.contentHeadContainer}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.name}>{item.anonymous == 1 ? '匿名' : item.evaluateUserName}</Text>
                            {item.evaluateStatus === '0' && (
                                <Image
                                    source={require('../../../asserts/images/case/ic_approving.png')}
                                    style={styles.approvingIcon}
                                />
                            )}
                            <View style={{ width: SeaScale.Layout(250) }}>
                                {item.scores && item.scores > 0 && (
                                    <AirbnbRating
                                        showRating={false}
                                        defaultRating={item.scores}
                                        count={5}
                                        size={SeaScale.Layout(25)}
                                        selectedColor={SeaColor.orange}
                                        isDisabled={true}
                                    />
                                )}
                            </View>
                        </View>
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(12)} />

                    <Text style={styles.content}>{content}</Text>
                    {more && (
                        <View>
                            <FSLWhiteSpace key="space" size={SeaScale.Layout(16)} />
                            <SeaButton style={styles.moreContainer} onPress={onMorePress}>
                                <Text style={[styles.more, { flex: 1 }]} numberOfLines={1}>
                                    <Text style={{ color: SeaColor.main }}>{moreUser}</Text>
                                    等人&nbsp;
                                    <Text style={{ color: SeaColor.main }}>
                                        共{moreCount}条回复＞
                                    </Text>
                                </Text>
                            </SeaButton>
                        </View>
                    )}
                    <FSLWhiteSpace size={SeaScale.Layout(20)} />

                    <View style={styles.contentHeadContainer}>      
                        <Text style={styles.date}>
                            {Moment(item.createTime).format('MM-DD HH:mm')}
                            {/* {SeaString.shortDateString(item.createTime, '未知')} */}
                        </Text>

                        <View style={SeaStyle.row}>
                            {item.evaluateStatus !== '0' && reply && (
                                <SeaButton style={styles.icon} onPress={onReplyPress}>
                                    <Image
                                        style={styles.bar_icon}
                                        resizeMode="contain"
                                        source={require('../../../asserts/images/case/comment.png')}
                                    />
                                </SeaButton>
                            )}
                            {item.evaluateStatus !== '0' && remove && (
                                <SeaButton style={styles.icon} onPress={onDeletePress}>
                                    <Image
                                        style={styles.bar_icon}
                                        resizeMode="contain"
                                        source={require('../../../asserts/images/case/delete.png')}
                                    />
                                </SeaButton>
                            )}
                            {item.evaluateStatus !== '0' && like && (
                                <SeaButton style={styles.icon} onPress={onLikePress}>
                                    <Image
                                        style={[
                                            styles.bar_icon,
                                            item.isLike && { tintColor: SeaColor.main },!item.isLike && { tintColor: SeaColor.text3 }
                                        ]}
                                        resizeMode="contain"
                                        source={require('../../../asserts/images/ic-bottom-like.png')}
                                    />
                                    <Text
                                        style={[
                                            styles.likeText,
                                            item.isLike && { color: SeaColor.main },
                                        ]}
                                    >
                                        {item.likeCount}
                                    </Text>
                                </SeaButton>
                            )}
                        </View>
                    </View>
                    <FSLWhiteSpace size={SeaScale.Layout(8)} />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    cell: {
        backgroundColor: 'white',
        paddingHorizontal: SeaTheme.h_spacing_md,
        paddingVertical: SeaTheme.v_spacing_sm,
        flexDirection: 'row',
        borderBottomColor: SeaColor.parting_line,
        borderBottomWidth: SeaTheme.line_width_xs,
    },
    contentView: {
        paddingLeft: SeaTheme.h_spacing_sm,
        flex: 1,
    },
    header: {
        width: SeaScale.Layout(88),
        height: SeaScale.Layout(88),
    },
    contentHeadContainer: {
        flexDirection: 'row',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    name: {
        fontSize: SeaTheme.font_size_md,
    },
    date: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.content_text,
    },
    content: {
        fontSize: SeaTheme.font_size_md,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(40),
    },
    moreContainer: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        height: SeaScale.Layout(80),
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: SeaTheme.h_spacing_sm,
    },
    more: {
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.h2_text,
    },
    icon: {
        flexDirection: 'row',
        marginLeft: 12,
    },
    bar_icon: {
        width: ICON_SIZE,
        height: ICON_SIZE,
        justifyContent: 'center',
        flexDirection: 'row',
    },
    likeText: {
        color: SeaColor.content_text,
        marginTop: SeaScale.Layout(6),
        fontSize: SeaTheme.font_size_xxs,
        marginLeft: 4,
    },
    approvingIcon: {
        width: SeaScale.Layout(70),
        height: SeaScale.Layout(35),
        resizeMode: 'contain',
        marginLeft: SeaScale.Layout(20),
    },
});
