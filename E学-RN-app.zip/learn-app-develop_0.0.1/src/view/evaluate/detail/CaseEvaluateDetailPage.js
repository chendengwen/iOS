/**
 * @author ouyfm
 * @date 2020/06/23
 * @class
 * @description CaseEvaluateDetailPage 评价详情页
 */
import React from 'react';
import PropTypes from 'prop-types';
import { View, DeviceEventEmitter } from 'react-native';
import EvaluateDetail from './EvaluateDetail';
import { EvaluateService, PersonalService, QAService } from '../../../servie';
import { FSLPrompt, FSLToast } from 'react-native-kpframework';
import { Actions } from 'react-native-router-flux';
import { IdentifyExtension } from '../../../redux';
import { SeaConstant, SeaStyle } from '../../../asserts';

export default class CaseEvaluateDetailPage extends React.PureComponent {
    static propTypes = {
        item: PropTypes.any,
        businessType: PropTypes.string.isRequired,
        businessId: PropTypes.string.isRequired
    };
    constructor(props) {
        super(props);
        this._loadingKey; //等待框
        this.getInitData();
        this._getState();
        this.state = { isComment: false }
    }
    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_CASEREPLY,
            this._reloadDetail
        );
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_STATE,
            this._reloadDetail
        );
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_QAREPLY,
            this._reloadDetail
        );
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_STATE,
            () => {
                this._getState();
            }
        );

    }
    componentWillUnmount() {
        this.listener && this.listener.remove();
        // 销毁的时候去刷新一下上一个列表的数据
        DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASE);
    }
    getInitData() {
        let userinfo = IdentifyExtension.getLoginUserInfo();
        this.userId = userinfo.id;
        this.userName = userinfo.userName;
        this.evaluateParentId = '-1';  //一级评论默认为-1 
        this.imgPerStr = '/auth/extends/v1/user/photo/stream-public/getImgByEmpId?empId='  //评论回复用户头像前缀
    }
    render() {
        const { item = {}, title } = this.props;
        return (
            <View style={SeaStyle.page}>
                <EvaluateDetail
                    title={title}
                    ref="detail"
                    item={item}
                    imgPerStr={this.imgPerStr}
                    needRenderheader={false}
                    onFetch={this._loader(item)}
                    onQuestionDeletePress={this._onQuestionDeletePress}
                    onAnswerMorePress={this._onAnswerMorePress}
                    onAnswerDeletePress={this._onAnswerDeletePress}
                    onAddAnswerPress={this._onAddAnswerPress}
                    onAddReplyPress={this._onAddReplyPress}
                    onCellLikePress={this._onLikeReplyPress}
                    isComment={this.state.isComment}
                />
            </View>
        );
    }
    // 查看回复
    _onAnswerMorePress = item => {
        const count = _.get(item, 'subEvaluateCount');
        Actions.show('caseAnswerReplyPage', {
            data: item,
            // title: `${count} 条回复`,
            businessType: this.props.businessType,
            businessId: this.props.businessId,
            evaluateParentId: item.evaluateId,
            evaluateUserId: item.evaluateUserId,
            evaluateUserName: item.evaluateUserName,
            replyId: item.replyId,
            userId: this.userId,
            pageTo: 1,
            pageSize: 25
        });
    };
    // 点赞or取消点赞
    _onLikeReplyPress = item => {
        let parmas = {
            "evaluateId": item.evaluateId,
            "likeUser": this.userId,
            "isLike": item.isLike
        };
        return EvaluateService.setCaseLike(parmas)
            .then(responseJson => {
                //通知列表刷新
                DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_CASEREPLY);
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    }

    _getState() {
        const resourceId = this.props.businessId;
        PersonalService.queryResourceById(resourceId)
            .then((responseJson) => {
                this.setState({
                    isComment: responseJson.data.evaluateParentCount > 0,
                });
            })
            .catch(() => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    }

    // 评论
    _onAddAnswerPress = () => {
        // Actions.show('caseAddReply',{
        //     title:'评价',
        //     businessType:this.props.businessType,
        //     businessId:this.props.businessId,
        //     evaluateUserId:this.userId,
        //     evaluateUserName:this.userName,
        //     evaluateParentId:this.evaluateParentId, 
        // });
        Actions.show('addScore', {
            resourceId: this.props.businessId,
            businessType: this.props.businessType,
        });
    };
    // 回复
    _onAddReplyPress = item => {
        const evaluateParentId = _.get(item, 'evaluateId');
        const replyId = _.get(item, 'replyId');
        const evaluateUserId = _.get(item, 'evaluateUserId');
        const evaluateUserName = _.get(item, 'evaluateUserName');
        Actions.show('caseAddReply', {
            title: '回复',
            businessType: this.props.businessType,
            businessId: this.props.businessId,
            evaluateUserId: this.userId,
            evaluateUserName: this.userName,
            evaluateParentId: evaluateParentId,
            replyId: replyId,
            replyUserId: evaluateUserId,
            replyUserName: evaluateUserName,
        });
    };
    // 暂停loading
    _stopLoading = () => {
        FSLPrompt.hide(this._loadingKey);
    };
    // 初始数据
    _reloadDetail = () => {
        this.refs.detail && this.refs.detail.reload();
    };
    // 获取评价
    _loader = item => (pageTo, pageSize) => {
        let { businessType, businessId } = this.props;
        let evaluateParentId = item.evaluateId ? item.evaluateId : this.evaluateParentId;
        let userId = this.userId;
        return EvaluateService.getCaseEvalate({ businessType, businessId, evaluateParentId, userId, pageNo: pageTo, pageSize })
            .then(responseJson => {
                if (responseJson.code == '000000') {
                    let dataJson = responseJson.data;
                    return Promise.resolve({
                        data: dataJson.list,
                        totalPage:
                            dataJson.total === 0 ? 0 : Math.ceil(dataJson.total / pageSize),
                    });
                }else{
                    FSLToast.show(responseJson.msg);
                }
        
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    };
    _deleteQuestion = async askId => {
        // todo...
        try {
            this._startLoading();
            await QAService.deleteQAQuestion(askId);
            this._stopLoading();
            //通知QA列表刷新
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QALIST);
            Actions.pop();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };
    _deleteAnswer = async (id, evaluateParentId) => {
        // todo...
        let { businessType, businessId } = this.props;
        try {
            this._startLoading();
            // await QAService.deleteQAAnswer(id, askid);
            await EvaluateService.detetCaseEvalate(id);  //删除一级评论
            await EvaluateService.deleteByCondition({businessId,businessType,id});    //删除子评论
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_STATE)
            this._stopLoading();
            this._reloadDetail();
            this._getState();
        } catch (error) {
            this._stopLoading();
            FSLToast.show(error.message);
        }
    };
    _onQuestionDeletePress = () => {
        // todo...
        this._deleteQuestion(this.props.askId);
    };
    // 删除提示
    _startLoading = () => {
        // todo...
        this._loadingKey = FSLPrompt.loading('正在删除');
    };
    _onAnswerDeletePress = item => {
        // todo...
        this._deleteAnswer(item.evaluateId, item.evaluateParentId);
    };
}
