/**
 * @author ouyfm
 * @date 2020/06/23
 * @class
 * @description 界面展示组件NoEvaluateFooter 当没有评价的时候展示
 *
 */
import React from 'react';
import PropTypes from 'prop-types';
import {StyleSheet, View} from 'react-native';
import {ExceptionView} from '../../../components';

export default class NoEvaluateFooter extends React.PureComponent {

    static propTypes = {};

    static defaultProps = {};

    constructor(props){
        super(props);
    }

    componentDidMount() {}

    render() {
        return (
            <View style={styles.footer}>
                <ExceptionView />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    footer: {
        height: 400,
    }
});