/**
 * @author ouyfm
 * @date 2020/06/23
 * @class
 * @description 回复EvaluateReplyCell
 */
import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text,Image } from 'react-native';
import { SeaGenderHeader } from '../../../components';
import { SeaColor, SeaTheme, SeaScale } from '../../../asserts';
import { SeaImageUtil, SeaString } from '../../../util';
import Moment from 'moment'

export default class EvaluateReplyCell extends React.PureComponent {
    static propTypes = {
        item: PropTypes.any,
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
    }

    componentDidMount() {}

    render() {
        const { item } = this.props;
        const replyId = _.get(item, 'replyId',"");  
        const evaluateParentId = _.get(item,'evaluateParentId',"");
        const replyUserName = _.get(item,'replyUserName',"");
        const content = SeaString.utf16Encoding(item.evaluateDetails);

        return (
            <View style={styles.cell}>
                <SeaGenderHeader
                    style={styles.header}
                    size={SeaScale.Layout(70)}
                    sex={item.sex}
                    source={(item.anonymous == 1)? null:this._imageSource(item)}
                />
                <View style={styles.contentView}>
                    <View style={styles.contentHeadContainer}>
                        <View style={styles.infoContainer}>
                            <View style={{flexDirection: 'row'}}>
                                <Text style={styles.name}>{item.anonymous == 1 ? '匿名' : item.evaluateUserName}</Text>
                                {item.evaluateStatus === '0' && (
                                <Image
                                    source={require('../../../asserts/images/case/ic_approving.png')}
                                    style={styles.approvingIcon}
                                />
                            )}
                            </View>
                            
                            <Text style={styles.date}>
                                {Moment(item.createTime).format('MM-DD HH:mm')}
                                {/* {SeaString.shortDateString(item.createTime, '未知')} */}
                            </Text>
                        </View>
                    </View>
                    {!replyId ? (
                        <Text style={styles.content}>{content}</Text>
                    ) : (
                        <Text style={styles.content}>
                            回复<Text style={{ color: SeaColor.main }}>{replyUserName}</Text>：{content}
                        </Text>
                    )}
                </View>
            </View>
        );
    }

    _imageSource = item => {
        return SeaImageUtil.getImageSource(item.evaluateUserImageId, item.replyImageId);
    };
}

const styles = StyleSheet.create({
    cell: {
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        paddingHorizontal: SeaTheme.h_spacing_md,
        flexDirection: 'row',
    },
    contentView: {
        marginLeft: SeaTheme.h_spacing_sm,
        flex: 1,
        borderBottomColor: SeaColor.parting_line,
        borderBottomWidth: SeaTheme.line_width_xs,
        paddingVertical: SeaTheme.v_spacing_sm,
    },
    header: {
        marginTop: SeaTheme.v_spacing_sm,
        marginLeft: SeaScale.Layout(10),
        width: SeaScale.Layout(70),
        height: SeaScale.Layout(70),
    },
    contentHeadContainer: {
        flexDirection: 'row',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    infoContainer: {
        flex: 1,
    },
    name: {
        fontSize: SeaTheme.font_size_sm,
    },
    date: {
        marginTop: SeaScale.Layout(12),
        fontSize: SeaTheme.font_size_xs,
        color: SeaColor.content_text,
    },
    content: {
        marginTop: SeaScale.Layout(8),
        fontSize: SeaTheme.font_size_sm,
        color: SeaColor.h2_text,
        lineHeight: SeaScale.Layout(38),
    },
    button: {
        width: SeaScale.Layout(80),
        height: SeaScale.Layout(80),
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
    },
    approvingIcon: {
        width: SeaScale.Layout(70),
        height: SeaScale.Layout(35),
        resizeMode: 'contain',
        marginLeft: SeaScale.Layout(20),
    },
});
