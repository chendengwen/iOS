/**
 * @author ouyfm
 * @date 2020/06/20
 * @class
 * @description 查看回复界面EvaluateReplyDetailPage
 */
import React from 'react';
import { Alert, DeviceEventEmitter } from 'react-native';
import PropTypes from 'prop-types';
import EvaluateReplyDetail from './EvaluateReplyDetail';
import { Actions } from 'react-native-router-flux';
import { FSLToast, FSLPrompt } from 'react-native-kpframework';
import { EvaluateService } from '../../../servie';
import { SeaConstant } from '../../../asserts';
import { IdentifyExtension } from '../../../redux';

export default class EvaluateReplyDetailPage extends React.PureComponent {
    static propTypes = {
        data: PropTypes.object,
        title: PropTypes.string,
        businessType: PropTypes.string,
        businessId: PropTypes.string,
        evaluateParentId: PropTypes.string,
        userId: PropTypes.string,
        pageTo: PropTypes.string,
        pageSize: PropTypes.string,
        evaluateUserId: PropTypes.string,
        evaluateUserName: PropTypes.string,
        replyId: PropTypes.string
    };

    static defaultProps = {};

    constructor(props) {
        super(props);
        this._loadingKey;
        this.state = { replyList: _.get(props, 'data.secList', []) };
        this.getInitData();
    }

    componentDidMount() {
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.Notification.RELOAD_CASEREPLY,
            this._reloadList
        );
        this.getItemList();
    }

    componentWillUnmount() {
        this.listener && this.listener.remove();
    }
    getInitData() {
        let userinfo = IdentifyExtension.getLoginUserInfo();
        this.userId = userinfo.id;
        this.userName = userinfo.userName;
    }
    render() {
        const { data } = this.props;
        const { replyList } = this.state;
        return (
            <EvaluateReplyDetail
                answer={data}
                replyList={replyList}
                needHeader={false}
                onReplyPress={this._onReplyPress}
                onReplyToPress={this._onReplyToPress}
                onDeletePress={this._onDeletePress}
            />
        );
    }
    // 长按@回复
    _onReplyToPress = item => {
        const { businessType, businessId, evaluateParentId } = this.props;
        const evaluateId = _.get(item, 'evaluateId');
        const evaluateUserId = _.get(item, 'evaluateUserId');
        const evaluateUserName = _.get(item, 'evaluateUserName');
        Actions.show('caseAddReply', {
            title: '回复',
            businessType: businessType,
            businessId: businessId,
            evaluateParentId: evaluateParentId,  //?
            evaluateUserId: this.userId,
            evaluateUserName: this.userName,
            replyId: evaluateId,
            replyUserId: evaluateUserId,
            replyUserName: evaluateUserName
        });
    };
    // 回复
    _onReplyPress = item => {
        const { businessType, businessId, evaluateParentId, evaluateUserId, evaluateUserName, replyId } = this.props;
        Actions.show('caseAddReply', {
            title: '回复',
            businessType: businessType,
            businessId: businessId,
            evaluateParentId: evaluateParentId,
            evaluateUserId: this.userId,
            evaluateUserName: this.userName,
            replyId: replyId,
            replyUserId: evaluateUserId,
            replyUserName: evaluateUserName
        });
    };

    _onDeletePress = (item, index) => {
        Alert.alert(
            '警告',
            '确定要删除这条回复吗？',
            [
                { text: '取消', style: 'cancel' },
                {
                    text: '删除',
                    style: 'destructive',
                    onPress: () => this._deleteReply(item, index),
                },
            ],
            { cancelable: false }
        );
    };

    _reloadList = data => {
        if (data.code == '000000') {
            this.getItemList();
        }
    };
    getItemList() {
        let nextProps = this.props;
        let parmas = {
            businessType: nextProps.businessType,
            businessId: nextProps.businessId,
            evaluateParentId: nextProps.evaluateParentId,
            userId: nextProps.userId,
            pageNo: nextProps.pageTo,
            pageSize: nextProps.pageSize
        };
        return EvaluateService.getCaseEvalate(parmas)
            .then(responseJson => {
                let dataJson = responseJson.data;
                this.setState({
                    replyList: dataJson.list
                })
            })
            .catch(error => {
                FSLToast.show(error.message);
                return Promise.reject(error);
            });
    }
    _deleteReply = async (item, index) => {
        // todo...
        try {
            const askId = _.get(this.props, 'data.askId');
            const replyId = _.get(item, 'id');
            this._loadingKey = FSLPrompt.loading('正在删除');
            // await QAService.deleteQAAnswer(replyId, askId);
            await EvaluateService.detetCaseEvalate(item.evaluateId);
            this.setState(prevState => ({
                replyList: _.chain(prevState.replyList)
                    .clone()
                    .remove((_, idx) => index != idx)
                    .value(),
            }));
            // 通知刷新回答列表
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_QAREPLY);
            DeviceEventEmitter.emit(SeaConstant.Notification.RELOAD_STATE)
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show('删除成功');
            if (this.state.replyList.length < 1) {
                Actions.pop()
            }
        } catch (error) {
            FSLPrompt.hide(this._loadingKey);
            FSLToast.show(error.message);
        }
    };
}
