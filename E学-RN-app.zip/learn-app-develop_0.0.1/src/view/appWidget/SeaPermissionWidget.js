/**
 * @author xukj
 * @date 2018/8/31
 * @description app启动时，用户使用权限处理
 */
import { Platform, Alert, PermissionsAndroid } from 'react-native';
import AppWidget from './core/AppWidget';

export default class SeaPermissionWidget extends AppWidget {
    didApplicationStart() {
        this._permissionRequest();
        // 执行完成后注销掉该widget，不用再监听
        this.unRegister();
    }

    _permissionRequest() {
        if (Platform.OS === 'android') {
            let pa = new PermissionsAndroid.constructor();

            let permissions = [
                pa.PERMISSIONS.CAMERA,
                pa.PERMISSIONS.READ_PHONE_STATE,
                pa.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
                pa.PERMISSIONS.READ_EXTERNAL_STORAGE,
                pa.PERMISSIONS.RECORD_AUDIO,
                pa.PERMISSIONS.ACCESS_FINE_LOCATION,
            ];
            pa.requestMultiple(permissions)
                .then(ret => {
                    let hasAllPer = true;
                    let keys = Reflect.ownKeys(ret);
                    // for(){
                    //     if(ret[key]!=='granted') hasAllPer=false;
                    //
                    // }
                    keys.map((v, i) => {
                        if (ret[v] !== 'granted') hasAllPer = false;
                    });
                    if (!hasAllPer) {
                        Alert.alert(
                            '授权提示',
                            'App部分功能将使用手机存储、获取电话信息、摄像头、录音、位置等权限，如果App没有获得这些权限，将导致部分功能不可用，请到手机应用设置中配置这些权限，谢谢。',
                            [{ text: '我知道了' }],
                            { cancelable: false }
                        );
                    }
                })
                .catch(error => {
                    console.log(error);
                });
        }
    }
}
