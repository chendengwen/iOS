/**
 * @author xukj
 * @date 2020/01/07
 * @description SeaAdsWidget 广告获取
 */
import AppWidget from './core/AppWidget';
import { SeaAds } from '../../util';

export default class SeaAdsWidget extends AppWidget {
    constructor(props) {
        super(props);
        // 获取广告的延时
        this.timer = null;
    }

    didApplicationStart() {
        // 获取广告
        this._getAds();
    }

    didApplicationActive() {
        // 获取广告
        this._getAds();
    }

    didApplicationBackground() {}

    didApplicationDestroy() {}

    // 广告 - 延迟 10秒
    // ---

    _getAds = () => {
        this.timer && clearTimeout(this.timer);
        const DELAY = 10000;
        setTimeout(SeaAds.prepareAds, DELAY);
    };
}
