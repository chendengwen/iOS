/**
 * @author xukj
 * @date 2019/03/28
 * @description app通过外部链接打开
 * 外部链接指定格式
 * studysmart365://来自/操作/类别/自定义部分/自定义部分/...
 * 例: 打开指定的阅读详情页
 * studysmart365://h5/open/detail/4/122123-2333-4444-888999
 */
import { Linking, Alert, Platform } from 'react-native';
import AppWidget from './core/AppWidget';
import { UserSessionManager } from '../login';
import { ResourceActions } from '../resource';

export default class SeaDeviceEventWidget extends AppWidget {
    didApplicationStart() {
        Linking.addEventListener('url', this._handleOpenURL);

        // android 注册比iOS晚需要直接获取
        if (Platform.OS == 'android') {
            (async () => {
                try {
                    const url = await Linking.getInitialURL();
                    setTimeout(() => {
                        this._handleOpenURL({ url });
                    }, 3000);
                } catch (error) {}
            })();
        }
    }

    didApplicationDestroy() {
        Linking.removeEventListener('url');
    }

    /**
     * @private
     * @description 打开url
     */
    _handleOpenURL = event => {
        console.log('openUrl', event.url);
        // 未登录用户不处理
        if (!UserSessionManager.isLogin()) {
            return;
        }

        // 错误的链接
        if (_.isEmpty(event.url)) {
            return;
        }

        try {
            // 执行链接的命令
            ResourceActions.link(event.url);
        } catch (error) {
            Alert.alert('提示', error.message, [{ text: '确定' }], { cancelable: false });
        }
    };
}
