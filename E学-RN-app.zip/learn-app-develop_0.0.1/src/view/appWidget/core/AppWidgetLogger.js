/**
 * @author xukj
 * @date 2018/8/31
 * @description 日志
 */

export default value => {
    console.log('appWidget', value);
};
