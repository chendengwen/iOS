/**
 * @author xukj
 * @date 2018/8/31
 * @description 非展示组件管理器。通过监听app的各个状态来通知注册的各个组件完成对应的操作
 */
import {AppState} from 'react-native'
import AppWidgetStore from './AppWidgetStore';
import logger from './AppWidgetLogger';

class AppWidgetManager {

    /**
     * @description 注册所有的widget
     * @param {Array<AppWidget>} [widgets]
     */
    registerAllWidget(widgets) {
        widgets.forEach((widget) => {
            widget.register();
        });
    }

    /**
     * @description 注销所有的widget
     */
    unregisterAllWidget() {
        const widgets = AppWidgetStore.allAppWidgets().concat();
        widgets.forEach((widget) => {
            widget.unRegister();
        });
    }

    /**
     * @description 激活所有注册的widget，监听app的各个状态
     */
    activeAllWidget() {
        AppState.addEventListener('change', this._appStateChangeHandler);
        AppState.addEventListener('memoryWarning', this._appStateMemoryWarningHandler);
        this._appStateStartHandler();
    }

    /**
     * @description 冻结所有注册的widget，即不再监听app的各个状态
     */
    inactiveAllWidget() {
        AppState.removeEventListener('change', this._appStateChangeHandler);
        AppState.removeEventListener('memoryWarning', this._appStateMemoryWarningHandler);
        this._appStateDestroyHandler();
    }

    /*
     * @private
     * @description app启动
     */
    _appStateStartHandler() {
        logger({ state: 'start' });
        const widgets = AppWidgetStore.allAppWidgets().concat();
        widgets.forEach((widget) => {
            widget.didApplicationStart();
        });
    }

    /*
     * @private
     * @description app销毁
     */
    _appStateDestroyHandler() {
        logger({ state: 'destroy' });
        const widgets = AppWidgetStore.allAppWidgets().concat();
        widgets.forEach((widget) => {
            widget.didApplicationDestroy();
        });
    }

    /*
     * @private
     * @description app状态变化
     */
    _appStateChangeHandler(appState) {
        logger({ state: appState });
        const widgets = AppWidgetStore.allAppWidgets().concat();
        switch (appState) {
            case 'active':
                widgets.forEach((widget) => {
                    widget.didApplicationActive();
                });
                break;
            case 'background':
                widgets.forEach((widget) => {
                    widget.didApplicationBackground();
                });
                break;
            case 'inactive':
                widgets.forEach((widget) => {
                    widget.didApplicationInactive();
                });
                break;
            default:
                break;
        }
    }

    /*
     * @private
     * @description app内存警告
     */
    _appStateMemoryWarningHandler() {
        logger({ state: 'memoryWarning' });
        const widgets = AppWidgetStore.allAppWidgets().concat();
        widgets.forEach((widget) => {
            widget.didApplicationMemoryWarning();
        });
    }
}

export default new AppWidgetManager();