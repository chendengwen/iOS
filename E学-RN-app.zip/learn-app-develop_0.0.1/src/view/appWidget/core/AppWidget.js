/**
 * @author xukj
 * @date 2018/8/31
 * @description 非展示业务组件父类，所有的该类组件必须继承该父类
 */
import AppWidgetStore from './AppWidgetStore';

export default class AppWidget {

    /**
     * @description app启动时自动调用
     */
    didApplicationStart() {
        // 子类实现
    }

    /**
     * @description app切换到前台时自动调用
     */
    didApplicationActive() {
        // 子类实现
    }

    /**
     * @description app未激活时自动调用(无交互感应)
     */
    didApplicationInactive() {
        // 子类实现
    }

    /**
     * @description app切换到后台时自动调用（请勿执行耗时异步操作）
     * 耗时异步操作会失败
     */
    didApplicationBackground() {
        // 子类实现
    }

    /**
     * @description app销毁时自动调用（请勿执行耗时异步操作）
     * 耗时异步操作会失败
     */
    didApplicationDestroy() {
        // 子类实现
    }

    /**
     * @description app内存警告时自动调用
     */
    didApplicationMemoryWarning() {
        // 子类实现
    }

    /**
     * @description 注册成功时自动调用
     */
    didRegister() {
        // 子类实现
    }

    /**
     * @description 注销时自动调用
     */
    didUnRegister() {
        // 子类实现
    }

    /**
     * @description 注册
     */
    register() {
        AppWidgetStore.addAppWidget(this);
        this.didRegister();
    }

    /**
     * @description 注销
     */
    unRegister() {
        AppWidgetStore.removeAppWidget(this);
        this.didUnRegister();
    }
}