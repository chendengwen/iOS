/**
 * @author xukj
 * @date 2018/8/31
 * @description app非展示业务组件, 加入后即表示生效，移除就失效
 */
import AppWidget from './AppWidget';
import logger from './AppWidgetLogger';
import _ from 'lodash';

/**
 * 非展示业务组件缓存
 * @type {Array<AppWidget>}
 */
let appWidgets = [];

/**
 * @description 新增非业务组件
 * @param {AppWidget} [widget]
 */
function addAppWidget(widget) {
    if (widget instanceof AppWidget) {
        appWidgets.push(widget);
        logger({ 'register': widget });
    }
}

/**
 * @description 移除非业务组件
 * @param {AppWidget} [widget]
 */
function removeAppWidget(widget) {
    _.remove(appWidgets, (n) => {
        const result = n === widget;
        if (result) {
            logger({ 'unRegister': widget });
        }
        return n === widget;
    });
}

/**
 * @description 所有生效的非业务组件
 * @return {Array<AppWidget>}
 */
function allAppWidgets() {
    return appWidgets;
}

export default {
    allAppWidgets,
    addAppWidget,
    removeAppWidget,
}