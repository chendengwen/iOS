/**
 * @author xukj
 * @date 2020/01/07
 * @description SeaLogoWidget logo切换
 */
import AppWidget from './core/AppWidget';
import { SeaNative } from '../../util';
import moment from 'moment';

export default class SeaLogoWidget extends AppWidget {
    constructor(props) {
        super(props);
        // 获取广告的延时
        this.timer = null;
    }

    didApplicationStart() {
        // 切换logo
        this._changeAppLogo();
    }

    didApplicationActive() {
        // 切换logo
        this._changeAppLogo();
    }

    didApplicationBackground() {}

    didApplicationDestroy() {}

    // 切换logo - 延迟 5秒
    // ---

    _changeAppLogo = () => {
        this.timer && clearTimeout(this.timer);
        const DELAY = 5000;
        // 春节(1.15-2.8)
        // 劳动节(4.27-5.8)
        // 端午节(6.22-6.30)
        // 教师节(9.4-9.13)
        // 国庆节(9.28-10.16)
        // 2021(2020.12.30-2021.1.10)
        const FESTIVAL_LIST = [
            { start: '2020-01-15', end: '2020-02-09', logo: 'logo02' },
            { start: '2020-04-27', end: '2020-05-09', logo: 'logo03' },
            { start: '2020-06-22', end: '2020-07-01', logo: 'logo04' },
            { start: '2020-09-04', end: '2020-09-14', logo: 'logo05' },
            { start: '2020-09-28', end: '2020-10-17', logo: 'logo07' },
            { start: '2020-12-30', end: '2021-01-11', logo: 'logo08' },
        ];

        // 因为不能立即执行，这里需要延迟5秒后执行操作
        this.timer = setTimeout(() => {
            const festival = _.find(FESTIVAL_LIST, value =>
                moment().isBetween(value.start, value.end)
            );
            const useName = festival ? festival.logo : 'logo01';

            SeaNative.useAppLogo(useName, error => {
                console.log('使用logo', { error, useName });
            });
        }, DELAY);
    };
}
