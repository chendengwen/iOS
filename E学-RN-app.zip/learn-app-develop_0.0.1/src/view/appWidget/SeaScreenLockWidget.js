/**
 * Created by zk on 2018/9/13.
 */
import AppWidget from './core/AppWidget';
import Orientation from 'react-native-orientation-locker'

export default class SeaScreenLockWidget extends AppWidget {
    
    didApplicationStart() {
        //锁定App到竖屏
        console.log('锁定竖屏')
        Orientation.lockToPortrait()
    }
}