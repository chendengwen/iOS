/**
 * @author xukj
 * @date 2019/03/28
 * @description 全局通知接收并处理业务
 */
import { DeviceEventEmitter, Alert } from 'react-native';
import AppWidget from './core/AppWidget';
import { UserSessionManager } from '../login';
import { SeaConstant } from '../../asserts';

export default class SeaDeviceEventWidget extends AppWidget {
    constructor(props) {
        super(props);
        // 注销提示
        this.sessionErrorEvent = null;
        this.alertShow = false;
    }

    didApplicationStart() {
        this.alertShow = false;

        // 登出通知
        this.sessionErrorEvent = DeviceEventEmitter.addListener(
            SeaConstant.SeaGlobalEventType.LOGOUT,
            this._logout
        );
    }

    didApplicationActive() {}

    didApplicationBackground() {}

    didApplicationDestroy() {
        this.sessionErrorEvent.remove();
    }

    // 登出监听
    // ---

    /**
     * @private
     * @description 弹出超时提示框，并登出系统
     */
    _logout = error => {
        // 修复重复弹出登出提示框
        if (this.alertShow || !UserSessionManager.isLogin()) return;
        this.alertShow = true;
        Alert.alert(
            '提示',
            error.message,
            [{ text: '确定', type: 'cancel', onPress: () => (this.alertShow = false) }],
            { cancelable: false }
        );
        UserSessionManager.signOut();
    };
}
