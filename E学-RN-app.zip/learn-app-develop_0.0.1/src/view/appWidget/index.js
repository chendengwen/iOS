/**
 * @author xukj
 * @date 2018/8/31
 * @description app的非展示业务模块。包括后台定时业务、app开关业务、socket接收业务等
 * 使用方法例：需要在app退到后台时执行上报逻辑pv
 * 1.创建
 * class SeaPVWidget extends AppWidget {
 *
 *   didApplicationActive() {
 *     // 上传pv操作...
 *   }
 *
 *   didApplicationBackground() {
 *     // 上传pv操作...
 *   }
 * }
 * 2.实现需要监听的状态
 * didApplicationStart()
 * didApplicationActive()
 * didApplicationInactive()
 * didApplicationBackground()
 * didApplicationDestroy()
 * didApplicationMemoryWarning()
 * didRegister()
 * didUnRegister()
 * 3.需要到本文件的widgets中添加初始化方法 new SeaPVWidget()
 */
import AppWidgetManager from './core/AppWidgetManager';
import SeaPermissionWidget from './SeaPermissionWidget';
import SeaScreenLockWidget from './SeaScreenLockWidget';
import SeaReportWidget from './SeaReportWidget';
import SeaDeviceEventWidget from './SeaDeviceEventWidget';
import SeaLinkingWidget from './SeaLinkingWidget';
import SeaAdsWidget from './SeaAdsWidget';
import SeaLogoWidget from './SeaLogoWidget';

export default function configAppWidget() {
    const widgets = [
        // 权限提醒
        new SeaPermissionWidget(),
        //锁屏竖屏
        new SeaScreenLockWidget(),
        // 上报数据
        new SeaReportWidget(),
        // 全局通知监听
        new SeaDeviceEventWidget(),
        // 打开linking
        new SeaLinkingWidget(),
        // 广告获取
        new SeaAdsWidget(),
        // 切换logo逻辑
        new SeaLogoWidget(),
        // TODO 这里添加新的widget
    ];
    // 注册定义好的widget
    AppWidgetManager.registerAllWidget(widgets);

    /**
     * @description 配置器
     */
    const configuration = () => {};

    /**
     * @description app启动时调用
     */
    configuration.didAppStart = () => {
        AppWidgetManager.activeAllWidget();
    };

    /**
     * @description app销毁时调用
     */
    configuration.didAppDestroy = () => {
        AppWidgetManager.inactiveAllWidget();
    };

    return configuration;
}
