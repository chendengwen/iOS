/**
 * @author xukj
 * @date 2018/12/10
 * @description SeaReportWidget app上报信息
 *
 * modify by xukj - 1.27.0
 * 调整为上报收集到的所有用户信息，数据模型
[
    { userId: "xxx0", type: "pv", data:"{amount: 10}" },
    { userId: "xxx0", type: "learn-track", data:"[{"resourceId":"552fb7e9-1d24-4f4a-b815-cc70d8abfdae","snapshotId":"43adac3f-64ae-48a3-8d99-1aba3f20d95e","contentId":"47f5bea4-b9e7-4cab-9dda-b8746f9a29e3","type":1,"duration":65,"timestamp":1554101373615}]" },
    { userId: "xxx1", type: "learn-track", data:"[{"resourceId":"552fb7e9-1d24-4f4a-b815-cc70d8abfdae","snapshotId":"43adac3f-64ae-48a3-8d99-1aba3f20d95e","contentId":"47f5bea4-b9e7-4cab-9dda-b8746f9a29e3","type":1,"duration":65,"timestamp":1554101373615}]" },
    { userId: "xxx2", type: "learn-track", data:"[{"resourceId":"552fb7e9-1d24-4f4a-b815-cc70d8abfdae","snapshotId":"43adac3f-64ae-48a3-8d99-1aba3f20d95e","contentId":"47f5bea4-b9e7-4cab-9dda-b8746f9a29e3","type":1,"duration":65,"timestamp":1554101373615}]" },
    ...
]
 */
import { DeviceEventEmitter } from 'react-native';
import AppWidget from './core/AppWidget';
import { SeaStudyTimeUtil, SeaPVUtil, SeaPlayProgressUtil } from '../../util';
import { CommonService, ExceptionService } from '../../servie';
import { SeaConstant } from '../../asserts';
import { IdentifyExtension } from '../../redux';

// 定时上报：1分钟
const INTERVAL_DURATION = 1 * 60 * 1000;
// 请求频率控制：1分钟
const REPORT_FREQUENCY = 1 * 60 * 1000;

export default class SeaReportWidget extends AppWidget {
    constructor(props) {
        super(props);
        this.reporting = false;
        this.latestDate = 0; // 最近一次上报时间
        this.timer;
        this.listener;
    }

    didApplicationStart() {
        this.timer = setInterval(this._report, INTERVAL_DURATION);
        this.listener = DeviceEventEmitter.addListener(
            SeaConstant.SeaGlobalEventType.REPORT,
            this._reportByFinish
        );
    }

    didApplicationActive() {
        this._report();
    }

    didApplicationBackground() {
        // 进入后台时，js bridge会被关闭，这里不能执行异步耗时操作
    }

    didApplicationDestroy() {
        this.timer && clearInterval(this.timer);
        this.listener && this.listener.remove();
    }

    /**
     * @private
     * @description 执行上报逻辑
     */
    _report = async () => {
        try {
            console.log('report');
            // 1. 是否正在上报/上一次上报是否超过2分组
            if (this.reporting) return;
            const diff = new Date().getTime() - this.latestDate;
            if (diff < REPORT_FREQUENCY) return;

            // 开始上报逻辑
            // ---
            this.reporting = true;
            // 2. 执行数据组装
            let values = [];
            // 2.1 pv上报
            const pvData = await this._loadPVData();
            if (pvData) {
                values = values.concat(pvData);
            }
            // 2.2 学习时长
            const timeData = await this._loadStudyTimeData();
            if (timeData) {
                values = values.concat(timeData);
            }
            // 2.3 学习进度
            const progressData = await this._loadPlayProgressData();
            if (progressData) {
                values = values.concat(progressData);
            }
            // 3. 执行上报
            if (values && values.length > 0) {
                await CommonService.reportData(values);

                // 4. 执行清空缓存
                await Promise.all([
                    SeaPVUtil.resetPVData(),
                    SeaStudyTimeUtil.resetUserStudyTime(),
                    SeaPlayProgressUtil.resetUserPlayProgress(),
                ]);

                // 5. 记录上报时间
                this.latestDate = new Date().getTime();
            }
            this.reporting = false;
        } catch (error) {
            console.log('report', error);
            this.reporting = false;
            // 不记录上报频繁的报错
            if (error && error.code == 412) return;
            // 提交错误到服务器作分析
            const userinfo = IdentifyExtension.getLoginUserInfo();
            ExceptionService.sendException({
                type: '上报学时',
                content: error === undefined ? '未定义' : error.message + ' ' + error.stack,
                phone: userinfo ? userinfo.id : null,
            });
        }
    };

    /**
 * @private
 * @description 执行手动上报逻辑
 */
    _reportByFinish = async () => {
        try {
            let values = [];
            // 2.1 pv上报
            const pvData = await this._loadPVData();
            if (pvData) {
                values = values.concat(pvData);
            }
            // 2.2 学习时长
            const timeData = await this._loadStudyTimeData();
            if (timeData) {
                values = values.concat(timeData);
            }
            // 2.3 学习进度
            const progressData = await this._loadPlayProgressData();
            if (progressData) {
                values = values.concat(progressData);
            }
            // 3. 执行上报
            if (values && values.length > 0) {
                await CommonService.reportData(values);

                // 4. 执行清空缓存
                await Promise.all([
                    SeaPVUtil.resetPVData(),
                    SeaStudyTimeUtil.resetUserStudyTime(),
                    SeaPlayProgressUtil.resetUserPlayProgress(),
                ]);
            }
        } catch (error) {
            console.log('report', error);
            // 不记录上报频繁的报错
            if (error && error.code == 412) return;
            // 提交错误到服务器作分析
            const userinfo = IdentifyExtension.getLoginUserInfo();
            ExceptionService.sendException({
                type: '上报学时',
                content: error === undefined ? '未定义' : error.message + ' ' + error.stack,
                phone: userinfo ? userinfo.id : null,
            });
        }
    };

    /**
     * @private
     * @description 准备上报数据，封装成服务器可以识别的结构
     * @param {string} userId 登录用户id
     */
    _prepareReportData = (userId, type, data) => {
        return { userId, type, data };
    };

    /**
     * @private
     * @description pv数据
     * @resolve {array}
     */
    _loadPVData = () => {
        return SeaPVUtil.getPVData()
            .then(data => {
                const pv = JSON.stringify(data);
                const value = this._prepareReportData(
                    undefined,
                    'pv',
                    JSON.stringify({ amount: pv })
                );
                return Promise.resolve([value]);
            })
            .catch(() => {
                return Promise.resolve();
            });
    };

    /**
     * @private
     * @description 学时时长数据
     * @resolve {array}
     */
    _loadStudyTimeData = () => {
        return SeaStudyTimeUtil.getUserStudyTimes()
            .then(data => {
                // 转换为上报识别的数据结构
                const value = _.chain(data)
                    .groupBy('userId')
                    .mapValues((value, key) =>
                        this._prepareReportData(key, 'learn-track', JSON.stringify(value))
                    )
                    .values()
                    .value();

                if (value && value.length > 0) {
                    // 判断数组长度
                    return Promise.resolve(value);
                } else {
                    return Promise.resolve();
                }
            })
            .catch(() => {
                return Promise.resolve();
            });
    };

    /**
     * @private
     * @description 学习进度数据
     * @param {string} userId 登录用户id
     */
    _loadPlayProgressData = () => {
        return SeaPlayProgressUtil.getUserPlayProgress()
            .then(data => {
                // 转换为上报识别的数据结构
                const value = _.chain(data)
                    .groupBy('userId')
                    .mapValues((value, key) =>
                        this._prepareReportData(key, 'play-progress', JSON.stringify(value))
                    )
                    .values()
                    .value();
                if (value && value.length > 0) {
                    return Promise.resolve(value);
                } else {
                    return Promise.resolve();
                }
            })
            .catch(() => {
                return Promise.resolve();
            });
    };

    /**
     * @private
     * @description 上报成功后，情况本地数据
     * @param {string} userId 登录用户id
     */
    _clearReport = userId => { };
}
