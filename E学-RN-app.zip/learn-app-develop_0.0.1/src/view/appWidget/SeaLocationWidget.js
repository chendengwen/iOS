/**
 * @author xukj
 * @date 2020/01/07
 * @description SeaLocationWidget 定位逻辑
 */
import AppWidget from './core/AppWidget';
import { SeaLocation } from '../../util';

export default class SeaLocationWidget extends AppWidget {
    constructor(props) {
        super(props);
        // 获取广告的延时
        this.timer = null;
    }

    didApplicationStart() {
        this._startLocation();
    }

    didApplicationActive() {
        this._startLocation();
    }

    didApplicationBackground() {
        this._stopLocation();
    }

    didApplicationDestroy() {}

    // 定位
    // ---

    _startLocation = () => {
        SeaLocation.startLocation(
            locate => {
                console.log('locate', locate);
                // DeviceEventEmitter.emit(
                //     'sea-location',
                //     `${locate.coords.longitude},${locate.coords.latitude}`
                // );
            },
            error => {
                console.log('locate', error);
                // DeviceEventEmitter.emit('sea-location', error.message);
            }
        );
    };

    _stopLocation = () => {
        SeaLocation.stopLocation();
    };
}
