/**
 * @author xukj
 * @date 2019/08/28
 * @description 屏幕、分辨率、字体适配
 */
import { Dimensions, PixelRatio, StyleSheet } from 'react-native';

/**
 * @description 设计图相关信息
 * 标准: iPhone 6
 */
const DESIGN_WIDTH_PX = 750;
const DESIGN_HEIGHT_PX = 1334;
const DESIGN_RATIO = 2;
const DESIGN_WIDTH_DP = DESIGN_WIDTH_PX / DESIGN_RATIO; // 设计图宽度,单位dp
const DESIGN_HEIGHT_DP = DESIGN_HEIGHT_PX / DESIGN_RATIO; // 设计图高度,单位dp

/**
 * @description 当前设备相关信息
 */
// 设备屏幕高宽, 单位dp
const { width, height } = Dimensions.get('window');
// 设备长边
const longSide = Math.max(width, height);
// 设备短边
const shortSide = Math.min(width, height);
// 像素密度
const pixelRatio = PixelRatio.get();

/**
 * @description 缩放、计算
 */
// dp缩放比例
const widthScale = width / DESIGN_WIDTH_DP; // 当前屏幕相对设计图的宽度缩放比例
const heightScale = height / DESIGN_HEIGHT_DP; // 当前屏幕相对设计图的高度缩放比例
const minScale = Math.min(widthScale, heightScale); // 当前屏幕相对设计图的推荐缩放比例
// 字体缩放比例
const fontScale = PixelRatio.getFontScale();

// 在global中设置通用 $scale
export default $scale = {
    /**
     * 适配真实设备宽, 特殊情况下使用. 一般情况下请使用 @see Size(size)
     * @param {number} size 设计图的宽度px
     * @return {number} dp
     */
    LayoutW: function(size) {
        return Math.round((size * widthScale) / DESIGN_RATIO + 0.5);
    },
    /**
     * 适配真实设备高, 特殊情况下使用. 一般情况下请使用 @see Size(size)
     * @param {number} size 设计图的高度px
     * @return {number} dp
     */
    LayoutH: function(size) {
        return Math.round((size * heightScale) / DESIGN_RATIO + 0.5);
    },
    /**
     * 适配真实设备px, 一般只需要使用该方法计算dp即可
     * @param {number} size 设计图的px
     * @return {number} dp
     */
    Layout: function(size) {
        return Math.round((size * minScale) / DESIGN_RATIO + 0.5);
    },
    /**
     * 适配真实设备字体
     * @param {number} size 设计图字体pt
     * @return {number} dp
     */
    Font: function(size) {
        return Math.round((size * minScale) / fontScale / DESIGN_RATIO + 0.5);
    },
    /**
     * 屏幕宽度dp
     */
    screenWidth: width,
    /**
     * 屏幕高度dp
     */
    screenHeight: height,
    /**
     * 默认分割线宽度: 1px
     */
    spWidth: StyleSheet.hairlineWidth,
    /**
     * @deprecated 今后不再使用
     */
    scaleVertical: height / 1334.0,
    scaleHorizontal: width / 750.0,
    longSide,
    shortSide,
};
