/**
 * @author xukj
 * @date 2019/07/25
 * @description 通用样式
 */
import { StyleSheet } from 'react-native';
import SeaColor from './SeaColor';
import SeaScale from './SeaScale';
import SeaTheme from './SeaTheme';

// 在global中设置通用 $style
export default $style = StyleSheet.create({
    // 页面背景样式
    // ---
    // 页面
    page: {
        flex: 1,
        backgroundColor: '#ffffff',
    },

    // 列表
    list: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
    },

    // 案例中心列表
    cassList: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        paddingRight:10,
        paddingLeft:10,
    },

    // 案例管理列表
    caseManageList: {
        flex: 1,
        backgroundColor: SeaColor.defaultBackgroudColor_3,
        paddingLeft: SeaScale.Layout(10),
        paddingRight: SeaScale.Layout(10),
        paddingTop: SeaScale.Layout(5),
    },

    greyPage: {
        flex: 1,
        backgroundColor: SeaColor.bg_grey_color,
    },

    // 布局样式
    // ---
    // 列布局，居中
    center: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    // 行布局，垂直居中
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },

    // 导航
    // ---
    // 导航栏
    nav: {},

    // 导航栏标题
    navTitle: {
        color: '#333333',
        fontSize: SeaTheme.font_size_xxxl,
        fontWeight: 'normal',
    },
});
