/**
 * @author xukj
 * @date 2019/09/09
 * @description SeaTheme 主题定义
 * 见文档:App视觉规范.png
 */
import { StyleSheet } from 'react-native';
import SeaScale from './SeaScale';
import SeaColor from './SeaColor';


const font = {
    size: {
        xxxxl: SeaScale.Font(60), // 标题文字，信息层级最高
        xxxl: SeaScale.Font(36), // 顶部栏文字、模块标题
        xxl: SeaScale.Font(34), // 按钮文字
        xl: SeaScale.Font(32), // 列表文字、栏目标题
        lg: SeaScale.Font(30), // 列表标题或需要强调的正文
        md: SeaScale.Font(28), // 归类性标题
        sm: SeaScale.Font(26), // tab栏、表格内数据或正文、小标题
        xs: SeaScale.Font(24), // 次要文字(过小，不推荐使用字号)
        xxs: SeaScale.Font(22), // app中最小字号(过小，不推荐使用字号)
    }
}

const radius = {
    lg: SeaScale.Layout(16),
    md: SeaScale.Layout(8),
    sm: SeaScale.Layout(4),
}

//详情页底部操作栏
const footerToolBar = {
    box: {
        flexDirection: 'row',
        width: SeaScale.screenWidth,
        // height: SeaScale.Layout(120),
        padding: SeaScale.Layout(5),
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: '#ddd',
        backgroundColor: "#fcfbfa",
    },
    boxAutoFix: {
        flexDirection: 'row',
        width: SeaScale.screenWidth,
        // height: SeaScale.Layout(120),
        padding: SeaScale.Layout(26),
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: '#ddd',
        backgroundColor: "#fcfbfa",
        // backgroundColor: "#ff0",
        justifyContent: 'space-around',
    },
    buttonMain: {
        flex: 1,
        height: SeaScale.Layout(68),
        marginLeft: SeaScale.Layout(10),
        borderRadius: radius.md,
    },
    buttonMainText: {
        fontSize: font.size.lg,
    },
    buttonAsside: {
        paddingLeft: SeaScale.Layout(5),
        paddingRight: SeaScale.Layout(5),
        height: SeaScale.Layout(68),
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonAssideText: {
        color: SeaColor.content_text,
        marginTop: SeaScale.Layout(6),
        fontSize: font.size.xxs,
        width: SeaScale.Layout(68),
        textAlign: 'center',
    },
    icon: {
        // height: SeaScale.Layout(45),
        // backgroundColor: "red",
        // width: SeaScale.Layout(38),
        height: SeaScale.Layout(38),
        alignItems: 'center',
    },
};

//章节列表
const chapters = {
    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '#fff',
    },
    box: {
        flex: 1,
        flexDirection: 'column',
    },
    resourceTypeFlag: {
        width: SeaScale.Layout(68),
        height: SeaScale.Layout(30),
        backgroundColor: "#F9F9F9",
        borderWidth: StyleSheet.hairlineWidth,
        borderRadius: radius.lg,
        borderColor: "#ddd",
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: SeaScale.Layout(10),
    },
    resourceTypeText: {
        fontSize: SeaScale.Font(22),
        color: "#999",
    },
    chapter: {
        height: SeaScale.Layout(70),
        backgroundColor: SeaColor.grey5,
        alignItems: 'center',
        // marginTop: SeaScale.Layout(10),
        flexDirection: 'row',
        paddingLeft: SeaScale.Layout(8),
        paddingRight: SeaScale.Layout(8),
    },
    contentHeight: SeaScale.Layout(120),
    content: {
        flexDirection: 'row',
        padding: SeaScale.Layout(16),
        // alignItems: 'center',
        // height: SeaScale.Layout(100),
    },
    contentBody: {
        flex: 1,
    },
    t1: {
        fontSize: font.size.md,
        color: '#333',
    },
    t2: {
        marginTop: SeaScale.Layout(8),
        color: SeaColor.content_text,
        fontSize: font.size.xs,
    },
    contentFooter: {
        width: SeaScale.Font(100),
    },
    statusIcon: {
        height:SeaScale.Font(36),
    },
    choose: {
        color: SeaColor.main,
    },
}

export default $theme = {
    // 文字大小
    // ---
    font_size_xxxxl: SeaScale.Font(60), // 标题文字，信息层级最高
    font_size_xxxl: SeaScale.Font(36), // 顶部栏文字、模块标题
    font_size_xxl: SeaScale.Font(34), // 按钮文字
    font_size_xl: SeaScale.Font(32), // 列表文字、栏目标题
    font_size_lg: SeaScale.Font(30), // 列表标题或需要强调的正文
    font_size_md: SeaScale.Font(28), // 归类性标题
    font_size_sm: SeaScale.Font(26), // tab栏、表格内数据或正文、小标题
    font_size_xs: SeaScale.Font(24), // 次要文字(过小，不推荐使用字号)
    font_size_xxs: SeaScale.Font(22), // app中最小字号(过小，不推荐使用字号)

    // 间距样式
    // ---
    // 水平
    h_spacing_md: SeaScale.Layout(30),
    h_spacing_sm: SeaScale.Layout(20),

    // 垂直
    v_spacing_md: SeaScale.Layout(30),
    v_spacing_sm: SeaScale.Layout(20),
    v_spacing_xs: SeaScale.Layout(10),

    // 圆角
    // ---
    raduis_lg: SeaScale.Layout(16),
    raduis_md: SeaScale.Layout(8),
    raduis_sm: SeaScale.Layout(4),

    // 边框线宽度
    // ---
    line_width_sm: 1, // 根据屏幕像素密度计算
    line_width_xs: StyleSheet.hairlineWidth, // 1px

    // 图标大小
    // ---
    icon_size_md: SeaScale.Layout(50),

    // 普通列表高度
    // ---
    row_height_lg: SeaScale.Layout(140),
    row_height_md: SeaScale.Layout(100),

    // 颜色定义
    // ---
    // 背景颜色
    color_bg_gray1: '#F5F5F5', // 背景颜色 - 浅灰，页面
    color_bg_gray2: '#E5E5E5', // 背景颜色 - 浅灰，封面

    // 文字颜色
    color_txt_h1: '#333', // 文字颜色 - 一级黑，大标题
    color_txt_h2: '#666', // 文字颜色 - 二级深灰，小标题
    color_txt_h3: '#6d6d6d', // 文字颜色 - 三级深灰，导航字体色
    color_txt_h4: '#9A9A9A', // 文字颜色 - 浅灰，内容/辅助次要文字
    color_txt_tag: '#99A4BF', // 文字颜色 - 标签性文字（下载提示）

    // 图标颜色
    color_ic_orange: '#FDB26F', // 图标颜色 - 橘
    color_ic_blue: '#6CB2FF', // 图标颜色 - 蓝
    color_ic_green: '#70C664', // 图标颜色 - 绿
    color_ic_red: '#FD6B6D', // 图标颜色 - 红
    color_ic_main: '#378cdc', // 图标颜色 - 主色调
    color_ic_grey: '#808080', // 图标颜色 - 深灰

    // 按钮颜色
    color_btn_main: '#378cdc', // 按钮颜色 - 主色调
    color_btn_orange: '#FFA42F', // 按钮颜色 - 橘
    color_btn_blue: '#4BA7FC', // 按钮颜色 - 蓝
    color_btn_green: '#6DC85F', // 按钮颜色 - 绿
    color_btn_grey: '#A0A0A0', // 按钮颜色 - 深灰（不可点击）

    // 标签颜色
    color_tag_orange: '#FFA42F', // 标签颜色 - 橘
    color_tag_blue: '#8BCAF1', // 标签颜色 - 蓝
    color_tag_green: '#70BFB3', // 标签颜色 - 绿
    color_tag_red: '#ED7D71', // 标签颜色 - 红
    color_tag_yellow: '#F2D37A', // 标签颜色 - 黄
    color_tag_mpurple: '#B6C5F2', // 标签颜色 - 适中的紫色

    //师课中心
    color_teacher_label:'#e2f7fd',   //标签颜色
    color_teacher_border:'#2ec4fd',   //标签边框颜色
    color_teacher_back:'#485361', //详情背景色
    color_teacher_class:'#49D16D',   //课程名称
    color_teacher_classify:'#626262',  //课程分类名称

    // 其他颜色
    color_main: '#378cdc', // app主色调 - 蓝
    color_line: '#E5E5E5', // 分割线/边框颜色 - 灰
    color_white: '#FFFFFF', // 白
    color_black: '#000000', // 黑
    color_grey_line:'#9c9c9c',
    color_grey_back:'#f5f5f5',

    //Tab
    tab_line_width: SeaScale.Layout(6),
    tab_line_color: "#0C5FDD",
    tab_line_radius: 6,
    tab_active_font_size: SeaScale.Layout(30),
    tab_active_font_color: '#333',
    tab_aside_font_size: SeaScale.Layout(26),
    tab_aside_font_color: '#666',

    footerToolBar,
    chapters,
};
