/**
 * Created by xukj on 2018/6/21.
 */

const DefaultPageSize = 20;

/**
 * @description 资源类型
 * @type {{ONLINE_COURSE: number, TRAINING_CLASS: number, EXAM: number, READER: number, NEWS: number, PRESURVEY: number, QUESTIONNAIRE: number,
 *  SUBJECT: number, CASE:number, LECTURER:number, LEARN_BAR:number, SHARE_LEARN:number,EXAM_BAR:number, MENTOR:number,SYSTEM_NOTICE:numberSHARE_LEARN}}
 */
const ResourceType = {
    ONLINE_COURSE: 1, // 在线
    TRAINING_CLASS: 2, // 培训
    EXAM: 3, // 考试
    READER: 4, // 阅读
    NEWS: 5, // 新闻
    PRESURVEY: 6, // 预开课
    QUESTIONNAIRE: 7, // 调查表/问卷
    LECTURER: 8, //讲师
    CASE: 9, //案例
    SUBJECT: 10, // 专题
    FEEDBACK: 11, // 意见反馈
    LEARN_BAR: 12, //学吧
    SHARE_LEARN: 13, //享学
    EXAM_BAR: 14, //考吧
    MENTOR: 16, //导师
    SYSTEM_NOTICE: 15, //系统消息
};

/**
 * @description 二维码code type
 * @type {{ONLINE_COURSE: number, TRAINING_CLASS: number, ASSIGN: number, PRESURVEY: number, NEWS: number, EXAM: number, READER: number, QUESTIONNAIRE: number}}
 */
const QRCodeType = {
    E_COURSE: 1, // e课
    TRAINING_CLASS: 2, // 面授
    ASSIGN: 3, // 签到
    PRESURVEY: 4, //预开课
    NEWS: 5, // 新闻
    EXAM: 6, // 考试
    READER: 7, // 阅读
    QUESTIONNAIRE: 8, // 问卷
    PROJECT_EXAM: 9, //E课和面授中考试
    PROJECT_QUESTIONNAIRE: 10, //e课和面授中的问卷
};

/**
 * @description h5的path必须一致，否则无法访问
 * Sign: 签到
 */
const H5Href = {
    ASSIGN: '/h5/sign',
};

/**
 * @description 资源状态
 * @type {{DRAFT: number, PUBLISHED: number, UNDERCARRIAGE: number, REVIEWPENDING:number, REVIEWUNPASS:number, DELETE: number}}
 */
const ResourceStatus = {
    DRAFT: 0, // 草稿
    PUBLISHED: 1, // 已发布
    UNDERCARRIAGE: 2, // 已下架
    REVIEWPENDING: 3, // 待审核
    REVIEWUNPASS: 4, // 审核不通过
    DELETE: 5, //已删除
};

/**
 * @description 资源附件类型
 * @type {{VEDIO: number, AUDIO: number, AUDIOANDRICHSNIPPET: number, PICANDTXT: number, RICHSNIPPET: number, SIMPLE: number}}
 */
const CoursewareType = {
    VEDIO: 1, // 视频
    AUDIO: 2, // 音频
    AUDIOANDRICHSNIPPET: 3, // 音频含图文
    PICANDTXT: 4, // 图文
    RICHSNIPPET: 5, // 图文富文本
    SIMPLE: 6, // 简课
};

/**
 * @description 考试类型
 * @type {{WAITING: number, COMPLETE: number, PUBLIC: number}}
 */
const ExamTaskType = {
    WAITING: 1,
    COMPLETE: 2,
    PUBLIC: 3,
};

/**
 * @description 考试结果(该常量在本地维护)
 * @type {{UNKNOWN: number, NONE: number, PASS: number, FAIL: number}}
 */
const ExamResultType = {
    UNKNOWN: -99, // 未知
    NONE: 0, // 未考试
    PASS: 1, // 通过考试
    FAIL: 2, // 未通过考试
};

/**
 * @description 性别
 * @type {{MALE: number, FEMALE: number}}
 */
const GenderType = {
    MALE: 0, // 男
    FEMALE: 1, // 女
};

/**
 * @description 搜索接口使用的资源类型
 * @type {{READ: string, NEWS: string, EXAM: string, TRAIN: string, ECLASS: string, QA: string, SUBJECT: string,
 *        CASES:string,LECTURER:string,TEACHERCENTER:string}}
 */
const SearchType = {
    READ: 'read', // 阅读
    NEWS: 'news', // 新闻
    EXAM: 'exam', // 考试
    TRAIN: 'train', // 面授
    ECLASS: 'eclass', // e课
    QA: 'ask', // 问吧
    QUESTIONNAIRE: 'questionnaire', //问卷
    SUBJECT: 'subject', // 专题
    TEACHER: 'teacher', //师课
    CASES: 'case',
    LECTURER: 'lecturer', //讲师
    TEACHERCENTER: 'teacherCenter', //讲师中心
};

/**
 * @description 期次签到状态
 * @type {{EXPIRE: number, WAITING: number, COMPLETE: number}}
 */
const TrainClassStatus = {
    EXPIRE: 0, // 已过期
    WAITING: 1, // 未签到
    FINISH: 2, // 已签到
};
/**
 * @description 资源类型文本
 * @param type
 * @returns {*}
 */
const getResourceTypeString = (type) => {
    switch (Number(type)) {
        case ResourceType.NEWS:
            return '新闻';
        case ResourceType.READER:
            return '阅读';
        case ResourceType.TRAINING_CLASS:
            return '培训管理';
        case ResourceType.ONLINE_COURSE:
            return '在线学习';
        case ResourceType.EXAM:
            return '考试';
        case ResourceType.PRESURVEY:
            return '预开课';
        case ResourceType.QUESTIONNAIRE:
            return '问卷';
        case ResourceType.CASE:
            return '案例';
        case ResourceType.LECTURER:
            return '讲师';
        case ResourceType.LEARN_BAR:
            return '学吧';
        default:
            return '其他';
    }
};

/**
 * 指定哪些资源类型可以预览
 * @param type
 * @return {boolean}
 */
const canResourcePreview = (type) => {
    // 支持预览的有
    // 面授 - 2、e课 - 1、考试 - 3、阅读 - 4、新闻 - 5、面授 - 7
    const rType = Number(type);
    return (
        rType === ResourceType.ONLINE_COURSE ||
        rType === ResourceType.TRAINING_CLASS ||
        rType === ResourceType.EXAM ||
        rType === ResourceType.READER ||
        rType === ResourceType.NEWS ||
        rType === ResourceType.QUESTIONNAIRE
    );
};

/**
 * @description 资源是否包含文本，根据资源类型判断
 * @param types
 * @returns {boolean}
 */
const coursewareHasDoc = (types) => {
    const doc = types.find((n) => {
        return (
            n == CoursewareType.AUDIOANDRICHSNIPPET ||
            n == CoursewareType.PICANDTXT ||
            n == CoursewareType.RICHSNIPPET
        );
    });
    return typeof doc != 'undefined' && doc !== null;
};

/**
 * @description 资源是否包含音频，根据资源类型判断
 * @param types
 * @returns {boolean}
 */
const coursewareHasAudio = (types) => {
    const audio = types.find((n) => {
        return n == CoursewareType.AUDIO || n == CoursewareType.AUDIOANDRICHSNIPPET;
    });
    return typeof audio != 'undefined' && audio !== null;
};

/**
 * @description 资源是否包含视频，根据资源类型判断
 * @param types
 * @returns {boolean}
 */
const coursewareHasVideo = (types) => {
    const video = types.find((n) => {
        return n == CoursewareType.VEDIO;
    });
    return typeof video != 'undefined' && video !== null;
};

/**
 * @description 是否考试通过
 * @param examTimes
 * @param resultScore
 * @param passScore
 * @returns {number}
 */
const getExamResult = (examTimes = 0, resultScore = 0, passScore = Number.MAX_VALUE) => {
    // 未参加考试
    if (examTimes <= 0) {
        return ExamResultType.NONE;
    }
    // 通过考试
    if (resultScore >= passScore) {
        return ExamResultType.PASS;
    } else {
        return ExamResultType.FAIL;
    }
};

/**
 * @description 用户考试状态
 * @type {{NONE: number, TESTING: number, EXCEPTION: number}}
 */
const UserExamType = {
    NONE: 0, // 试卷已提交
    TESTING: 1, // 考试中
    EXCEPTION: 2, // 异常退出
};

/**
 * @description 职业班是否通过
 * @type {{WAITING: number, PASS: number, FAIL: number}}
 */
const CareerIsPass = {
    WAITING: 0,
    PASS: 1,
    FAIL: 2,
};

/**
 * @description 全局通知key
 * @type {{LOGOUT: string, HOME_APPEAR: string, REPORT: string}}
 */
const SeaGlobalEventType = {
    LOGOUT: 'SeaGlobalEventType_LOGOUT', // 登出
    HOME_APPEAR: 'SeaGlobalEventType_HOME_APPEAR', // 已废弃
    REPORT: 'SeaGlobalEventType_REPORT', // 手动上报数据
};

/**
 * 用户角色
 */
const RoleType = {
    USER_ADMIN: 'r_user_admin',
    OPERATOR_ADMIN: 'r_operator_admin',
    PROJECT_RESPONSIBLE: 'r_project_responsible',
    SUPER_USER_ADMIN: 'r_super_user_admin',
    SYS_ADMIN: 'r_system_admin',
    PLATFORM_CLASS_ADMIN: 'r_platform_class_admin',
    EXAM_ADMIN: 'r_exam_admin',
    APPROVAL_ADMIN: 'r_approval_admin',
    PRE_USER_ADMIN: 'r_prepare_user_admin',
    GRADE_ADMIN: 'r_grade_admin',
};

/**
 * 意见反馈分类
 * add by xukj - 1.30.0
 */
const FeedbackType = {
    OPTIMIZATION_SUGGESTION: 1, //优化建议
    SYSTEM_ISSUES: 2, // 系统问题
};

/**
 * 意见反馈状态
 * add by xukj - 1.30.0
 */
const FeedbackStatus = {
    NO_DISPOSE: 0, //"未处理"
    DISPOSED: 1, // "已处理"
    DELETED: 5, // "已删除"
    RESERVED: 6, // "遗留"
};

/**
 * 培训形式
 * @type {{OPEN: number, HALF_CLOSED: number, CLOSED: number}}
 * add by xukj - 1.31.1
 */
const TrainForm = {
    NONE: 0, // 没有
    OPEN: 1, // 开放
    HALF_CLOSED: 2, // 半封闭
    CLOSED: 3, // 封闭
};

/**
 * 外部链接打开的相关信息
 */
const Linking = {
    // 中转页
    AppDiscover: 'app-discover',
    // 启动scheme
    Scheme: 'studysmart365',
    // 操作部分
    Open: 'open',
    // 类型部分
    Detail: 'detail',
};

/**
 * 积分规则
 */
const ScoreRulesTypeDisplay = {
    needSignIn: '达成签到次数',
    needOnline: '完成所有在线课程学习',
    needExam: '考试通过',
    needQuestionnaire: '提交问卷',
};

/**
 * 积分规则
 */
const getVisibilityTypeString = (type) => {
    switch (Number(type)) {
        case 1:
            return '仅推送人员可见';
        case 3:
            return '部门可见';
        case 4:
            return '公司可见';
        case 5:
            return '企业可见';
        default:
            return '未知';
    }
};

/**
 * 考试题目类型
 */
const TestTopicType = {
    SINGLE: 1,
    MULTIPLE: 2,
    JUDGEMENT: 3,
    SHORTANSWER: 4,
};

/**
 * 问卷题目类型
 */
const QuestionTopicType = {
    SINGLE: '01',
    MULTIPLE: '02',
    ESSAY: '03', // 问答题
};

/**
 * 频道定义
 */
const ChannelCode = {
    ONLINE_COURSE: 'ONLINE_COURSE', // 在线
    TRAINING_CLASS: 'TRAINING_CLASS', // 面授
    EXAM: 'EXAM', // 考试
    READER: 'READER', // 阅读
    NEWS: 'NEWS', // 新闻
    QUESTIONNAIRE: 'QUESTIONNAIRE', // 问卷
    SUBJECT: 'SPECIAL_SUBJECT', // 专题
    ASK: 'ASK', // 问吧
    TEACHER_COURSE: 'TEACHER_COURSE', // 师课
    OTHER: 'APP_OTHER', // 其他分类, app内部使用
};

/**
 * App广播定义
 */
const Notification = {
    RELOAD_QLIST: 'RELOAD_QLIST', // 刷新问卷列表
    RELOAD_APPROVELIST: 'RELOAD_APPROVELIST', // 刷新审批列表
    RELOAD_QALIST: 'RELOAD_QALIST', // 刷新问吧问题列表
    RELOAD_QAREPLY: 'RELOAD_QAREPLY', // 刷新问吧回答列表
    RELOAD_COMMENTLIST: 'RELOAD_COMMENTLIST', // 刷新评论列表

    CASE_RECORD_APPROVER_DATA: 'CASE_RECORD_APPROVER_DATA', //(案例管理-个人提交记录)审批人信息
    CASE_RECORD_CATEGORY: 'CASE_RECORD_CATEGORY', //(案例管理-个人提交记录)案例分类

    AWAITING_LIST_TOTAL_NUM: 'AWAITING_LIST_TOTAL_NUM', //(提交与审批)刷新待审批列表条目数
    APPROVED_LIST_TOTAL_NUM: 'APPROVED_LIST_TOTAL_NUM', //(提交与审批)刷新已审批列表条目数
    FINISHED_APPROVAL_PROCESS: 'FINISHED_APPROVAL_PROCESS', //(提交与审批)完成审批过程
    RELOAD_RECORDS_LIST: 'RELOAD_RECORDS_LIST', //(提交与审批-个人提交记录)刷新列表

    LECTURER_FINISHED_APPROVAL_PROCESS: 'LECTURER_FINISHED_APPROVAL_PROCESS', //(讲师管理)完成审批过程
    LECTURER_RELOAD_RECORDS_LIST: 'LECTURER_RELOAD_RECORDS_LIST', //(讲师管理-个人提交记录)刷新列表
    LECTURER_AWAITING_LIST_TOTAL_NUM: 'LECTURER_AWAITING_LIST_TOTAL_NUM', //(讲师管理)刷新待审批列表条目数
    LECTURER_APPROVED_LIST_TOTAL_NUM: 'LECTURER_APPROVED_LIST_TOTAL_NUM', //(讲师管理)刷新已审批列表条目数
    LECTURER_RECORD_APPROVER_DATA: 'LECTURER_RECORD_APPROVER_DATA', //(讲师管理-个人提交记录)审批人信息
    LECTURER_RECORD_TECH_AREA: 'LECTURER_RECORD_TECH_AREA', //(讲师管理-个人提交记录)授课方向
    LECTURER_RECORD_MAIN_COURSE: 'LECTURER_RECORD_MAIN_COURSE', //(讲师管理-个人提交记录)主讲课程

    RELOAD_STATE: 'RELOAD_STATE', // 刷新课程按钮状态

    COMMENT_RELOAD_APPROVAL_LIST: 'COMMENT_RELOAD_APPROVAL_LIST', //评论审核刷新列表
    UPDATE_ISREAD: 'UPDATE_ISREAD', //消息已读
    UPDATE_LEARNCORNER: 'UPDATE_LEARNCORNER', //刷新学吧
    REFRESH_EXAM_LIST: 'REFRESH_EXAM_LIST', // 刷新考试列表
    
    UPDATE_USER_INFO:'UPDATE_USER_INFO', // 更新用户信息
    CLOSE_CLASS:'CLOSE_CLASS', //关闭课程
    CHANGEPLATECODE:'CHANGEPLATECODE',  //切换板块
};

// 广告等待时间 5秒
const AdsCounting = 5;

// 消息分类
const MessageGroupType = {
    Comment: '7', // 评论消息
    Like: '8', // 赞消息
};

//添加审批人情形
const ApproverType = {
    CASE_HUI: 'CASE_HUI', //案例审批会签
    CASE_HUO: 'CASE_HUO', //案例审批或签
    CASE_RECORDS: 'CASE_RECORDS', //案例个人提交记录
    LECTURER_HUI: 'LECTURER_HUI', //讲师审批会签
    LECTURER_HUO: 'LECTURER_HUO', //讲师审批或签
    LECTURER_RECORDS: 'LECTURER_RECORDS', //讲师个人提交记录
};

//提交与审批
const ApproveType = {
    APPROVING: 1, //待审批
    APPROVED: 2, //已审批
};

//提交与审批-个人提交记录
const ApproveRecordsType = {
    DRAFT: 0, //待提交
    AWAITING: 1, //待审批
    APPROVING: 2, //审批中
    APPROVED: 3, //已完成
};

export default {
    DefaultPageSize,
    ResourceType,
    QRCodeType,
    H5Href,
    CoursewareType,
    ExamTaskType,
    ExamResultType,
    GenderType,
    SearchType,
    UserExamType,
    TrainClassStatus,
    ResourceStatus,
    coursewareHasDoc,
    coursewareHasAudio,
    coursewareHasVideo,
    getExamResult,
    getResourceTypeString,
    canResourcePreview,
    CareerIsPass,
    SeaGlobalEventType,
    RoleType,
    // add by xukj - 1.30.0
    FeedbackType,
    FeedbackStatus,
    // add by xukj - 1.31.1
    TrainForm,
    // add by xukj - 1.30.0
    Linking,
    // add by xukj - 1.36.0
    ScoreRulesTypeDisplay,
    getVisibilityTypeString,
    TestTopicType,
    QuestionTopicType,
    ChannelCode,
    Notification,
    // add by xukj - 1.40.0
    AdsCounting,
    // add by xukj - 1.41.0
    MessageGroupType,
    ApproverType,
    ApproveType,
    ApproveRecordsType,
};
