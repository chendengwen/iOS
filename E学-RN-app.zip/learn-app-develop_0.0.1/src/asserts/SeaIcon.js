/**
 * @providesModule SeaIcon
 */
import React, {Component} from 'react';
import {Text} from 'react-native';

const map = {
    'play2':0xe900,   //播放2
    'play':0xe901,     //播放
    'play-history':0xe902, //播放记录
    'success':0xe903,   //成功
    'tolearn':0xe904,  //待学
    'tolearn-selected':0xe905,   //待学，已选
    'favour':0xe906,     //点赞
    'favoured':0xe907,    //已赞
    'qrcode':0xe908,   //二维码
    'back':0xe909,   //返回
    'category':0xe90a,   //分类
    'category-selected':0xe90b,   //分类已选
    'arrow-goto':0xe90c,      //箭头
    'play-fullscreen':0xe90d,  //全屏播放
    'drop-down':0xe90e,    //三角形，下拉
    'scan':0xe90f,   //扫一扫
    'filter':0xe910, //筛选
    'setting':0xe911,  //设置
    'home':0xe912,     //首页
    'home-selected':0xe913,   //首页，已选
    'searchbar':0xe914,     //搜索条
    'personal':0xe915,    //我的
    'personal-selected':0xe916,   //我的已选
    'history':0xe917,       //线下历史记录
    'message':0xe918,   //消息
    'star':0xe919,    //星星
    'pause':0xe91a,    //暂停
};

const map2 = {
    'delete': 0xe900,   //删除
    'qaInput': 0xe901,   // 扫描录入
    'share': 0xe902,   // 分享推荐
    // add by xukj - 1.37.0
    'delete1': 0xe903,   // 删除
    'message': 0xe904,   // 消息
    // add by xukj - 1.40.0
    'sign-ok': 0xe905, // 日历勾勾
};

/*
 * @private
 * @description 查找字体文件信息
 */
function getFontProps(name) {
    let code = map2[name];
    if (code) {
        return {
            family: 'sea-icons',
            code: code,
        };
    }
    else {
        return {
            family: 'icomoon',
            code: map[name],
        };
    }
}

export default class SeaIcon extends Component {
    constructor(props) {
        super(props);
    }

    static defaultProps = {
        bgColor:'rgba(0,0,0,0)'
    };

    _getIconStyle(props) {
        const {
            size,
            color,
            bgColor,
        } = props;
        return {
            fontSize: size,
            color: color,
            backgroundColor: bgColor,
        };
    }

    render() {
        const {
            name,
            style,
        } = this.props;
        const fontProps = getFontProps(name);
        return (
            <Text style={[this._getIconStyle(this.props), { fontFamily: fontProps.family }, style]}>
                {String.fromCharCode(fontProps.code)}
            </Text>
        );
    }
}
