/**
 * @author xukj
 * @date 2019/08/28
 * @description SeaColor 主题颜色
 * @deprecated 因为定义的颜色太多太繁杂，需要规范化，将逐步用  @see SeaTheme 替换
 */

// 在global中设置通用 $color
export default $color = {
    primary: '#397af8',
    grey5: '#E1E8EE',
    red: '#ef2a2a',
    red_text: '#fa5d5d',
    orange: '#fda228',
    green: '#50cf71',

    white: '#FFFFFF',
    //下面是设计规范中给的颜色
    main: '#2374F2', //主色调，用于重要按钮、突出文字  （2e84d4、3b5998-facebook、188eee-腾讯云课堂、378cdc：每日英语）
    newMain: '#FFFFFF',
    grey: '#B6BBBD', //按钮已设置颜色，提示文字颜色
    back: '#FFFFFF', //内容区域底色

    //半屏播放器用到的颜色
    icon: 'rgb(166,170,174)',
    left: 'rgb(48,129,214)',
    right: 'rgb(33,157,117)',
    circle: 'rgb(30,60,90)',
    max: 'rgb(57,85,94)',

    defaultBackgroudColor_3: '#F7F7F7', //底色

    //设计规范 11.8
    parting_line: '#E5E5E5', //分割线，边框
    h1_text: '#101010', //一级文字，大标题
    h2_text: '#565656', //二级文字，小标题
    h3_text: '#6D6D6D', //三级文字，内容
    content_text: '#9A9A9A', //内容，辅助次要文字信息
    tag_text: '#99A4BF', //标签性文字（下载提示）
    version_btn: '#6cb2ff',

    img_background: '#E5E5E5', //图片背景色
    // 标签颜色(一般tag不会用一个颜色，按照以下顺序变化)
    tag_01: '#fda228',
    tag_02: '#65adf2',
    tag_03: '#2ccbc3',
    tag_04: '#f46466',

    text1: '#333333',//主色黑
    text2: '#666666',//浅灰
    text3: '#999999',//深灰
    text4: '#000000',//深黑

    bg_grey_color: '#F5F5F5', // 背景颜色 - 浅灰，页面
    input_bg_grey_color: '#F8F8F8', // 输入框背景颜色 - 浅灰
};
