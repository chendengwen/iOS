### 学习平台APP

## Get Started

1 clone代码库

```
git clone http://gitlab.foresealife.com/learn/learn-app.git
```

2 install安装依赖

```
npm install
```

3 link dependencies for react-native

```
react-native link
```

4 运行代码

```
react-native run-android 或者 react-native run-ios
```

5 单元测试配置

```
cp setup.js  node_modules/jest
```



# 学习平台
建设中...




<br><br><br>




## 环境搭建
建设中...




<br><br><br>





## 项目框架（重构中...）
项目基于[react-native](https://reactnative.cn/docs/0.51/getting-started.html)搭建，实现android/iOS跨平台设计；
***在asserts、component、config、service、redux、util以及各个module下必须设计一个index.js，定义供外部模块访问的组件、功能。模块间在使用的时候严禁绕过index.js直接访问（模块内部访问请勿使用该方式）。***
- <h3>android</h3>
android项目原生代码
- <h3>ios</h3>
iOS项目原生代码，这里iOS项目使用[CocoaPods](https://cocoapods.org/)进行第三方库管理。
- <h3>src</h3>
react-native源码
   - <h3>asserts</h3>
   资源文件，包括图片、音频、通用样式、颜色定义、布局等相关文件
   - <h3>component</h3>
   通用的UI类型组件，可重用，无状态，与业务无关，高度独立，例如ImageButton、TextButton、ListCell等组件；
   - <h3>config</h3>
   项目配置文件
   - <h3>service</h3>
   项目所有的网络访问api
   - <h3>redux</h3>
   [react-redux](https://github.com/reduxjs/react-redux)分层代码，分层规范遵守redux的设计规范
      - <h3>actions/reducer/store</h3>
   - <h3>module</h3>
   分模块划分的业务代码。根据业务设计的展示用组件和容器组件；特定界面的布局文件；高度耦合的业务代码；
   - <h3>util</h3>
   工具类

<br><br><br>







## 框架设计规范（持续更新...）
### Component
在设计一个界面的时候，首先需要设计为：界面展示组件 和 界面容器组件；

##### 1. 展示类组件
只负责UI展示，不带有任何业务逻辑；

可重用，独立性强；

不使用任何redux的api；

例如：PersonalInfo(个人信息界面)

##### 2.容器类组件
负责业务的具体逻辑（获取数据、更新状态），不负责UI的具体呈现；

与业务高度耦合；

通常render()函数内返回为展示类组件；

可依赖redux，数据来源可以是redux-store；

例如：PersonalInfoPage(个人信息容器)

##### 3.UI类组件
抽象出来的通用UI组件，纯组件；

可重用，高度独立；

所有数据都由参数this.props提供；

不使用任何redux的api，无状态；

**这部分可用于扩充代码库**；

例如：TextButton、ImageButton、ListCell 之类

### Redux
基于[react-redux](https://github.com/reduxjs/react-redux)设计
##### 1.action
设计为纯函数；
[redux-thunk](https://github.com/reduxjs/redux-thunk)相关的代码，其他逻辑代码严禁写到action中；

ps：redux-thunk的用法其实是对redux的分层设计的混淆。现阶段暂时继续使用该方式。后期重构时，会修改为更为合理的[redux-saga](https://redux-saga-in-chinese.js.org/)或[redux-observable](https://redux-observable-cn.js.org/)

##### 2.reducer
设计为纯函数，严禁写入任何其他逻辑代码；

仅定义需要使用state记录的数据；如果action来自的数据需要处理后记录到state中，则另建selector来处理转换的业务逻辑；

严禁修改state，必须返回一个全新的state；

##### 3.使用准则
防止滥用redux。根据现在的页面需求，大部分页面都不需要使用redux。参考以下的准则

跨页面共享数据；

界面展示需要多个来源获取的数据；

大量的数据交互；

复杂的界面交互和状态；

如果无必要，请在componentWillUnMount中清空相关state，以防store中的数据越来越庞大，影响性能。

### Asserts
设计规范
##### 1.images
图片资源文件；

##### 2.styles
这里仅定义通用的样式文件，而非通用的样式请在各自的模块中定义；因为在快速迭代的App项目中，业务变更非常频繁，非通用的样式随着业务会发生频繁变动，如果放在asserts资源目录下，会影响开发效率；
通用颜色文件；
通用布局文件；
通用字体文件；

##### 3.constant
需要用的各种通用常量、枚举定义；推荐项目中使用的各种type都定义到该处，提高可读性、易维护。

##### 4.other
其他资源相关的文件；

### Util
工具类，通用的功能性部分代码设计；

可重用，高度独立；

**这部分可用于扩充代码库；**

##### 1.网络请求、数据库操作、文件操作等
因为网络请求在整个app中通用，因此设计为一个工具类，便于统一封装和拦截；

其他类似；

##### 2.对象扩展
在一些特定的情况下，我们会对已有的对象进行功能上的扩展，供App全局使用；

例如：展示时间统一格式 xxxx年xx月xx日，可以设计一个统一的Number对象的功能扩展；

##### 3.便捷方法
需要在App内多次用到，但是又不与业务耦合的功能；

例如：emoji字符编码转换

### Service
网络相关api；

提供网络接口访问api；

纯函数；

### Config
项目的配置信息

包括：服务器信息、api信息、打包信息等；

### Module
模块化设计；按功能划分模块，仅通过index.js定义供外部使用的组件、功能；

外部访问该模块的组件、功能时，严禁绕过index.js；

### Common
项目框架没有设计Common目录，是因为common具有很大的迷惑性。我们在开发时倾向于把不清楚不明确的功能代码一股脑全部放入common中，导致common目录臃肿不堪，更让人崩溃的是这些代码还是高耦合度。因此如果在设计时出现上述状况的功能，首先应拆分成功能明确的子功能。





<br><br><br>




## 组件设计规范
建设中...






<br><br><br>




## 第三方库/框架
- [prop-types](https://github.com/facebook/prop-types) 使用prop-types进行属性确认（必要属性验证、类型验证）

建设中...





<br><br><br>






## 代码规范
### React （Javascript）
参考[airbnb的编码规范](https://github.com/airbnb/javascript)

建设中...
### Android（Java）
建设中...
### iOS（Swift/Object-C）
建设中...