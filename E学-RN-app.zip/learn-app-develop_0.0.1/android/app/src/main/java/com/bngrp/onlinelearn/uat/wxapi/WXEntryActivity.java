package com.bngrp.onlinelearn.uat.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * Created by xukj 2018/12/26
 * 这个是uat渠道测试微信分享时需要的，勿删
 */

public class WXEntryActivity extends WXCallbackActivity {



}