package com.forsealife.util;

import java.util.*;
import android.text.TextUtils;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.view.TextureView;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;

public class RNHardwareTool extends ReactContextBaseJavaModule  {

    private static final String DEVICE_ISIPHONEX = "isIphoneX";
    private static final String DEVICE_INFORMATION = "deviceInformation";
    private static final String DEVICE_STATUSBARHEIGHT = "statusBarHeight";
    private static final String DEVICE_BOTTOMHEIGHT = "bottomHeight";
    private static final String DEVICE_BRAND = "deviceBrand";
    private static final String DEVICE_MODEL = "deviceModel";
    private static final String DEVICE_OS = "deviceOS";
    private static final String DEVICE_OS_VERSION = "deviceOSVersion";
    private static final String DEVICE_APP_VERSION = "appVersion";
    private static final String DEVICE_APP_VERSIONCODE = "appBuildVersion";

    private final ReactApplicationContext mContext;

    public RNHardwareTool(ReactApplicationContext reactContext) {
        super(reactContext);
        mContext = reactContext;
    }

    @Override
    public String getName() {
        return "RNHardwareTool";
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<>();
        // 兼容RN使用iOS部分信息（这里直接固定值）
        constants.put(DEVICE_ISIPHONEX, false);
        constants.put(DEVICE_INFORMATION, android.os.Build.PRODUCT);
        constants.put(DEVICE_STATUSBARHEIGHT, getStatusBarHeight());
        constants.put(DEVICE_BOTTOMHEIGHT, 0);
        // RN获取设备信息
        constants.put(DEVICE_BRAND, TextUtils.isEmpty(android.os.Build.BRAND) ? "unknown" : android.os.Build.BRAND);
        constants.put(DEVICE_MODEL, TextUtils.isEmpty(android.os.Build.MODEL) ? "android device" : android.os.Build.MODEL);
        constants.put(DEVICE_OS, "android");
        constants.put(DEVICE_OS_VERSION, TextUtils.isEmpty(android.os.Build.VERSION.RELEASE) ? "unknown" : android.os.Build.VERSION.RELEASE);
        constants.put(DEVICE_APP_VERSION, getAppVersionName());
        constants.put(DEVICE_APP_VERSIONCODE, getAppVersionCode());
        return constants;
    }

    // 获取当前版本号
    private String getAppVersionName() {
        PackageInfo info = getPackageInfo();
        return info != null ? info.versionName : "";
    }

    // 获取当前build号
    private int getAppVersionCode() {
        PackageInfo info = getPackageInfo();
        return info != null ? info.versionCode : 0;
    }

    // 获取packageInfo
    private PackageInfo getPackageInfo() {
        try {
            PackageManager packageManager = mContext.getPackageManager();
            return packageManager.getPackageInfo(mContext.getPackageName(), 0);
        } catch (Exception e) {
            return null;
        }
    }

    private int getStatusBarHeight() {
        int result = 0;
        int resourceId = mContext.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = mContext.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }
}