package com.bngrp.onlinelearn.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * Created by wangfei on 17/8/28.
 */

public class WXEntryActivity extends WXCallbackActivity {



}