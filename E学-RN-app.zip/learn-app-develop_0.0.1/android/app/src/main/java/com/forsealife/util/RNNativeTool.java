package com.forsealife.util;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.util.Log;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class RNNativeTool extends ReactContextBaseJavaModule  {

    private final ReactApplicationContext mContext;

    private final String packageName = "com.bngrp.onlinelearn";
    private ComponentName defaultComponent;
    private ComponentName currentComponent;
    private PackageManager packageManager;

    public RNNativeTool(ReactApplicationContext reactContext) {
        super(reactContext);
        mContext = reactContext;
        // 初始化切换app logo的环境
        prepareCompnent();
    }

    @Override
    public String getName() {
        return "RNNativeTool";
    }

    // 切换app logo
    // ---

    /**
     * 初始化切换环境
     */
    private void prepareCompnent() {
        packageManager = mContext.getPackageManager();
        defaultComponent = new ComponentName(mContext, packageName + ".MainActivity");
    }

    @ReactMethod
    public void useAppLogo(String name, Callback callback) {
        try {
            if (currentComponent == null) {
                currentComponent = mContext.getCurrentActivity().getComponentName();
            }

            disableComponent(currentComponent);
            enableComponent(new ComponentName(mContext, packageName + "." + name));
            callback.invoke(null, name);
        } catch (Error error) {
            callback.invoke(error.getMessage());
        }
    }

    @ReactMethod
    public void currentAppLogo(Callback callback) {
        try {
            if (currentComponent == null) {
                currentComponent = mContext.getCurrentActivity().getComponentName();
            }
            callback.invoke(null, currentComponent.getShortClassName());
        } catch (Error error) {
            callback.invoke(error.getMessage());
        }
    }


    /**
     * 启用组件
     * @param componentName
     */
    private void enableComponent(ComponentName componentName) {
        int state = packageManager.getComponentEnabledSetting(componentName);
        if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
            //已经启用
            return;
        }
        packageManager.setComponentEnabledSetting(componentName,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);

        // 更新当前使用的component
        currentComponent = componentName;
    }

    /**
     * 禁用组件
     * @param componentName
     */
    private void disableComponent(ComponentName componentName) {
        int state = packageManager.getComponentEnabledSetting(componentName);
        if (state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
            //已经禁用
            return;
        }
        packageManager.setComponentEnabledSetting(componentName,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }
}