package com.bngrp.onlinelearn;

import android.app.Application;
import android.os.Build;
import androidx.multidex.MultiDex;
import android.util.Log;

import com.facebook.react.ReactApplication;
import com.reactnativecommunity.geolocation.GeolocationPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.PackageList;
import com.facebook.soloader.SoLoader;

import java.util.Arrays;
import java.util.List;

import com.umeng.commonsdk.UMConfigure;
import com.umeng.socialize.PlatformConfig;
import com.umeng.message.IUmengRegisterCallback;
import com.umeng.message.PushAgent;
import org.android.agoo.huawei.HuaWeiRegister;
import org.android.agoo.xiaomi.MiPushRegistar;
//import org.android.agoo.vivo.VivoRegister;
//import org.android.agoo.oppo.OppoRegister;

import com.forsealife.util.*;

import rym.component.BNReactPackage;

public class MainApplication extends Application implements ReactApplication {

    private static final String TAG = MainApplication.class.getName();
    private static final String UMENG_APPKEY = "5ec63fb8895cca65ef0000b8";
    private static final String UMENG_CHANNEL = "Official";
    private static final String UMENG_APPSECRET = "e17fab911c4a8a7f81ac5535259206af";
    private static final String WX_APPID = "wxfae0f6fbd89fa6ac";
    private static final String WX_APPKEY = "ff9f0beb369431602d2f870d5346a92a";
    private static final String QQ_APPID = "101534291";
    private static final String QQ_APPKEY = "71271be3b846b6bfc4d83b1abf9b7aca";
    private static final String XIAOMI_APPID = "2882303761518026678";
    private static final String XIAOMI_APPKEY = "5371802614678";
    private static final String OPPO_APPKEY = "xxxxxx";
    private static final String OPPO_APPSECRET = "xxxxxx";

    private ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;//true:调试模式  false:生产模式
        }

        @Override
        protected List<ReactPackage> getPackages() {
            @SuppressWarnings("UnnecessaryLocalVariable")
            List<ReactPackage> packages = new PackageList(this).getPackages();
            // 硬件相关
            packages.add(new FSLUtilPackage());
            //任意门
            packages.add(new BNReactPackage());
            return packages;
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }

        @Override
        protected String getBundleAssetName() {
            return "index.android.bundle";
        }
    };

    //添加以下代码
    public void setReactNativeHost(ReactNativeHost reactNativeHost) {
        mReactNativeHost = reactNativeHost;
    }

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MultiDex.install(this);
        SoLoader.init(this, /* native exopackage */ false);
        //初始化组件化基础库, 统计SDK/推送SDK/分享SDK都必须调用此初始化接口
        RNUMConfigure.init(this, UMENG_APPKEY, UMENG_CHANNEL, UMConfigure.DEVICE_TYPE_PHONE,
                UMENG_APPSECRET);
        UMConfigure.setLogEnabled(true);
        UMConfigure.setEncryptEnabled(true);
        setupSharePlatform();
        setupPush();
    }

    private void setupSharePlatform() {
        PlatformConfig.setWeixin(WX_APPID, WX_APPKEY);
        PlatformConfig.setQQZone(QQ_APPID, QQ_APPKEY);
    }

    private void setupPush() {
        PushAgent mPushAgent = PushAgent.getInstance(this);
        // 注册推送服务 每次调用register都会回调该接口
        mPushAgent.register(new IUmengRegisterCallback() {
            @Override
            public void onSuccess(String deviceToken) {
                Log.i("push", "device token: " + deviceToken);
            }

            @Override
            public void onFailure(String s, String s1) {
                Log.i("push", "register failed: " + s + " " + s1);
            }
        });

        String brand = Build.BRAND;
        Log.i("push", brand);
        // 华为推送
        HuaWeiRegister.register(this);
        // 小米推送
        MiPushRegistar.register(this, XIAOMI_APPID, XIAOMI_APPKEY);
//        // Vivo推送
//        VivoRegister.register(this);
//        // Oppo
//        OppoRegister.register(this,OPPO_APPKEY, OPPO_APPSECRET);
    }
}
