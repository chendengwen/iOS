package rym.component;

import android.content.Context;
import android.graphics.Point;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.baoneng.bnrym.RandomDoor;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableMap;

public class RNScreenpxModule extends ReactContextBaseJavaModule {
    private int w = 0; // 当前设备的宽度方向 像素数
    private int h = 0; // 当前设备的宽度方向 像素数
    private volatile static boolean mHasCheckAllScreen;
    private volatile static boolean mIsAllScreenDevice;   // 是否全面屏
    private volatile static boolean notNavigationBarExist; // 不存在虚拟导航器 (即真正的使用全面屏)
    private Context mContext;

    @NonNull
    @Override
    public String getName() {
        return "RNScreenpxModule";
    }

    public RNScreenpxModule(@NonNull ReactApplicationContext reactContext) {
        super(reactContext);
        mContext = reactContext;
        WindowManager wm = (WindowManager) reactContext.getSystemService(Context.WINDOW_SERVICE);

        // 1. 获取当前安卓设备的真实像素
        w = RNScreenpxModule.getRealPXFromScreenW(reactContext);
        h = RNScreenpxModule.getRealPXFromScreenH(reactContext);

        // 2. 判断是否为全面屏
        mIsAllScreenDevice = RNScreenpxModule.isAllScreenDevice(reactContext);
        if (mIsAllScreenDevice) {
            notNavigationBarExist = Settings.Global.getInt(reactContext.getContentResolver(), "force_fsg_nav_bar", 0) != 0;

        }
    }

    public static int getRealPXFromScreenH(Context context) {
        WindowManager wd = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display defaultDisplay = wd.getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        int x = point.x;
        int y = point.y;
        return y;
    }

    public static int getRealPXFromScreenW(Context context) {
        WindowManager wd = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display defaultDisplay = wd.getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        int x = point.x;
        int y = point.y;
        return x;
    }

    public static boolean isAllScreenDevice(Context context) {
        if (mHasCheckAllScreen) {
            return mIsAllScreenDevice;
        }
        mHasCheckAllScreen = true;
        mIsAllScreenDevice = false;
        // 低于 API 21的，都不会是全面屏
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return false;
        }
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            Display display = windowManager.getDefaultDisplay();
            Point point = new Point();
            display.getRealSize(point);
            float width, height;
            if (point.x < point.y) {
                width = point.x;
                height = point.y;
            } else {
                width = point.y;
                height = point.x;
            }
            if (height / width >= 1.97f) {
                mIsAllScreenDevice = true;
            }
        }
        return mIsAllScreenDevice;
    }

    @ReactMethod
    public void getScreenW(Promise promise) {
        promise.resolve(w);
    }

    @ReactMethod
    public void getScreenH(Promise promise) {
        promise.resolve(h);
    }

    @ReactMethod
    public void checkFullScreen(Promise promise) {

        Boolean fullScreenAndNotNavigationBarExist = mIsAllScreenDevice && notNavigationBarExist;
        WritableMap map = Arguments.createMap();
        // 全面屏切启用了全面屏
        if (fullScreenAndNotNavigationBarExist) {
            map.putString("full", "true");
            promise.resolve(map);
        } else {
            // 非全面屏或 全面屏但是未启用全面屏功能
            map.putString("full", "false");
            promise.resolve(map);
        }
    }

    @ReactMethod
    public void getInfoFromRN(String name, String phone) {
//        Toast.makeText(mContext, name+";"+phone, Toast.LENGTH_SHORT).show();
        Log.d("5555555555", "getInfoFromRN: "+name+ ";"+phone);
        RandomDoor.updateUserInfo(name,phone);
    }
}
