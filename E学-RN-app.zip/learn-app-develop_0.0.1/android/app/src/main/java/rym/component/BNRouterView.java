package rym.component;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.baoneng.bnrym.RandomDoor;
import com.baoneng.bnrym.RandomDoorItemClickListener;
import com.baoneng.bnrym.view.RymView;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewProps;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.views.image.ImageResizeMode;
import com.facebook.react.views.image.ReactImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class BNRouterView extends SimpleViewManager<RymView> {

    public static final String REACT_CLASS = "BNRouterView";

    @Override
    public String getName() {
        return REACT_CLASS;
    }

    @NonNull
    @Override
    protected RymView createViewInstance(@NonNull ThemedReactContext reactContext) {
        Log.d("5555555555", "createViewInstance: ");
        RandomDoor.init(RandomDoor.RELEASE, reactContext.getPackageName(),"","");
        RymView rymView = new RymView(reactContext.getCurrentActivity());
        RandomDoor.updateList();
        rymView.setItemClickListener(new RandomDoorItemClickListener() {
            @Override
            public void OnItemClicked(int i, String s, String s1) {
                WritableMap map = Arguments.createMap();
                map.putString("name", s);
                map.putString("appUrl", s1);

                nativeCallRn(reactContext, map);
            }
        });

        //初始化布局参数
//        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//                reactContext.getCurrentActivity().addContentView(rymView,layoutParams);
//        rymView.setLayoutParams(layoutParams);

        //测试添加文本
//        TextView textView = new TextView(reactContext);
//        textView.setText("11212121212");
        //测试添加图片
//        ImageView imageView = new ImageView(reactContext);
//        imageView.setImageResource(R.mipmap.src_asserts_images_bg_notice);

        //设置布局参数
//        rymView.addView(imageView,layoutParams);

//        LinearLayout layout = new LinearLayout(reactContext);
//        layout.addView(rymView,layoutParams);

        return rymView;
    }

    /**
     * Native调用RN
     *
     * @param data
     */
    private void nativeCallRn(@NonNull ThemedReactContext reactContext, @Nullable Object data) {
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit("router", data);
    }

}
