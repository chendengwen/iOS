package rym.component;

import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import java.util.HashMap;
import java.util.Map;

import io.reactivex.annotations.Nullable;

public class BNRouterEventManager extends ReactContextBaseJavaModule {
    public static final String REACT_NATIVE_CLASSNAME = "BNNativeModule";
    private ReactApplicationContext mContext;
    public static final String EVENT_NAME = "nativeCallRn";
    public static final String TAG = "TAG";

    public BNRouterEventManager(ReactApplicationContext reactContext) {
        super(reactContext);
        mContext = reactContext;
    }
    @NonNull
    @Override
    public String getName() {
        return REACT_NATIVE_CLASSNAME;
    }

    @ReactMethod
    public void rnCallNative(String msg){
        Toast.makeText(mContext,msg, Toast.LENGTH_SHORT).show();
    }


    @ReactMethod
    public void startActivityRN(String name, String params) {
        try {
            Activity activity = getCurrentActivity();
            if (activity != null) {
                Class toClass = Class.forName(name);
                Intent intent = new Intent(activity, toClass);
                intent.putExtra("params", params);
                activity.startActivity(intent);
            }
        } catch (Exception ex) {
            throw new JSApplicationIllegalArgumentException("不能打开Activity " + ex.getMessage());
        }
    }
    //后面该方法可以用Linking代替
    @ReactMethod
    public void getDataFromIntent(Callback success, Callback error) {
        try {
            Activity currentActivity = getCurrentActivity();
            String result = currentActivity.getIntent().getStringExtra("result");//会有对应数据放入
            if (!TextUtils.isEmpty(result)) {
                success.invoke(result);
            }
        } catch (Exception ex) {
            error.invoke(ex.getMessage());
        }
    }

    /**
     * Native调用RN
     * @param msg
     */
    public void nativeCallRn(String msg) {
        mContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(EVENT_NAME,msg);
    }

    /**
     * Callback 方式
     * rn调用Native,并获取返回值
     * @param msg
     * @param callback
     */
    @ReactMethod
    public void rnCallNativeFromCallback(String msg, Callback callback) {

        String result = "hello RN！Native正在处理你的callback请求";
        // .回调RN,即将处理结果返回给RN
        callback.invoke(result);
    }

    /**
     * Promise
     * @param msg
     * @param promise
     */
    @ReactMethod
    public void rnCallNativeFromPromise(String msg, Promise promise) {
        Log.e(TAG,"rnCallNativeFromPromise");
        String result = "hello RN！Native正在处理你的promise请求" ;
        promise.resolve(result);
    }
    /**
     * 向RN传递常量
     */
    @Nullable
    @Override
    public Map<String, Object> getConstants() {
        Map<String,Object> params = new HashMap<>();
        params.put("Constant","我是Native常量，传递给RN");
        return params;
    }
}
