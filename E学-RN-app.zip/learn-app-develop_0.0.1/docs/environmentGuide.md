<!--
 * @Author: ouyfm
 * @Date: 2020-07-01 11:15:10
 * @LastEditors: ouyfm
 * @LastEditTime: 2020-07-01 14:28:06
 * @Descripttion: 
--> 


# 开发基础

## 环境：Node（>=12.x）、Python(2x)、JDK (1.8)、 Android Studio;
  - 安装过程中注意版本，`确保是括号中标识的版本`
  - 其中Android Studio安装中包含了sdk、gradle、ndk包的下载可在AS里面去下载，也可以将这几个包下载好，在AS中关联，`需要注意的是下载好的sdk、grandle、ndk的版本应该涵盖项目所需的版本`
  - 配置Node、Python、Jdk 、Sdk、Android Studio的环境变量
    - eg:配置到最后目录如下：

      ```
        …nodejs
        …Python
        …JAVA\jdk1.8.0_13\bin
        …JAVA\jdk1.8.0_13\jre\bin
        …JAVA\jdk1.8.0_13\lib\tools.jar
        …sdk\tools
        …sdk\platform-tools
        …sdk\tools\bin
        …sdk\emulator
    - 在cmd中检测是否配置成功，运行node、python、java\javac\javadoc\java -version、android、adb不报错即可
    tips:由于网路限制，网上下全包是难点慢点，有的包不能一步下全，可以找公司共享库里找找有没有相应的

## 调试：Vscode插件、Fiddler、真机/模拟器
  - Vscode插件
    - 在基础开发的插件后，需要安装React Native Tools插件，用于看log信息或者debugger
  - Fiddler
    - 辅助看网络请求
  - 真机/模拟器
    - 需要其中一个即可，模拟器可能公司电脑带不动，建议真机连接usb调试，连接成功后可以运行adb devices看是否出现类似如下字眼提示，提示则连接成功

      ```
        List of devices attached
        0715f7c0ac980538        device
      ``` 
    tips:调试挺不方便的，有好的方式，持续更新...


## 运行：
  - 下载项目:git clone http://git.bngrp.com/information-management-center/bn-system-dev/learn/learn-app.git
  - 安装包：npm install
  - 创建忽略文件local.properties:创建目录为...\android\local.properties，用于指向你本地sdk的地址,内容如下：
     ```
       # 修改成你自己的sdk目录
       sdk.dir=D\:\\soft\\sdk
      ``` 
  - 手动改包：由于下下来的包中有些引用的依赖，我们的仓库没有覆盖全，需要手动去node_modules中修改，需要修改如下2个包：
    - 报错：evaluating '_this.view_component.measureInWindow'
      位置：node_modules/react-native-safe-area-view/index.js
        ```
         修改前：
            this.view._component.measureInWindow((winX, winY, winWidth, winHeight) => {
         修改后：
            this.view.getNode().measureInWindow((winX, winY, winWidth, winHeight) => {
        ```
    - 报错：Could not resolve com.facebook.react:react-native:0.20.+.
      位置：node_modules\react-native-audio-streamer\android\build.gradle
       ```
        修改前：
          compile 'com.facebook.react:react-native:0.20+'
        修改后：
          compile 'com.facebook.react:react-native:+'
        ```
   - 清理gradlew：切到android目录中，运行gradlew clean
   - 再切到项目目录中npm run android(具体看package.json中的配置)

     tips：是否能运行成功，主要取决于第一点的环境配置是否都成功，安装的sdk、ndk、gradle是否包含项目所需要的，node_modules中的包是否下全了，依赖有没有问题