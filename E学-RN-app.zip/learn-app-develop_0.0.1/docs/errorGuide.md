<!--
 * @Author: ouyfm
 * @Date: 2020-07-01 14:30:14
 * @LastEditors: ouyfm
 * @LastEditTime: 2020-07-01 15:29:11
 * @Descripttion: 
--> 

# 常见报错

- 报错：Make sure you have the Android development environment
    ```
    error Failed to install the app. Make sure you have the Android development environment set up: https://reactnative.dev/docs/environment-setup. Run CLI with --verbose flag for more details.
    Error: Command failed: gradlew.bat app:installUatDebug -PreactNativeDevServerPort=7777

    FAILURE: Build failed with an exception.

    * What went wrong:
    Could not determine the dependencies of task ':app:installUatDebug'.
    > java.io.IOException: �ļ�����Ŀ¼��������﷨����ȷ��

    * Try:
    Run with --stacktrace option to get the stack trace. Run with --info or --debug option to get more log output. Run with --scan to get full insights.

    * Get more help at https://help.gradle.org
    ```
    原因：所需环境任一或多个不满足，可能：
    1.adb devices检查真机或者模拟器是否连接成功;
    2.检查environmentGuide.md中所有的环境是否都安装成功；
    3.着重检查sdk、ndk、gradle和本项目所需的版本是否涵盖，及Android Studio是否管理上了；
    4.清理gradlew
    ```
    cd android 
    gradlew clean
    ```

- 报错：Could not get unknown property 'MYAPP_RELEASE_STORE_FILE
  原因：打包的签名文件配置没找，android/gradle.properties文件缺失或被忽略者字段缺失：
  解决：gradle.properties中应该为：
    ```
    android.useAndroidX=true
    android.enableJetifier=true
    MYAPP_RELEASE_STORE_FILE=my-release-key.jks
    MYAPP_RELEASE_KEY_ALIAS=my-key-alias
    MYAPP_RELEASE_STORE_PASSWORD=WoAiQianHai$1234
    MYAPP_RELEASE_KEY_PASSWORD=WoAiQianHai$1234

- 报错：No version of NDK matched the requested version 21.0.6113669. Versions available locally: 20.1.5948944
原因：本地ndk没有和项目所需要的sdk版本没匹配上
解决：在build.gradle（Module：app）中添加：(可以参考这篇文章https://blog.csdn.net/dingpwen/article/details/105834794)
    ```
    android {
     ndkVersion “21.1.6352462”
    }

- 报错：Task :react-native-kpframework-gallery:generateDebugBuildConfig FAILED/Error: Command failed: gradlew.bat
  原因：不明（待大佬更新，貌似还有很多莫名其妙的报错也是这个引起的）
  解决：
  ```
   cd android 
   gradlew clean
   ```

- 报错：SDK location not found. Define location with sdk.dir in the local.properties file or with an ANDROID_HOME environment variable.
原因：local.properties被忽略了，需要手动添加
解决：创建忽略文件local.properties:创建目录为...\android\local.properties，用于指向你本地sdk的地址,内容如下：
    ```
    # 修改成你自己的sdk目录
    sdk.dir=D\:\\soft\\sdk
     ``` 
- 报错：Execution failed for task ':app:installDebug'.
 原因：由于包名和签名的信息与原先手机上的冲突导致的，也就是说，手机上已经安装了该APP
 解决：需要先手动卸载已安装的APP，才能通过命令安装成功