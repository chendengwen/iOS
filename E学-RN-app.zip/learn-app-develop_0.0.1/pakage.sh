#!/usr/bin/env bash
# 项目地址
PROJ_ROOT=$(pwd)
# 打包平台
PROJ_PLATFORM='all'
# 打包地址
PROJ_IPA_PATH=${PROJ_ROOT}/ios/LearnStarter.ipa
PROJ_APK_PATH=${PROJ_ROOT}/android/app/build/outputs/apk/prd/release/app-prd-release.apk

printf "\n\x1B[33m
# 使用前须知：请勿移动该文件位置
# 1.需要安装\x1B[35m react-native-version \x1B[33m地址:https://github.com/stovmascript/react-native-version/
# 2.需要安装\x1B[35m fastlane \x1B[33m地址:https://docs.fastlane.tools/
# 3.需要安装\x1B[35m CocoaPods(iOS第三方库管理脚本) \x1B[33m地址:https://cocoapods.org/
# 4.需要安装\x1B[35m jetify(androidx支持工具) \x1B[33m'yarn add -D jetifier'
# 4.需要安装\x1B[35m fir(测试包托管脚本) \x1B[33m地址:https://github.com/FIRHQ/fir-cli/blob/master/README.md/
# 5.iOS打包ipa地址: ${PROJ_IPA_PATH}
# 6.android打包apk地址: ${PROJ_APK_PATH}
#
# \x1B[32m参数:
# -t            [ios/android/all]打包平台, 默认all
\x1B[0m\n"


# 读取参数
while getopts "t:" opt; do
    case ${opt} in
        t)
            if [[ ${OPTARG} == 'all' ]] || [[ ${OPTARG} == 'ios' ]] || [[ ${OPTARG} == 'android' ]]; then
                PROJ_PLATFORM=${OPTARG}
            else
                printf "出错啦, 平台必须是[ios/android/all]"
                exit 1
            fi
            ;;
        *)
            printf "出错啦,无法识别的命令"
            exit 1
            ;;
    esac
done

# projectPath=~/reactNativeProject/learn-app/
# exportPath=~/LearnStarterArchive/
# publishPath=~/Desktop/app-cloud/

# iOS平台打包
function build_ios() {
    if [[ $? != 0 ]]; then
		exit 1
	fi

    if [[ ${PROJ_PLATFORM} != 'all' ]] && [[ ${PROJ_PLATFORM} != 'ios' ]]; then
        return 0
    fi

    cd ${PROJ_ROOT}/ios
    fastlane uat
}

# android打包
function build_android() {
    if [[ $? != 0 ]]; then
		exit 1
	fi

    if [[ ${PROJ_PLATFORM} != 'all' ]] && [[ ${PROJ_PLATFORM} != 'android' ]]; then
        return 0
    fi

    cd ${PROJ_ROOT}/android
    fastlane beta
}

# 结果日志
function finish() {
    if [[ $? != 0 ]]; then
		exit 1
	fi

    printf "\n\n------------------------------------\n\x1B[32m恭喜，打包成功!🎉\x1B[0m\n------------------------------------\n"

    if [[ ${PROJ_PLATFORM} == 'all' ]] || [[ ${PROJ_PLATFORM} == 'ios' ]]; then
        printf "\x1B[35m# ipa:\x1B[32m ${PROJ_IPA_PATH}\x1B[0m\n"
    fi

    if [[ ${PROJ_PLATFORM} == 'all' ]] || [[ ${PROJ_PLATFORM} == 'android' ]]; then
        printf "\x1B[35m# apk:\x1B[32m ${PROJ_APK_PATH}\x1B[0m\n"
    fi
}

build_ios
build_android
finish