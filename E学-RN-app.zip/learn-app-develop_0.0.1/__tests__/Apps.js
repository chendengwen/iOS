/**
 * Created by zk on 2017/5/24.
 */
// import 'react-native';
// import React from 'react';
// import SeaCardList from '../src/view/home/SeaCardList';
// import CourseDetail from '../src/view/home/Course/CouresDetail'
// // Note: test renderer must be required after react-native.
// import renderer from 'react-test-renderer';
// import AppInfo from '../src/config/appinfo';
// import Image from '../src/view/home/Course/Image'
// import Video from '../src/view/home/Course/Video'
// import ImageFullScreen from '../src/view/home/Course/ImageFullScreen'
// import SeaCard from '../src/view/home/SeaCard'


const ImageToLearn={
    file_url:[`${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
    ],
    create_user:'李开复',
    valid_start:'2017-05-15',
    valid_end:'2017-07-01',
    description:'在企业级JavaEE应用开发中，对数据库的访问和操作是必须的。Spring Data作为SpringSource的其中一个子项目，旨在统一和简化对各类型持久化存储和访问，而不拘泥于是关系型数据库还是NoSQL数据存储，使得对数据库的访问变得方便快捷，并支持MapReduce框架及云计算服务；对于拥有海量数据的项目，可以用Spring Data来简化项目的开发，就如Spring Framework对JDBC、ORM的支持一样，Spring Data会让数据的访问变得更加方便，极大提高开发效率、提升程序员的幸福指数！',
    file_type:'image',
    toLearn:false,
    cover_image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

}

const VideoToLearn={
    file_url:[`${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
    ],
    create_user:'李开复',
    valid_start:'2017-05-15',
    valid_end:'2017-07-01',
    description:'在企业级JavaEE应用开发中，对数据库的访问和操作是必须的。Spring Data作为SpringSource的其中一个子项目，旨在统一和简化对各类型持久化存储和访问，而不拘泥于是关系型数据库还是NoSQL数据存储，使得对数据库的访问变得方便快捷，并支持MapReduce框架及云计算服务；对于拥有海量数据的项目，可以用Spring Data来简化项目的开发，就如Spring Framework对JDBC、ORM的支持一样，Spring Data会让数据的访问变得更加方便，极大提高开发效率、提升程序员的幸福指数！',
    file_type:'video',
    toLearn:false,
    cover_image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

}
const ImageLearned={
    file_url:[`${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
    ],
    create_user:'李开复',
    valid_start:'2017-05-15',
    valid_end:'2017-07-01',
    description:'在企业级JavaEE应用开发中，对数据库的访问和操作是必须的。Spring Data作为SpringSource的其中一个子项目，旨在统一和简化对各类型持久化存储和访问，而不拘泥于是关系型数据库还是NoSQL数据存储，使得对数据库的访问变得方便快捷，并支持MapReduce框架及云计算服务；对于拥有海量数据的项目，可以用Spring Data来简化项目的开发，就如Spring Framework对JDBC、ORM的支持一样，Spring Data会让数据的访问变得更加方便，极大提高开发效率、提升程序员的幸福指数！',
    file_type:'image',
    toLearn:true,
    cover_image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

}
const VideoLearned={
    file_url:[`${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
        `${AppInfo.apiDomain}:8085/images/classImage.jpg`,
    ],
    create_user:'李开复',
    valid_start:'2017-05-15',
    valid_end:'2017-07-01',
    description:'在企业级JavaEE应用开发中，对数据库的访问和操作是必须的。Spring Data作为SpringSource的其中一个子项目，旨在统一和简化对各类型持久化存储和访问，而不拘泥于是关系型数据库还是NoSQL数据存储，使得对数据库的访问变得方便快捷，并支持MapReduce框架及云计算服务；对于拥有海量数据的项目，可以用Spring Data来简化项目的开发，就如Spring Framework对JDBC、ORM的支持一样，Spring Data会让数据的访问变得更加方便，极大提高开发效率、提升程序员的幸福指数！',
    file_type:'video',
    toLearn:true,
    cover_image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

}

const SeaCardData =


        [
            {
                title:'java基础',
                watchSum:666,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            }
            ,
            {
                title:'java基础',
                watchSum:500000,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            },

            {
                title:'java基础',
                watchSum:500000,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            },
            {
                title:'java基础',
                watchSum:500000,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            },
            {
                title:'java基础',
                watchSum:500000,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            },
            {
                title:'java基础',
                watchSum:500000,
                image:`${AppInfo.apiDomain}:8085/images/classImage.jpg`,

            },
        ]


//
it('render SeaCardList', () => {
    const component=renderer.create(
        <SeaCardList  />
    )
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();



});
// it('render SeaCard', () => {
//     const component=renderer.create(
//         <SeaCard classData={SeaCardData} />
//     )
//     let tree = component.toJSON();
//     expect(tree).toMatchSnapshot();
//
//
//
//
// });
// it('render Image Course detail to learn',() =>{
//    const tree= renderer.create(<Image data={ImageToLearn}/>).toJSON();
//     expect(tree).toMatchSnapshot();
//
// })
// it('render Video Course detail to learn',() =>{
//
//     const tree= renderer.create(  <Video data={VideoToLearn}/>).toJSON();
//     expect(tree).toMatchSnapshot();
//
//
// })
// it('render Image Course detail learned',() =>{
//
//     const tree= renderer.create(<Image data={ImageLearned}/>).toJSON();
//     expect(tree).toMatchSnapshot();
// })
//
// it('render ImageFullScreen',() =>{
//
//     const tree= renderer.create(<ImageFullScreen file_url={ImageLearned.file_url} index={ImageLearned.file_url.length-1}/>).toJSON();
//     expect(tree).toMatchSnapshot();
// })


// it('render SeaCard',() =>{
//
//     const tree= renderer.create(<SeaCard classData={SeaCardData}
//     rowHasChanged={jest.fn}
//     onCardPress={jest.fn}
//     />).toJSON();
//     expect(tree).toMatchSnapshot();
// })


