/**
 * Created by zk on 2017/7/13.
 */
'user strict'
import 'react-native';
import React from 'react';
import renderer from 'react-test-renderer';
import {Home} from '../src/view/home/Home'
import {AC_FetchRecommendResource,AC_FetchBanner} from '../src/redux/actions/home'











//测试数据
const userInfo={
    username:Teseter,
    phone:13887651234,
}
const banners=[{
    "id": "1",
    "name": "线上课程1",
    "imageHash": "7f5d047b-d950-4056-b6c7-57d955b6e3e0",
    "resourceHash": "01fcd1e2-d276-4a16-9772-deaefeef7d55",
    "displayOrder": 1,
    "bannerType": "1",
    "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/7f5d047b-d950-4056-b6c7-57d955b6e3e0"
}, {
    "id": "2",
    "name": "培训班1",
    "imageHash": "0bd9bc6b-cffc-4927-8f8c-77f6a05c56e9",
    "resourceHash": "f5df50ea-5397-4321-9852-332a1a4268be",
    "displayOrder": 2,
    "bannerType": "2",
    "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/0bd9bc6b-cffc-4927-8f8c-77f6a05c56e9"
}, {
    "id": "3",
    "name": "培训班3",
    "imageHash": "fb497a35-b0aa-4236-b6be-59067f777f28",
    "resourceHash": "61e03e4c-3a1b-45c7-9220-2f20f332d98d",
    "displayOrder": 3,
    "bannerType": "2",
    "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/fb497a35-b0aa-4236-b6be-59067f777f28"
}]
const  recommendResources=[{
    "hash": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
    "categoryName": "项目管理",
    "data": [{
        "id": "01fcd1e2-d276-4a16-9772-deaefeef7d55",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 1,
        "name": "大家一起来学ABC",
        "summary": "大家一起来学ABC入门级",
        "outline": "",
        "author": "英语狂人",
        "publishTime": 1499068222000,
        "status": 1,
        "coverImage": "7c2bfdfe-64cf-4383-9c5a-3af0687385a3",
        "validStart": 1500336000000,
        "validEnd": 1503014400000,
        "frequency": 0,
        "coursewares": [{
            "name": "2015-01-06-15-55-00.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/5268a1f2-e77e-44f2-b0de-d4980aedb9a4",
            "fileType": 1,
            "resourceFiles": []
        }],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/7c2bfdfe-64cf-4383-9c5a-3af0687385a3",
        "coursewareFileTypeMap": {
            "1": "2015-01-06-15-55-00.mp4"
        },
        "tags": [],
        "publisher": "狄倩"
    }, {
        "id": "1c195669-6e7f-4400-9457-e63b70e52cd5",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 1,
        "name": "JAVA语言进阶",
        "summary": "JAVA语言进阶11",
        "outline": "",
        "author": "开发者",
        "publishTime": 1499069333000,
        "status": 1,
        "coverImage": "5b9288c4-85b3-40a8-9ee1-8e7843ef2be1",
        "validStart": 1504137600000,
        "validEnd": 1535673600000,
        "frequency": 0,
        "coursewares": [{
            "name": "2015-01-06-12-57-08.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/70c3e8ff-4eb9-46ec-aa67-2e602a25de96",
            "fileType": 1,
            "resourceFiles": []
        }],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/5b9288c4-85b3-40a8-9ee1-8e7843ef2be1",
        "coursewareFileTypeMap": {
            "1": "2015-01-06-12-57-08.mp4"
        },
        "tags": [],
        "publisher": "狄倩"
    }, {
        "id": "f00bee29-3880-424a-9ac4-35e6ad40708f",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 1,
        "name": "汽车人的生存现状",
        "summary": "汽车人的生存现状1~5",
        "outline": "",
        "author": "擎天柱",
        "publishTime": 1499069497000,
        "status": 1,
        "coverImage": "ed9cde67-9a5c-48e2-9058-d3ff42513f67",
        "validStart": 1498780800000,
        "validEnd": 1501372800000,
        "frequency": 0,
        "coursewares": [{
            "name": "2015-01-06-15-58-05.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/2c970aef-bf51-45ab-ae76-44d6b5bd7c2d",
            "fileType": 1,
            "resourceFiles": []
        }],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/ed9cde67-9a5c-48e2-9058-d3ff42513f67",
        "coursewareFileTypeMap": {
            "1": "2015-01-06-15-58-05.mp4"
        },
        "tags": [],
        "publisher": "狄倩"
    }, {
        "id": "61e03e4c-3a1b-45c7-9220-2f20f332d98d",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 2,
        "name": "C语言探索",
        "summary": "C语言课堂",
        "outline": "C语言大纲123",
        "publishTime": 1499069677000,
        "status": 1,
        "coverImage": "98865cd9-3bcc-4f66-9659-dd49bcdea920",
        "frequency": 0,
        "coursewares": [{
            "name": "2015-01-06-12-50-45.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/2baee7f1-e68b-40a8-b904-55ee38dcaed9",
            "fileType": 1,
            "resourceFiles": []
        }, {
            "name": "2015-01-06-12-50-45.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/e2e636bc-eb7e-4bd3-ab0d-4a9dce1fabca",
            "fileType": 1,
            "resourceFiles": []
        }],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/98865cd9-3bcc-4f66-9659-dd49bcdea920",
        "coursewareFileTypeMap": {
            "1": "2015-01-06-12-50-45.mp4"
        },
        "tags": [],
        "publisher": "狄倩"
    }, {
        "id": "f5df50ea-5397-4321-9852-332a1a4268be",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 2,
        "name": "摄影的魅力",
        "summary": "摄影的魅力123",
        "outline": "摄影的魅力456",
        "publishTime": 1499070092000,
        "status": 1,
        "coverImage": "5830d613-3550-403e-b1d3-542ec3704d99",
        "frequency": 0,
        "coursewares": [{
            "name": "2015-01-06-12-57-08.mp4",
            "httpUrl": "http://10.60.32.178:8080/learn/api/resource/file/1/860d404f-0cbc-40fe-8f16-82d46a629949",
            "fileType": 1,
            "resourceFiles": []
        }],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/5830d613-3550-403e-b1d3-542ec3704d99",
        "coursewareFileTypeMap": {
            "1": "2015-01-06-12-57-08.mp4"
        },
        "tags": [],
        "publisher": "狄倩"
    }, {
        "id": "43641983-0af5-46eb-8e20-0e6e76b7d0ca",
        "category": "5f884ab9-5f9a-11e7-aa29-fa163ed5a835",
        "orgId": 1,
        "type": 2,
        "name": "摄影高级教程",
        "summary": "摄影高级教程介绍11",
        "outline": "大纲7662323",
        "publishTime": 1499070719000,
        "status": 1,
        "coverImage": "ae490ac5-1859-494b-a230-ff8ed089c15e",
        "frequency": 0,
        "coursewares": [],
        "coverImageUrl": "http://10.60.32.178:8080/learn/api/resource/file/2/ae490ac5-1859-494b-a230-ff8ed089c15e",
        "tags": [],
        "publisher": "狄倩"
    }]
}]

//mock组件






//测试用例
it('客户端保存用户信息时打开客户端', () => {

    // jest.mock('../src/redux/actions/home',()=>{
    //     AC_FetchRecommendResource:jest.fn(),
    //         AC_FetchBanner:jest.fn()
    //
    // });

    // jest.mock('../src/redux/actions/home', ()=>'AC_FetchRecommendResource');

    // AC_FetchBanner=jest.fn()
    // AC_FetchRecommendResource=jest.fn()


    const component=renderer.create(
        <Home banners={banners} recommendResources={recommendResources} fetchBanner={jest.fn()}
              fetchRecommendResource={jest.fn()}
        />
    )
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();



});