module.exports = {
    dependency: {
        assets: ['src/asserts/fonts', 'src/asserts/logo'],
    },
};
